# Delivery driver

*Deliver, take the code, hand in the cash.*

## Your private page

- The shop gives you a **link** and a **PIN** (sent separately). Open the link on your phone and type the PIN. You see only **your** orders. Do not share the link or the PIN; if the phone is lost, tell the shop for a new PIN.
- After five wrong PINs the link is locked for 30 minutes; the shop can unlock it with a new PIN.

## A delivery

- Each order shows the customer, phone (tap to call), address and map, the delivery time, **what to collect** and the goods.
- Hand the goods over. Ask the customer for his **4-digit delivery code** and type it under **Hand over**. The order is then complete. Never ask for the code before the goods are handed over, and never write it down.
- If the customer is not there, refuses, or the address is wrong: **do not complete**. Phone the shop; staff record the failed delivery.
- If the customer keeps only part of the goods: phone the shop; staff record it.
- Wrong code: ask the customer to read it again from his order page. After five wrong tries the code is blocked for 30 minutes: the shop sends a new one.

## Cash

- A cash order: collect exactly what the page says (**what to collect**). An order paid online has nothing to collect.
- **Cash I hold** at the top shows what you took and have not handed in. Hand it to the shop; staff record what you handed in. A difference needs a reason.

## Returns to collect

- A **Returns to collect** list shows customers' returns assigned to you. Collect the goods, ask for the customer's **return code**, tap **Collect the goods** and type it. The shop checks the goods and refunds the customer.

> **Need more?** Call the shop (its phone is on your page).
