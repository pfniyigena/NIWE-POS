# Accountant

*Keep the books right, close the period.*

## Daily and weekly

- **Customers > Collections** and **Purchases > Payables Aging**: chase and pay on time.
- Approve **Expenses** (Expenses > Expenses > tick, **Approve selected**); check **Overview** for bills overdue or due soon.
- Record **supplier payments** with the oldest-first suggestion.

## Month end

- Review the **Trial Balance**, **Income Statement**, **Balance Sheet**, **Cash Flow**; run the **Tax Report**.
- **Accounting > Controls > Bank reconciliation**: enter the statement date and balance, tick matching lines until the difference is zero.
- Post depreciation (**Assets > Run depreciation**) and any manual **journal entries** (debits = credits).
- **Close the books** up to the month end (admin).

## Online shop money (if the business has an online shop)

- Each provider (MTN, Airtel, card) has a **clearing account** (what it still owes) and a **payout account**. **Online Store > Online payments > Payouts**: record each payout with its fee; a balance that keeps growing or goes negative means a payment or payout is missing.
- Compare each clearing and wallet account with the provider's statement every month. Check that **Cash with Drivers** agrees with the *To hand in* total of Driver cash, and that **Suspense** is zero.
- **Customer Credit Payable**, **Gift Card Liability** and **Loyalty Points Liability** must agree with their customer lists.

## Rules to remember

- Do not edit posted entries; reverse or void the source document.
- Freight on a purchase goes in the receipt's **Landed cost**, not in a separate expense.
- Gift card money is owed (liability) until the card is spent.

## Payroll

- Run payroll monthly, **Approve and post**, pay by the bank file, record tax and social-security payments. Rates are a starting point: confirm with your accountant.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
