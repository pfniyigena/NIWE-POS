# Store keeper

*Know what you have and where it is.*

## Receiving

- **Purchases > Purchase orders**, open the order, **Record a receipt**: quantities now, batch/lot or serial numbers, **Landed cost**. Print the GRN.
- Goods land in the warehouse's **Receiving** location. Move them to a **Sales** location with a **Stock transfer**.

## Corrections

- **Stock adjustments > New**: product, quantity change (+/-), reason. It stays *logged* until an approver presses **Confirm**.
- **Stock counts**: **Start a stock count**, print the sheet, enter counted quantities, **Submit for approval**.

## Reorder

- **Inventory > Reorder** lists what is at or below its reorder level. **Create requisition** to turn it into a purchase request.

## If the business has an online shop

- The shop sells only from **Sales locations** outside the Main warehouse. Stock that arrives sits in *Receiving* until you move it to a Sales location. Expired batches are never sold.
- **Reorder** shows two more columns: **Online orders** (units held by orders nobody answered yet) and **Waiting customers** (people waiting for a product to be back).

## Moving stock

- **Stock transfers > New**: product, from and to locations, quantity. Between branches, the receiver presses **Receive** and records any shortage.

## Look it up

- Product page > **Stock movement history**. Reports: Stock On Hand & Valuation, Expiring Stock, Dead Stock.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
