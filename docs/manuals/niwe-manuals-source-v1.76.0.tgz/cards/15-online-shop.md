# Online shop staff

*Answer orders, keep the shop fresh, watch the money.*

## Every day

- **Online Store > Online orders**, tab **New**: **Accept** (holds the stock) or **Reject** (give a reason). A delivery order gets a **Driver**; then **Mark packed**, **Out for delivery** or **Ready for pick-up**. The customer receives a 4-digit **delivery code**.
- **Complete** by typing the code the customer reads out. Staff never see the code; **Send a new code to the customer** if it was lost. Print the **Delivery slip** (one order) or the **Run sheet** (a driver's day).
- **Delivery failed** (pick a reason) when nobody was home; the customer chooses a new time. **Keeps only part** when the customer takes some of the goods.
- **Refunds due**: **Refund through the provider**, or refund by hand (always for Airtel) and enter the reference with **I refunded it myself**.
- **Online payments**: look at *Under review* (money that needs a person; it is not in the books until you deal with it), *Refunds due* and *Stuck pending*.
- **Messages** (contact form) and **Waiting customers** (people to tell when a product is back): answer them.

## Money, every week

- **Driver cash**: type what each driver really handed in, write a reason for any difference, **Settle the selected**. It should agree with the account *Cash with Drivers*.
- **Online payments > Payouts**: record each provider payout (gross, provider fee, date, reference from the provider's statement).
- **Online Store > Sales reports**: a sale counts on the day the order was **completed**.

## When asked

- **Returns**: **Approve** (a driver collects the goods with a return code) or **Refuse**; when the goods are back press **Goods received: put back and refund** (tick the serial numbers that came back).
- **Reviews**: **Approve** or **Hide** the new written reviews; **Remove rating** for an unfair rating.

## Keep the shop fresh

- **Shop settings > Products on the shop**: titles, online prices, product page, and the ticks **Featured**, **Best seller**, **Offer**, **New**.
- **Front page**: announcement, banner pictures, colour, footer links. **Shop pages**: read and adapt the Terms, Privacy, Returns and Delivery pages.
- **Delivery areas** (fee, tax, days), **Delivery times**, **Drivers** (**Give a link** gives a private page and PIN).
- **Abandoned carts**, **Loyalty points**, **Coupons**, **Newsletter**, **Send a newsletter** (test to yourself first), **Advertising**.

## "It says Sold out"

- Under the product: *sellable stock − reserved − held by unanswered orders − buffer − share kept for the till = sellable now*. Lower the buffer, move stock to a Sales location, answer the orders in **New**, or look at expired batches.

> **Need more?** See *Online Store* (chapters 23 to 25) in the User Manual, or ask your administrator.
