# Administrator

*Set up, secure, back up.*

## First day

- Change the **admin password** and the JWT secret; set **Business details**, **System settings**, **Taxes**, **Payment methods**.
- **Settings > Modules**: copy the installation id, install the licence, activate only needed modules.

## People

- **Staff > Roles** for access areas (None / View / Manage). On each person: role, extra approval permissions, branch access, **PIN**.

## Every week

- Check the **backup** exists and download one off the server. Review the **Sign-in log** and **Audit Log**. Look at **Server logs** if anything failed.

## For an online shop

- Set `app.frontend-url` to the public https address. Switch each payment provider on with its own keys in the server's environment, never in a file that is copied around. Give each provider its **accounts** (Online Store > Online payments > Accounts by provider).
- Give each driver a **link and PIN** (Shop settings > Drivers). Add the web-server rule for link previews. Read and adapt the shop's Terms and Privacy pages.

## Before an upgrade

- **Backup now**, download it, then follow the release notes.

## Remember

- Module activation is permanent. Restoring a backup replaces everything and needs a restart.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
