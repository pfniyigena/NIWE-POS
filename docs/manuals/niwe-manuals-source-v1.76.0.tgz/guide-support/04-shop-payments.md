# The online shop, payments and deliveries

Money and customers are involved here, so be careful and write down what you see before you change anything.

## "The customer paid but the order did not arrive"

1. Open **Online Store > Online payments** and search the customer's phone or the amount. Look at the **status** and the flag.
2. **Pending**: the customer has not approved the prompt, or the provider's answer has not come yet. The shop asks the provider about every pending payment about once a minute; wait a few minutes. If it stays pending long after it should have closed it shows under *Stuck pending*. Ask the customer to look for the prompt on their phone; a payment not approved within the shop's limit expires and the customer can pay again from the order page.
3. **Paid** but no order in **New**: the order reaches the shop when the payment is confirmed; reload Online orders and look in **Awaiting payment** too.
4. **Under review**: the amount or currency differed from the order, or the order was paid twice. The money is with the provider, **not in the books** until a person deals with it. See the next section.
5. **Failed** or **Expired**: nothing was taken; the customer can try again.
6. The provider's own portal shows the truth about the money: check the payment there by the reference. If the provider says **paid** and the shop says **pending** for more than ten minutes, check that the **webhook address** is given to the provider, that the provider's keys are valid (the server log says when a call to the provider fails), and that `app.frontend-url` and https are right. Collect the order code and the provider's reference and send the developer a full report.

> **Warning:** Do not complete an order by hand to "make it work" while its payment is unclear. Settle what happened to the money first.

## A payment under review

Open it, read why. Typical cases:

- **Paid twice** for one order: refund the second payment through the provider (Airtel: from the Airtel Money account, by hand), or record the refund you made yourself with its reference; write what you did; press **Mark as dealt with**.
- **A different amount**: decide with the customer whether to refund the whole amount and let them order again, or refund the difference. Never edit the order's price to fit the payment.
- After you press **Mark as dealt with** nothing is posted automatically: the books receive a payment only through the normal order steps, and a refund you made is booked when you record it on the order. If money is still sitting unposted, tell the accountant and the developer.

## A refund

- Cancelled or rejected order, paid online: the order shows in **Refunds due**. **Refund through the provider** (MTN) or by hand (Airtel; any provider that cannot do it) and then **I refunded it myself** with the reference.
- *The provider did not confirm the refund*: check the provider's portal first. If it went through, record it by hand with the reference; **never repeat a refund**.
- A completed order: use **Returns**, not Online orders.
- Check afterwards that the provider's **clearing account** has gone down by the refund.

## "The provider's balance does not match its statement"

Each provider's clearing account (what it still owes the shop) should equal what it has collected since its last payout, minus refunds it made, minus its fees if it keeps them. When it does not:

1. List what the provider's statement shows for the period: collected payments, refunds, fees, payouts. List what the **Payouts** panel and the clearing account's ledger show.
2. **A payment in the statement and not in the ledger**: it is *Under review*, *Pending*, or an order that was paid before the accounts existed. Find it by the reference.
3. **A payout missing**: record it (gross, fee, date, reference). **A payout recorded twice or against the wrong provider**: the accountant corrects it with a reversing journal entry.
4. **A fee not recorded**: it is part of the payout record (gross minus fee reaches the bank).
5. **A balance on the old shared Mobile Money account**: payments from before the provider accounts existed. Clear it with a payout of the way *Mobile money (earlier payments)*.
6. **A refund by hand not recorded**: record it on the order.

A balance that keeps growing means payouts are not being recorded; a balance that goes negative means a payout was recorded twice or for the wrong provider.

## Driver cash does not match

*Cash with Drivers* in the ledger should equal the *To hand in* total of **Driver cash**. A difference means: an order was delivered before version 1.72 (its cash went to Cash and Bank); a settlement was posted twice or by hand; or a delivery order paid in cash was completed without the cash being recorded (the driver's customer tapped *I received my order*: that does not prove the money was collected). A settlement cannot be undone on its screen: the accountant corrects it with a journal entry. If a driver's total never matches, check the delivery fee product's tax (a tax added on top makes the cash recorded higher than what the customer paid).

## Deliveries and codes

| Symptom | Likely cause | First action |
|---|---|---|
| The customer has no delivery code | The message did not arrive, or the text company is not connected | The code is on his order page and in My orders; the order history says how each message went; staff press **Send a new code to the customer**. |
| The driver gets "wrong code" | Typed wrongly, or an old code after a new one was sent | Ask the customer to read the code again from his order page. Five wrong tries block it for 30 minutes: a new code unlocks it. |
| The driver's page says "please call the shop" | The completion was refused (stock, batch, another reason) | The order's history has the real reason; fix it (for example stock) and try again. |
| The driver cannot open his link | Link switched off or replaced, driver not active, five wrong PINs, wrong `app.frontend-url`, no https | **Show link** or **Give a link** again; make a **New PIN**; check the address. |
| An order stays *Out for delivery* | Nobody completed it | Complete it with the code, or record **Delivery failed**. |
| A customer cannot choose a delivery time | Windows are off, full, too close, closed day, beyond days ahead, or a pick-up order | Shop settings > Delivery times; **Change time** on the order lets staff pick any window. |
| After a failed visit the customer cannot rebook | Windows are off, or the order is not *Packed after a failed visit* | Staff use **Change time** and phone the customer. |
| A return pick-up cannot be completed | No driver assigned, wrong return code, five wrong tries, the order was picked up at the shop | Assign the driver; **New return code (send again)**. For a shop pick-up order the customer brings the goods back. |

## Stock and prices on the shop

| Symptom | Likely cause | First action |
|---|---|---|
| A product says *Sold out* but stock exists | Buffer, share kept for the till, units held by unanswered orders, expired batches, stock not in a Sales location | Read the line under the product in Shop settings > Products on the shop: it lists every figure (Administrator Manual, chapter 7). |
| A customer was sold something that is not there | Over-promised: an order was accepted with **Accept anyway** | Phone the customer; receive stock or cancel the order. |
| An online price is wrong | An online price was typed on the product, or a promotion applies, or the price list | The product row shows *Offer from Sales: price (name)*. **Apply now** recalculates; prices refresh every 2 minutes. |
| A product does not appear | Not added, **Shown** unticked, inactive, or a variant switched off | Products on the shop. |
| A link pasted in WhatsApp has no card | The nginx rule or `app.frontend-url` | `curl -A "facebookexternalhit/1.1" "https://<address>/shop?product=12"` must return a page with `og:title`. WhatsApp keeps old previews for a while: add `&v=2` to the link. |
