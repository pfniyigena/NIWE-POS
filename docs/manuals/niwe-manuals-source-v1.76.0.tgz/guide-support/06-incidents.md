# Incidents, communication and routines

## Handling a severity 1 incident

1. **Acknowledge** the customer within minutes: "We are on it; next update at <time>."
2. **Stabilise first**: if the service is down, bring it up; if money is at stake, stop the cause (switch the provider off in Shop settings, pause orders with **Pause orders for now**) before finding the reason.
3. **Collect facts** (chapter 2), not guesses. Take a backup before any change.
4. **Decide**: fix forward, or go back (put the previous version and the last good backup back).
5. **Update the customer** every hour, in plain words: what is known, what is being done, what they should do (for example "keep selling; sales are queued").
6. **After it is fixed**: confirm with the customer that it works, and check the books (Suspense zero, balances right).
7. **Write the post-incident note** within two days: what happened, the cause, how it was found, how it was fixed, how long it lasted, what was lost, and what will stop it happening again (a check, an alert, a change in the manual, a defect for the developer).

## Messages that help

- **Say what you know and what you do not know.** "Payments from MTN are accepted but orders are not showing; we are checking" is better than silence.
- **Give the customer something to do**: a workaround (cash only, pick-up only), who to call.
- **Never promise a time** you cannot keep. Promise the next update.
- Use the customer's language: French for Chad and many Rwandan users, English otherwise.

## Escalating to the developer

Send the full report of chapter 2, say which customer and which severity, say what you already tried, and keep one person as the contact so the developer is not asked the same question by three people. Ask for a **fix version** (with a migration if needed) or a **workaround**. When the fix is ready, it is tried on a **copy of the customer's data** before it goes live, and the customer's register is updated with the new version.

## Support routines for every customer

**Weekly** (a few minutes per customer): is the service up and the version recorded; did last night's backup arrive off the server; disk space; the error log; certificate and licence expiry dates (warn the customer 60 days before the licence ends).

**Monthly**: a short message to the owner with the version, the uptime, the number of problems and how they were solved; remind the accountant of the month-end routine (reconciliation, Suspense at zero, close the books, a named backup); ask whether staff changes need account changes.

**Quarterly**: a **restore drill**; review of staff accounts; applying the security updates of the server; a look at the release notes for a useful upgrade and a proposal of a window.

**Yearly**: the security checklist (Administrator Manual, chapter 13) and the secrets rotation (Installation guide, chapter 8); the licence renewal; a review of whether the modules and the number of users still match the business.

## Keeping the manuals honest

When a customer asks a question that the manuals answer badly, or a problem that the manuals do not list, add it to the *Troubleshooting* tables and, if the program should have prevented it, send it to the developer as a wish. The best support document is the one a customer's administrator can use alone.
