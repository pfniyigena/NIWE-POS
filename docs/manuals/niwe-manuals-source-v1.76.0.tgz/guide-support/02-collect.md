# Collect the facts first

A problem that arrives with the right facts is half solved. Ask for these before you start, and write them in the ticket.

## The standard information

1. **Who and where**: the customer, the person, their role, the device and browser.
2. **The version** of the program and the **installation id** (Settings > Modules shows the installation id).
3. **What they did**: the exact steps and the screen, from the menu.
4. **What they expected** and **what happened**: the words of the message, word for word (a screenshot is best).
5. **When**: the date and time, to the minute, and whether it happened once or every time.
6. **Since when**: after an upgrade, a settings change, a power cut, a new user?
7. **Who else** is affected (everybody, one till, one person)?
8. For an order or a payment: the **order code** (for example `9FMMY2MC`) or the invoice number, and the **provider's reference**.
9. For an error: the **request id** and the matching lines of `niwe-erp-error.log` (Settings > Server logs, or the file on the server).

## Quick facts you can read yourself

- **Is the service running?** `systemctl status niwe-<customer>`; `curl -I https://<address>/api/public/store/...` or just open the address.
- **The log**: `tail -n 200 /opt/niwe/<customer>/logs/niwe-erp-error.log`. Search the request id, the order code, the person's user name.
- **The audit log** (Settings > Audit Log): who did what, when: voids, returns, price overrides, stock adjustments, settlements, setting changes, with the person's name.
- **The sign-in log** (Settings): successful and failed sign-ins and from where.
- **The journal** (Accounting > Journal entries): for an order, search its code; every entry from an online order ends with the order number.
- **The order's history** (Online Store > Online orders > the order): every step with who and when, the code message result (e-mail and text), and the reason of a refused completion.
- **Text messages** (Online Store > Text messages): every text with its result.
- **Online payments** (Online Store > Online payments): every online payment with its status and flag.

## What to send the developer

A complete report holds: the standard information above, the **exact steps to repeat it**, the **log lines** around the time (with the request id), a **screenshot**, what you already tried, whether it is **repeatable on a copy of the data** (restore a backup into a spare database to try, never on live), and the severity. If it is about money, add the order code, the invoice number, the journal entries and the amounts you expected.
