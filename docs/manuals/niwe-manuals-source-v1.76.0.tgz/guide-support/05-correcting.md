# Correcting mistakes safely

NIWE ERP keeps an honest trail: most things are **voided, credited, returned or reversed**, not deleted, and every correction is in the audit log with the person's name. Use that.

## Which tool for which mistake

| Mistake | Tool | Notes |
|---|---|---|
| A draft document is wrong | Edit or delete it | Only a draft can be changed freely. |
| An issued invoice is wrong | **Void** it (or **cancel and credit** it if payments exist) and create it again | The stock and the books follow. |
| Goods came back | **Sale order return** (or **Process a return** at the till) | Takes the VAT and the cost back too. |
| A wrong stock quantity | **Stock adjustment** or a **stock count** | Always with a reason. |
| A wrong manual journal entry | A **reversing entry** | Posted entries are not edited. |
| A wrong amount handed in by a driver | A **journal entry** on Cash with Drivers, Cash and Bank and Cash Over / Short | A settlement cannot be undone on its screen. |
| A payout recorded twice or for the wrong provider | A **reversing journal entry** by the accountant | Keep the provider's reference in the memo. |
| A refund made by hand and not recorded | Record it on the order (**I refunded it myself** with the reference) | |
| A payment that is *Under review* | Deal with it, write what you did, **Mark as dealt with** | It is not in the books until then. |
| A wrong amount in a closed month | An **admin** reopens the books to a date (the reason is logged), the correction is made, the books are closed again | Or post the correction in the open period with a clear memo. |
| A customer's data to remove | The customer deletes their account in the portal; staff **Remove** a newsletter address or an abandoned cart | |

## What never to do

- **Never delete rows by SQL** on a live database to "tidy up": the books reference them.
- **Never edit a posted journal line** in the database.
- **Never change a licence or an installation id** by hand.
- **Never restore a backup over a live system** without taking a fresh backup of the current state first and telling everyone. A restore replaces the whole database: sales since the backup are lost.
- **Never turn on the `dev` profile** to bypass a licence or a permission.

## If a restore really is needed

1. Take a **fresh backup** of the current state (so you can go back).
2. Tell the customer what will be lost (everything entered since the backup chosen) and get their yes.
3. Restore (Settings > Backup & Data > Restore, or the database tools: Installation guide, chapter 7). The system is in maintenance mode while it runs.
4. **Restart** the application and check the data.
5. Help the business re-enter what was lost, from paper and from the tills' queues.

## When SQL is unavoidable

Sometimes a defect leaves data in a state no screen can fix. Then: the developer writes and reviews the statement; you take a **backup immediately before**; you run it in a transaction on a **copy first**; you run it on the live database with the customer's agreement; you check the result in the screens; and you write the statement and its result in the customer's notes. A fix that is needed twice becomes a migration or a screen.
