# How support works

## Who this guide is for

This guide is for the people who help a customer when something is wrong: the first-line support contact, the technician who looks after the server, and the developer who is called when it is a defect. It also helps a customer's administrator decide whether to fix a thing alone or to call. The Administrator Manual's *Troubleshooting* chapter holds the customer-level problems; this guide adds the method, the places to look, the safe ways to correct the books, and the shop and payment problems that come up in real life.

## Three levels

| Level | Who | What they do |
|---|---|---|
| **1. The customer's administrator** | The person who holds the Admin account | Resets passwords, checks roles and settings, reads the manuals, restarts a till's browser, looks at the screens listed in this guide. Solves most problems. |
| **2. NIWE support / technician** | The person who looks after the server | Reads the logs, checks the services, backups and the web server, applies upgrades, fixes configuration, helps with accounting questions, collects the facts for level 3. |
| **3. Developer** | The person who changes the program | Fixes defects and writes migrations. Receives a complete report from level 2, never "it does not work". |

## How urgent is it

| Severity | Meaning | Aim |
|---|---|---|
| **1 Stopped** | The system is down, nobody can sell, or money is being lost or taken wrongly (for example payments accepted and not recorded). | Start at once; update the customer every hour. |
| **2 Hurt** | A main function fails for some people (a till cannot print, a module will not open, e-mail fails), with a workaround. | The same day. |
| **3 Annoying** | A wrong label, a slow report, a question. | Within a few days. |
| **4 Wish** | A request for a change. | Collected for a later version. |

## The rules that keep customers safe

1. **Never change a customer's data by SQL** on a live database unless the developer has written the statement and you have a backup taken **just before**. Use the program's own screens: void, credit note, return, reversing journal entry.
2. **Never edit or delete a migration**, and never run an old jar against a database made by a newer one.
3. **Never ask for a password** on the phone or in a message. Ask the administrator to type it themselves, or reset it.
4. **Never copy a customer's data** (a backup, a screenshot with customers' names) to a place that is not private, and delete test copies when done.
5. **Write it down.** Every call gets a line in the customer's notes: what was reported, what was found, what was done, the version, and the result.
