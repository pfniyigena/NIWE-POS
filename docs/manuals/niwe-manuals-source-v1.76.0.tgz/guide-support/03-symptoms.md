# Symptoms and what to do

Each table gives the symptom, the likely cause and the first action. Customer-level problems are also in the Administrator Manual (chapter 14).

## The system will not start, or is slow

| Symptom | Likely cause | First action |
|---|---|---|
| The address does not answer at all | Server down, nginx stopped, certificate expired, DNS | Check the server, `systemctl status nginx`, the certificate date, the DNS record. |
| nginx answers *502 Bad Gateway* | The backend is not running or is on another port | `systemctl status niwe-<customer>`; read the end of the log; check the port in the settings and in the nginx file. |
| The service stops by itself right after start | A start-up error | Read the first ERROR line in the log: database password, *Migration checksum*, *Schema-validation*, *address in use*, *cannot write backups folder* (Installation guide, chapter 6). |
| Very slow everywhere | Disk full, memory, the database busy, a huge report | `df -h`, `free -m`, `top`; look at the log for long requests; check that backups are not running in the middle of the day. |
| After an upgrade: *a migration it does not know* | An older jar on a newer database | Deploy the newer jar. Never use the old jar on that database. |
| After a restore, the screens are wrong | A backup from a different version | Restore into the version that made it or newer. Restart the application after a restore. |

## Sign-in, users and licence

| Symptom | Likely cause | First action |
|---|---|---|
| Everybody is signed out at once | The service restarted, or the sign-in secret changed | Normal after an upgrade or after rotating `app.jwt.secret`. Sign in again. |
| One person cannot sign in | Wrong password, account inactive, locked after many tries | The administrator resets the password on the Staff record; check *Active*; look at the sign-in log. |
| *Forgot password* sends nothing | E-mail not set up, or the person has no e-mail on file | **Send test email**; the administrator sets a password by hand. |
| *PIN not recognized* | Wrong PIN, inactive person, or two people share it (not allowed) | Reset the PIN on the Staff list. |
| A module is missing or *not part of your licence* | Not in the licence, not activated, expired licence, or the role has no access | Settings > Modules: the state of each module; the expiry date; the person's role. |
| *The developer switch is on* | The server was started with the `dev` profile | Restart without the `dev` profile at once. |
| A restored backup says the licence is invalid | A new installation id (a new empty database) rather than a restore | A restore keeps the id. For a new database, ask NIWE for a licence for the new id. |

## Tills, devices and printing

| Symptom | Likely cause | First action |
|---|---|---|
| *Offline* at the till | The connection to the server dropped | Keep selling: sales queue and sync when it returns. Do not clear the browser; check the offline queue for *Failed* items afterwards. |
| The till refuses: wrong device | The register is bound to another PC | The administrator unbinds it, or binds it to this PC. |
| The thermal printer prints nothing | Browser, https, connection | Chrome or Edge on https or localhost; *Connect device*; *Print test page*; read the red line it prints. |
| Strange characters on receipts | Code page | *Plain ASCII* in the device settings. |
| A sale is refused for stock | Negative stock is off | Receive or adjust stock first. |

## Accounting and reports

| Symptom | Likely cause | First action |
|---|---|---|
| The trial balance does not balance | It cannot normally: every entry balances. A *Suspense* balance means a posting was out of balance and the difference was parked | Open Suspense in the ledger; find the entry; correct with a reversing entry; report the source type to the developer. |
| *Suspense* is not zero | As above | Same. It must be zero at every month-end. |
| *Cannot post: the books are closed* | A lock date is set | An admin can reopen to a date (the reason is logged) or the entry is dated after the lock. |
| A new account (Cash with Drivers, a provider account) is missing | The backfill after start-up has not run, or the chart is a custom one | Wait a minute after start and reload the chart; if still missing, tell the developer the version. |
| A report looks wrong | Filters, dates, the lock | Check the dates and filters; open the Trial Balance line for the entries behind a figure. |
| Online reports do not match the invoices | A sale counts on the day the order was **completed**, not ordered | Compare by completion date. A voided invoice shows 0. |

## E-mail and text messages

| Symptom | Likely cause | First action |
|---|---|---|
| No e-mail arrives (reset, newsletter, order updates) | SMTP not set up or wrong; the mail provider refuses; spam folder | **Send test email**; read the error; check the sending limit of the provider. A failed e-mail never blocks the work itself. |
| Links in e-mails open the wrong site | `app.frontend-url` is wrong | Set it to the public https address and restart. |
| No text messages | No provider chosen, daily limit, bad number | Online Store > Text messages shows each text and its result. With the built-in sender, codes stay *Waiting for an SMS company*. |
| A newsletter stays on *Sending* | Batches and the daily limit | See the Administrator Manual (chapters 7 and 14). |
