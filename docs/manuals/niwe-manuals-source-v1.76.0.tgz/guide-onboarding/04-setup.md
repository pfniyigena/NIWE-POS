# Stage 3 continued: the set-up workshop

Run this with the business administrator beside you, so that they learn where each setting lives.

## Per module

Go through the module settings of every module the customer uses (Administrator Manual, chapter 7): sales (discount limits, switches for promotions, gift cards and loyalty), POS (receipts, shifts, cash rules), inventory (negative stock, batch and expiry, cartons), expenses (approval limits), assets, and so on. Write down every choice in the register's notes so that the next person knows why.

## Tills and devices

For each till PC (Administrator Manual, chapter 8): bind the register to the PC where tills are in public areas; connect the thermal printer and press **Print test page**; test the cash drawer, the barcode scanner and the customer display. A direct thermal printing needs Chrome or Edge on **https** (or localhost). Print a test receipt and check the business name, tax number, VAT lines and the footer text.

## E-mail, alerts and reports

Set up e-mail and press **Send test email** (chapter 9). Choose the addresses for the **business alerts** (low stock, expiring quotations, credit limit warnings, unanswered shop orders) and the **scheduled reports** the owner asked for (for example the daily sales summary and the Online Store sales reports).

## Security before real data

Run the Administrator Manual's **Security checklist** (chapter 13): new admin password, no demo accounts, each person with their own login and PIN, approval permissions only where needed, https only, a nightly backup with a copy off the server, and the first **restore test**.

## A first test day

Before the training, the administrator and the implementer do a **dry run** with the real data: ring up a few sales of each kind at the till, take a payment, return an item, close a session and print the Z report; create an invoice and receive a purchase; open the Journal and the Trial Balance and check that the entries make sense. Fix the settings that did not behave as expected now, not on the first day of real trading.
