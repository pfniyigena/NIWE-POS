# Launching the online shop

The Online Store is a public shop that takes real orders and real money from strangers. Launch it only after the till and the books are working, and follow the order below. Each item has the person who does it and how you know it is done. It is also the go-live checklist for one business.

## The business decisions

- [ ] **Delivery or pick-up or both**, the **delivery areas** with their fees and tax, the minimum order and the free-delivery amount, the estimate in days for each area, and the delivery **time windows** if the business wants them.
- [ ] **Who delivers**: a list of drivers with phones. Each gets a private link and a 4-digit PIN, sent in two messages.
- [ ] **Payment providers**: MTN Mobile Money, Airtel Money, card. The **business registers** with each provider in its own name (the provider asks for company documents); the keys belong to the business. This takes days or weeks: start it in stage 1.
- [ ] **Accounts**: for each provider, whether the business has a separate wallet or bank account. Agree with the accountant the provider's **clearing account** and **payout account**.
- [ ] **Terms and Conditions**, **Privacy Policy**, **Returns and Refunds**, **Delivery and Shipping**: read the starter texts in Online Store > Shop pages, adapt them to the business and the country, and have someone responsible check them.
- [ ] **Returns window** (days), loyalty points rules, coupons, whether newsletters and abandoned-cart reminders are wanted (they need e-mail).

## Technical set-up (the implementer)

- [ ] The site is on **https** with the customer's domain and `app.frontend-url` is that address.
- [ ] The **nginx rule** for link previews, the sitemap and robots.txt is in place (Installation guide, chapter 5) and the test with `curl -A "facebookexternalhit/1.1"` returns a small page.
- [ ] **E-mail** is working (Send test email) and the shop's address for new-order e-mails is set.
- [ ] A **text message provider** is chosen, or the business knows that codes by text stay in the text list until one is connected (codes also go by e-mail and show on the order page).
- [ ] **Payment provider keys** are in the server's environment or private settings file, never in a repository; the provider shows as *available* in Shop settings > Online payments; the webhook address from the screen is given to the provider.
- [ ] The business's own **logos** of the providers are in `frontend/src/assets/payment/` before the frontend was built (otherwise the buttons show names).

## Shop set-up (the shop manager, with the implementer)

- [ ] **Products on the shop**: add the products, titles, online prices (or the price list), pictures, descriptions, specifications, and the four row ticks; for products with sizes or colours, put the template on the shop.
- [ ] **Stock the shop sells from**, the buffer, the share kept for the till and the hours after which unanswered orders are released. Check the line under a few products and agree it with a real count.
- [ ] **Delivery service product** (a service product, tax inclusive or none), delivery areas, delivery times, drivers and their links.
- [ ] **Front page**: announcement, banner pictures, colour, about, opening hours, contact and WhatsApp numbers, footer and social links.
- [ ] **Branch the shop sells for** (only with more than one branch).
- [ ] **Online Store > Online payments > Accounts by provider**: every provider has its clearing account and payout account chosen.
- [ ] Tax rates on products and on the delivery fee; the accounting **lock date** set to the day before the opening date.
- [ ] Users and roles: the shop staff have the **Operations** area; only the owner and the accountant manage Accounting and lock periods; drivers use their private page only.

## Test with real money (small amounts, one at a time)

Do each with a small real order, then read the journal entries (Accounting > Journal; search for the order code).

- [ ] **MTN payment**, delivered: the payment debits MTN's clearing account and credits Online Customer Deposits; delivery releases the deposit.
- [ ] **Airtel payment**, delivered: the same, on the Airtel accounts.
- [ ] **Card payment**, delivered (when card is used).
- [ ] A **paid order cancelled** and refunded through the provider (Airtel: by hand with the reference): the provider's clearing account returns to zero.
- [ ] A **delivered order, part returned** and refunded: the VAT and the cost are reversed and the goods are back in stock.
- [ ] A **cash-on-delivery** order: the driver's cash shows under *Cash with Drivers* until the hand-in; the hand-in clears it.
- [ ] An order with a **coupon** and one with **loyalty points**: *Sales Discounts Given* and *Loyalty Points Liability* show the amounts.
- [ ] A **failed delivery** and a **new delivery time** chosen by the customer; a **partial delivery**.
- [ ] **One payout** from each provider recorded under Online Store > Online payments > Payouts with its fee; compare the amounts with the provider's own statement.
- [ ] A **message** sent from the contact form is answered; a **back-in-stock** request is notified.
- [ ] Open the shop on a phone: the first page, a product page, the cart, the checkout, the order page. Install it as an app on one phone.

## Opening the shop

- [ ] Tick **Shop is open to the public** and save. Announce it to a few friendly customers first.
- [ ] Watch **Online orders** (New), **Online payments** (Under review, Refunds due, Stuck pending) and **Messages** closely for the first week, several times a day.
- [ ] After a week, review: how fast are orders answered, are deliveries completed with the code, do the clearing balances look right, are returns and refunds handled.

## Routines after the launch

**Daily** (owner or cashier): count the till and record the difference; compare **Cash with Drivers** with the *To hand in* total of Driver cash; look at Online payments for payments *Under review* and *Refunds due*.

**Weekly** (one named person): record every provider payout received, with its fee. Each provider's balance should be about what it has collected since its last payout; a balance that keeps growing or goes negative means a payout or a payment is missing. Look for orders stuck in one status, failed deliveries and returns waiting.

**Monthly** (accountant): the bank, MTN, Airtel and card statements agree with their accounts; the trial balance balances; VAT payable agrees with the tax return; receivables, payables and inventory (against a count of a few products) are right; Customer Credit Payable, Gift Card Liability and Loyalty Points Liability agree with their lists; review Cash Over / Short, Payment Provider Fees and **Suspense** (it must be zero). Then lock the month and take a backup named after it.

**Quarterly**: a restore test; review user accounts and remove people who left; update the software.

## Limits to tell the owner

- A payment under review is not in the books until staff deal with it.
- Orders paid before version 1.71.0 have no deposit; orders delivered before 1.72.0 settle driver cash with the difference only; returns before 1.70.0 keep their old figure; loyalty points earned before 1.73.0 are not in the liability. These matter only to a business upgrading an existing shop.
- Real provider payments have not been tested by NIWE with the customer's own keys: step 4 is that test.

## Who does what

Fill in the names: the owner, the accountant, the person who records payouts, the person who restores backups, and the NIWE contact to call when something fails.
