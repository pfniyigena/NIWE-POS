# The onboarding path

## Who this guide is for

This guide is for the person who brings **a new business onto NIWE ERP**: a NIWE implementer, a partner, or the customer's own project lead. It follows the customer from the first conversation to the end of the first month-end close. The server work is in the **Installation and deployment guide**; day-to-day screens are in the **User Manual**; settings are in the **Administrator Manual**. Here you will find the order of the work, the questions to ask, the data to prepare, how to train, how to launch the online shop and how to hand over.

A business that follows these steps in order, and ticks each box, starts with books it can trust. A business that skips the opening balances or the training starts with a mess it will spend months cleaning.

## The path in five stages

| Stage | Typical time | What happens | Result |
|---|---|---|---|
| **1. Discovery** | 1 to 3 days | Understand the business; agree the modules, the chart of accounts, the users and the date to start (chapter 2). | A signed list of what will be installed and used. |
| **2. Install** | 1 day | The server and the program are installed for this customer and the licence is loaded (Installation guide). | A running, empty system at the customer's own address. |
| **3. Set up and load** | 1 to 2 weeks | Business details, taxes, accounts, roles, products, customers, suppliers, opening balances (chapters 3 and 4). | A system that matches the business on the start date. |
| **4. Train and rehearse** | 1 week | Each role is trained on its own tasks; the team runs a full day of "pretend" work (chapter 5). | People who can do their job without help. |
| **5. Go live and look after** | Day 0 to the first month-end | Real work starts; daily support; first routines; first close (chapters 7 and 8). | A signed hand-over. |

An online shop adds a sixth, parallel stage: the **shop launch** (chapter 6), which should only start once the first five stages are finished for the till and the books.

## Who does what

Name these people on the first day and write them in the customer register:

- **The owner or sponsor**: decides, signs, and is the person to call when something is stuck.
- **The business administrator**: holds the Admin account, creates users, does the daily checks. This person reads the Administrator Manual.
- **The accountant**: owns the chart of accounts, the opening balances and the month-end close.
- **A champion for each module** (cashier lead, store keeper, HR officer, shop manager): learns first and helps the others.
- **The NIWE implementer** and **the NIWE support contact**.

> **Tip:** Choose a **start date at the beginning of a month** (or of a financial year). Opening balances, stock counts and the first close are much simpler when the old system and the new one meet on a clean boundary.

## What the customer must provide

Ask for these early; most delays come from waiting for one of them:

- the business's legal name, address, tax number and logo;
- a **domain name** (or permission to use one of NIWE's) and who manages its DNS;
- an **e-mail account** the system can send from (SMTP details) and addresses for the owner's alerts;
- the list of **modules** wanted, the **branches**, and the **people** who will use the system with their e-mail addresses and roles;
- **products, customers and suppliers** in a spreadsheet (chapter 3), and the **opening figures** at the start date;
- for an online shop: pictures and descriptions, delivery areas and fees, the **payment providers** and accounts (chapter 6), and the shop's terms.
