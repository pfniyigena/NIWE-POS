# Stage 3: preparing and loading the data

The quality of the data decides the quality of the first month. Prepare it in spreadsheets **before** the training, check it with the program's *Check file* (which saves nothing), and load it only when the result is what you want.

## Order of work

1. **Settings first.** Business details, system settings (currency, date format, language, discount mode), taxes, payment methods, branches and warehouses, then the **chart of accounts** and the accounting controls (Administrator Manual, chapters 5 and 6). Choose the chart country carefully: it is locked after the first screen.
2. **Roles and staff** (Administrator Manual, chapter 4), with each person's e-mail address.
3. **Categories and brands**, then **products** (with barcodes, cost and sale prices, taxes, units, reorder levels), then **customers** and **suppliers**.
4. **Opening stock**, **customer balances** and **supplier balances**, then **ledger opening balances** for the rest.

## Importing

**Settings > Backup & Data > Bulk import** (also inside some modules for employees, law clients, properties). For each importer: **Download template**, fill it keeping the header row, choose the file and press **Check file**; read how many rows can be imported and the **list of rows that will be skipped, with the reason**; correct the file and check again until it is clean; then press **Import**. A bad row is skipped and listed; the rest still imports. Split big files (module imports read the first sheet only, up to 2,000 rows).

Rules of thumb:

- One product, one barcode, one unit. Decide the **naming rules** (capitals, brand first or last) before importing, so the catalogue is consistent.
- Check **tax** on every product: a wrong tax on the first import is a wrong tax on every sale.
- Customer and supplier **opening balances** become real `OB-` invoices and bills that age and are collected and paid like any other. Load them one line per open document, not one total.

## Opening balances: the books must start from the truth

Choose the **opening date** (for example the first of a month) and have the accountant approve each figure:

- [ ] **Cash and Bank**: the counted cash and each bank balance on that date.
- [ ] **Mobile money and card**: what each provider owes the business at that date (the clearing accounts) and the balance of each wallet or bank account that receives payouts.
- [ ] **Stock**: a **stock count** of every product (quantity and cost), so that Inventory agrees with the shelf. Count on the opening date or adjust back to it.
- [ ] **Customers who owe and suppliers owed**: one document per open invoice or bill.
- [ ] **Loyalty points** customers already hold, **gift cards** and **store credit** already sold: these are liabilities.
- [ ] **Fixed assets, loans and the owner's equity.**
- [ ] **Check:** the trial balance balances and **Suspense is zero**.
- [ ] Set the **accounting lock date** to the day before the opening date, so nobody can post into closed days.

> **Warning:** Do not start trading on the new system with a stock list that nobody counted. A negative or invented stock quantity is the most common reason owners stop trusting a new system.
