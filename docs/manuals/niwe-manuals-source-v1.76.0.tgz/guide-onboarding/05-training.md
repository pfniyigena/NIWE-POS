# Stage 4: training and rehearsal

## Train by role, not by screen

People remember what they do every day. Give each role a **short session on their own tasks**, with the real system and real (but test) data, and the matching **Quick Start card** on paper beside them. Keep sessions to 60 to 90 minutes and let people click.

| Role | Teach (User Manual chapters) | Card |
|---|---|---|
| Cashier | POS: sell, take payment, returns, cash, the offline queue, end of shift (chapter 2) | Cashier |
| Shift supervisor | Open and close sessions, approvals with a manager PIN, X and Z reports | Supervisor |
| Sales staff | Quotations, sale orders, invoices, customers, price lists (chapters 3 and 4) | Sales |
| Store keeper | Receiving, stock counts, transfers, adjustments, reorder (chapters 5 and 6) | Storekeeper |
| Purchasing | Requisitions, purchase orders, supplier bills (chapter 5) | Purchasing |
| Accountant | Chart, journal entries, controls, bank reconciliation, reports, expenses (chapters 10 and 11) | Accountant |
| Restaurant, hotel, front desk, HR, booking, helpdesk | Their module chapters | Their card |
| Online shop staff and drivers | Online Store chapters 23 to 25 | Online shop staff |
| Administrator | The Administrator Manual: users, modules, backup, upgrades, logs, troubleshooting | Administrator |

## The three habits to teach first

1. **Never share a login or PIN.** Everything is recorded under the person's name.
2. **Do not delete: void, credit or return.** The books stay honest and the audit log keeps the trail.
3. **Count the till and record the difference.** At the end of each shift, every day.

## The rehearsal day

One full "pretend" day, a few days before go-live, with everybody at their post and the implementer walking around:

- tills open with a float, sell all day with test products, take every kind of payment the business uses, make returns and voids;
- the store keeper receives a purchase and does a stock count;
- the accountant looks at the journal and the trial balance at the end, and closes a test session;
- the administrator restores a backup into the spare database (the restore test) and reads the log;
- for the shop: a test customer places orders, staff answer them, and a driver (or a colleague) completes one by code.

Write down every question that came up; the answers become the customer's own cheat sheet and, if the manuals are unclear, feedback to NIWE.

## After training: the cheat sheet

Give the customer a one-page sheet with: the address of the system, who the administrator is, who to call at NIWE and in what hours, how to reset a password, what to do when the connection drops (keep selling; do not clear the browser while the offline queue has sales), and where to find the manuals and the wiki.
