# Stage 5: go-live and the first month

## The week before

- [ ] Final **backup** of the empty (or loaded) system, copied off the server, and a **restore test** done.
- [ ] Every user has signed in once and changed their password; every till PC has printed a test receipt.
- [ ] The **opening balances** are loaded, checked by the accountant and the lock date is set.
- [ ] The cheat sheet is printed and handed out; the support contacts and hours are agreed.
- [ ] A **go / no-go meeting** with the owner and the accountant: if a box above is not ticked, say why and decide.

## Day 0

- Be there (or on the phone) from the opening of the business. Start the day with the **opening of the till sessions** with the float.
- Keep a list of every question and every small problem; fix settings in the evening, not in the middle of a sale.
- At the end of the day: count the tills, close the sessions, print the **Z reports**, check the daily sales against the cash and the trial balance, and **back up**.

## The first two weeks

- **Daily check-in** of 15 minutes with the administrator: what went wrong, what was slow, who needs help.
- Watch the **dashboard's "Needs your attention"** list and the audit log for voids, returns, price overrides and stock adjustments: they show whether the habits taught in training are being followed.
- Check **stock** against a few products on the shelf every day, then every week.
- Fix the **naming and data mistakes** found in the first days (a wrong tax, a duplicate customer) with the right tools: edit the record, or void and redo; never delete.

## The first month-end

With the accountant, once the month is finished:

1. All sales sessions closed, all invoices issued, supplier bills entered, expenses approved.
2. Bank and mobile money **reconciliation** (Accounting > Controls).
3. Trial balance reviewed; **Suspense** is zero; VAT report agreed with the tax return.
4. Stock valuation against a count of key products.
5. **Close the books** up to the month-end date (an admin does this; the reason is logged), then take a **backup named with the month** and copy it off the server.
6. Look at the month's reports and send the owner the figures.

## Hand-over and sign-off

At the end of the first month, meet the owner and sign a one-page hand-over:

- [ ] The system runs on the agreed version; the licence number and expiry are recorded.
- [ ] Backups run nightly, a copy leaves the server, and a **restore test** was done within the last quarter.
- [ ] Each person has their own login; leavers are removed.
- [ ] The administrator knows how to reset a password, restore a backup, read the log and contact support.
- [ ] The first month-end was closed with a trial balance that balances and Suspense at zero.
- [ ] The customer knows the **upgrade routine** and has agreed a window for the first upgrade (see the *Release and upgrade notes for customers*).
- [ ] Open points are listed with an owner and a date.

After sign-off the customer moves to normal support (see the *Support and troubleshooting guide*).
