# Stage 1: discovery

A one-hour conversation with the owner and the accountant, and a short walk around the business. Take the answers into the customer register and into a one-page **scope** the owner signs.

## Questions to ask

**The business**

- What does the business sell or do? Which of these apply: shop with tills, restaurant, hotel, manufacturing, services with work orders, bookings, subscriptions, instalment sales, helpdesk, law firm, real estate, property management, an online shop?
- How many **branches**, **warehouses** and **tills**? How many people will have a login?
- Which **country** and which **chart of accounts** (Rwanda or Chad; this also sets the currency, RWF or XAF, and the starting language)? Does the accountant have a chart they must keep?
- Which **taxes** (VAT rate, exempt goods)? Are prices shown with tax included?
- Which **payment methods** are used: cash, card, MTN Mobile Money, Airtel Money, bank transfer, credit to customers, gift cards, loyalty points?
- How are **suppliers** paid and **customers** invoiced today? Is there credit? What are the credit limits?
- Who **approves** discounts, voids, large expenses?
- What **reports** does the owner want every day, week and month? Should some be e-mailed on a schedule?
- Which **devices**: PCs for tills, thermal printers, cash drawers, barcode scanners, customer displays?
- What exists today (another system, spreadsheets, paper) and what data can come from it?

**The online shop** (when wanted)

- Delivery, pick-up or both? Which **areas** and fees? Who delivers (own drivers)? Is cash on delivery accepted?
- Which **online payment providers**: MTN Mobile Money, Airtel Money, card? Who in the business can **register** them (it must be the business, in its own name)? Is there a separate wallet or bank account for each?
- Who answers orders, how fast, and from which screen? Who packs and who hands over?
- What are the shop's **Terms**, **returns policy** and **privacy** rules? (The program supplies starter texts, not legal advice.)
- Pictures and descriptions for how many products? Is there a brand colour and logo?

## The scope sheet

Write down, and have the owner sign: the modules; the branches, warehouses and tills; the number of users by role; the chart and currency; the languages; the payment methods and providers; the data to be loaded; the start date; the dates of training and go-live; the shop's launch date if any; what is **not** included. Everything not on the sheet is a later project.

## Licence

Send NIWE the list of modules. The licence is issued for the installation id shown on **Settings > Modules** after the server is installed (Installation guide, chapter 6). It is checked without internet. Note the **expiry date** in the register and set a reminder 60 days before; the administrator sees a warning only in the last 30 days.
