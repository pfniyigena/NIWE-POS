# Running it: backups, upgrades and monitoring

## Backups: three layers

1. **The program's nightly backup.** A full database backup runs every night (2 a.m. server time unless changed by `app.backup.cron`) into the `backups` folder next to the jar. Staff can also press **Backup now** in Settings > Backup & Data. These files include the migration history, so a restore brings data and structure back together.
2. **A server-level copy off the machine.** The nightly files are on the same server, so if the server is lost the backups are lost with it. Copy the `backups` folder to another machine or cloud storage every day (for example `rclone` or `rsync` in a cron job), and keep the copies: **daily for 30 days, one a week for three months, one a month for a year**. Encrypt the copy if it leaves the customer's country or your control, because a backup holds customers' names, phone numbers and addresses.
3. **Files outside the database.** If the customer uses a storage folder for uploaded documents, include it in the same copy. Banner and product pictures are in the database and so in the backup.

> **Warning:** Restoring a backup made by a **newer** version into an **older** version fails ("a migration it does not know"). Restore into the version that made it, or a newer one.

**Restore drill.** Every quarter, and once at installation: restore the latest copy into a spare database, start a spare backend against it, and check that you can sign in and that today's sales are there. Write the date in the register.

**Restoring in an emergency.** In the program: Settings > Backup & Data > **Restore** (or upload a file). It puts the whole system in maintenance mode while it runs, and you restart the application when it finishes. If the program itself will not start, restore with the database tools: stop the service, drop and recreate the empty database (chapter 3), `pg_restore` the dump, start the service of the same version as the dump.

## Upgrading a customer

The same routine for every customer, whether the gap is one version or twenty:

1. **Read the release notes** of every version between the customer's version and the target, and the **one-time actions** in the *Release and upgrade notes for customers* (a new setting, a new nginx rule, a new key, a check of the chart of accounts).
2. **Announce** a short window to the customer.
3. **Backup**: press Backup now, then copy the file off the server. Note the current version and keep the **old jar**.
4. For a customer far behind, **try the upgrade first on a copy**: restore the backup into a spare database and start the new jar against it. Watch the migrations run.
5. **Stop** the service: `sudo systemctl stop niwe-acme`.
6. **Replace** the jar (`cp` the new one over `/opt/niwe/acme/pos-app.jar`, keeping the old one as `pos-app.jar.prev-1.75.0`) and the frontend folder (replace the files in `/var/www/niwe/acme`).
7. Apply the **one-time actions** (settings in `config/application.properties`, nginx rules, then `nginx -t && systemctl reload nginx`).
8. **Start** the service and watch the log: every new migration applied, then **Started PosApplication**.
9. **Check**: sign in, Settings > Modules (licence and modules), open a few screens, make a test sale; after a few seconds check **Accounting > Chart of accounts** for new accounts when the release notes say so.
10. Write the new version and the date in the customer register.

**Going back.** If the upgrade fails *before* the migrations ran, put the old jar and frontend back and start. If migrations ran, the database is already newer: **restore the backup** you took in step 3 into an empty database (the program cannot undo a migration), put the old jar and frontend back and start. Tell the developer the exact error from the log.

Never edit or delete a migration, never run SQL by hand on a customer's database without a backup, and never upgrade on a Friday afternoon.

## Monitoring

You do not need much to notice trouble early:

- **Is it up?** An uptime check on `https://erp.acme.com/` (a free monitor is enough) that e-mails you.
- **Disk space** on the data disk and the backups disk, with an alert at 80%.
- **The logs**: `logs/niwe-erp-error.log` holds errors, `logs/niwe-erp.log` everything, `logs/niwe-access.log` the requests. Staff can read the server log in Settings > Server logs. Look at the error log after every upgrade and once a week.
- **Backups arrived**: a daily check (or an automatic one) that last night's file exists off the server and is not empty.
- **Licence expiry**: the administrator sees a warning in the last 30 days; you should know the date from the register too.
- **Certificate expiry**: certbot renews by itself; check `systemctl list-timers` shows the renewal timer.

## Moving a customer to another server

Take a backup; install the same version on the new server as in chapters 2 to 5 (the **same installation id comes with the database**, so the licence keeps working); restore the backup into the new empty database; copy the settings file (change addresses only if they changed); point the domain to the new server; start. Keep the old server unchanged until the customer has worked a day on the new one.
