# The customer register and the security routine

## The customer register

Keep one table (a spreadsheet kept in a shared place that only the team can reach) with a line for each customer. It is the first thing you open when anything happens. **It does not hold passwords or keys**: those are in the password manager.

| Column | Example |
|---|---|
| Customer code, name, country | `acme`, Acme Ltd, Rwanda |
| Contact person for IT and for the business | names, phones, e-mails |
| Server, address and domain | server-3, erp.acme.com |
| Backend port, folder, database name | 9101, /opt/niwe/acme, niwe_acme |
| Version running, date installed or upgraded | 1.76.0, 2026-11-24 |
| Installation id, licence number and expiry, modules | ..., LIC-0007, 2027-11-30, Sales, Purchases, Accounting, POS, Online Store |
| Chart (Rwanda or Chad), currency, language | Rwanda, RWF, English |
| Payment providers on, and who registered each | MTN MoMo (Acme Ltd), Airtel Money (Acme Ltd) |
| Backups: where copies go, retention, date of the last restore test | bucket-acme, 30/12/12, 2026-11-24 |
| Support agreement and hours | |

## Secrets

- **One password manager** for the team, with a folder for each customer: database password, JWT secret, e-mail account, provider keys, the server login.
- **Rotate** the secrets of a customer when a person who knew them leaves, when a secret was ever pasted in a chat, e-mail or repository, and once a year. Rotating the JWT secret signs everyone out (harmless). Rotating the database password means changing it in PostgreSQL and in `config/application.properties`, then restarting.
- A payment provider key that was ever committed or sent unprotected is **burnt**: ask the provider for a new one and revoke the old.
- The **licence signing key** is NIWE's own: it never goes to a customer's machine and is backed up in two places.

## The yearly security routine

For every customer, once a year (and after any incident): the checklist of the Administrator Manual (chapter 13); updates of the operating system, Java, PostgreSQL and nginx; a review of the staff list and removal of leavers; a look at the sign-in log and the audit log; a restore drill; a check that the database and backend ports are not reachable from outside (`nmap` from another machine); and a check that the demo account and the `dev` profile are not in use.

## Privacy

A customer's installation holds personal data: staff, customers, and for an Online Store the names, phone numbers, addresses and e-mail addresses of shoppers, newsletter subscribers and abandoned-cart visitors. Tell the customer that the **data-protection rules of their country** apply to them as the owner of the data, that the shop pages (Privacy Policy, Terms) must be adapted to their business and checked, that backups must be kept private, and that a shopper's account can be deleted from the portal and a subscriber removed from the Newsletter screen on request.

## Known gaps to keep in mind

- The jar's built-in default for `app.jwt.secret` is public. **Always** set a value of your own in the customer's settings.
- Real MTN Mobile Money, Airtel Money and card payments have been tested only against imitations. A customer's first live provider must be tested with small real payments before the shop opens.
- The text message provider is a placeholder until a real company is connected; codes by text stay in the text list until then (the e-mail still goes).
