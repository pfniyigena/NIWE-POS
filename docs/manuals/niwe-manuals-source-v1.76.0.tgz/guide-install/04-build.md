# Building the program

You build **once for each version**, not once for each customer. The same jar and the same frontend folder go to every customer.

## What you need on the build machine

Java 21 and Maven for the backend; Node.js (the version the project uses) and npm for the frontend; the project's source at the tag of the version you are building.

## Backend

```bash
cd backend
mvn clean verify          # compiles, runs the tests, makes target/pos-app-<version>.jar
```

The result is `backend/target/pos-app-<version>.jar` (for example `pos-app-1.76.0.jar`). It contains the program and its migrations. Check that the version number in the file name is the one you meant to build. Keep the jar: the same file goes to every customer, and the old jar is your way back (chapter 7).

> **Warning:** Do not start a customer's server with the `dev` profile. It turns on demo data, a known admin password and the switch that treats every module as licensed. Customer servers use no profile, or the customer's own private settings file.

## Frontend

```bash
cd frontend
npm ci
npx ng build --configuration production
```

The result is the folder `frontend/dist/pos-frontend/browser/` (the folder that contains `index.html`). Pack it for shipping: `tar -czf niwe-1.76.0-frontend.tgz -C dist/pos-frontend/browser .`. The production build asks for the API at the **relative address `/api`**, so it works behind any domain and any certificate with no change.

- Do **not** use the `niweSoft`, `accounting` or `store` build configurations for a customer: they are NIWE's own sites and may point to NIWE's own addresses.
- The files carry a hash in their names, so a browser fetches new files after each release; the page `index.html` itself is always asked from the network first.
- **Payment logos.** If the customer uses MTN Mobile Money or Airtel Money, put the official logo files at `frontend/src/assets/payment/mtn_momo.png` and `airtel_money.png` **before** building (the logos are trademarks and are not shipped). Without them the buttons show the provider's name, which works.

## What to keep

For each version keep: the jar, the zipped frontend folder, the release notes, and the output of the build (so you can show it was clean). Name them with the version, for example `niwe-1.76.0-backend.jar` and `niwe-1.76.0-frontend.tgz`, in one place that everybody who deploys can reach. The customer servers receive these files; they do not build.

## Before you ship a version to customers

1. The build is clean and the tests pass.
2. The version was tried on a **copy of a real customer's database** (a restored backup): the migrations ran, you could sign in, and the main screens opened.
3. The release notes list every **one-time action** (a new setting, a new web server rule, a new key) and say which versions they apply to.
4. The **Release and upgrade notes for customers** has a new row for the version.
