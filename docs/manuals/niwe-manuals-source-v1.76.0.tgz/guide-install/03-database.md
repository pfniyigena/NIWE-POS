# The customer's database

One database for each customer, with its own user. Run this as the PostgreSQL administrator (`sudo -u postgres psql`), replacing `acme` with the customer code and the password with a long random one made on the spot (for example `openssl rand -base64 24`):

```sql
CREATE ROLE niwe_acme LOGIN PASSWORD 'PUT-A-LONG-RANDOM-PASSWORD-HERE';
CREATE DATABASE niwe_acme OWNER niwe_acme ENCODING 'UTF8';
```

Notes:

- The database must be **empty**. On the first start the program creates every table by itself (Flyway: migration V1 is the baseline, V2 the licence tables, then every later migration). This takes about a minute. Never create tables by hand.
- The user owns the database and needs no other rights. Do **not** give the application the PostgreSQL superuser.
- Write the password in the customer's **private settings file** (chapter 5) or in the service's environment, and in your password manager. It must **not** be in a repository, an e-mail or a chat.
- PostgreSQL listens on `localhost` only. If a managed database is used, allow only the application server's address.

## Checks

- `psql -h localhost -U niwe_acme niwe_acme -c "select 1"` works.
- After the first start of the backend, `\dt` lists hundreds of tables and `select count(*) from flyway_schema_history;` shows the applied migrations. The newest migration of the version being installed must be the last row, with `success` true.

## Backups at the database level

The program takes **its own nightly backup** (a `pg_dump` into the `backups` folder next to the jar; see chapter 7). That is a good first line. For a customer that matters, also make a **server-level** backup: a cron job that runs `pg_dump -Fc` to another disk and copies it off the machine. Both are described in chapter 7. A backup that has never been restored is not a backup: restore one into a spare database during the installation (chapter 6, step 12).
