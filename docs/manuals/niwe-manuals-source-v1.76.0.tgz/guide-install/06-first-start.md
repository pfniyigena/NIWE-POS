# First start and acceptance

After chapter 5 the program is running. These steps turn a running program into a customer's installation. Do them in this order and tick each one in the customer register.

## The checklist

1. **Sign in** as `admin` over https and **change the password** (My profile). Remove or deactivate any demo account if one exists (there should be none with `app.seed-demo-data=false`).
2. **Settings > Modules**: copy the **installation id** and send it to NIWE with the list of modules the customer bought. NIWE issues a `.niwelic` licence file signed for this id; **upload** it. The message *License installed* appears. A licence for another installation will not work, and an installation restored from a backup keeps its id.
3. **Activate** the modules the customer needs. Activation is **permanent**, so activate only what the business will use. Only the core modules (Sales, Purchases, Accounting) work with no licence.
4. **Accounting**: the first-time screen asks for the **chart of accounts country** (Rwanda or Chad). It sets the account numbers and the currency (RWF or XAF) and is locked afterwards: agree it with the customer's accountant first.
5. **Settings > Business details** (name, address, tax number, logo), **System settings** (currency symbol, date format, language: Chad starts in French, Rwanda in English), **Taxes** (VAT 18% for Rwanda) and **Payment methods**.
6. **Branches and warehouses**, if the business has more than the head office.
7. **Roles and staff**: one account for each person, custom roles for the accountant, the store keeper and the cashiers, and the approval permissions only for the people who need them (Administrator Manual, chapter 4).
8. **E-mail settings**: enter the sending account and press **Send test email**; a real message must arrive at a real address. Password resets, reports and the shop's messages depend on it.
9. **Server settings seen on screen**: **Settings > Modules** must not say *The developer switch is on*; the page must be served over https (the padlock).
10. **Backup now** (Settings > Backup & Data) and check that the file appears in the list and in `/opt/niwe/acme/backups/`.
11. **Copy the backup off the server** (another machine or cloud storage), and set up the routine of chapter 7.
12. **Restore test**: restore that backup into a **separate empty database** (a spare one on this server), start a second copy of the backend on a different port against it, sign in, and see the data. Then delete the test copy. A restore that has never worked is not a backup.
13. **Smoke test** of the modules in use: make a sale at the till and print a receipt, create an invoice, receive a purchase, and check that the entries appear in the Journal. For the Online Store: open `/shop`, place a cash order, accept and complete it, and read the entries.
14. **Write down** in the customer register: the version, the licence number and its expiry, the installation id, the modules, the port, the backup place, the date of the restore test and who to call.

## Reading the first-start log

On a clean first start you should see, in this order: Flyway creating the schema and applying each migration (the last is the newest of this version), the line **Started PosApplication**, then a few seconds later the accounting backfill adding any missing accounts. If the administrator password was not set, a line starting **FIRST START** gives the one-time password: copy it once and then change it.

## When the first start fails

| What the log says | What to do |
|---|---|
| *Connection refused* or *password authentication failed* | The database is not running, the address is wrong, or the user or password in `config/application.properties` is wrong. Test with `psql` using the same values. |
| *Migration checksum mismatch* | A migration file differs from the one this database applied. You are running a different build than the database was made with. Use the right jar; never edit a migration. |
| *Detected applied migration not resolved locally* or *a migration it does not know* | The database was made by a **newer** version than this jar. Deploy the newer version. |
| *Schema-validation: missing column / table* | The database is behind the code. This should not happen on an empty database; if it is an old database, see the upgrade chapter of the Administrator Manual (the one-time `dbsync` start, after a backup). |
| *Address already in use* | Another program (often a second copy of the same customer) uses the port. Check the port plan. |
| *Failed to create backup directory* | The service account cannot write in the folder next to the jar. Fix the owner of `/opt/niwe/acme`. |

## Handing over

Before you leave the customer: give the administrator the **Administrator Manual**, the **User Manual** and the **Quick Start cards** for the roles in use; tell them who to call; and agree the date of the first upgrade window. The **Customer onboarding guide** carries on from here.
