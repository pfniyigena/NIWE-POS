# What a deployment is made of

## Who this guide is for

This guide is for the person at NIWE (or a partner) who **installs NIWE ERP for a customer business** and keeps it running: a developer, a system administrator or a technically able consultant. It assumes you can use a Linux shell, edit a text file and read a log. The customer's own administrator uses the **Administrator Manual** instead; the first weeks with a new customer are in the **Customer onboarding guide**, versions and upgrades in the **Release and upgrade notes for customers**, and problems in the **Support and troubleshooting guide**.

The aim is a deployment that is **the same for every customer** except for a short list of things that belong to that customer. Do the same steps in the same order every time, write down what you did in the customer register (chapter 8), and no installation depends on anybody's memory.

## The pieces

Every customer installation has four pieces:

| Piece | What it is | Where it runs |
|---|---|---|
| **Backend** | One Java 21 / Spring Boot program (`pos-app-<version>.jar`) holding all the business rules and the public shop's server side. | A service on the server, on a local port (for example 9101). |
| **Database** | One PostgreSQL database for this customer only. The structure is created and upgraded by the program itself (Flyway migrations). | PostgreSQL on the same server or a managed database. |
| **Frontend** | One folder of static files made by `ng build`. The same files serve staff screens, the public shop and the installable app. | Served by nginx (or another web server). |
| **Web server** | Terminates **HTTPS**, serves the frontend files, passes `/api/` to the backend, and carries the rules for share previews. | nginx on the same server. |

Staff and customers only need a modern browser. A till PC that prints directly to a thermal printer needs Chrome or Edge on https (or on localhost).

## One customer, one set of everything

Never share any of these between two customers:

- the **database** (each customer has its own database, user and password);
- the **secret that signs sign-ins** (`app.jwt.secret`): anyone who knows it can forge a sign-in for that installation;
- the **licence file** (it is signed for that installation's id only);
- the **payment provider keys** (MTN, Airtel, a card gateway are registered in the customer's business name);
- the **e-mail account** the shop sends from, and the **text message provider** account;
- the **domain name and its certificate**.

What is the same for every customer: the **jar**, the **frontend build** (the production build asks for the API at the relative address `/api`, so one build works behind any domain), and the **procedure**.

## Two layouts

**One server per customer** (a small virtual server for each business). It is the simplest to reason about and to move, and a problem at one customer cannot touch another. Choose it when a customer will have many users or the shop, or when the customer owns the server.

**Several customers on one server.** Each customer still has its own folder, its own jar process on its own port, its own database, its own nginx site and its own domain. Choose it for small customers to share a cost. Plan the memory: allow about 1 GB of memory for each running backend, plus the database. Do not share a database server's superuser between them.

Whichever layout you use, the folder and naming plan below keeps the customers apart.

## Naming plan

Pick a short **customer code** (lower case, no spaces, for example `acme`) and use it everywhere:

| Thing | Name |
|---|---|
| Linux folder of the backend | `/opt/niwe/acme/` (the jar, `config/`, `logs/`, `backups/` live here) |
| Frontend files | `/var/www/niwe/acme/` |
| Database and database user | `niwe_acme` and `niwe_acme` |
| Backend service | `niwe-acme.service` |
| Local port | one number per customer, for example 9101, 9102, ... (write it in the register) |
| nginx site | `/etc/nginx/sites-available/acme.conf` |
| Domain | for example `erp.acme.com` (staff and shop on the same address) |

Keep the **customer register** (chapter 8): one line for each customer with these names, the port, the version running, the licence number, the modules, the backup place, and who to call.
