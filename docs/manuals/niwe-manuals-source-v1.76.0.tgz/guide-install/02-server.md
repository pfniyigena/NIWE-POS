# Preparing the server

These steps are done **once per server**, not once per customer. The commands are for Ubuntu Server 22.04 or 24.04 LTS; use the equivalent on another system.

## Size

For one customer with up to about 20 staff and a public shop of moderate traffic: **2 vCPU, 4 GB of memory, 40 GB of disk**, with the disk growing with the number of invoices, product pictures and backups. Add 1 GB of memory and a vCPU for each extra customer on the same server. Put the backups on a **different disk or machine** than the database.

## Install the programs

1. **Update the system** and set the **time zone** to the customer's: `sudo timedatectl set-timezone Africa/Kigali` (Rwanda) or `Africa/Ndjamena` (Chad). The program's reports, daily jobs and the shop's "today" use the server's time zone. A server in the wrong time zone puts sales on the wrong day.
2. **Java 21**: `sudo apt install openjdk-21-jre-headless`. Check with `java -version`.
3. **PostgreSQL** (a supported version, for example 16): `sudo apt install postgresql postgresql-client`. The backup feature runs `pg_dump` and `psql` from the application server, so the **client tools must be installed on the machine that runs the backend** and be of the **same major version as the database**.
4. **nginx**: `sudo apt install nginx`. And **certbot** for free certificates: `sudo apt install certbot python3-certbot-nginx`.
5. **A service account**: `sudo useradd --system --home /opt/niwe --shell /usr/sbin/nologin niwe`, and `sudo mkdir -p /opt/niwe /var/www/niwe && sudo chown niwe:niwe /opt/niwe`.

## Firewall and access

- Allow only **22** (SSH, ideally from known addresses or with keys only), **80** and **443**. The backend ports and **PostgreSQL (5432) must not be reachable from the internet**: bind the database to `localhost` (the default) and let nginx be the only public door.
- Turn off SSH password login and use keys.
- Turn on automatic security updates (`unattended-upgrades`).

## Time, disk and memory checks

- Time must be correct (`timedatectl` says "System clock synchronized: yes"): sign-in tokens and payment checks depend on it.
- Make sure there is free disk for at least three nightly backups plus the database. A full disk stops the database.
- Give Java enough memory: the default is a quarter of the memory; for a server with several customers set `-Xmx1g` for each service (see the service file).

## The web server in front

The backend must never face the internet directly. nginx does the following for each customer (chapter 5 has the full site file):

1. answers on **HTTPS** with the customer's certificate and redirects http to https;
2. serves the static frontend, with every unknown path falling back to `index.html` (the staff screens and the shop are one single-page app);
3. passes `/api/` to the customer's backend port, adding the headers that tell the backend the visitor's real address and that the connection was https;
4. allows uploads up to 100 MB (`client_max_body_size 110m`), because the program accepts backup files and imports of that size;
5. carries the rules that give share previews, `/sitemap.xml` and `/robots.txt` to the shop.

Because nginx sits in front, set `server.forward-headers-strategy=native` in the customer's settings, so the limits "per connection" see each visitor's real address (otherwise everybody shares one address and is limited together).
