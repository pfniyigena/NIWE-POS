# Installing a customer

This is the routine for a **new customer on a prepared server**. Replace `acme` and the numbers with the customer's. It takes about an hour once the domain points to the server.

## Point the domain

Create the DNS record (for example `erp.acme.com`) pointing to the server's address, and wait until it answers.

## Create the folders and put the files

```bash
sudo mkdir -p /opt/niwe/acme/config /var/www/niwe/acme
sudo cp niwe-1.76.0-backend.jar /opt/niwe/acme/pos-app.jar
sudo tar -xzf niwe-1.76.0-frontend.tgz -C /var/www/niwe/acme
sudo chown -R niwe:niwe /opt/niwe/acme
```

The jar has a **fixed name** (`pos-app.jar`) inside the customer's folder, so the service file never changes. Keep the version-named copy in your store.

## The customer's private settings

Create `/opt/niwe/acme/config/application.properties`. The program reads a `config` folder next to where it is started, and this file wins over the defaults inside the jar. It holds **this customer's** values and secrets, and it lives only on this server (never in a repository):

```properties
# --- database (chapter 3)
spring.datasource.url=jdbc:postgresql://localhost:5432/niwe_acme
spring.datasource.username=niwe_acme
spring.datasource.password=THE-DATABASE-PASSWORD

# --- the program
server.port=9101
server.forward-headers-strategy=native
app.jwt.secret=A-LONG-RANDOM-VALUE-OF-AT-LEAST-32-BYTES
app.frontend-url=https://erp.acme.com
app.cors.allowed-origins=https://erp.acme.com

# --- first start
app.seed-demo-data=false
app.accounting.chart-country=RWANDA
# optional: the first administrator's password; if empty a random one is written once to the log
# app.initial-admin-password=

# --- licence requests are e-mailed here
app.license.vendor-email=licences@niwe.example
```

Make the file readable only by the service account: `sudo chmod 600 /opt/niwe/acme/config/application.properties`.

What each line means and how to choose it:

| Setting | Meaning |
|---|---|
| `spring.datasource.*` | The customer's database address, user and password. |
| `server.port` | The local port of this customer's backend (from your port plan). |
| `server.forward-headers-strategy=native` | Needed behind nginx, so limits per connection see each visitor. |
| `app.jwt.secret` | **Unique for each customer.** Make it with `openssl rand -base64 48`. The value inside the jar is public (it is in the source): leaving it means anybody can forge a sign-in. |
| `app.frontend-url` | The public address, `https://` and no trailing slash. It builds the links in e-mails, driver links, share previews and the sitemap. |
| `app.cors.allowed-origins` | The same address (comma-separated if there are more). |
| `app.seed-demo-data=false` | Keep it `false`. Demo data and demo passwords are for learning only. |
| `app.accounting.chart-country` | `RWANDA` or `CHAD`: the suggestion on the first-time chart screen. The administrator picks the chart on screen at the first sign-in and it is then locked in. |
| `app.initial-admin-password` | Optional. Without it a random password is written once to the log on the very first start (look for *FIRST START*). |
| `app.backup.directory` | Optional. Where backups go (default: the `backups` folder next to the jar). |
| `app.backup.pg-dump-path`, `app.backup.psql-path` | Only if `pg_dump` and `psql` are not on the service's PATH. |

**Payment provider keys, text provider and anything else secret** are added to this same file, or to the service's environment, only when the customer is ready to use them (see the onboarding guide). Never put the same value in two customers' files. Environment variables are the setting names in capitals with dots and dashes turned into underscores (`APP_JWT_SECRET`).

## The service

`/etc/systemd/system/niwe-acme.service`:

```ini
[Unit]
Description=NIWE ERP (acme)
After=network.target postgresql.service

[Service]
User=niwe
WorkingDirectory=/opt/niwe/acme
ExecStart=/usr/bin/java -Xmx1g -jar /opt/niwe/acme/pos-app.jar
Restart=on-failure
RestartSec=10
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target
```

The **working directory** is what makes `config/`, `logs/` and `backups/` live next to the jar. The account that runs the service must be allowed to write in that folder (the program creates `logs` and `backups` when they are missing).

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now niwe-acme
sudo journalctl -u niwe-acme -f        # or: tail -f /opt/niwe/acme/logs/niwe-erp.log
```

Wait for the line **Started PosApplication**. The first start applies every migration and takes about a minute; a few seconds after it the program also adds missing accounts to the chart (backfill). Watch for lines that say *ERROR*, *Migration* failed or *Schema-validation*.

## nginx

`/etc/nginx/sites-available/acme.conf`, then link it into `sites-enabled`:

```nginx
server {
    listen 80;
    server_name erp.acme.com;
    location /.well-known/acme-challenge/ { root /var/www/certbot; }
    location / { return 301 https://$host$request_uri; }
}

server {
    listen 443 ssl http2;
    server_name erp.acme.com;
    # certificate lines are added by certbot
    root /var/www/niwe/acme;
    index index.html;
    client_max_body_size 110m;

    location /api/ {
        proxy_pass http://127.0.0.1:9101;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_read_timeout 120s;
    }

    # the page itself is always asked from the network
    location = /index.html { add_header Cache-Control "no-cache"; }

    # the share-preview, sitemap and robots rules of the Online Store go here
    # (copy them from docs/online-store-seo.md, using this customer's backend port)

    location / { try_files $uri $uri/ /index.html; }
}
```

Get the certificate with `sudo certbot --nginx -d erp.acme.com`, then `sudo nginx -t && sudo systemctl reload nginx`.

For a customer who uses the **Online Store**, add the rules from `docs/online-store-seo.md` (the `map` for crawlers goes in the `http` block, the `location` blocks in the `server` block, and the backend address is `127.0.0.1:9101` for this customer). Where the file says `try_files /index.html =404` use `try_files $uri $uri/ /index.html` as noted there. Test with `curl -A "facebookexternalhit/1.1" "https://erp.acme.com/shop"`.

## Open it

Open `https://erp.acme.com`. The first page shows the staff login (or the shop when the Online Store module is on). Sign in as `admin` with the password from the settings file or from the log line *FIRST START*, **change the password at once** (My profile), and carry on with chapter 6.
