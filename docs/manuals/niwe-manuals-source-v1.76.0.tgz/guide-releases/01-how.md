# How upgrades work

## Why there are new versions

NIWE ERP is improved in small steps. Each step is a **version** with a number such as **1.76.0** and its own release notes. A new version brings new screens, fixes, and sometimes a change to the database. This document is the customer's view of them: what each version brings, and what you must do, if anything, when you move to it. It is for the business owner, the administrator and the person at NIWE who looks after the installation.

## What an upgrade is, and what it is not

- An upgrade replaces the **program** (the backend and the web pages). Your **data stays**: sales, invoices, customers, stock and accounts are in your database and are kept.
- If the new version needs a change to the **database structure**, it makes it by itself the first time it starts (this is called a *migration*). Migrations are numbered and run once, in order, and are never changed afterwards.
- Your **licence**, your **modules** and your **settings** stay as they are. Staff are signed out once and sign in again.
- An upgrade is **not** automatic. NIWE (or your own technician) does it on a day you agree, usually outside business hours. Nothing changes under your feet.
- You can go **from an old version straight to the newest**; the migrations in between run in order. When the gap is large, NIWE first tries the upgrade on a copy of your data.

## How long it takes

A normal upgrade stops the system for **five to fifteen minutes**: stop, replace, start, check. The first start after a version with migrations can take a minute or two longer. Choose a quiet moment, and tell staff when it will happen. Tills keep selling during a short break and queue the sales (see the POS chapter of the User Manual); do not clear the browser while sales are waiting.

## Your part

1. **Agree the day and the version** with NIWE. Read the entry of the version in chapter 2 and any **action** for you in chapter 3.
2. **Close the day** if you can: tills closed, nothing half-finished.
3. **Be reachable** during the window, so that someone can check the system afterwards.
4. **After the upgrade**, sign in, look at the screens you use every day, make a test sale or a test order, and tell NIWE at once if anything looks wrong.

## NIWE's part, in short

Before upgrading, NIWE takes a **backup** and copies it off the server and keeps the previous version so that it can go back; applies the one-time actions of the version; checks the log for the migrations and for errors; and checks a few screens with you. If something goes wrong the previous version and the backup are put back (see the Installation guide, chapter 7).

## Fixes between versions

Small fixes carry a third number: **1.58.1**, **1.64.1**. They are usually a single change and need no action.

## Reading a version number

The first number changes only for a very big step. The second number changes with each release of new features (1.76). The third number is a fix (1.76.1). The **Release notes** of each version are the exact, technical list; this document is the short version for the business.
