# Versions and database changes

The database structure changes by numbered **migrations** (V70, V71, ...). The newest migration a database has applied shows which version it was last started on. A database made by a **newer** version cannot be used with an **older** program: the program stops at start-up and names the migration it does not know. Restore a backup into the version that made it, or use the newer program.

| Version | Theme | Migrations |
|---|---|---|
| 1.32 | Text messages | V70 |
| 1.33 | Returns and refunds | V71 |
| 1.35, 1.36 | Front page, banner pictures | V72, V73 |
| 1.38 | Newsletter sending | V74 |
| 1.39 | Abandoned-cart reminders | V75 |
| 1.40 | Loyalty points | V76 |
| 1.42 | Several payment providers | V77 |
| 1.43 | Advertising | V78 |
| 1.44 | Product page | V79 |
| 1.45 | Shop look and delivery days | V80 |
| 1.46 | Ratings and reviews | V81 |
| 1.47 | Account extras (invoice, addresses, wish list, WhatsApp) | V82 |
| 1.48 | Product rows that slide | V83 |
| 1.50 | Product variants | V84 |
| 1.51, 1.51.1 | Information pages, contact form and replies | V85, V86 |
| 1.52 | Drivers | V87 |
| 1.54 | Back-in-stock alerts | V88 |
| 1.56 | Order reception (codes) | V89 |
| 1.57 | Driver cash | V90 |
| 1.58 | Failed and partial deliveries | V91 |
| 1.59 | Driver private link and PIN | V92 |
| 1.59.1 | Tax for each delivery area | V93 |
| 1.59.2 | Codes by SMS and e-mail | V94 |
| 1.61 | Delivery time slots | V95 |
| 1.62 | Return pick-ups | V96 |
| 1.63 | Delivery estimate per area | V97 |
| 1.65 | Stock location of the shop | V98 |
| 1.66 | Held stock and buffers | V99 |
| 1.67 | Expiry and serials | V100 |
| 1.69 | Prices from Sales, weights and lengths | V101 |
| 1.71 | Online payments in the books, payouts | V102 |
| 1.72 | Cash with Drivers | V103 |
| 1.74 | Cost sold and the shop's branch | V104 |
| 1.75 | An account for each payment provider | V105 |
| 1.76 | Choose the accounts of each provider | V106 |

Versions not in the table (for example 1.41, 1.49, 1.53, 1.55, 1.58.1, 1.58.2, 1.60, 1.64, 1.64.1, 1.68, 1.70, 1.73) have **no migration**.

## Checking what a database is on

An administrator with database access can run `select version, description, success from flyway_schema_history order by installed_rank desc limit 5;`. The first row is the newest migration applied. Without database access, the log of the last start lists the migrations that ran and the version of the program.
