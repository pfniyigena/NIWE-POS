# What is new, version by version

The versions are grouped by what they bring. Each line says what you can now do. Versions before 1.23 are summarised in the last section.

## 1.76: choose the accounts of each payment provider

In **Online Store > Online payments > Accounts by provider** you choose, for each payment provider (MTN, Airtel, card, and later ones), the account for **what the provider still owes you** and the **wallet or bank account its payouts arrive in**. Each can be an existing account or one created on the spot. Payouts are recorded one provider at a time.

## 1.75: an account for each payment provider

MTN Mobile Money, Airtel Money and card each have their own accounts, so each balance can be matched to that provider's own statement. Orders paid before this version keep their old accounts, so no balance moves.

## 1.73 and 1.74: the shop's accounts show discounts, delivery income and loyalty points; returns at cost

Sales Revenue now shows the **full price** of the goods; coupon and points discounts are in **Sales Discounts Given** and delivery fees in **Delivery Income**. Loyalty points the shop owes are a **liability**. A return puts the goods back into stock at the **cost they were sold at**. A **branch** can be chosen for the online shop.

## 1.72: cash that drivers hold

Cash a driver takes at the door is booked to **Cash with Drivers** until he hands it in. The hand-in moves it to Cash and Bank and books any difference.

## 1.71: online payments are held and cleared against payouts

Money paid online is recorded when the provider confirms it, held until the order is delivered, and cleared when the provider pays out. A new **Payouts** panel records each payout and its fee.

## 1.70: returns post the VAT and the refund

A return now reverses the VAT as well as the sale and posts the money handed back to the customer.

## 1.65 to 1.69: the stock and the prices the shop uses

- The shop sells only from **Sales locations** (outside the Main warehouse), one chosen or all.
- A shop order **holds its stock from the moment it is placed**, so two customers cannot be sold the last unit; unanswered orders are cancelled after a number of hours you set.
- A **buffer for each product** and a **share kept for the till**.
- **Expired goods** are never sold; batches near their expiry can be left out; **serial numbers** are shown and returned correctly.
- **Cartons** count as stock; **Reorder** takes shop orders and waiting customers into account.
- **Prices and promotions from Sales** are used online; products can be **sold by weight or length**.
- Fixes: completing an order with several warehouses no longer fails, and refusals show their real reason.

## 1.52 to 1.64: delivery

- **Drivers**, **delivery slips** and **run sheets**; the customer sees his driver's name and phone.
- A **4-digit delivery code**: the customer gives it to the driver to complete the order. Staff never see it. It is sent by e-mail and text (text is a placeholder until a text company is connected).
- A **private page for each driver** (link and PIN, no staff login) with his orders, his cash and his returns to collect.
- **Driver cash**: follow the cash drivers take until it is handed in, with differences recorded.
- **Failed deliveries** and **partial deliveries**, with the customer choosing a **new delivery time**.
- **Delivery time windows** (limits per window, closed days, notice).
- **Return pick-ups**: a driver collects returned goods with a return code.
- **Delivery estimate and tax for each area**; the fee is the amount the customer pays and the tax is included.
- Every accounting entry from an online order ends with the order number.

## 1.41 to 1.51 and 1.53 to 1.55: a richer shop

- **Airtel Money** as a second payment provider, and several providers at once with a choice at checkout (1.41, 1.42).
- **Advertising**: sell space in the shop to other businesses, with a report of views and clicks (1.43).
- A **product page** for each product; search, filters and sorting; product cards, quick view, recently viewed; **ratings** (stars count at once) and **reviews** (words, approved by staff) (1.44 to 1.46).
- **Invoice download**, an **address book**, a **wish list** and **WhatsApp** links (1.47); product rows that slide (1.48).
- **Product variants** (size, colour, model) as one product with options (1.50); a **contact form** with replies inside the program, and four **information pages** (1.51).
- **Link previews** in WhatsApp, Facebook and others, a **sitemap** and Google product data (1.53); **back-in-stock alerts** (1.54); the customer **portal** (1.55); and the **installable app** for the whole site (1.49).

## 1.27 to 1.40: the Online Store is born

A public shop with delivery and pick-up and cash orders (1.27); e-mails at every step (1.28); **online payment** with a test provider and then **MTN Mobile Money** (1.29, 1.34); customer **accounts** by e-mailed code (1.30); **coupons** (1.31); **text messages** (1.32); **returns and refunds** (1.33); the shop as the first page; a full first page with banner pictures, rows, reviews, newsletter and footer (1.34 to 1.36); six **sales reports** (1.37); **newsletters** sent from the program (1.38); **abandoned-cart reminders** (1.39); **loyalty points** (1.40).

## 1.23 to 1.26: French

French throughout: screens, messages, lists, report headings, printed documents, e-mails and the messages the server writes. Each user can switch language, and the business has a default language (Chad starts in French, Rwanda in English).

## Before 1.23

1.1 module licensing; 1.2 to 1.4 Property Management, Real Estate and Law firm; 1.5 paging, search and exports everywhere, collections, imports with check-first, accounting controls, price lists, promotions, gift cards and loyalty at the till; 1.6 to 1.10 HR and Payroll, Hotel, Restaurant, POS, Manufacturing and decimal quantities; 1.11 receipts with the tax number, dashboard paging; 1.12 thermal printing, cash drawer and customer display; 1.13 a register tied to one device; 1.14 server logs, the sign-in log and the wider audit log; 1.15 to 1.22 Work orders, Time tracking, Booking, Installments, Subscriptions, Help Desk, Expenses and Assets.
