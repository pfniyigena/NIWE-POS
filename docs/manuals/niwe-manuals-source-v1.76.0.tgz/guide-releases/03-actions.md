# What you must do at each upgrade

Most versions need nothing from you. These are the versions that need a **one-time action**. The technician does the technical ones; the business does the ones marked *business*.

| Version | Action | Who |
|---|---|---|
| Any | Take a **backup** and copy it off the server before the upgrade. Keep the previous jar and frontend until the new version has worked a day. | NIWE |
| 1.22.3 and later | The database password, the sign-in secret and the e-mail password are **never in the shipped files**: they are in the server's private settings or environment. | NIWE |
| 1.38 | Optional pace settings for newsletters (`app.online-store.newsletter.batch-size`, `daily-limit`). | NIWE |
| 1.39 | Abandoned-cart reminders need working e-mail and `app.frontend-url` set to the public address. Off until switched on in Shop settings. | NIWE and business |
| 1.41, 1.42 | Airtel Money and several providers: provider keys go in the server's environment, and each provider must be switched on there before it can be ticked in Shop settings. | NIWE |
| 1.42 | Optional: put the official MTN and Airtel logo files in `frontend/src/assets/payment/` before building the frontend; otherwise the buttons show names. | NIWE |
| 1.49 | The site is installed as an app only over **https**. | NIWE |
| 1.51 | Read and adapt the four **information pages** (Terms, Privacy, Returns, Delivery) in Online Store > Shop pages. They are starter texts, not legal advice. | Business |
| 1.53 | Add the **web server rule** for link previews, the sitemap and robots.txt (`docs/online-store-seo.md`) and set `app.frontend-url` to the public address. Without it the shop works but links show no preview. | NIWE |
| 1.54 | Back-in-stock alerts use e-mail (and text when connected). No action. | |
| 1.57, 1.59.1 | Give the **delivery fee product** an inclusive tax or none, and set each delivery area's **tax**, so that the invoice and the driver's cash match the customer's total. | Business |
| 1.59 | Set `app.frontend-url`; serve over https; give each driver a **link and PIN** in Shop settings > Drivers. | NIWE and business |
| 1.61 | Delivery times are off until windows are added in Shop settings > Delivery times. | Business |
| 1.65 | With several warehouses, choose **Stock the shop sells from** (or leave Automatic). Check the line under a few products. | Business |
| 1.66 | Choose **Release unanswered orders after (hours)** and the **share kept for the till**. | Business |
| 1.67 | Choose **Do not sell goods with fewer days left than** if the shop sells expiring goods. | Business |
| 1.69 | Choose the **price list** the shop uses; mark products sold by weight or length. | Business |
| 1.70 to 1.76 | Accounting changes: open **Accounting > Chart of accounts** a few seconds after the first start and check that the new accounts exist (Rwanda: 1011, 1012, 1013, 1020, 1021, 1022, 1030, 1050, 2810, 2820, 4030, 4040, 5240; Chad: 5212 to 5219, 4197, 4198, 631, 7071, 7091). | NIWE and accountant |
| 1.71, 1.75, 1.76 | Choose each provider's **clearing and payout accounts** in Online Store > Online payments > Accounts by provider. Record each provider **payout** in Payouts. Post **opening balances** of the provider accounts if you start part-way. | Accountant |
| 1.72 | Check that **Cash with Drivers** agrees with the *To hand in* total of Driver cash each day. | Business |
| 1.73 | Loyalty points customers held before this version are **not in the liability**: post one manual opening entry (Dr Customer Rewards Expense, Cr Loyalty Points Liability). | Accountant |
| 1.74 | With more than one branch, choose **Branch the shop sells for**. | Business |

If you are several versions behind, do **all** the actions of every version you pass.

## Known limits to remember (version 1.76)

- A payment *under review* (wrong amount, or a second payment for an order already paid) is not in the books until staff deal with it.
- Orders paid online before 1.71 have no deposit: their payment is booked against the provider's account when they are delivered. Orders delivered before 1.72 settle driver cash with the difference only. Returns before 1.70 keep their old refund figure. Orders paid before 1.75 keep the old accounts.
- A provider that pays out net of its fee: enter the gross the payout covers and the fee.
- Real MTN, Airtel and card payments depend on your own keys and approval; the first live payments must be tested with small amounts.
- The text message sender is a placeholder until a real text company is connected: codes by text stay in the text list; the e-mail still goes.
