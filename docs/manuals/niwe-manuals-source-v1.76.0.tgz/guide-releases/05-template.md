# Upgrade record (one page for each upgrade)

Copy this page for every upgrade of a customer and keep it with the customer register.

| | |
|---|---|
| Customer | |
| From version, to version | |
| Date and window agreed with the customer | |
| Done by | |

## Before

- [ ] Release notes of every version passed have been read; the actions of chapter 3 are listed below.
- [ ] Customer informed; day closed if possible.
- [ ] Backup taken and copied off the server (file name, size, place): ________________
- [ ] Old jar and old frontend kept (where): ________________
- [ ] For a large gap: tried on a copy of the data (result): ________________

## During

- [ ] Service stopped; new jar and frontend in place.
- [ ] One-time actions applied (list): ________________
- [ ] Service started; log shows each new migration (last one: V____) and *Started PosApplication*; no ERROR lines.

## After

- [ ] Signed in as admin; **Settings > Modules** shows the licence and the modules.
- [ ] **Accounting > Chart of accounts** has the new accounts (when the release said so).
- [ ] A test sale (or order) made and its entries read in the Journal.
- [ ] The customer's administrator checked the screens used every day.
- [ ] Register updated with the new version and the date.
- [ ] Problems found and who owns them: ________________

Signed (NIWE): ______________   Signed (customer): ______________
