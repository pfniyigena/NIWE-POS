# Module settings

Every module that needs choices keeps them on its own **Settings** page, at the bottom of that module's menu. All of these pages are **Admin only**. This chapter lists them, in the order of the menu, and explains the choices that matter. Press **Save** on each page; most show *Saved* when done.

> **Tip:** Set a module up *before* staff start using it. Some settings (for example Help Desk deadlines) only apply to records created after you switch them on.

## Sales settings (Sales > Settings)

- **Features**: switch on only what you use: **Promotions** (discounts, buy-X-get-Y, coupons), **Gift cards**, **Loyalty points** (the earning and spending rules are set on the Loyalty page). When a feature is off, its menu entries and till parts are hidden and the server refuses to use it. What was already saved is kept and works again when you switch it back on.
- **Invoice receiver emails**: one address per line. Whenever an invoice is issued, a PDF copy is e-mailed to the customer's own address and to everyone on this list. It is sent only if e-mail is set up (chapter 9); a failed send never blocks or undoes the invoice.

## POS settings (POS > POS settings)

The rules the till enforces. They are the main control against loss at the counter.

| Group | Setting |
|---|---|
| **Cash at the till** | A closing difference up to a set amount is accepted without comment; a bigger one needs a note saying why. Closing a shift needs the notes and coins counted (option). A paid-out from the drawer above an amount needs a manager's PIN (0 = no limit). Remind the cashier to drop cash into the safe when the drawer holds more than an amount (0 = no reminder). |
| **Voids and returns** | Voiding a sale needs a manager (their sign-in or PIN). A sale can be voided only while its shift is open (afterwards it is a return). A return needs a reason. Returns of sales older than a number of days need a manager (0 = no limit). A refund above an amount needs a manager (0 = no limit). The reasons offered for a return (separated by commas). |
| **Discounts and prices at the till** | A cashier may give a discount up to a percent alone; above it a manager approves (0 = every discount needs a manager). A discount needs a reason. A manager may change a price at the till. Refuse a price below the item's cost. The reasons offered for a discount. |
| **Receipts** | Paper: 80 mm or 58 mm thermal roll. Extra lines under the business details (opening hours, phone, VAT note). Text at the bottom of every receipt. Print the business logo. Print a QR code of the invoice number (sales sent to EFRIS keep their own QR code). |

The first printing of a receipt is the original; every later printing is marked **COPY 1, COPY 2...** and listed in **Voids & returns**. "A manager" means an Admin, or a person with the *Approve voids and returns / price changes / big paid-outs* permissions from chapter 4.

## Inventory settings (Inventory > Inventory settings)

- **Allow negative stock** (default on): a sale or manual adjustment may take stock below zero. Untick it to make checkout refuse a sale that would oversell and Stock adjustments refuse a correction that would go negative.
- **Product packaging & breakdown**: lets you break one product into smaller sellable units (a bottle into shots, a case into bottles). Off by default; packaging rules can be configured but a breakdown is refused until this is on.
- **Multi-warehouse**: off by default, the store stays on one warehouse ("Main"). When on, you can create further warehouses, but no sale may complete against Main any more: every register must be assigned a different warehouse (**POS > Registers & Terminal**) before it can ring a sale. Purchases always land on Main's default location.
- **Costing method**: *Weighted average* (recommended), *Last purchase cost*, or *Manual* (never change cost automatically). Landed cost on receiving needs weighted average or last purchase.
- **Daily stock jobs**: *Email a daily low-stock digest* (one e-mail a day to the notifications address, nothing on a day when nothing is low); *Draft purchase requisitions automatically* (each day one DRAFT requisition for products at or below their reorder level; it never submits or approves, and skips products already on an open requisition); *Run from* (store time); and a *Run now* button that uses the saved settings.
- **Restaurant kitchen location**: where restaurant orders and wastage take their stock from (shown when the store has more than one location).

## Expenses settings (Expenses > Settings)

- **Approval limit**: expenses above this amount can only be approved by an Admin or someone with *Approve large expenses*. 0 = no limit.
- **Nobody approves, rejects or voids an expense they entered themselves** (option).
- **Block approval when it would go over the monthly budget**: an Admin can still approve with an override, which is written to the expense history.
- **Days until a bill is due** (used when an unpaid bill is entered without a due date) and **Warn this many days before the due date**.

## Assets settings (Assets > Settings)

- **Warn before a warranty or insurance ends (days)**.
- **"Fully depreciated soon" means within (months)**.
- **Disposal approval limit (book value)**: disposing of an asset whose book value is above this needs an Admin or a user with *Approve large asset disposals*. 0 = no limit.

## Installments settings (Installments > Settings)

- **Email reminders**: send reminders to customers (needs e-mail), how many days before a due date, and how often to chase overdue instalments.
- **Starting values for a new plan**: whole amounts (no cents) for currencies such as RWF and XAF, yearly interest %, grace days, late fee (fixed) and late fee (% of unpaid).
- **Early payoff and default**: the percent of interest waived on an early payoff (changeable per payoff); mark a plan defaulted after this many days overdue (0 = never automatically).
- **Agreement wording**: one term per line, printed under "Terms" on the agreement PDF. Leave empty for the standard wording; have your own text checked by a lawyer.

## Subscriptions job settings (Subscriptions > Job settings)

- **Run from (store time)**: the daily job time, using the time zone in System settings. If the server was off then, it runs when next up the same day.
- **Bill due subscriptions automatically**: each active subscription whose next billing date has arrived gets its invoice. Turn off to bill only by hand with **Bill now**.
- **Email upcoming-billing reminders**: how many days before, to the customer and/or the notifications e-mail.
- **When an invoice stays unpaid**: do nothing, pause the subscription, or cancel it after a number of days past the invoice date. Pausing can be undone with **Resume**; cancelling cannot.
- **Email a daily results digest** to the notifications e-mail (not sent on days when nothing happened).
- **Overdue reminders and catching up**: e-mail the customer when a subscription invoice is overdue (first reminder after n days, then every n days, at most n reminders), and **Missed billing cycles to bill in one run** (1 = one per day; a higher number catches up at once, each with its own period).
- **Run now** uses the saved settings and counts as today's run.

## Help Desk settings (Help Desk > Settings)

- **Public website**: when on, anyone can send a support request and follow a ticket at `/helpdesk` on your site without signing in; options let customers reply and attach files and rate the help. Switch it off to close the page.
- **Notification emails**: one address per line; they get an e-mail for each new ticket, for customer replies to an unassigned ticket, and for missed deadlines.
- **E-mail each reply to the customer** when the ticket has an e-mail address.
- **Deadlines (SLA)**: give every new ticket a first-reply and a resolution deadline by priority (Urgent, High, Medium, Low), counted in calendar hours from creation; time *waiting for the customer* does not count. Only tickets created after you switch this on get deadlines. Options: internal tickets too; warning e-mail before the deadline and alert when missed; **Close a resolved ticket automatically after (days)**.

## Time tracking settings (Time tracking > Settings)

- A manager must approve submitted time (switch off to approve everything automatically).
- **Round stopped timers up to** exact minutes, 5, 6, 10, 15, 30 minutes or 1 hour.
- **Default hourly rate**, **most hours one person can log in a day**, **working hours in a day** (for utilisation).
- **Keeping timesheets tidy**: stop a timer running more than n hours (kept as a draft for the person to check; 0 = never); **Lock time up to and including** a date so approved and invoiced weeks stay as they are; a weekly reminder e-mail to people who have not handed in last week's time; a warning when a project has used n% of its budget (recorded in the audit log).
- **Service product billed time is invoiced under**: the product named "Professional services (time)" can be created automatically; its tax rate and accounting follow the product.

## Booking settings (Booking > Settings)

- **Opening hours**: opens, closes, time between start times, working days.
- **Booking rules**: earliest booking (minutes ahead), furthest ahead (days), hold for payment (minutes), online cancel until (hours before).
- **Reminders and moving a booking**: e-mail the guest a reminder (with a calendar file) n hours before; guests may move their own booking on the public page.
- **Public website**: guests pick a service and a time themselves at `/book`. Also confirmation e-mail, bookings per phone number per day, page title, intro text, and how to pay (shown to guests who owe a deposit).

## Work orders settings (Work orders)

- **New customer jobs need the customer's approval**: work cannot start until an estimate has been sent and approved (can be switched off for a single job).
- **E-mail the customer when a job is completed**: a completion note (PDF) is sent. If the e-mail fails, the job is still completed.

## Attendance and leave settings (HR > Attendance > Settings)

- **Working time**: work starts at, grace period (minutes), hours in a normal day, overtime pays (multiple of normal hourly pay), working days. Clocking in after the start time plus grace counts as late.
- **Leave types**: name, days a year, whether days become available all at the start of the year or are earned month by month, carry-over (max days), paid or unpaid, paid out when leaving.
- **Public holidays**: add the holidays of each year; they are not counted as leave or working days.

## Hotel settings (Hotel > Settings)

- **How room revenue reaches Accounting**: *Every night* (posted by the night audit; best for most hotels), *At check-out*, or *At booking and check-out* (booked value is held as unearned revenue until check-out). The mode can only be changed when no booking is open.
- **Tax on rooms and services (%)**, **check-in time**, **check-out time**, **night audit runs at**.
- **Cancellation and fee policy**: free cancellation until n days before arrival; late-cancellation, no-show, early-departure fees (in nights); late check-out fee. The front desk can waive any fee. See also **Online booking** settings for the hotel's public booking page.

## Restaurant settings (Restaurant > Settings)

Service charge by order type (dine-in, takeaway, delivery) and VAT on it; the most a waiter may discount without a manager; tips (quick-choice percents); quick kitchen notes; usual preparation time and amber/red thresholds for kitchen tickets; rounding of the bill; and table bookings from the public site at `/reserve`.

## Online Store settings (Online Store > Shop settings)

The Online Store needs the **Online Store** module in the licence and activated. Its pages are `/shop` (the public shop, also the first page of the site for a visitor who is not signed in), `/shop/order/<code>` (where a customer follows an order), `/shop/account` (the customer's account), `/shop/info/...` (information pages), `/driver/<secret>` (a driver's private page) and a few small pages for the newsletter and carts; staff use the **Online Store** group of the menu (**Online orders**, **My deliveries**, **Driver cash**, **Online payments**, **Returns**, **Coupons**, **Reviews**, **Messages**, **Waiting customers**, **Shop pages**, **Newsletter**, **Send a newsletter**, **Abandoned carts**, **Loyalty points**, **Advertising**, **Sales reports**, **Text messages**, **Shop settings**). Everything starts closed: the public pages answer "not available" until the module is activated and **Shop is open to the public** is ticked. The User Manual (Online Store, chapters 23 to 25) describes the screens for the shop staff; this section is for the person who sets it up.

Set up, in this order:

1. **Products on the shop**: only products added here are shown or sold. The picture is the product's own; the price is the online price if set, otherwise the price list of the shop and the best promotion, otherwise the normal price. Prices are shown with tax included. The ticks **Featured**, **Best seller**, **Offer** and **New** choose the products of the rows on the first page. Products with variants appear as one product with options.
2. **Delivery areas** with a fee, an optional minimum order, a tax (included in the fee) and an estimate in days each. With none, the shop delivers anywhere for free.
3. **Service product for the delivery fee**: a *service* product (no stock) that carries the delivery fee on the sale order and the invoice. Without it, an order that has a delivery fee cannot be accepted. Give it a tax that is **inclusive**, or none, and choose each area's own tax, so that the invoice total, and the cash a driver must hand in, match what the customer saw.
4. The shop switches and limits: **Delivery**, **Pick-up**, **Pay cash on delivery or at pick-up**, **Minimum order**, **Free delivery from**, **Orders waiting per phone** and **Orders per connection per hour**. **Send new-order e-mails to** and **Alert by e-mail when an order waits this many minutes** tell the shop who to warn. **WhatsApp number of the shop** and the **Contact e-mail** appear on the contact page.
5. **Front page**: the announcement, banner texts and pictures, shop colour, footer text and links (see the User Manual). Banner pictures are stored in the database: up to 8, so a backup is slightly larger.
6. **Shop pages**: read and adapt the four information pages (Terms, Privacy, Returns, Delivery). They are a starter text, not legal advice.
7. **Branch the shop sells for** (only with more than one branch).
8. **Drivers** and **Delivery times**, if the shop delivers.
9. **Accounts by provider** (Online Store > Online payments), once the providers are switched on.

### Stock the shop sells

The shop has no stock of its own. It sells what the warehouses hold in **sellable locations** (with several warehouses: Sales locations outside the Main warehouse; choose one in **Stock the shop sells from**, or *Automatic*), minus the quantities reserved on confirmed sales orders, minus the units **held** by shop orders nobody has answered yet, minus the product's **buffer**, minus the **Share kept for the till (%)**. Expired batches are never counted and, with **Do not sell goods with fewer days left than**, batches close to their expiry are left out. Cartons that can be opened (breakdown on in Inventory) count as units. Under each product in **Products on the shop** the screen shows every figure. If products say *Sold out* although you have stock, see *The online shop* in chapter 14.

- **Release unanswered orders after (hours)** (default 24, 0 = never) cancels an order waiting for a payment, or a cash order nobody accepted, so its stock is free again. An order paid online is never cancelled this way. A job checks every 10 minutes.
- **Price list used by the shop** and **Apply now**: online prices from Sales (promotions that need a coupon, group, limit, minimum, "buy X get Y" or that cover the whole cart are not applied online). Prices are recalculated every 2 minutes.
- A product can be **sold by weight or length** (decimals from 0.1 to 100).

Accepting an order creates a confirmed sale order for the customer (found by phone number, or created), which holds the stock. Completing it fulfils the sale order from the shop's Sales location (or the chosen one), issues the invoice and records the payment: cash for a cash order, or the online payment already received. Staff need the **Operations** area to answer orders. If completing an order is refused, for example for lack of stock, staff see the real reason; drivers and customers see "please call the shop" and the reason is in the order's history.

### Customer accounts

Tick **Customers can sign in to see their orders**. A customer types an e-mail address and receives a one-time code (valid 10 minutes, 5 tries); there are no passwords. This needs the **e-mail settings** of the business (chapter 9), or text messages for a code sent to a saved phone number.

### Delivery times and drivers

**Delivery times** is switched off until you add windows (from and to, orders per day, weekdays), the switches (customers choose a time; they must choose one; days ahead; notice in hours) and the days without deliveries. A delivery window is checked again on the server when the order is placed.

**Drivers**: a driver is a list entry (name, phone, note, active). **Give a link** makes a private address and a 4-digit PIN for him (the PIN is shown once and stored scrambled); **Show link**, **New PIN** and **Switch off** manage it. For the link to be complete **`app.frontend-url`** must be the public address, and the site must be served over **HTTPS**. Five wrong PINs lock the link for 30 minutes; the phone keeps a session for up to 14 hours. A driver sees only his own orders and returns and his own cash. The code that completes a delivery (4 digits) is sent to the customer by e-mail and text and is never shown to staff or drivers; five wrong tries block it for 30 minutes.

### Online payments

In **Online payments** tick every **provider** you want to offer, tick **Customers can pay online**, and set **Minutes the customer has to pay**. Each ticked provider must be switched on and keyed on the server, otherwise saving is refused with a clear message; at least one must stay ticked while online payments are on. When more than one provider can take the customer's way to pay, checkout shows a **Pay with** row of buttons. A customer who pays online has an order that reaches the shop only once the payment is confirmed; an order that is never paid is cancelled. Set the **currency of the business** (Business details) to the currency you charge in. The providers are:

- **Simulated provider** (for tests only; it exists when the server is started with `app.online-store.payments.simulated.enabled=true` and a `...simulated.secret`). The customer lands on a test page with **Pay** and **Decline**. Never use it with real customers.
- **MTN Mobile Money (MoMo)** for Rwanda. The customer types an MTN number and approves on the phone. It stays **unavailable** until it is switched on and keyed in the server's environment: `app.online-store.payments.mtn.enabled=true`, `...subscription-key`, `...api-user`, `...api-key`, `...base-url` (https only) and `...target-environment` (`sandbox` while testing). The step-by-step guide to get sandbox keys, test, and go live is `docs/online-store-mtn-momo.md` in the program's files. The sandbox accepts only the currency EUR.
- **Airtel Money** for Rwanda. The customer types an Airtel number and approves on the phone. Keys: `app.online-store.payments.airtel.enabled=true`, `...client-id`, `...client-secret`, `...base-url` (https only) and `...country` (`RW`). Airtel's refund gives back a whole payment and cannot do a part, so **refunds are done by hand**: the screen tells staff to refund from the Airtel Money account and record it with **I refunded it myself** and the Airtel reference. The guide is `docs/online-store-airtel-money.md`.

Put the keys in the **environment of the server** or in the private files `config/application-<provider>-production.properties` that are never committed; never in a file that is copied around. The program never shows or logs them. Replace dots and dashes by underscores and use capitals for an environment variable (`APP_ONLINE_STORE_PAYMENTS_MTN_API_KEY`). **Each customer business has its own keys**: a provider's application is registered in the business's name.

> **Warning:** Both real providers have been tested only against imitations of their systems. Before opening the shop, do a sandbox test, then one small real purchase, one cancelled and refunded order, one part-returned order and one payout, and compare each with the provider's own statement.

Give the provider the **webhook address** shown on the screen: `<your address>/api/public/store/payments/<provider code>/webhook`. A callback is never trusted by itself: the shop asks the provider for the payment's status and accepts the callback only when the provider's own answer agrees, and it also checks every pending payment about once a minute, so a lost call-back only delays the order a little. A payment that does not match its order (another amount or currency, or a double payment) goes to **review** instead of being accepted: watch **Online Store > Online payments**.

**Logos.** Each provider's button shows its logo if the file exists at `frontend/src/assets/payment/<code in lower case>.png` (`mtn_momo.png`, `airtel_money.png`). The MTN and Airtel logos are trademarks and are not shipped: put the official files there and rebuild the frontend; without them the button shows the name.

**Accounts by provider.** In **Online Store > Online payments > Accounts by provider** each provider gets a **clearing account** (what it still owes the shop) and a **payout account** (the wallet or bank account it pays into). MTN and Airtel start with accounts the program creates; a provider with none uses the shared Mobile Money or Card clearing account and its payouts arrive in Cash and Bank. Decide this with the accountant before the first real payment (chapter 6).

Another provider (MOOV, ORANGE, a card gateway, IREMBO) is a small piece of programming for a developer; `docs/online-store-payment-providers.md` describes it. Once it exists it appears in the list and in Accounts by provider.

### Text messages (SMS or WhatsApp)

In **Text messages** choose a **Text provider**, the channel (**Send as**), the **Country code** (250 for Rwanda; it is put in front of numbers that start with 0), **Most texts per day** (default 300; 0 = no limit) and **Text the owner at** a phone number. Nothing is sent until a provider is chosen. The program includes a **test sender** (it sends nothing: every text is listed in **Online Store > Text messages**) and needs a developer to add a real provider (`docs/online-store-text-providers.md`). Order updates are texted only to customers who ticked the box at checkout. The delivery, pick-up, return and new codes are the exception: they are sent by e-mail and by text to the order's phone number whatever the box says. Until a real company is connected the built-in sender keeps those texts as *Waiting for an SMS company* and nothing leaves the server.

### Returns

**Customers can return goods up to this many days after the order is completed** (14 by default; 0 = no returns through the shop). A return of a delivered order is collected by a driver, with a 4-digit return code.

### Newsletter and links in e-mails

The newsletter sign-up and the sending of newsletters need the e-mail settings to be working. The confirmation link in the e-mail, the unsubscribe links, the "View your order" link in every customer e-mail, the driver's link, the share previews and the sitemap are built from the setting `app.frontend-url`: **set it to the public address of the site** (for example `https://shop.yourbusiness.com`, no trailing slash), otherwise the links will point to the wrong place (the default is `http://localhost:4200`).

**Sending limits.** A newsletter started in **Online Store > Send a newsletter** goes out in batches by a job that runs every minute. Two settings (properties or environment variables) control the pace: `app.online-store.newsletter.batch-size` (e-mails per minute, default 25) and `app.online-store.newsletter.daily-limit` (most e-mails in any 24 hours, default 500, 0 = no limit). Set the limit to what your mail provider allows: when it is reached the rest waits until older e-mails are more than 24 hours old, then continues by itself. After five failures in a row the batch pauses and the newsletter shows the reason. An e-mail is marked as taken before it is handed to the mail server, so a crash can lose one e-mail but never sends one twice; a delivery stuck for more than 10 minutes is shown as failed ("Interrupted") and can be retried by staff once checked.

**Abandoned-cart reminders.** Switched on with the box **Send reminders for abandoned carts** (off by default; nothing is saved while it is off). A job looks every 3 minutes for carts due a reminder (first one 1 hour, second one 3 days after the last change) and sends at most `app.online-store.cart-reminders.batch-size` e-mails per pass (default 20). They use the same e-mail settings and `app.frontend-url`. A reminder that fails is tried again 30 minutes later, three times at most. A cart is deleted after 60 days without change. The data kept is the e-mail address, the language, the products and quantities, and the reminder times.

**Loyalty points.** Switched on with **Customers earn and spend loyalty points** (off by default; needs **Customer accounts**). Two numbers: **points earned per 100 paid for the goods** (1 to 100, default 1) and **points may pay at most % of the goods** (0 to 100, default 50); one point is always worth 1 unit of the currency, and points do not expire. These points are **separate from the till's loyalty programme** in Sales. In the books they are a liability (**Loyalty Points Liability**) and the discount shows as **Sales Discounts Given**. Changing the two numbers affects later orders only.

### Link previews, search engines and the installable app

When a shop link is pasted in WhatsApp, Facebook, Telegram and similar apps, a card with the product picture, name and price should appear, and Google should be able to show price, stock and stars. Those programs do not run the shop, so the web server must hand them a small page built by the backend. **Add the nginx rule from `docs/online-store-seo.md`** (a `map` for the crawlers' names, the `location` blocks for `/shop`, `/shop/info/...`, `/_seo/...`, `/sitemap.xml` and `/robots.txt`, using your backend's address), then `nginx -t && nginx -s reload`. Without it the shop works as before but links show no preview. Check with `curl -A "facebookexternalhit/1.1" "https://your-shop/shop?product=12"`: it must return a small page with `og:title` and `product:price:amount`. In Google Search Console, add `sitemap.xml`.

The site can be installed as an app (PWA) from Chrome, Edge, Android and iPhone Safari. This needs **HTTPS**. The app keeps only the program's own files and shop pictures; nothing from `/api` is kept, so no old figure is ever shown as current. A new release is picked up on the next visit; a till is never reloaded in the middle of a sale.

### Behind a reverse proxy

**Behind a reverse proxy** (nginx, IIS, a cloud load balancer): add `server.forward-headers-strategy=native` to the server's settings so that the limit per connection sees each visitor's own address. Without it all visitors share the proxy's address and the limit applies to everybody together.

## Law firm settings (Law firm > Settings)

Practice areas and jurisdictions (one per line); "due soon" window; default billing basis for new matters (Hourly, Fixed fee, Retainer, Contingency, Pro bono); daily e-mail of deadlines and tasks to each lawyer; new matters restricted by default; **limitation date warnings** (first warning n days before, a second 3 days before, and one if the date has passed); and **unpaid fees**: the usual payment term and automatic client reminders listing late invoices with a statement attached.

## Real Estate settings (Real Estate > Settings)

Areas you work in; how long a viewing lasts; when a lead is "quiet"; a morning e-mail to each agent about late and due calls and quiet leads (agents need an e-mail address on their user account); and viewing reminders to the person viewing and the agent.

## Property Management settings (Property management > Settings)

Areas; when a lease is "ending soon"; the day rent usually falls due; the usual management fee % and VAT on it; rent invoicing (how many days before the due date, and automatically every morning); and **owner statements every month** (make last month's statements automatically from a chosen day, and optionally agree them and e-mail owners when they have no warnings). There is also a separate reminder and late-fee page for tenants.

## Settings that are not in a module

**Settings > System settings, Business details, Email settings, Payment methods, Taxes, Scheduled reports, Apps, Backup & Data** are covered in chapters 5, 9 and 10. The **Loyalty**, **Promotions**, **Gift cards** and **Price lists** pages are maintained by staff with the Sales area and are described in the User Manual.
