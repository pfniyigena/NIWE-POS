# About this manual

## Who it is for

This is the **Administrator Manual** for NIWE ERP (the NIWE POS/ERP system). It is written for the person who installs, configures and looks after the system: the business owner, the IT person, or the office manager who holds the **Admin** account. Day-to-day instructions for cashiers, accountants, store keepers and other staff are in the separate **User Manual** and in the **Role quick-start cards**.

You do not need to be a programmer to follow most of this manual. Chapters 2 and 12 (installation and upgrades) are technical and are meant for whoever manages the server.

## How the manual is organised

| Chapter | What it covers |
|---|---|
| 2. Installing and first start | Requirements, database, starting the system, first sign-in |
| 3. Licence and modules | Installation id, licence file, activating and requesting modules |
| 4. Users, roles and permissions | Staff accounts, custom roles, per-person approval rights, branch access |
| 5. Business set-up | Business details, currency, taxes, payment methods, branches, warehouses |
| 6. Accounting set-up | Chart of accounts, cost centers, controls, opening balances |
| 7. Module settings | Where each module keeps its own settings |
| 8. Tills, printers and devices | Thermal printing, cash drawer, customer display, binding a register to a PC |
| 9. E-mail, alerts and scheduled reports | SMTP, business alerts, scheduled reports, daily stock jobs |
| 10. Backup, restore, import and export | Nightly backup, restore, bulk import with check-first, year-end archive |
| 11. Logs and monitoring | Audit log, sign-in log, server logs |
| 12. Upgrades and migrations | Installing a new version, database migrations |
| 13. Security checklist | What to change before going live |
| 14. Troubleshooting | Common problems and what to do |

## Conventions

- Menu paths are written like **Settings > Modules**. The words are exactly as they appear on screen.
- Buttons and fields are written in **bold**.
- Boxes marked *Note*, *Tip* and *Warning* call attention to things that matter. A warning describes something that cannot easily be undone.

## What is new in this edition

This edition covers everything up to **version 1.76.0**. The main administrator-facing additions since version 1.12 are:

- **1.12** Thermal (Epson ESC/POS) printing, cash drawer and COM customer display.
- **1.13** A register can be tied to one known device.
- **1.14** Server logs and the sign-in log; more actions in the audit log; currency follows the chart of accounts (RWF for Rwanda, XAF for Chad).
- **1.15 to 1.22** Improvements to Work Orders, Time Tracking, Booking, Installments, Subscriptions, Help Desk, Expenses and Assets, including new approval permissions (*Approve large expenses*, *Approve large asset disposals*) and new reports available to scheduled reports.
- **1.22.1 to 1.22.5** Fixes and hardening: subscription month-end billing, first-start administrator on a real installation, no password or secret kept in the shipped files, the server logs written next to the jar, and a printable PDF of the modules list.
- **1.23** French. Every user can switch between English and Français from the top bar or the sign-in page, and the business has a default language (Settings > System settings) that follows the chart of accounts: Chad starts in French, Rwanda in English. The core screens are translated: sign-in, menus, dashboard, POS, Sales, Purchases, Inventory, Customers, Accounting and Settings.
- **1.24** French for the other modules: Restaurant, Hotel, Manufacturing, Subscriptions, Installments, Help Desk, HR and Payroll, Time tracking, Work orders, Booking, Law firm, Real estate, Property management, Assets, Gift cards, Loyalty, Promotions, the client portal, My profile and the Invoice list. A phrase without a French version shows in English. Ask a French speaker to read the wording before customers use it.
- **1.25** French for the messages written in the program code (error messages, "Are you sure?" questions, notices), for lists such as status filters, weekdays and permission names, and for the titles and column headings of every report. A fix makes texts that carry a value (for example "3 days left") show correctly in English. Server messages, e-mails and printed PDF documents were still English in this version.
- **1.26** French for the texts the server writes: printed documents (invoices, quotations, receipts, statements, delivery and goods-received notes, payslips, hotel bills, law-firm letters, instalment agreements, the modules list and more), the e-mails sent to customers, tenants, owners, guests, clients and staff, and the messages the server returns (for example "Customer not found"). They follow the **business language** in Settings > System settings, not the language a user picked on their own screen. Dates and amounts are written the French way (5 mars 2026, 1 234,50). Audit trail entries and names already stored in the database stay as they were written. Ask a French speaker to read the wording before customers receive it.
- **1.26.1** Fix: "Failed to create backup directory ./backups" when the server runs as a service. Backups now go to a **backups** folder next to the jar by default.
- **1.26.2** The log files go into a folder named **logs** next to the jar (instead of the jar's folder itself).
- **1.27.0** New optional module **Online Store**: a public shop at `/shop` where customers order for delivery or pick-up and pay in cash. See *Online Store settings* in chapter 7 and the public-side notes in chapter 13.
- **1.28 to 1.34** The Online Store grows: orders can be **paid online** (a test provider and MTN Mobile Money for Rwanda), customers can **sign in** with an e-mailed code, **coupons**, **text messages** (SMS or WhatsApp, through a provider a developer adds), and **returns and refunds** of completed orders. Delivery of order e-mails in the customer's language, alerts for unanswered orders and resized photos.
- **1.35 and 1.36** The shop's **first page** has an announcement bar, header with search, a banner of **uploaded pictures that slide**, four product rows chosen by staff (the rows slide), customer reviews (staff approve them), a newsletter sign-up with e-mail confirmation and a footer with links; new screens **Reviews** and **Newsletter**; **Sellable now** figures under each product explain the stock the shop shows. See *Online Store settings* in chapter 7.
- **1.37** Online Store: **Sales reports** (by day, orders with invoices, payment methods, orders not counted as sales, coupons, best-selling products), counted on the day an order is completed and matching the invoices; they can be e-mailed on a schedule. Needs the Reports area or Operations area for the user.
- **1.38** Online Store: **Send a newsletter** from the program (subject, text, optional button; everyone or only English or French readers; a test e-mail first; sent in batches with a daily limit; progress, stop, retry of failed addresses; each e-mail has the person's own unsubscribe link). New tables by migration V74.
- **1.39** Online Store: **abandoned-cart reminders** (e-mail after 1 hour and after 3 days to visitors who typed an e-mail address at checkout; no discount; a link in every e-mail stops them; **Online Store > Abandoned carts** lists them); off until switched on in Shop settings; new tables (migration V75, runs by itself at start-up).
- **1.40** Online Store: **loyalty points** for signed-in shop customers (earned when an order is completed, spent at checkout as a discount; given back on cancellation, adjusted on returns; **Online Store > Loyalty points** for staff to see and adjust); off until switched on in Shop settings; separate from the till's loyalty programme; new tables (migration V76, runs by itself at start-up).
- **1.41 and 1.42** Online Store: **Airtel Money** as a second payment provider, and **several providers at once**: the customer picks one at checkout. Keys for each provider live only in the server's environment.
- **1.43** Online Store: **Advertising** (advertisers, ads in three places of the shop, a report of views and clicks). Migration V78.
- **1.44 to 1.48** Online Store: a **product page** for each product, search and filters, **ratings (stars, at once) and reviews (words, approved by staff)**, invoice download, address book, wish list, WhatsApp, product rows that slide. Migrations V79 to V82.
- **1.49** The whole site can be **installed as an app** (PWA); nothing from the server is kept offline. Needs https.
- **1.50 to 1.51** Online Store: **product variants** (size, colour, model) from the ERP's own variants; a **contact form** and four **information pages**. Migrations V84 to V86.
- **1.52 to 1.64** Online Store delivery: **drivers**, delivery slips and run sheets; the **delivery code**; the driver's **private link and PIN** page; **driver cash** hand-in; failed and partial deliveries; **delivery time slots**; **return pick-ups**; delivery estimate and tax per area. Migrations V87 to V97. One web-server rule is needed for link previews (chapter 7).
- **1.53 and 1.54** Link previews and search engines (sitemap, robots.txt); **back-in-stock alerts**.
- **1.55** The customer **portal** (`/shop/account`).
- **1.65 to 1.69** Online Store stock and prices: the **stock the shop sells** (Sales locations), stock **held from checkout**, a buffer for each product, automatic release of unanswered orders, expiry dates and serial numbers, cartons, reorder with shop demand, **prices and promotions from Sales**, products sold by weight or length. Migrations V98 to V101.
- **1.70 to 1.76** Online Store **accounting**: returns post VAT and the refund; online payments are held and cleared against **provider payouts**; **Cash with Drivers**; **Sales Discounts Given**, **Delivery Income** and **Loyalty Points Liability**; returns at the cost sold; a branch for the shop; **an account for each payment provider**, chosen on screen. Migrations V102 to V106. New accounts appear in the chart by themselves.

For a list a customer can read, with the steps to take at each upgrade, see the separate **Release and upgrade notes for customers**.
