# Online Store: delivery, drivers and cash

This chapter follows an online delivery order from the moment staff set up the delivery rules to the moment the cash the driver took is handed in. Everything here is on **Online Store > Shop settings** (the setup cards) and **Online Store > Online orders**, **My deliveries**, **Driver cash** and **Returns**.

## Delivery areas, fees and tax

On **Shop settings > Delivery areas** add each area you deliver to. For each area:

- **Fee**: what the customer pays for delivery in that area. With no area the shop delivers anywhere for free; with areas, the customer chooses one.
- **Minimum order**: optional, for that area.
- **Tax**: choose one of your existing taxes, or leave *The delivery product's tax*. The fee you type is **the amount the customer pays**; the tax you choose is the part of it that is tax, **included in the fee**. Example: a fee of 2,000 with VAT 18% is 1,694.92 of fee plus 305.08 of tax; the customer still pays 2,000. So the sale order, the invoice and the cash collected always equal the total the customer saw.
- **Delivery days**: *from* and *to*, in days after the shop accepts the order (0 = the same day). Leave both empty to use the estimate of the whole shop (Shop settings > Front page). The customer sees the estimate of **his** area at checkout (as dates), on the order page and in the "received" and "accepted" messages. The estimate is kept on the order when it is placed.

Under **The shop**, choose the **Service product for the delivery fee**: a *service* product (no stock) that carries the delivery fee on the sale order and the invoice. Without it, an order that has a delivery fee cannot be accepted. When the area has its own tax this product's tax is not used; otherwise give it a tax that is **inclusive** (or none), because a tax added on top would make the invoice, and the cash the driver should hand in, higher than the total the customer saw.

## Delivery times

**Shop settings > Delivery times** lets customers choose a day and a time window. It is switched off until you set it up.

- **Windows**: a from and to time (for example 08:00-11:00, 11:00-14:00, 14:00-17:00, 17:00-20:00), **orders per day** (0 = no limit), the **weekdays** the window exists, and *active*.
- **Switches**: *customers choose a delivery time*, *they must choose one* (off = "As soon as possible" is allowed), **days ahead** (0 to 60) and **notice** (hours before a window starts that it closes, 0 to 72).
- **Days without deliveries**: dates (a holiday, a stock-taking) with an optional reason. No window can be chosen that day.

At checkout, under the address, the customer picks a day (Today, Tomorrow, ...) and a window. A window that is full shows *Full* and one that starts too soon shows *Too late*; neither can be picked, even when two customers order at the same moment. Pick-up orders have no window. A rejected or cancelled order frees its place.

After the order, the window shows on the order page, in the messages, on **Online orders** (where **Change time** lets staff pick any window and day, or go back to *As soon as possible*; the limit does not stop staff), on the driver's page, on the **delivery slip**, and the **run sheet** is sorted by window then area.

## Drivers

A driver is a simple list entry, not an employee record. In **Shop settings > Drivers** add the **name**, **phone** and a **note**, and keep *active* ticked. A driver with orders still to deliver cannot be removed: switch him off instead.

### Giving the order to a driver

Every delivery order (New, Accepted, Packed, Out for delivery) has a **Driver** choice on **Online orders**. Set or change it any time before delivery; the change is written in the history. **Out for delivery** asks for a driver when none is set, as long as the shop has active drivers. Three prints and shortcuts help the driver:

- **Delivery slip (PDF)**: one page per order with the customer, phone, address, area, note, driver, delivery time, the goods, the total, the amount to collect (or *Already paid online: nothing to collect*) and signature lines. Not available for pick-up orders.
- **Run sheet (PDF)**: choose a driver (or *Not assigned*) in the filter above the orders and press **Run sheet**: all his orders still to deliver, grouped by area and sorted by time window, with the number of stops, the cash to collect and a tick column.
- **WhatsApp to the driver**: a link on the order opens WhatsApp to the driver with the order code, customer, phone, address and amount to collect.

Once the order is out for delivery the customer's order page shows **Your driver: name, phone**, and the "on its way" message adds them.

### The driver's private page (no staff login)

A driver does not need a staff account. In **Shop settings > Drivers** press **Give a link** on the driver. The program makes a private link (for example `https://your-shop/driver/...`) and a 4-digit **PIN**. The PIN is shown **once**, at that moment; nobody can read it later. Buttons send the link, and the PIN separately, to the driver on WhatsApp. Staff can later press **Show link**, make a **New PIN**, or **Switch off** the link; any of these signs the driver out at once.

The driver opens the link on his phone, types his PIN, and sees only **his own** orders that are out for delivery: customer, phone (tap to call), address and map, the delivery time, what to collect, and the goods. The page also shows:

- **Cash I hold**: the total of the cash he took at the door and has not handed in (amber when there is something to hand in, green when nothing), the orders behind it, and his last ten hand-ins with the difference. It is the same list staff settle in **Driver cash**. The page refreshes every 20 seconds.
- **Returns to collect**: customers' returns assigned to him (see below).

> **Note:** Safety: the link carries a long secret and the PIN is checked on top of it. Five wrong PINs lock the link for 30 minutes (a new PIN from staff unlocks it). After the PIN the phone keeps a session for up to 14 hours of use. Opening the link on a second phone signs out the first. A driver switched off (not *active*) cannot use his link. The site must be served over HTTPS and `app.frontend-url` must be the public address, so the link is complete.

Staff who prefer to use a phone themselves have the **My deliveries** screen in the menu: pick your name once and it lists the orders out for delivery with the same details.

### Handing over: the delivery code

When an order goes out for delivery (or is ready for pick-up) the customer gets a 4-digit **delivery code** by e-mail and text, in the portal and on his order page. The driver, or the staff at the counter, asks the customer for the code and types it under **Hand over**. The order is then completed exactly as if staff pressed **Complete**: stock out, invoice, cash recorded as collected (it then waits in **Driver cash**), the customer thanked. The code is **never** shown to staff or drivers and is not on the delivery slip.

- Five wrong codes block the code for 30 minutes. A customer who lost the code, or whose code was blocked, gets a new one with **Send a new code to the customer** on the order; the old code stops working.
- The customer can also complete the order himself: **I received my order** on his order page, with an optional drawn signature. A signature given there is kept and printed on the delivery slip. Drivers and the staff screen do not offer signatures: hand-over is by the code. A completed order shows how it was received (customer, code or signature) and **View signature** when there is one.
- A customer's tap does not prove the driver collected the money: check the driver's cash against the run sheet as before.

## When the delivery does not go as planned

Only **staff** record a failed or partial delivery (screen **Online orders**). The driver's page tells him to call the shop.

### Delivery failed

On an order that is out for delivery press **Delivery failed**, choose the reason (customer not at home, customer refused the goods, wrong or unreachable address, no answer on the phone, other) and add details if you like. The order goes back to **Packed** with the reason and the number of tries; the stock stays reserved and the driver stays on the order; the customer is told. Send it out again later (or give it to another driver) or cancel it; from the third failed try the screen suggests cancelling.

When delivery times are on, the old window is **freed at once** and the customer is asked, in the message and on his order page, to **choose a new delivery time** (a day, then a free window, then **Confirm this delivery time**). Staff see *Waiting for a new time* until it is set and can still use **Change time** after phoning the customer. If you made delivery times compulsory, the order cannot go out again until a window is set.

### The customer keeps only part of the goods

Tick the box on an order that is out for delivery (or ready for pick-up), type the quantity **kept** for each line, then **Complete** (or confirm with the customer's code). The invoice, the stock and the cash to collect cover only what the customer kept; what was not delivered is no longer reserved. The delivery fee stays on the invoice. Loyalty points are earned on what was delivered.

If the order was **paid online**, the part that was paid but not delivered shows under **Refunds due** as *Refund due for the goods not delivered*: refund it through the provider or record the refund you made yourself, with its reference. The customer is told. Nothing delivered at all is refused: use **Delivery failed** or cancel the order.

## Return pick-ups

A return of a **delivered** order is **collected from the customer by a driver**, free of charge. In **Online Store > Returns**, when you **Approve** a return of a delivery order, a 4-digit **return code** is made and sent to the customer by e-mail and text ("A driver will come to collect the goods ... Give the code to the driver only when you hand over the goods"). Choose the **driver** at the same time, or later in the **A driver collects the goods** box (you can change or remove him until the goods are collected, and make a **New return code (send again)**).

The driver sees the return under **Returns to collect** on his page, with the customer, phone, address, reason and goods. He taps **Collect the goods**, types the return code the customer gives him and confirms. The return becomes **Collected** (a new tab lists them), the customer and the shop are told, and you then press **Goods received: put back and refund** as usual. Five wrong codes lock that return for 30 minutes; a new code unlocks it. A return of an order picked up at the shop has no address, code or driver: the customer brings the goods back.

## Cash the driver holds

A delivery order paid **in cash on delivery** and completed keeps its cash as **cash to be handed in**. Open **Online Store > Driver cash**:

- the tab **To hand in** shows, for each driver, the total and the orders behind it (customer, delivery time, cash collected);
- the tab **Settled** shows the latest 200 settlements: collected, handed in, difference, who and when, and the reason.

To settle: choose the driver (or *All drivers*), and for each order type what the driver **really handed in** (it starts at the amount collected). A difference needs a **reason** of at least 3 characters. Tick the orders (or **Select all**) and press **Settle the selected**. All the selected orders are settled together or none is.

In the books, the cash the driver took sits in **Cash with Drivers** until he hands it in; the settlement moves what he handed in to **Cash and Bank** and posts a short or surplus amount to **Cash Over / Short**. The order's history says *Driver cash handed in: X (difference Y)*. A settlement cannot be undone on this screen; correct a mistake with a journal entry.

Only delivery orders paid in cash appear here. Orders paid online or by mobile money, and cash taken at the counter on a pick-up, never do. Orders delivered before version 1.72.0 settle with the difference only (see the accounting chapter).

> **Tip:** Check **Cash with Drivers** in the accounts against the *To hand in* total every day. They should agree; a difference means an order was settled twice or a hand-in was posted by hand.
