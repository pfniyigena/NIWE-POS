# Online Store

The **Online Store** module gives your business a public shop on the internet at `/shop` (for example `https://erp.yourbusiness.com/shop`). When the module is on, `/shop` is also the first page a visitor sees at the main address, with a **Staff Login** link for your own people. Customers choose products, order for **delivery** or **pick-up**, and pay **in cash** or **online** (MTN Mobile Money, Airtel Money or card, when your administrator has set up a payment provider). You answer each order, and an accepted order becomes a normal sale order, invoice and payment, so stock, accounting and reports stay in one place.

The module must be in your licence and activated by an administrator (Settings > Modules). The **Online Store** group then appears in the menu. Staff need the **Operations** area to use it. The chapters about the Online Store are:

- **This chapter**: what the shop looks like, how to set it up, why a product may say *Sold out*, what the customer does, how staff answer orders, refunds, coupons, returns, reviews, messages, newsletter, abandoned carts, loyalty points and text messages.
- **Online Store: delivery, drivers and cash** (next chapter): delivery areas and tax, delivery times, drivers and their private page, the delivery code, failed and partial deliveries, return pick-ups and the cash drivers hold.
- **Online Store: payments, accounting and reports** (the chapter after): payment providers, payouts, how an order reaches the books, advertising, sales reports and the accountant's checks.

The menu entries are: **Online orders**, **My deliveries**, **Driver cash**, **Online payments**, **Returns**, **Coupons**, **Reviews**, **Messages**, **Waiting customers**, **Shop pages**, **Newsletter**, **Send a newsletter**, **Abandoned carts**, **Loyalty points**, **Advertising**, **Sales reports**, **Text messages**, **Shop settings** and **Open the shop**.

## What a visitor sees

### The first page

From top to bottom, the first page of the shop shows:

1. an **announcement bar** (a short message, optionally a link);
2. the **header** with the shop name or logo, a **search** box, the wish list heart, the cart, the **account** button and **Staff Login**;
3. the **banner**: your pictures sliding one after the other, with a title, a text and a button;
4. an **advertisement** (when you sell advertising space, see the payments and reports chapter);
5. rows of products you choose: **Featured products**, **Best-selling products**, **Special offers and discounts**, **New arrivals** and, for a returning visitor, **Recently viewed**. Each row stays on one line and moves with its arrow buttons, the mouse wheel or a swipe of the finger. By default it does not move by itself; you can switch that on in Shop settings > Front page (**Product rows slide by themselves**);
6. **Shop by category**: a tile for each category with a picture of one of its products and the number of products;
7. the shop's **overall rating** (the average of the stars, how many ratings, and how many of each star) and the written **customer reviews**;
8. a **newsletter** sign-up;
9. the **footer** with quick links, contact details, opening hours, an "about" text, links to your social pages and the information pages (Terms and Conditions, Privacy Policy, Returns and Refunds, Delivery and Shipping, Contact us);
10. below the rows, **All products** with the category buttons.

A part with nothing to show (no featured product, no review yet, no announcement) is simply left out. When a visitor searches or picks a category, the page goes straight to the matching products.

### Finding a product

- **Search**: every word typed must be found in the name, the title on the shop, the SKU, the barcode, the brand, the category or the description, in any order, so "hose garden" finds "20m Garden Hose". Suggestions (products, categories and brands) appear while typing.
- **Filters**: price range (as the customer sees it, tax included), brand, rating (4, 3 or 2 stars and up) and *in stock only*. **Sort** by recommended, newest, most popular (units sold on online orders), best rated, or price. **Clear filters** resets them.
- **Product cards** have the same size everywhere: picture, name, price (the normal price crossed out and a **-NN%** badge on an offer), stars with the number of ratings, **In stock**, **Few left** or **Out of stock**, a **Quick view** window and **Add to cart**. A product sold by weight or length shows "/ kg" or "/ m" next to the price.

### The product page

Opening a product leads to its own page, at `/shop?product=ID`, which can be shared or bookmarked. It shows a big picture with a gallery (hover zoom, full-screen view), the price, the stock word, a quantity box and **Add to cart**, the full description, a table of specifications, the stars with a breakdown and the approved reviews, a **Delivery** box (the cheapest fee, the free-delivery amount, the pick-up address and an estimated delivery date range), **Share on WhatsApp**, a heart for the wish list, **Related products**, **Frequently bought together** (with **Add all to cart**) and **Recently viewed**.

- **Products with options.** A product with sizes, colours or models (Products > Variants) is **one card**, with one button per value. The price, stock, SKU and pictures change with the choice. An option that is sold out stays visible, greyed, and cannot be added. A card says **Starting at** when the options do not all cost the same.
- **Sold out? "Tell me when it is back."** On a sold-out product (or option) the customer leaves an e-mail address and/or a phone number. The shop tells them once when the product can be sold again (see *Waiting customers* below).
- **Prices.** A product with no online price follows the shop's **price list** and the best promotion from Sales (a percent or amount off the product or its category); the normal price is crossed out. See *Prices* below.

## Setting up the shop (manager)

Open **Online Store > Shop settings**. The page is a series of cards; each has its own **Save**.

### Products on the shop

Search a product and press **Add**. Only products you add here are shown or sold online. For each product you can set:

- **Title on the shop** and **Online price** (leave the price empty to use the normal price or the offer from Sales; an online price below the normal price shows the normal price crossed out as an offer);
- **Order**: the lower number comes first;
- **Shown**: untick to hide the product for a while;
- the four row ticks **Featured**, **Best seller**, **Offer** and **New**: the shop never picks products by itself, you decide which products appear in each row (up to 8 per row; the first three rows follow the **Order** number, **New arrivals** shows the most recently added first). Press **Save** at the end of the product's card;
- **Sold by (kg, m ...)**: for rice, cloth, cheese and other goods sold by weight or length. The customer may order decimals (0.1 to 100, three decimals);
- **Buffer for this product**: its own safety buffer (empty = the shop-wide one);
- **Product page: pictures, description, specifications**: write the description, add up to 5 more pictures (5 MB each, reorder, remove) and up to 20 specification rows (name and value). The product's own picture is always the first.

A product with options is **one row**: **Options: price, stock, pictures** opens the list of its options with SKU, normal price, stock, an **Online price** for each, a **Sold online** switch and pictures of their own. Put the template of the product on the shop and all its options follow; new options added in Products > Variants appear by themselves within five minutes.

The picture is the product's own picture: add one on the product screen. Under every product the screen shows where its stock figure comes from (see *Why does the shop say "Sold out"?* below).

### Front page wording

In **Front page** write what the first page says. Everything is optional.

- **Announcement bar** and its **link**; **Banner title**, **Banner text**, **Banner button text** and **Banner button link** (empty = down to the products).
- **Banner pictures**: choose up to **8 pictures** (JPEG, PNG, WebP or GIF, 8 MB each; you can choose several at once). Use the arrows to put them in order and **Remove** to take one away. A wide picture, about 1600 × 600 pixels, looks best. With no picture the banner is a plain colour.
- **About the shop**, **Contact e-mail**, **WhatsApp number of the shop** and **Opening hours**.
- **Shop colour** for buttons and the announcement bar, and the **estimated delivery time** in days (for example 2 to 4), which the product page uses (a delivery area can have its own, see the next chapter).
- **Footer links** and **Social links**: one per line, written **Label|address**, for example `Delivery|/shop` or `Facebook|https://facebook.com/yourshop`. At most 8 and 6. An address must start with `/` (a page of this site), `https://`, `http://`, `mailto:` or `tel:`; anything else is refused.

Press **Save the front page**, then **Open the shop** to look at it.

### The shop switches

1. **The shop**: set **Delivery**, **Pick-up** and **Pay cash on delivery or at pick-up**, the **Pick-up address**, the **Minimum order**, **Free delivery from** an amount, and the **Service product for the delivery fee** (see the next chapter).
2. **Customer accounts**, **Text messages**, **Returns** (how many days after completion a customer may return goods; 0 = no returns through the shop) and **Online payments** are switched on here too. Your administrator sets up the providers (Administrator Manual, chapter 7).
3. **Branch the shop sells for**: shown only when the business has more than one branch. The shop's sale orders, invoices, payments and loyalty entries carry this branch, so branch reports include the shop. Head office is the default.
4. Tick **Shop is open to the public** and **Save settings**. Use **Pause orders for now** to stop taking orders without taking the page down; the message you write is shown to visitors.
5. Press **Open the shop** and place a test order before telling customers.

*Tip:* Prices on the shop include tax.

### Shop pages

**Online Store > Shop pages** holds the four information pages every shop needs: Terms and Conditions, Privacy Policy, Returns and Refunds, and Delivery and Shipping. Each starts with a general starter text in English and French with the shop's name, phone, e-mail and address filled in. You can edit the title and the text of each (paragraphs; a line starting with `## ` is a heading, one starting with `- ` is a bullet; `{shop}`, `{phone}`, `{email}` and `{address}` are replaced by the shop's details), switch a page off, or go back to the starter text.

> **Warning:** The starter texts are a general beginning, **not legal advice**. Read them, adapt them to your business and your country, and have them checked before you open the shop. A page you have saved is shown as you wrote it to every visitor, in one language. The checkout says "By placing your order you agree to ..." with links to the pages that are shown.

### Install the shop as an app

The whole site, the shop included, can be installed on a phone or computer like an app (Chrome, Edge and Android offer an **Install the app** card; on an iPhone use Share > Add to Home Screen). The shop installs under the shop's own name and colour, the staff screens as "NIWE ERP". The installed app opens even without a connection, with a red strip "You are offline", but **nothing from the server is kept**: sales, stock and prices always come from the server, so an order cannot be placed offline. (The till has its own queue for sales when the connection drops; see the POS chapter.)

## Why does the shop say "Sold out"?

You do **not** need a separate stock for the shop. The shop uses the same stock as the till and the warehouses:

> stock in the **sellable locations** of your warehouses − quantities **reserved** on confirmed sales orders − units **held** by shop orders nobody has answered yet − the product's **buffer** − the **share kept for the till** = what the shop may still sell

The line under each product in **Products on the shop** shows every one of these numbers: in the sellable locations, reserved on confirmed orders, held by orders nobody answered yet, the buffer, the share kept for the till, what is expired or too close to its expiry date, and **sellable now**. When the last one is 0 or less the shop says *Sold out*. The card word, *Only n left*, the *In stock* filter, the check at checkout and the back-in-stock alerts all use this same figure. If the line says *Stock is not tracked for this product*, the shop always shows it as available.

What counts as **sellable locations**: with several warehouses in use, only **Sales** locations outside the **Main warehouse**. Shop settings > **Stock the shop sells from** lets you choose one Sales location, or *Automatic* (all of them). Goods sitting in *Receiving*, *Storage*, *Damaged* or an inactive location are not counted. With one warehouse nothing changes.

What the settings do:

- **Units kept back for the till** (shop-wide buffer, 1 unless you changed it) and **Buffer for this product** (its own, wins over the shop-wide one).
- **Share kept for the till (%)**: this share of the available units of every product is kept back for the till (rounded up), on top of the buffer.
- **Release unanswered orders after (hours)**: default 24, 0 = never. A shop order **holds its units from the moment it is placed**, so two customers cannot be sold the same last units. An order waiting for a payment, or a cash order nobody accepted, is cancelled after this many hours and its stock is free again; the customer is told. An order **paid online** is never cancelled this way: staff must answer it.
- **Do not sell goods with fewer days left than** (default 0): for batch-tracked products, expired batches are never sold; with a number here, batches closer to their expiry date are left out as well. Deliveries take the batches the shop may sell first, earliest expiry first.
- **Cartons**: when breakdown is on in Inventory, the units that can be had by opening cartons count as stock, and cartons are opened automatically when an order is accepted or delivered.

When a product says sold out and you believe you have stock, look for:

| What you see | Usual reason | What to do |
|---|---|---|
| Sellable now is exactly 0 and the stock is 1 | The buffer of 1 | Lower **Units kept back for the till** (or the product's own buffer) to 0 |
| The stock figure is 0 but the product has stock | The stock sits in a location that is not sellable (*Receiving*, *Damaged*, the Main warehouse, an inactive location) or was never entered per warehouse | Open **Inventory** and the product's stock; move the goods to a sales location with a stock transfer (see the Inventory chapter) |
| Stock and reserved are both high | The goods are already promised on confirmed sales orders, including accepted online orders | Complete or cancel those orders, or add stock |
| *Held by unanswered orders* is high | Orders placed but not yet accepted hold their units | Answer the orders in **New** |
| *Expired or too close to expiry* shows a number | Those batches are left out of the figure | Sell them at the till, or change the setting |

Stock that arrives on a purchase receipt sits in the *Receiving* location until it is moved to a *Sales* location. The **Reorder** screen subtracts the units of shop orders nobody has answered yet and counts customers waiting for a back-in-stock e-mail as demand (columns **Online orders** and **Waiting customers**); the stock valuation report has an **Online orders** column.

## Prices

A product with an **Online price** is sold at that price. A product with no online price follows **Shop settings > Price list used by the shop** and the best **promotion** from Sales that applies to everybody on the product or its category; the normal price is crossed out. Prices are recalculated every 2 minutes; press **Apply now** to see a change at once. Promotions that need a coupon, a customer group, a limit, a minimum, "buy X get Y", or that apply to the whole cart, are **not** applied online. The product row shows "Offer from Sales: price (name)".

## What the customer does

The customer opens `/shop`, searches or picks a category, adds products to the cart, and presses **Proceed to checkout**. They choose **Delivery** or **Pick-up**, give a name and a phone number (an e-mail address is optional), and for delivery an area, an address and, when the shop offers delivery times, a day and a time window. A signed-in customer picks one of the **saved addresses** or saves a new one. Then they choose how to pay:

- **Cash on delivery** or **Cash at pick-up**. After **Place order** the order reaches you at once.
- **Mobile money** (they type the number to pay from and approve on their phone) or **Card**. When more than one provider can take the chosen way to pay, a **Pay with** row shows one button per provider (with its logo when you have added it). After **Place order and pay** the order reaches you only once the payment is **confirmed**.
- A **coupon code** can be typed and checked with **Apply** before ordering (when you have an active coupon), and a signed-in customer can **use loyalty points**.
- When text messages are on, a box offers updates about the order by text (or WhatsApp).

They then see an order **code**. The page `/shop/order/<code>` shows where the order is, the delivery estimate, the driver once the order is out, the **delivery code**, lets them cancel it while it is new, **order again**, **Download invoice (PDF)** once completed, **Send this order to the shop on WhatsApp**, ask for a **return** and **rate** the products. If they gave an e-mail address, they receive a message when the order is received, accepted, on its way or ready, completed or refused, each ending with a link **View your order**.

### The customer's account

A customer may **sign in** (the account button at the top of the shop): they type their e-mail address (or a saved phone number), receive a one-time code valid for 10 minutes, and enter the portal. No password is needed, and buying as a guest always works. The portal is at `/shop/account` and has a menu with one page for each:

- **My orders**: all orders, filtered All / In progress / Delivered / Cancelled, with **Track**, **Order again** (fills the cart with today's products and prices) and **Invoice** (PDF) on each completed order, and the delivery code of an order that is on its way.
- **My invoices**: one line per invoice, with **Download (PDF)**.
- **My wish list**: the hearted products with price and stock and **Add to cart**. Guests keep their hearts in their browser; they join the account at sign-in.
- **My returns**: every return asked for, with its status, the goods, the reason, the shop's note, the return code and driver, and the amount refunded.
- **My addresses**: up to 10 delivery addresses (name, area, address, a default).
- **Loyalty points** (when the shop has them) and **My profile**, with sign-out and **delete my account**.

### Ratings and reviews

A customer who bought a product on a **completed** order can rate it from the order page, once per product per order. The **rating** (1 to 5 stars) counts **at once**; the **review** (optional words) is shown only after staff approve it. A rating without words has nothing to check, so nothing waits. Only real ratings exist: staff cannot add one.

## Answering orders (staff)

Open **Online Store > Online orders**. The tabs are **New**, **Awaiting payment**, **Open**, **Refunds due**, **Completed**, **Rejected**, **Cancelled** and **Everything**, each with its number. The **New** tab lists orders waiting for an answer, with a *late* mark when one has waited too long. The list refreshes by itself, so it can stay open on a counter screen. Buttons at the top lead to **Returns**, **Online payments** (with the number needing attention) and **Shop settings**.

- **Accept** creates a confirmed sale order that holds the stock. If the stock does not cover the order, the screen says so and offers **Accept anyway**; the sale order is then over-promised until stock arrives. Phone the customer if you are unsure. An order paid online is already paid: there is no cash to collect.
- **Reject** needs a reason; the customer sees it. An order paid online and rejected shows under **Refunds due**.
- **Driver**: on a delivery order, choose the driver (see the next chapter), print the **Delivery slip** or the **Run sheet**, or send the order to the driver on WhatsApp.
- **Mark packed** (optional), then **Out for delivery** for a delivery or **Ready for pick-up** for a pick-up. The customer is told and receives a 4-digit **delivery code** (or pick-up code) by e-mail and text.
- **Complete** hands the order over. The person who receives the goods gives the 4-digit code, which you type; this takes the stock out through the sale order, issues the invoice, records the payment, sends the invoice by e-mail and gives the loyalty points. For a cash order the cash is recorded as collected. A customer who lost the code can have it sent again with **Send a new code to the customer**: staff never see the code itself.
- **Delivery failed** and **The customer keeps only part of the goods** are described in the next chapter.
- **Cancel order** (accepted but not completed) cancels the sale order and releases the stock.
- **Awaiting payment** lists orders whose customer has not paid yet. They come to **New** when the payment is confirmed. A payment the customer does not approve within **Minutes the customer has to pay** (30 unless changed in the shop settings) expires, and the customer can try again from the order page.
- A customer who also gave a WhatsApp-capable phone has a **WhatsApp** link beside the number.

A discount from a coupon or loyalty points is shown on the order. **History** lists every step with who did it and when, including whether the code message went by e-mail and text.

The batch-tracked or **serial-numbered** goods delivered show their serial numbers on the order, on the customer's order page and on the invoice.

## Refunds of online payments

When a customer who paid online cancels, or you reject the order, the order moves to **Refunds due**. Open it and press **Refund through the provider** to give the money back through the payment provider. If the provider cannot do it (Airtel Money refunds are done by hand), refund by hand outside the program, type the **reference** of your refund and press **I refunded it myself**. Once an order is completed, goods coming back go through **Returns** (below). The accounting entries of every refund are described in the payments and accounting chapter.

## Coupons

**Online Store > Coupons** holds the codes a customer types at checkout. When at least one coupon is active, the shop shows a coupon box.

- A coupon gives **Percent off the items** (with an optional *Never more than* amount), **Amount off the items**, or **Free delivery**.
- Optional limits: **Minimum order**, **Valid from**, **Valid until**, **Orders it can be used on**, and **Once per customer** (the same phone number or account).
- A rejected or cancelled order gives its use back. The discount is part of the sale order and the invoice, so the invoice always equals what the customer paid. In the books the discount is shown in **Sales Discounts Given**, not taken off Sales Revenue.
- One coupon per order, and it applies to the whole order, not to one product.

## Returns

A customer can ask to return goods from a **completed** order, within the number of days set in the shop settings (14 unless changed), from their order page or from **My returns**. They choose the items and quantities, give a reason and the phone number of the order (not needed when signed in).

1. Open **Online Store > Returns**. The **Waiting** tab lists new requests. Press **Approve** or **Refuse** (a note for the customer is needed to refuse).
2. For a **delivery** order a driver collects the goods at the customer's door, free of charge (next chapter). For an order the customer **picked up** at the shop, the customer brings the goods back.
3. When the goods are back, press **Goods received: put back and refund** (it works from **Approved** and from **Collected**), choose where the goods go back in, and give the money back: **Refund through the provider** for an online payment, or the same by hand with its reference; for a cash order the screen says how much cash to hand back. For **serial-numbered** lines, tick the serial numbers that came back; they are in stock again.
4. The goods go back into stock through a normal sale order return, so stock, revenue, VAT and reports follow. The goods return to Inventory at the **cost they were sold at**. A coupon discount follows the goods (the customer gets back what they paid for them); the **delivery fee is not refunded**. Loyalty points follow the goods too.

The customer is e-mailed (and texted) at each step. Exchanges, store credit and restocking fees are not part of this screen.

## Reviews

Open **Online Store > Reviews**. The tabs are **Waiting** (new written reviews), **Shown**, **Rating only**, **Hidden** and **Everything**. **Approve** shows the words on the shop, **Hide** keeps them but does not show them, **Delete** removes the entry for good. Two more buttons act on the stars: **Remove rating** keeps an unfair rating out of the averages and **Count rating again** brings it back. The shop's overall rating and the stars on cards and product pages follow at once.

## Messages (contact form)

The shop has a **Contact us** page with the shop's phone, e-mail, WhatsApp, address and opening hours and a form (name, e-mail, phone, subject, message, an optional order code). The visitor must give an e-mail or a phone number so that you can answer. Open **Online Store > Messages**: the tabs **New**, **Answered** and **Everything** have a search box. For each message you can **Reply by e-mail** (a box opens: write the answer, press **Send the answer**; it goes from the shop's e-mail, in the customer's language, with the message quoted, and the message becomes Answered), use the **WhatsApp** button, write a note, **Mark as answered** or **Mark as new** again, or **Delete**. The shop is told of each new message by e-mail (and by text when the owner alert is set up), and the visitor who gave an e-mail gets a copy. A visitor who gave only a phone number cannot be answered by e-mail: use the phone or WhatsApp.

## Waiting customers (back-in-stock alerts)

**Online Store > Waiting customers** lists the products customers asked to be told about, **the most wanted first**, so you know what to restock; it says *back in stock* when a product can be sold again. Below it is the list of people (**Waiting**, **Told**, **Could not be told**, **Everything**, with a search box). The shop looks every five minutes: as soon as a product can be sold again, each waiting customer gets **one** e-mail in their language (and one text message when text messages are on), and the request is closed. If sending fails it is tried three times and then marked **Could not be told**. Customers whose only contact is a phone number while text messages are off stay **Waiting** for you: use the **WhatsApp** button (the message and the link are already written), then **Mark as told**. **Tell them now** runs the notice at once; **Remove** deletes a request.

## Newsletter

Visitors can ask for your newsletter at the bottom of the first page. The shop sends them an e-mail with a link; they are counted only after they open it. Open **Online Store > Newsletter** to see the list (**Subscribed**, **Not confirmed**, **Unsubscribed**), to **Remove** an address, and to **Download confirmed addresses (CSV)**, with each person's own unsubscribe link, for a mailing tool.

### Sending a newsletter

Open **Online Store > Send a newsletter** (also a button on the Newsletter screen) and press **New newsletter**.

1. Type the **Subject** and the **Message**. A blank line starts a new paragraph. The message is plain text: nothing you type is treated as formatting or code. You may add one **button** with its text and a link that starts with `https://` or `/` (for example `/shop`).
2. Choose **Who gets it**: everyone who confirmed, only the English readers, or only the French readers (each person's language is the one they had when they signed up). The number of people is shown.
3. Press **Save draft**, type your own e-mail address and press **Send me a test**. The test looks like the real e-mail and has [TEST] in the subject. Change the draft and test again as often as you like.
4. Press **Send to N people** and confirm. The list is fixed at that moment.

The shop name and **each person's own unsubscribe link** are added at the bottom of every e-mail automatically, in the person's language. The e-mails do not leave all at once: a small batch goes out about every minute, and there is a limit per 24 hours (500 unless your administrator changed it) so your mail server does not block you. Open the newsletter from the list to follow it: a bar and the numbers **Sent**, **Waiting**, **Failed** and **Skipped**. The page updates by itself.

- **Stop sending** stops the rest. What was already sent stays sent, and a stopped newsletter cannot be started again (write a new one).
- **Skipped** are people who unsubscribed (or were removed) after you pressed send but before their turn: they get nothing.
- **Failed** addresses are listed with the reason the mail server gave. After you have fixed the cause (for example the e-mail settings; an address with a typo can only be removed), press **Try the failed ones again**: only those are tried, nobody gets a second copy. If five e-mails fail one after another, sending pauses and shows the reason; fix it and press **Try the failed ones again**.
- Pressing **Send** twice, or two people pressing it, cannot send a newsletter twice. A sent newsletter stays in the list as a record; only a draft can be changed or deleted.

> **Note:** The newsletter needs the e-mail settings of the business to be working (Administrator Manual, chapter 9), and `app.frontend-url` must be the public address of the site (Administrator Manual, chapter 7), or the unsubscribe links will be wrong.

## Abandoned carts

Many visitors fill a cart and then leave. When your manager switches on **Send reminders for abandoned carts** (Shop settings), the shop can remind the ones who typed an **e-mail address** at checkout.

- **What the customer sees.** Under the e-mail box a short notice says the shop may remind them about their cart by e-mail, and that every e-mail has a link to stop the reminders. Nothing is saved until the customer has typed an address that looks right (guests too: no account is needed).
- **Two reminders, no discount.** The first goes out about **1 hour** after the customer last changed the cart, the second **3 days** after. The e-mail lists the cart as the shop is today (current prices; what is sold out is named as no longer available) with a button **Go back to my cart**. The e-mail is in the language the customer was using on the shop.
- **Nobody is pestered.** An address that **orders** is not reminded any more. A link at the bottom of each e-mail (**Stop these reminders**) stops them at once and for good. A cart whose items are all gone, or that is more than 2 days old when its first reminder would go out, is dropped without an e-mail.
- **Your screen.** **Online Store > Abandoned carts** shows the numbers (Waiting, Reminded once, Reminded twice, Ordered, Stopped, Nothing to remind) and a list with the e-mail address, the products and pieces, the last change and when each reminder went out. Press a number to filter. **Remove** deletes a cart and its address (for example when a customer asks to be forgotten). Carts untouched for two months are deleted by themselves.

> **Note:** The reminders need the e-mail settings of the business to be working and `app.frontend-url` set to the public address of the site. They are off until you tick the box, and nothing is saved while they are off.

## Loyalty points

When your manager switches on **Customers earn and spend loyalty points** (Shop settings; it needs Customer accounts to be on), customers who are **signed in** earn points and spend them on later orders. Guests earn nothing: the points belong to the account. These points are the shop's own and are separate from the loyalty programme at the till (Sales).

- **Earning.** When an order is **completed** the customer earns points on what they paid for the goods: **1 point for every 100** by default (your manager can change it), after any coupon or points discount and without the delivery fee. On a partial delivery they earn on what was delivered.
- **Spending.** At checkout a signed-in customer with points sees **Use loyalty points**: they type how many, or press **Use the most I can**. **One point takes 1 off** (1 unit of the shop's currency), and points can pay at most a share of the goods (50% by default) that is left after a coupon. The shop checks the balance again when the order is sent, so the same points can never be spent twice.
- **Their balance.** In the portal (**Loyalty points**) the customer sees the balance and the history (earned, used, returned).
- **Cancelled or refused orders** give the spent points back. **Returned goods** give back the matching share of the points spent on them and take back the matching share of the points they earned; if the customer has already spent those points the balance can go below zero until they earn more.
- **Your screen.** **Online Store > Loyalty points** lists the customer accounts with their points (the most first, with a search box), shows the history of one customer, and lets you **add or remove points** with a reason.
- **In your books.** Points earned are an expense and a liability (**Loyalty Points Liability**); points spent on a delivered order release the liability, and the cost then shows as **Sales Discounts Given**. Points never expire, and deleting a customer's account deletes their points history. Points earned before version 1.73.0 are not in the liability; your accountant posts an opening entry for the points customers already hold.

## Text messages

When your administrator has chosen a text provider, the shop can text customers about their order (only those who ticked the box at checkout), text sign-in codes, and text you about new orders. The **delivery code**, **pick-up code**, **return code** and **new code** are the exception: they are sent by e-mail **and** by text to the phone number of the order whether or not the box was ticked, because the code is part of the delivery. **Online Store > Text messages** lists every text, also the ones that failed or were not sent, and has a **Send test message** form. There is a daily limit to keep the cost in check. Until a real text company is connected, a built-in sender keeps every code text in the list marked **Waiting for an SMS company**: nothing leaves the server, and the e-mail still goes. The code itself is never written in the text list.

## Good to know

- Online orders from a phone number that already exists in **Customers** attach to that customer; otherwise a customer is created.
- A customer may have only a few orders waiting for an answer at once, and a script that sends many orders from one connection is slowed down. These limits are in **Shop settings**.
- Link previews: when a shop link is pasted in WhatsApp, Facebook, Telegram and similar apps, a card appears with the product picture, name and price, and Google can show price, stock and stars. The administrator adds one rule to the web server for this (Administrator Manual, chapter 7); without it the shop works but links show no preview.
- Newsletters are plain text with one optional button, with no pictures, and cannot be scheduled for later. Online orders also appear in the normal sales reports.
