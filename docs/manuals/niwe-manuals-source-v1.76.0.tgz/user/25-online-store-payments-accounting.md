# Online Store: payments, accounting and reports

This chapter is for the person who watches the money of the shop: the owner, the cashier who records payouts, and the accountant. It explains the **Online payments** screen, how each payment provider is booked, what the program posts at each step of an order, the weekly and monthly checks, advertising and the sales reports.

## Online payments (screen)

**Online Store > Online payments** lists every online payment for a period, with cards for **Paid**, **In the books**, **Held for open orders**, **Refunds due**, **Refunded**, **To review** and **Failed or expired**. Use the filters (**Under review**, **Refunds due**, **Stuck pending**, **Paid**, **Pending**, **Failed**, **Expired**) to see what needs a person:

- **Under review**: money arrived that needs a person, for example a different amount than the order, or a second payment for the same order. Such a payment is **not in the books** until a person has dealt with it. Look at it, deal with it (for instance refund the extra), write what you did and press **Mark as dealt with**.
- **Refunds due** (press *Go to the orders to refund it*) and **Stuck pending** (a payment still pending long after it should have closed).

The card **Needs attention** on the Online orders screen shows how many payments wait for a person.

### Payment providers

The customer chooses a provider at checkout when more than one can take the way to pay. The providers are switched on by your administrator (Administrator Manual, chapter 7) and chosen in **Shop settings > Online payments**:

- **MTN Mobile Money (MoMo)** for Rwanda: the customer types an MTN number and approves on the phone. Refunds can go back through MTN.
- **Airtel Money** for Rwanda: the customer types an Airtel number and approves on the phone. **Refunds are done by hand**: refund from the Airtel Money account, then record it with **I refunded it myself** and the Airtel reference.
- **Card**, when a card provider has been connected.
- **A simulated provider** exists for tests only; never use it with real customers.

A callback from a provider is never believed on its own: the shop asks the provider for the payment's status and accepts the callback only when the provider's own answer agrees. A lost callback is covered by a status check about once a minute.

## Where the money goes: accounts of each provider

Money paid online is **not** cash in your hand. The provider holds it until it pays you out. So each provider has two accounts in your chart of accounts:

- **What the provider still owes you** (the *clearing* account): payments the provider confirmed and has not yet paid out.
- **Payouts arrive in** (the *payout* account): the wallet or bank account the provider pays into.

With the Rwanda chart, MTN Mobile Money uses clearing account 1021 and wallet 1011; Airtel Money uses 1022 and 1012; Card uses 1030 and the bank account 1013 for card settlements. (Chad chart: 5215 and 5217, 5216 and 5218, 5213 and 5219.) The old shared Mobile Money Clearing (1020, Chad 5212) stays for the test provider and for orders paid before these accounts existed.

Open **Online Store > Online payments > Accounts by provider** to see every provider, switched on or not, and choose its two accounts. Each can be an existing asset account or a new one created on the spot (**Create a new account...**, with a suggested name and the next free code). **None** for the payout account means Cash and Bank. When you add a new provider (MOOV, ORANGE, a bank gateway), it appears in this list once a developer has connected it, and you choose its accounts here.

Rules the screen enforces:

- a clearing account belongs to **one** provider and must be an ordinary asset account (not Cash and Bank or another system account);
- a clearing account **cannot be changed while the provider still owes you money on it**: record its payouts first;
- a payout account may be shared (for example one bank account for all card payouts);
- the clearing and payout accounts of a provider must be different.

Orders paid before you set or changed the accounts keep using the accounts they were booked to, so no balance moves.

## What the program posts for an online order

You do not post any of this by hand; it is here so that the accountant can follow the entries. Every entry's description ends with the order code, for example *(online order 9FMMY2MC)*, so searching the journal for the code finds all the entries of an order.

| When | Debit | Credit |
|---|---|---|
| The provider confirms the payment | The provider's clearing account | Online Customer Deposits (2810) |
| The order is delivered: the deposit is applied to the invoice | Online Customer Deposits | Accounts Receivable |
| The order is delivered: goods, VAT and cost | Accounts Receivable; Cost of Goods Sold | Sales Revenue, VAT Payable; Inventory |
| The order is delivered: the discount and the delivery fee are shown apart | Sales Discounts Given (4040); Sales Revenue (the fee) | Sales Revenue (the discount); Delivery Income (4030) |
| A paid order is cancelled or rejected and the money is paid back | Online Customer Deposits | The provider's clearing account (refund through the provider) or Cash and Bank (refunded by hand) |
| Part of a paid order is not delivered and the difference is paid back | Online Customer Deposits | The same |
| Goods are returned and refunded | Sales Revenue, VAT Payable, Inventory (at the cost sold); Accounts Receivable | Accounts Receivable, Cost of Goods Sold; the provider's clearing account or Cash and Bank |
| A cash order is delivered | Cash with Drivers (1050) | Accounts Receivable |
| The driver hands in the cash | Cash and Bank (what he handed in); Cash Over / Short if short | Cash with Drivers; Cash Over / Short if over |
| A customer earns loyalty points | Customer Rewards Expense | Loyalty Points Liability (2820) |
| Points are spent on a delivered order | Loyalty Points Liability | Customer Rewards Expense |
| The provider pays out | The provider's payout account (net); Payment Provider Fees (5240) | The provider's clearing account (gross) |

Things to know:

- **Sales Revenue shows the full price of the goods.** The coupon and points discount is in **Sales Discounts Given**, before tax, and the delivery fee is in **Delivery Income**, before tax. The total income of an order does not change.
- **A return reverses the VAT too**, not only the net price, and the goods go back into Inventory at the cost they had when they were sold, not at today's cost price. A cash-on-delivery order whose payment was never collected has nothing to hand back: no cash entry.
- Nothing is booked for an order that is **cancelled or rejected** before delivery, except the deposit paid back when it was paid online.
- **Branch**: with more than one branch, the shop's entries carry the branch chosen in Shop settings > *Branch the shop sells for*.
- **Orders from before the accounting releases.** Orders paid before version 1.71.0 have no deposit: their payment is booked to the provider's clearing account when they are delivered. Orders delivered before version 1.72.0 settle driver cash with the difference only. Returns made before version 1.70.0 keep their old net refund figure. Loyalty points earned before version 1.73.0 are not in the liability: post one manual opening entry for the points customers already hold (Dr Customer Rewards Expense, Cr Loyalty Points Liability, one point = one unit of currency).

## Payouts: recording what the provider paid you

Open **Online Store > Online payments > Payouts from the providers**. It shows one balance per provider with a clearing account, then Card: **what the provider still owes you**. These balances come straight from the ledger (debits minus credits), so they always agree with the books.

To record a payout, choose the provider (**Way**), type **Paid by customers (gross)** (the total of the payments this payout covers), the **Provider fee**, the **Date** and a **Reference** from the provider's statement, and press **Record payout**. **Reached the bank** is worked out for you (gross minus fee). The net goes to the provider's payout account and the fee to **Payment Provider Fees**. If a provider pays out net of its fee and of refunds, still enter the gross the payout covers and the fee, so the rest reaches the right account.

To move money from a provider's wallet to your main bank, or to pay a supplier from it, post a transfer with a manual journal entry on those accounts.

A balance on the old shared Mobile Money account (payments from before the provider accounts) is cleared with a payout of the way *Mobile money (earlier payments)*, which lands in Cash and Bank.

## Routines for the shop's money

**Daily** (owner or cashier): count the till and record the difference; compare **Cash with Drivers** with the *To hand in* total of **Driver cash**; look at **Online payments** for payments *Under review* and *Refunds due*.

**Weekly** (one named person): record every provider payout received, with its fee. Each provider's balance should be about what it has collected since its last payout; a balance that keeps growing or goes negative means a payout or a payment is missing. Look for orders stuck in one status, failed deliveries and returns waiting.

**Monthly** (accountant): the bank, MTN, Airtel and card statements agree with their accounts; the trial balance balances; VAT Payable agrees with the tax return; Accounts Receivable, Accounts Payable and Inventory (against a stock count of a few products) are right; **Customer Credit Payable**, **Gift Card Liability** and **Loyalty Points Liability** agree with their customer lists; review **Cash Over / Short**, **Payment Provider Fees** and **Suspense** (Suspense must be zero: anything in it is an error to find). Then lock the month in Accounting and take a backup with the month's name.

## Advertising

The shop can sell space to other businesses. Open **Online Store > Advertising**, which has three tabs:

- **Advertisers**: the businesses that pay you.
- **Ads**: a picture, a link (a plain web address, http or https), the places it appears, the dates, a note about the fee and a *paid* flag. The picture is checked by its content and a big JPEG or PNG is shrunk; pictures up to 5 MB.
- **Report**: views, clicks and the click rate for each ad over a period, for one advertiser or all, with the fee and whether it is paid. Print it or save it as PDF, or download it as CSV.

There are three **places**: the top of the first page, above the product list (also on product pages), and the order tracking page. Several ads in a place take turns, every ad is labelled **Advertisement**, and links open in a new tab. An ad counts as *shown* when it is really on screen (once per visitor and half an hour). A click goes through the shop, which counts it and sends the visitor to the saved address.

## Online sales reports

**Online Store > Sales reports** has six reports, each with a from and to date and the usual **Excel** and **PDF** download. They are also in the list of reports you can have e-mailed on a schedule (Reports > Scheduled).

**An order counts as a sale on the day it was completed**, the day it was handed over and the invoice was issued, not the day the customer ordered or paid. The money is what the invoice says, so the totals agree with your invoices. Refunds of returns are shown on the day they were refunded.

- **Online sales by day**: for each day, the orders completed, how many were delivery and how many pick-up, goods, coupon discounts, delivery fees, **Invoiced**, returns refunded that day and **Net** (invoiced minus refunded).
- **Online sales orders**: every completed order with its invoice number, **Invoiced**, **Paid** and **Refunded**, so you can check a total order by order.
- **Online sales by payment method**: how those invoices were paid (cash, mobile money, card), and **Not collected yet** for the part of the invoices nobody has paid.
- **Online orders not counted as sales**: orders placed in the period that are not sales: **Open (being handled)**, **Waiting for online payment**, **Never paid (cancelled)**, **Cancelled** and **Rejected**, with their value, what was paid online and what was refunded. Use it to see money that is still waiting or must be given back.
- **Online sales by coupon**: for each coupon the orders, the discount given, the delivery fees waived and the amount invoiced.
- **Online best-selling products**: quantity sold, revenue after coupons, returned quantity and refunds, and the net, best first.

> **Note:** An order whose invoice was voided still shows as an order but with **Invoiced** 0, and a payment on a voided invoice is not counted. The by-day and payment reports are cut at midnight in the time zone of the server.

## Known limits

- A payment under review is not in the books until staff deal with it.
- Real MTN, Airtel and card payments depend on the keys and the approval of the provider. Before opening the shop to customers, do a test with each provider: one small real order delivered, one cancelled and refunded, one part-returned, and one payout recorded and compared with the provider's own statement.
- A provider that pays out net of its fee: enter the gross and the fee, as above.
