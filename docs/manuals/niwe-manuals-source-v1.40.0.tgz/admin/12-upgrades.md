# Upgrades and migrations

## How the database stays in step

The database structure is owned by **Flyway**. Each release carries numbered SQL migration files; on start-up Flyway applies any the database has not seen and records them in the `flyway_schema_history` table. Hibernate only *validates* that the code and the database agree (`ddl-auto=validate`); it never changes tables.

Rules that matter to an administrator:

1. **Never edit or delete a migration that has been applied.** Flyway stores a checksum and refuses to start if a file changed.
2. A new release is simply started: the new migrations run once, each in its own transaction.
3. **Back up first.** Always (chapter 10).

## Installing a new release

Each release is delivered as a package (for example `niwe-pos-v1.22.0.tgz`) with its own release notes (`RELEASE-NOTES-v1.22.0.md`). The usual steps:

1. Announce a short maintenance window. Take a **Backup now** and download it.
2. Stop the backend.
3. Unpack the package over the project folder.
4. Run the release's apply script(s), as named in the release notes: `tools/apply-vXXXX.py` and `tools/wire-vXXX.py frontend/src/app`.
5. Build the frontend and the backend.
6. Start the backend. Watch the log for Flyway applying the new migrations and for *Started PosApplication*.
7. Open the system, sign in, and check **Settings > Modules** (licence and module states) and a few screens.

If a release adds a new permission (for example *Approve large asset disposals*), nobody has it until you grant it under **Staff**; Admins have all permissions automatically.

## The first time on an old database (one time per database)

The current builds start with schema validation. If an old database was created before Flyway and lacks tables or columns:

1. Take a backup.
2. Start the backend **once** with the extra profile `dbsync` (for example `mvn spring-boot:run -Dspring-boot.run.profiles=dbsync`, or your usual profile plus `dbsync`).
3. Wait for *Started PosApplication*, then stop it.
4. Start normally. Flyway baselines the database and carries on.

> **Warning:** Never use `dbsync` on a database that Flyway already manages.

A database created during development with the older 23 migrations must be dropped and recreated (safe only if it has no real data), because the single V1 baseline has a different checksum.

## Version history in brief

| Version | Main theme |
|---|---|
| 1.1 | Module licensing |
| 1.2 to 1.4 | Property Management, Real Estate and Law firm improvements |
| 1.5 | Core: paging, search and exports everywhere; collections; imports with check-first; accounting controls; price lists; promotions, gift cards and loyalty |
| 1.6 to 1.10 | HR and Payroll, Hotel, Restaurant, POS, Manufacturing; decimal quantities |
| 1.11 | Receipt tax ID, dashboard paging, sales feature switches |
| 1.12 | Thermal printing and COM customer display |
| 1.13 | Register tied to one device |
| 1.14 | Server logs, sign-in log, wider audit log |
| 1.15 to 1.22 | Work orders, Time tracking, Booking, Installments, Subscriptions, Help Desk, Expenses, Assets |
| 1.23 to 1.26 | French throughout: screens, messages, lists, reports and printed documents |
| 1.27 | Online Store: the public shop, cash orders |
| 1.28 to 1.34 | Online Store: shop improvements, online payments (simulated provider, then MTN Mobile Money), customer accounts, coupons, text messages, returns and refunds |
| 1.35 to 1.36 | Online Store: a full first page (announcement, banner pictures that slide, product rows, reviews, newsletter, footer), Reviews and Newsletter screens, "Sellable now" figures |
| 1.37 | Online Store: six sales reports, also available as scheduled e-mailed reports; no database change |
| 1.38 | Online Store: send a newsletter from the program; new tables (migration V74, runs by itself at start-up); optional settings `app.online-store.newsletter.batch-size` and `daily-limit` |
| 1.39 | Online Store: abandoned-cart reminders; new tables and a new setting column (migration V75, runs by itself at start-up); optional setting `app.online-store.cart-reminders.batch-size`; the shop must have working e-mail settings and `app.frontend-url` |
| 1.40 | Online Store: loyalty points for shop accounts; new table and columns (migration V76, runs by itself at start-up); off until switched on in Shop settings |

## If a start-up fails

- *Migration checksum mismatch*: a migration file was changed after being applied. Restore the original file.
- *Schema-validation: missing column/table*: the database is behind the code. Run the one-time `dbsync` start described above (after a backup).
- A message naming a *migration it does not know*: you are running an older build against a database made by a newer one. Deploy the newer build.
