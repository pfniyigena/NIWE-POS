import json,re,sys,os,glob
fr=json.load(open('/mnt/user-data/uploads/NIWE-POS/frontend/src/app/core/i18n/fr.json'))
low={k.lower():v for k,v in fr.items()}
OVR={"Bump all":"Tout valider","Cancel & credit invoice":"Annuler et créditer la facture","Cash Flow":"Flux de trésorerie","Charge to room":"Mettre sur la chambre","Confirm now":"Confirmer maintenant","Create requisition":"Créer une demande d'achat","Fire course":"Lancer le service","Fulfil order":"Préparer la commande","Income Statement":"Compte de résultat","Insert a saved reply":"Insérer une réponse enregistrée…","Merge into":"Fusionner dans…","Merge into another ticket":"Fusionner dans un autre ticket…","Move table":"Déplacer la table…","POS Exceptions":"Exceptions POS","Payouts":"Versements","Quotation":"Devis","Registers & Terminal":"Caisses et terminal","Serve":"Servir","Split / move items":"Diviser / déplacer des articles…","Tags":"Étiquettes","Trial Balance":"Balance","Voids & returns":"Annulations et retours","customer group":"groupe de clients"}
try:
    OVR.update(json.load(open('/home/claude/man176/fr_extra.json')))
except Exception: pass
missing={}
def tr(t):
    t=t.strip()
    v=OVR.get(t) or fr.get(t) or low.get(t.lower())
    if v is None:
        t2=t.rstrip(':.')
        v=fr.get(t2) or low.get(t2.lower())
    if v is None:
        missing[t]=missing.get(t,0)+1
        return t
    return v
def lab(s):
    return ' > '.join(tr(x) for x in s.split(' > '))
def conv(txt):
    txt=re.sub(r'\{i\{(.+?)\}\}',lambda m:'*'+lab(m.group(1))+'*',txt)
    txt=re.sub(r'\{\{(.+?)\}\}',lambda m:'**'+lab(m.group(1))+'**',txt)
    return txt
def main(src,dst):
    os.makedirs(dst,exist_ok=True)
    for f in sorted(glob.glob(src+'/*.md')):
        s=open(f).read()
        open(os.path.join(dst,os.path.basename(f)),'w').write(conv(s))
    for t,c in sorted(missing.items()): print('MISSING:',t,c)
if __name__=='__main__': main(sys.argv[1],sys.argv[2])
