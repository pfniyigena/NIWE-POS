set -e
export LANGX=fr
V="Version 1.76.0"
b(){ folder="$1"; title="$2"; sub="$3"; name="$4"; notoc="$5"
  if [ -n "$notoc" ]; then export NOTOC=1; else unset NOTOC; fi
  python3 build_docx.py "$folder" "$title" "$sub" "out-fr/$name.docx" "$V"
  python3 update_toc.py "out-fr/$name.docx" "out-fr/$name.pdf"
  echo "done $name"
}
b fr/cards "Fiches de démarrage rapide" "Une fiche par rôle" NIWE-ERP-Fiches-de-demarrage-rapide 1
b fr/guide-install "Guide d'installation et de déploiement" "Installer et faire fonctionner NIWE ERP pour un client" NIWE-ERP-Guide-installation-deploiement
b fr/guide-onboarding "Guide d'intégration d'un client" "Du premier échange à la première clôture mensuelle" NIWE-ERP-Guide-integration-client
b fr/guide-releases "Notes de version et de mise à jour" "Pour les clients : ce que chaque version apporte et que faire à la mise à jour" NIWE-ERP-Notes-de-version-et-mise-a-jour
b fr/guide-support "Guide d'assistance et de dépannage" "Trouver la cause, résoudre le problème, corriger les comptes en toute sécurité" NIWE-ERP-Guide-assistance-depannage
b fr/admin "Manuel de l'administrateur" "Installation, configuration et exploitation" NIWE-ERP-Manuel-administrateur
b fr/user "Manuel utilisateur" "L'utilisation quotidienne de chaque module" NIWE-ERP-Manuel-utilisateur
