# Étape 1 : la découverte

Une conversation d'une heure avec le propriétaire et le comptable, et une courte visite de l'entreprise. Reportez les réponses dans le registre des clients et dans une **note de périmètre** d'une page que le propriétaire signe.

## Questions à poser

**L'entreprise**

- Que vend ou que fait l'entreprise ? Lesquels de ces cas s'appliquent : magasin avec caisses, restaurant, hôtel, fabrication, services avec ordres de travail, réservations, abonnements, ventes à tempérament, support client, cabinet d'avocats, immobilier, gestion locative, boutique en ligne ?
- Combien de **agences**, d'**entrepôts** et de **caisses** ? Combien de personnes auront un identifiant ?
- Quel **pays** et quel **plan comptable** (Rwanda ou Tchad ; cela fixe aussi la devise, RWF ou XAF, et la langue de départ) ? Le comptable a-t-il un plan qu'il doit conserver ?
- Quelles **taxes** (taux de TVA, produits exonérés) ? Les prix sont-ils affichés taxes comprises ?
- Quels **modes de paiement** sont utilisés : espèces, carte, MTN Mobile Money, Airtel Money, virement bancaire, crédit aux clients, cartes cadeaux, points de fidélité ?
- Comment les **fournisseurs** sont-ils payés et les **clients** facturés aujourd'hui ? Y a-t-il du crédit ? Quels sont les plafonds de crédit ?
- Qui **approuve** les remises, les annulations, les grosses dépenses ?
- Quels **rapports** le propriétaire veut-il chaque jour, semaine et mois ? Certains doivent-ils être envoyés par e-mail selon un calendrier ?
- Quels **appareils** : PC de caisse, imprimantes thermiques, tiroirs-caisses, lecteurs de codes-barres, afficheurs clients ?
- Qu'existe-t-il aujourd'hui (un autre système, des feuilles de calcul, du papier) et quelles données peuvent en venir ?

**La boutique en ligne** (si souhaitée)

- Livraison, retrait ou les deux ? Quelles **zones** et quels frais ? Qui livre (livreurs de l'entreprise) ? Le paiement à la livraison est-il accepté ?
- Quels **fournisseurs de paiement en ligne** : MTN Mobile Money, Airtel Money, carte ? Qui dans l'entreprise peut les **enregistrer** (ce doit être l'entreprise, en son propre nom) ? Y a-t-il un portefeuille ou un compte bancaire distinct pour chacun ?
- Qui répond aux commandes, avec quelle rapidité, et depuis quel écran ? Qui prépare et qui remet ?
- Quelles sont les **Conditions**, la **politique de retour** et les règles de **confidentialité** de la boutique ? (Le programme fournit des textes de départ, pas un conseil juridique.)
- Des images et des descriptions pour combien de produits ? Y a-t-il une couleur de marque et un logo ?

## La note de périmètre

Notez, et faites signer par le propriétaire : les modules ; les agences, entrepôts et caisses ; le nombre d'utilisateurs par rôle ; le plan comptable et la devise ; les langues ; les modes de paiement et les fournisseurs ; les données à charger ; la date de démarrage ; les dates de formation et de mise en service ; la date de lancement de la boutique le cas échéant ; ce qui n'est **pas** inclus. Tout ce qui n'est pas sur la note relève d'un projet ultérieur.

## Licence

Envoyez à NIWE la liste des modules. La licence est émise pour l'identifiant d'installation affiché dans **Paramètres > Modules** une fois le serveur installé (Guide d'installation, chapitre 6). Elle est vérifiée sans internet. Notez la **date d'échéance** dans le registre et fixez un rappel 60 jours avant ; l'administrateur ne voit un avertissement que dans les 30 derniers jours.
