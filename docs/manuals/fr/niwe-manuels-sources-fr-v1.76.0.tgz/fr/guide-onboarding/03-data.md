# Étape 3 : préparer et charger les données

La qualité des données décide de la qualité du premier mois. Préparez-les dans des feuilles de calcul **avant** la formation, vérifiez-les avec la fonction *Vérifier le fichier* du programme (qui n'enregistre rien), et ne les chargez que quand le résultat est celui que vous voulez.

## Ordre du travail

1. **Les paramètres d'abord.** Informations de l'entreprise, paramètres système (devise, format de date, langue, mode de remise), taxes, modes de paiement, agences et entrepôts, puis le **plan comptable** et les contrôles comptables (Manuel de l'administrateur, chapitres 5 et 6). Choisissez le pays du plan avec soin : il est verrouillé après le premier écran.
2. **Rôles et personnel** (Manuel de l'administrateur, chapitre 4), avec l'adresse e-mail de chaque personne.
3. **Catégories et marques**, puis **produits** (avec codes-barres, coûts et prix de vente, taxes, unités, seuils de réapprovisionnement), puis **clients** et **fournisseurs**.
4. **Stock d'ouverture**, **soldes clients** et **soldes fournisseurs**, puis **soldes d'ouverture du grand livre** pour le reste.

## Importer

**Paramètres > Sauvegarde et données > Import en masse** (aussi dans certains modules pour les employés, les clients du cabinet, les biens). Pour chaque import : **Télécharger le modèle**, remplissez-le en gardant la ligne d'en-tête, choisissez le fichier et appuyez sur **Vérifier le fichier** ; lisez combien de lignes peuvent être importées et la **liste des lignes qui seront ignorées, avec la raison** ; corrigez le fichier et vérifiez de nouveau jusqu'à ce qu'il soit propre ; puis appuyez sur **Importer**. Une ligne erronée est ignorée et listée ; le reste est quand même importé. Découpez les gros fichiers (les imports des modules ne lisent que la première feuille, jusqu'à 2 000 lignes).

Règles pratiques :

- Un produit, un code-barres, une unité. Décidez des **règles de nommage** (majuscules, marque en premier ou en dernier) avant d'importer, pour que le catalogue soit cohérent.
- Vérifiez la **taxe** de chaque produit : une taxe fausse dans le premier import est une taxe fausse sur chaque vente.
- Les **soldes d'ouverture** des clients et des fournisseurs deviennent de vraies factures et factures fournisseurs `OB-` qui vieillissent et sont encaissées et payées comme les autres. Chargez-les une ligne par document ouvert, pas un total.

## Soldes d'ouverture : les comptes doivent partir de la vérité

Choisissez la **date d'ouverture** (par exemple le premier d'un mois) et faites approuver chaque chiffre par le comptable :

- [ ] **Caisse et banque** : les espèces comptées et chaque solde bancaire à cette date.
- [ ] **Mobile money et carte** : ce que chaque fournisseur doit à l'entreprise à cette date (les comptes d'attente) et le solde de chaque portefeuille ou compte bancaire qui reçoit les versements.
- [ ] **Stock** : un **inventaire** de chaque produit (quantité et coût), pour que le Stock en comptabilité corresponde au rayon. Comptez à la date d'ouverture ou ajustez pour y revenir.
- [ ] **Clients qui doivent et fournisseurs à payer** : un document par facture ou facture fournisseur ouverte.
- [ ] **Points de fidélité** que les clients détiennent déjà, **cartes cadeaux** et **crédits client** déjà vendus : ce sont des dettes.
- [ ] **Immobilisations, emprunts et capitaux propres.**
- [ ] **Contrôle :** la balance est équilibrée et **le compte Suspens est à zéro**.
- [ ] Fixez la **date de verrouillage comptable** au jour précédant la date d'ouverture, pour que personne ne puisse passer d'écritures dans des jours clos.

> **Attention :** Ne commencez pas à vendre sur le nouveau système avec une liste de stock que personne n'a comptée. Une quantité de stock négative ou inventée est la raison la plus fréquente pour laquelle les propriétaires cessent de faire confiance à un nouveau système.
