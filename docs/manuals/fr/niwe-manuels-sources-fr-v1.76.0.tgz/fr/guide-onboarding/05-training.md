# Étape 4 : formation et répétition

## Former par rôle, pas par écran

Les gens retiennent ce qu'ils font tous les jours. Donnez à chaque rôle une **courte séance sur ses propres tâches**, avec le vrai système et de vraies données (de test), et la **Fiche de démarrage rapide** correspondante sur papier à côté d'eux. Gardez des séances de 60 à 90 minutes et laissez les gens cliquer.

| Rôle | À enseigner (chapitres du Manuel utilisateur) | Fiche |
|---|---|---|
| Caissier | POS : vendre, encaisser, retours, espèces, la file hors ligne, fin de poste (chapitre 2) | Caissier |
| Superviseur de poste | Ouvrir et clôturer les sessions, approbations avec le PIN d'un responsable, rapports X et Z | Superviseur |
| Personnel de vente | Devis, commandes clients, factures, clients, listes de prix (chapitres 3 et 4) | Commercial |
| Magasinier | Réception, inventaires, transferts, corrections, réapprovisionnement (chapitres 5 et 6) | Magasinier |
| Achats | Demandes d'achat, bons de commande, factures fournisseurs (chapitre 5) | Responsable des achats |
| Comptable | Plan comptable, écritures, contrôles, rapprochement bancaire, rapports, dépenses (chapitres 10 et 11) | Comptable |
| Restaurant, hôtel, réception, RH, rendez-vous, support client | Les chapitres de leur module | Leur fiche |
| Personnel de la boutique en ligne et livreurs | Boutique en ligne, chapitres 23 à 25 | Personnel de la boutique en ligne |
| Administrateur | Le Manuel de l'administrateur : utilisateurs, modules, sauvegarde, mises à jour, journaux, dépannage | Administrateur |

## Les trois habitudes à enseigner en premier

1. **Ne partagez jamais un identifiant ou un PIN.** Tout est enregistré au nom de la personne.
2. **Ne supprimez pas : annulez, créditez ou retournez.** Les comptes restent honnêtes et le journal d'audit garde la trace.
3. **Comptez la caisse et enregistrez l'écart.** À la fin de chaque poste, chaque jour.

## La journée de répétition

Une journée complète « pour de faux », quelques jours avant la mise en service, avec tout le monde à son poste et l'intégrateur qui circule :

- les caisses s'ouvrent avec un fond de caisse, vendent toute la journée avec des produits de test, acceptent tous les types de paiement que l'entreprise utilise, font des retours et des annulations ;
- le magasinier reçoit un achat et fait un inventaire ;
- le comptable regarde le journal et la balance à la fin, et clôture une session de test ;
- l'administrateur restaure une sauvegarde dans la base de secours (le test de restauration) et lit le journal ;
- pour la boutique : un client de test passe des commandes, le personnel y répond, et un livreur (ou un collègue) en termine une avec le code.

Notez chaque question qui s'est posée ; les réponses deviennent l'aide-mémoire propre du client et, si les manuels sont peu clairs, un retour à NIWE.

## Après la formation : l'aide-mémoire

Remettez au client une feuille d'une page avec : l'adresse du système, qui est l'administrateur, qui appeler chez NIWE et à quelles heures, comment réinitialiser un mot de passe, que faire quand la connexion tombe (continuer à vendre ; ne pas effacer le navigateur tant que la file hors ligne contient des ventes), et où trouver les manuels et le wiki.
