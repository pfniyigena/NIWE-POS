# Lancer la boutique en ligne

La Boutique en ligne est une boutique publique qui reçoit de vraies commandes et de l'argent réel de la part d'inconnus. Ne la lancez qu'une fois que la caisse et les comptes fonctionnent, et suivez l'ordre ci-dessous. Chaque point indique qui le fait et comment on sait qu'il est fait. C'est aussi la liste de contrôle de mise en service pour une entreprise.

## Les décisions de l'entreprise

- [ ] **Livraison, retrait ou les deux**, les **zones de livraison** avec leurs frais et leur taxe, la commande minimale et le montant de livraison gratuite, l'estimation en jours pour chaque zone, et les **créneaux horaires** de livraison si l'entreprise en veut.
- [ ] **Qui livre** : une liste de livreurs avec leurs téléphones. Chacun reçoit un lien privé et un PIN à 4 chiffres, envoyés en deux messages.
- [ ] **Fournisseurs de paiement** : MTN Mobile Money, Airtel Money, carte. **L'entreprise s'inscrit** auprès de chacun en son propre nom (le fournisseur demande des documents de société) ; les clés appartiennent à l'entreprise. Cela prend des jours ou des semaines : commencez à l'étape 1.
- [ ] **Comptes** : pour chaque fournisseur, l'entreprise a-t-elle un portefeuille ou un compte bancaire distinct ? Convenez avec le comptable du **compte d'attente** et du **compte de versement** du fournisseur.
- [ ] **Conditions générales**, **Politique de confidentialité**, **Retours et remboursements**, **Livraison et expédition** : lisez les textes de départ dans Boutique en ligne > Pages de la boutique, adaptez-les à l'entreprise et au pays, et faites-les vérifier par une personne responsable.
- [ ] **Délai de retour** (en jours), règles des points de fidélité, coupons, souhaite-t-on des lettres d'information et des rappels de panier abandonné (ils demandent l'e-mail).

## Mise en place technique (l'intégrateur)

- [ ] Le site est en **https** avec le domaine du client et `app.frontend-url` est cette adresse.
- [ ] La **règle nginx** pour les aperçus de liens, le plan du site et robots.txt est en place (Guide d'installation, chapitre 5) et le test avec `curl -A "facebookexternalhit/1.1"` renvoie une petite page.
- [ ] L'**e-mail** fonctionne (Envoyer un e-mail de test) et l'adresse de la boutique pour les e-mails de nouvelle commande est fixée.
- [ ] Un **fournisseur de SMS** est choisi, ou l'entreprise sait que les codes par SMS restent dans la liste des SMS jusqu'à la connexion d'un fournisseur (les codes partent aussi par e-mail et s'affichent sur la page de la commande).
- [ ] Les **clés des fournisseurs de paiement** sont dans l'environnement du serveur ou le fichier de paramètres privé, jamais dans un dépôt ; le fournisseur apparaît comme *disponible* dans Paramètres de la boutique > Paiements en ligne ; l'adresse du webhook affichée à l'écran est donnée au fournisseur.
- [ ] Les **logos** des fournisseurs de l'entreprise sont dans `frontend/src/assets/payment/` avant la compilation du frontend (sinon les boutons affichent des noms).

## Mise en place de la boutique (le responsable de la boutique, avec l'intégrateur)

- [ ] **Produits sur la boutique** : ajoutez les produits, les titres, les prix en ligne (ou la liste de prix), les images, les descriptions, les caractéristiques et les quatre cases de ligne ; pour les produits avec tailles ou couleurs, mettez le modèle sur la boutique.
- [ ] **Stock d'où vend la boutique**, la marge, la part gardée pour la caisse et le nombre d'heures après lesquelles les commandes sans réponse sont libérées. Vérifiez la ligne sous quelques produits et confrontez-la à un vrai comptage.
- [ ] **Produit de service de livraison** (un produit de service, taxe comprise ou aucune), zones de livraison, heures de livraison, livreurs et leurs liens.
- [ ] **Page d'accueil** : annonce, images de bannière, couleur, présentation, horaires d'ouverture, numéros de contact et WhatsApp, pied de page et liens sociaux.
- [ ] **Agence pour laquelle la boutique vend** (seulement avec plus d'une agence).
- [ ] **Boutique en ligne > Paiements en ligne > Comptes par fournisseur** : chaque fournisseur a son compte d'attente et son compte de versement choisis.
- [ ] Taux de taxe sur les produits et sur les frais de livraison ; **date de verrouillage** comptable fixée au jour précédant la date d'ouverture.
- [ ] Utilisateurs et rôles : le personnel de la boutique a la zone **Opérations** ; seuls le propriétaire et le comptable gèrent la Comptabilité et verrouillent les périodes ; les livreurs n'utilisent que leur page privée.

## Test avec de l'argent réel (petits montants, un à la fois)

Faites chacun avec une petite commande réelle, puis lisez les écritures du journal (Comptabilité > Journal ; cherchez le code de la commande).

- [ ] **Paiement MTN**, livré : le paiement débite le compte d'attente de MTN et crédite Acomptes clients en ligne ; la livraison libère l'acompte.
- [ ] **Paiement Airtel**, livré : la même chose, sur les comptes Airtel.
- [ ] **Paiement par carte**, livré (quand la carte est utilisée).
- [ ] Une **commande payée annulée** et remboursée via le fournisseur (Airtel : à la main avec la référence) : le compte d'attente du fournisseur revient à zéro.
- [ ] Une **commande livrée, partiellement retournée** et remboursée : la TVA et le coût sont contrepassés et les marchandises sont de retour en stock.
- [ ] Une commande **payée à la livraison** : les espèces du livreur apparaissent sous *Espèces chez les livreurs* jusqu'à la remise ; la remise les efface.
- [ ] Une commande avec un **coupon** et une avec des **points de fidélité** : *Remises accordées sur ventes* et *Dette de points de fidélité* affichent les montants.
- [ ] Une **livraison échouée** et un **nouvel horaire de livraison** choisi par le client ; une **livraison partielle**.
- [ ] **Un versement** de chaque fournisseur enregistré sous Boutique en ligne > Paiements en ligne > Versements avec ses frais ; comparez les montants avec le relevé du fournisseur.
- [ ] Un **message** envoyé depuis le formulaire de contact reçoit une réponse ; une demande de **retour en stock** est notifiée.
- [ ] Ouvrez la boutique sur un téléphone : la page d'accueil, une page produit, le panier, la commande, la page de suivi. Installez-la comme application sur un téléphone.

## Ouvrir la boutique

- [ ] Cochez **La boutique est ouverte au public** et enregistrez. Annoncez-la d'abord à quelques clients amis.
- [ ] Surveillez de près **Commandes en ligne** (Nouvelles), **Paiements en ligne** (À vérifier, Remboursements à faire, Bloqués en attente) et **Messages** pendant la première semaine, plusieurs fois par jour.
- [ ] Après une semaine, faites le bilan : avec quelle rapidité répond-on aux commandes, les livraisons sont-elles terminées avec le code, les soldes des comptes d'attente semblent-ils justes, les retours et remboursements sont-ils traités.

## Routines après le lancement

**Chaque jour** (propriétaire ou caissier) : comptez la caisse et enregistrez l'écart ; comparez **Espèces chez les livreurs** avec le total « À remettre » de Espèces des livreurs ; regardez dans Paiements en ligne les paiements *À vérifier* et *Remboursements à faire*.

**Chaque semaine** (une personne désignée) : enregistrez chaque versement de fournisseur reçu, avec ses frais. Le solde de chaque fournisseur doit être à peu près ce qu'il a encaissé depuis son dernier versement ; un solde qui grossit sans cesse ou devient négatif signifie qu'un versement ou un paiement manque. Cherchez les commandes bloquées dans un statut, les livraisons échouées et les retours en attente.

**Chaque mois** (comptable) : les relevés bancaire, MTN, Airtel et carte concordent avec leurs comptes ; la balance est équilibrée ; la TVA à payer concorde avec la déclaration ; les créances, les dettes et le stock (par rapport à un comptage de quelques produits) sont justes ; Crédit client à payer, Cartes cadeaux à honorer et Dette de points de fidélité concordent avec leurs listes ; examinez Écarts de caisse, Frais des fournisseurs de paiement et **Suspens** (il doit être à zéro). Puis verrouillez le mois et faites une sauvegarde nommée d'après lui.

**Chaque trimestre** : un test de restauration ; revue des comptes utilisateurs et suppression des personnes parties ; mise à jour du logiciel.

## Limites à signaler au propriétaire

- Un paiement à vérifier n'est pas dans les comptes tant que le personnel ne l'a pas traité.
- Les commandes payées avant la version 1.71.0 n'ont pas d'acompte ; les commandes livrées avant la 1.72.0 règlent les espèces des livreurs par la différence seulement ; les retours avant la 1.70.0 gardent leur ancien chiffre ; les points de fidélité gagnés avant la 1.73.0 ne sont pas dans la dette. Cela ne compte que pour une entreprise qui met à jour une boutique existante.
- NIWE n'a pas testé de vrais paiements de fournisseurs avec les propres clés du client : l'étape 4 est ce test.

## Qui fait quoi

Notez les noms : le propriétaire, le comptable, la personne qui enregistre les versements, la personne qui restaure les sauvegardes, et le contact NIWE à appeler quand quelque chose échoue.
