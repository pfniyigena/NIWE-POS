# Étape 5 : la mise en service et le premier mois

## La semaine précédente

- [ ] **Sauvegarde** finale du système vide (ou chargé), copiée hors du serveur, et **test de restauration** fait.
- [ ] Chaque utilisateur s'est connecté une fois et a changé son mot de passe ; chaque PC de caisse a imprimé un ticket de test.
- [ ] Les **soldes d'ouverture** sont chargés, vérifiés par le comptable et la date de verrouillage est fixée.
- [ ] L'aide-mémoire est imprimé et distribué ; les contacts et horaires du support sont convenus.
- [ ] Une **réunion go / no-go** avec le propriétaire et le comptable : si une case ci-dessus n'est pas cochée, dites pourquoi et décidez.

## Jour 0

- Soyez présent (ou au téléphone) dès l'ouverture de l'entreprise. Commencez la journée par l'**ouverture des sessions de caisse** avec le fond de caisse.
- Tenez une liste de chaque question et de chaque petit problème ; corrigez les paramètres le soir, pas au milieu d'une vente.
- En fin de journée : comptez les caisses, clôturez les sessions, imprimez les **rapports Z**, comparez les ventes du jour avec les espèces et la balance, et **sauvegardez**.

## Les deux premières semaines

- **Point quotidien** de 15 minutes avec l'administrateur : ce qui s'est mal passé, ce qui était lent, qui a besoin d'aide.
- Surveillez la liste **« À traiter »** du tableau de bord et le journal d'audit pour les annulations, retours, changements de prix et corrections de stock : ils montrent si les habitudes enseignées en formation sont suivies.
- Vérifiez le **stock** sur quelques produits du rayon chaque jour, puis chaque semaine.
- Corrigez les **erreurs de nommage et de données** trouvées dans les premiers jours (une taxe fausse, un client en double) avec les bons outils : modifiez la fiche, ou annulez et refaites ; ne supprimez jamais.

## La première fin de mois

Avec le comptable, une fois le mois terminé :

1. Toutes les sessions de vente sont clôturées, toutes les factures émises, les factures fournisseurs saisies, les dépenses approuvées.
2. **Rapprochement** bancaire et mobile money (Comptabilité > Contrôles).
3. Balance examinée ; **Suspens** à zéro ; rapport de TVA concordant avec la déclaration.
4. Valorisation du stock par rapport à un comptage des produits clés.
5. **Clôturez les comptes** jusqu'à la date de fin de mois (un administrateur le fait ; la raison est journalisée), puis faites une **sauvegarde nommée avec le mois** et copiez-la hors du serveur.
6. Regardez les rapports du mois et envoyez les chiffres au propriétaire.

## Remise et validation

À la fin du premier mois, rencontrez le propriétaire et signez une remise d'une page :

- [ ] Le système fonctionne sur la version convenue ; le numéro de licence et son échéance sont notés.
- [ ] Les sauvegardes tournent chaque nuit, une copie quitte le serveur, et un **test de restauration** a été fait au cours du dernier trimestre.
- [ ] Chaque personne a son propre identifiant ; les départs sont supprimés.
- [ ] L'administrateur sait réinitialiser un mot de passe, restaurer une sauvegarde, lire le journal et contacter le support.
- [ ] La première fin de mois a été clôturée avec une balance équilibrée et Suspens à zéro.
- [ ] Le client connaît la **routine de mise à jour** et a convenu d'une fenêtre pour la première mise à jour (voir les *Notes de version et de mise à jour pour les clients*).
- [ ] Les points ouverts sont listés avec un responsable et une date.

Après la validation, le client passe à l'assistance normale (voir le *Guide d'assistance et de dépannage*).
