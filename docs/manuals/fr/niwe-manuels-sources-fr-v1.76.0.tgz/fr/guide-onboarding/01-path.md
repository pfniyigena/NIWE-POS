# Le parcours d'intégration

## À qui s'adresse ce guide

Ce guide s'adresse à la personne qui amène **une nouvelle entreprise sur NIWE ERP** : un intégrateur NIWE, un partenaire ou le chef de projet du client lui-même. Il suit le client de la première conversation jusqu'à la fin de la première clôture mensuelle. Le travail sur le serveur est dans le **Guide d'installation et de déploiement** ; les écrans de tous les jours sont dans le **Manuel utilisateur** ; les paramètres sont dans le **Manuel de l'administrateur**. Vous trouverez ici l'ordre du travail, les questions à poser, les données à préparer, comment former, comment lancer la boutique en ligne et comment remettre le système.

Une entreprise qui suit ces étapes dans l'ordre, et coche chaque case, démarre avec des comptes fiables. Une entreprise qui saute les soldes d'ouverture ou la formation démarre avec un désordre qu'elle passera des mois à nettoyer.

## Le parcours en cinq étapes

| Étape | Durée type | Ce qui se passe | Résultat |
|---|---|---|---|
| **1. Découverte** | 1 à 3 jours | Comprendre l'entreprise ; convenir des modules, du plan comptable, des utilisateurs et de la date de démarrage (chapitre 2). | Une liste signée de ce qui sera installé et utilisé. |
| **2. Installation** | 1 jour | Le serveur et le programme sont installés pour ce client et la licence est chargée (Guide d'installation). | Un système vide, en marche, à l'adresse propre du client. |
| **3. Paramétrage et chargement** | 1 à 2 semaines | Informations de l'entreprise, taxes, comptes, rôles, produits, clients, fournisseurs, soldes d'ouverture (chapitres 3 et 4). | Un système qui correspond à l'entreprise à la date de démarrage. |
| **4. Formation et répétition** | 1 semaine | Chaque rôle est formé à ses propres tâches ; l'équipe fait une journée complète de travail « pour de faux » (chapitre 5). | Des personnes capables de faire leur travail sans aide. |
| **5. Mise en service et accompagnement** | Jour 0 jusqu'à la première fin de mois | Le vrai travail commence ; assistance quotidienne ; premières routines ; première clôture (chapitres 7 et 8). | Une remise signée. |

Une boutique en ligne ajoute une sixième étape, parallèle : le **lancement de la boutique** (chapitre 6), qui ne doit démarrer qu'une fois les cinq premières étapes terminées pour la caisse et les comptes.

## Qui fait quoi

Nommez ces personnes dès le premier jour et notez-les dans le registre des clients :

- **Le propriétaire ou le sponsor** : décide, signe, et c'est la personne à appeler quand quelque chose est bloqué.
- **L'administrateur de l'entreprise** : détient le compte Admin, crée les utilisateurs, fait les contrôles quotidiens. Cette personne lit le Manuel de l'administrateur.
- **Le comptable** : responsable du plan comptable, des soldes d'ouverture et de la clôture mensuelle.
- **Un référent par module** (chef de caisse, magasinier, responsable RH, responsable de la boutique) : apprend en premier et aide les autres.
- **L'intégrateur NIWE** et **le contact support NIWE**.

> **Conseil :** Choisissez une **date de démarrage au début d'un mois** (ou d'un exercice). Les soldes d'ouverture, les inventaires et la première clôture sont beaucoup plus simples quand l'ancien système et le nouveau se rejoignent sur une frontière nette.

## Ce que le client doit fournir

Demandez ces éléments tôt ; la plupart des retards viennent de l'attente de l'un d'eux :

- la dénomination légale de l'entreprise, son adresse, son numéro fiscal et son logo ;
- un **nom de domaine** (ou l'autorisation d'en utiliser un de NIWE) et la personne qui gère son DNS ;
- un **compte e-mail** depuis lequel le système peut envoyer (paramètres SMTP) et des adresses pour les alertes du propriétaire ;
- la liste des **modules** souhaités, les **agences**, et les **personnes** qui utiliseront le système avec leurs adresses e-mail et leurs rôles ;
- les **produits, clients et fournisseurs** dans une feuille de calcul (chapitre 3), et les **chiffres d'ouverture** à la date de démarrage ;
- pour une boutique en ligne : images et descriptions, zones et frais de livraison, les **fournisseurs de paiement** et les comptes (chapitre 6), et les conditions de la boutique.
