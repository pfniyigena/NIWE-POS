# Étape 3 (suite) : l'atelier de paramétrage

Faites-le avec l'administrateur de l'entreprise à côté de vous, afin qu'il apprenne où se trouve chaque paramètre.

## Module par module

Passez en revue les paramètres de chaque module que le client utilise (Manuel de l'administrateur, chapitre 7) : ventes (limites de remise, interrupteurs pour promotions, cartes cadeaux et fidélité), POS (tickets, postes, règles de caisse), stock (stock négatif, lots et péremption, cartons), dépenses (plafonds d'approbation), immobilisations, etc. Notez chaque choix dans les notes du registre pour que la personne suivante sache pourquoi.

## Caisses et appareils

Pour chaque PC de caisse (Manuel de l'administrateur, chapitre 8) : liez la caisse au PC lorsque les caisses sont dans des espaces publics ; connectez l'imprimante thermique et appuyez sur **Imprimer une page de test** ; testez le tiroir-caisse, le lecteur de codes-barres et l'afficheur client. L'impression thermique directe demande Chrome ou Edge en **https** (ou localhost). Imprimez un ticket de test et vérifiez le nom de l'entreprise, le numéro fiscal, les lignes de TVA et le texte de pied de page.

## E-mail, alertes et rapports

Configurez l'e-mail et appuyez sur **Envoyer un e-mail de test** (chapitre 9). Choisissez les adresses pour les **alertes de l'entreprise** (stock bas, devis qui expirent, avertissements de plafond de crédit, commandes de la boutique sans réponse) et les **rapports planifiés** que le propriétaire a demandés (par exemple le résumé quotidien des ventes et les rapports de ventes de la Boutique en ligne).

## Sécurité avant les vraies données

Parcourez la **liste de contrôle de sécurité** du Manuel de l'administrateur (chapitre 13) : nouveau mot de passe admin, aucun compte de démonstration, chaque personne avec son propre identifiant et son propre PIN, permissions d'approbation seulement là où il le faut, https uniquement, une sauvegarde nocturne avec une copie hors du serveur, et le premier **test de restauration**.

## Une première journée d'essai

Avant la formation, l'administrateur et l'intégrateur font une **répétition à blanc** avec les vraies données : passez en caisse quelques ventes de chaque type, encaissez un paiement, retournez un article, clôturez une session et imprimez le rapport Z ; créez une facture et recevez un achat ; ouvrez le Journal et la Balance et vérifiez que les écritures ont du sens. Corrigez dès maintenant les paramètres qui ne se sont pas comportés comme prévu, pas le premier jour de vente réelle.
