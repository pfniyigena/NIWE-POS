# Installer un client

Voici la routine pour un **nouveau client sur un serveur préparé**. Remplacez `acme` et les numéros par ceux du client. Cela prend environ une heure une fois que le domaine pointe vers le serveur.

## Faire pointer le domaine

Créez l'enregistrement DNS (par exemple `erp.acme.com`) vers l'adresse du serveur, et attendez qu'il réponde.

## Créer les dossiers et y mettre les fichiers

```bash
sudo mkdir -p /opt/niwe/acme/config /var/www/niwe/acme
sudo cp niwe-1.76.0-backend.jar /opt/niwe/acme/pos-app.jar
sudo tar -xzf niwe-1.76.0-frontend.tgz -C /var/www/niwe/acme
sudo chown -R niwe:niwe /opt/niwe/acme
```

Le jar porte un **nom fixe** (`pos-app.jar`) dans le dossier du client, de sorte que le fichier de service ne change jamais. Gardez la copie nommée avec la version dans votre dépôt de livrables.

## Les paramètres privés du client

Créez `/opt/niwe/acme/config/application.properties`. Le programme lit un dossier `config` à côté de l'endroit où il est lancé, et ce fichier l'emporte sur les valeurs par défaut contenues dans le jar. Il contient les valeurs et les secrets **de ce client**, et il n'existe que sur ce serveur (jamais dans un dépôt) :

```properties
# --- base de données (chapitre 3)
spring.datasource.url=jdbc:postgresql://localhost:5432/niwe_acme
spring.datasource.username=niwe_acme
spring.datasource.password=LE-MOT-DE-PASSE-DE-LA-BASE

# --- le programme
server.port=9101
server.forward-headers-strategy=native
app.jwt.secret=UNE-LONGUE-VALEUR-ALEATOIRE-D-AU-MOINS-32-OCTETS
app.frontend-url=https://erp.acme.com
app.cors.allowed-origins=https://erp.acme.com

# --- premier démarrage
app.seed-demo-data=false
app.accounting.chart-country=RWANDA
# facultatif : mot de passe du premier administrateur ; s'il est vide, un mot de passe aléatoire est écrit une fois dans le journal
# app.initial-admin-password=

# --- les demandes de licence sont envoyées par e-mail à cette adresse
app.license.vendor-email=licences@niwe.example
```

Rendez le fichier lisible par le seul compte de service : `sudo chmod 600 /opt/niwe/acme/config/application.properties`.

Ce que signifie chaque ligne et comment la choisir :

| Paramètre | Signification |
|---|---|
| `spring.datasource.*` | L'adresse, l'utilisateur et le mot de passe de la base du client. |
| `server.port` | Le port local du backend de ce client (d'après votre plan de ports). |
| `server.forward-headers-strategy=native` | Nécessaire derrière nginx, pour que les limites par connexion voient chaque visiteur. |
| `app.jwt.secret` | **Unique pour chaque client.** Fabriquez-le avec `openssl rand -base64 48`. La valeur contenue dans le jar est publique (elle est dans le code source) : la laisser permet à n'importe qui de falsifier une connexion. |
| `app.frontend-url` | L'adresse publique, en `https://` et sans barre oblique finale. Elle construit les liens des e-mails, les liens des livreurs, les aperçus de partage et le plan du site. |
| `app.cors.allowed-origins` | La même adresse (séparées par des virgules s'il y en a plusieurs). |
| `app.seed-demo-data=false` | Laissez-le à `false`. Les données et mots de passe de démonstration ne servent qu'à apprendre. |
| `app.accounting.chart-country` | `RWANDA` ou `CHAD` : la proposition de l'écran initial du plan comptable. L'administrateur choisit le plan à l'écran à la première connexion, puis il est verrouillé. |
| `app.initial-admin-password` | Facultatif. Sans lui, un mot de passe aléatoire est écrit une fois dans le journal au tout premier démarrage (cherchez *FIRST START*). |
| `app.backup.directory` | Facultatif. Où vont les sauvegardes (par défaut : le dossier `backups` à côté du jar). |
| `app.backup.pg-dump-path`, `app.backup.psql-path` | Seulement si `pg_dump` et `psql` ne sont pas dans le PATH du service. |

**Les clés des fournisseurs de paiement, du fournisseur de SMS et tout autre secret** s'ajoutent dans ce même fichier, ou dans l'environnement du service, seulement quand le client est prêt à les utiliser (voir le guide d'intégration). Ne mettez jamais la même valeur dans les fichiers de deux clients. Les variables d'environnement sont les noms des paramètres en majuscules, avec les points et les tirets remplacés par des tirets bas (`APP_JWT_SECRET`).

## Le service

`/etc/systemd/system/niwe-acme.service` :

```ini
[Unit]
Description=NIWE ERP (acme)
After=network.target postgresql.service

[Service]
User=niwe
WorkingDirectory=/opt/niwe/acme
ExecStart=/usr/bin/java -Xmx1g -jar /opt/niwe/acme/pos-app.jar
Restart=on-failure
RestartSec=10
SuccessExitStatus=143

[Install]
WantedBy=multi-user.target
```

Le **répertoire de travail** fait que `config/`, `logs/` et `backups/` se trouvent à côté du jar. Le compte qui exécute le service doit avoir le droit d'écrire dans ce dossier (le programme crée `logs` et `backups` s'ils manquent).

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now niwe-acme
sudo journalctl -u niwe-acme -f        # ou : tail -f /opt/niwe/acme/logs/niwe-erp.log
```

Attendez la ligne **Started PosApplication**. Le premier démarrage applique toutes les migrations et prend environ une minute ; quelques secondes après, le programme ajoute aussi les comptes manquants au plan comptable (rattrapage). Surveillez les lignes qui disent *ERROR*, *Migration* failed ou *Schema-validation*.

## nginx

`/etc/nginx/sites-available/acme.conf`, puis liez-le dans `sites-enabled` :

```nginx
server {
    listen 80;
    server_name erp.acme.com;
    location /.well-known/acme-challenge/ { root /var/www/certbot; }
    location / { return 301 https://$host$request_uri; }
}

server {
    listen 443 ssl http2;
    server_name erp.acme.com;
    # les lignes du certificat sont ajoutées par certbot
    root /var/www/niwe/acme;
    index index.html;
    client_max_body_size 110m;

    location /api/ {
        proxy_pass http://127.0.0.1:9101;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-Host $host;
        proxy_read_timeout 120s;
    }

    # la page elle-même est toujours demandée au réseau
    location = /index.html { add_header Cache-Control "no-cache"; }

    # les règles d'aperçu de partage, de plan du site et de robots de la boutique en ligne vont ici
    # (copiez-les depuis docs/online-store-seo.md, avec le port du backend de ce client)

    location / { try_files $uri $uri/ /index.html; }
}
```

Obtenez le certificat avec `sudo certbot --nginx -d erp.acme.com`, puis `sudo nginx -t && sudo systemctl reload nginx`.

Pour un client qui utilise la **Boutique en ligne**, ajoutez les règles de `docs/online-store-seo.md` (le `map` pour les robots va dans le bloc `http`, les blocs `location` dans le bloc `server`, et l'adresse du backend est `127.0.0.1:9101` pour ce client). Là où le fichier dit `try_files /index.html =404`, utilisez `try_files $uri $uri/ /index.html` comme indiqué dans ce fichier. Testez avec `curl -A "facebookexternalhit/1.1" "https://erp.acme.com/shop"`.

## L'ouvrir

Ouvrez `https://erp.acme.com`. La première page affiche la connexion du personnel (ou la boutique quand le module Boutique en ligne est actif). Connectez-vous en tant que `admin` avec le mot de passe du fichier de paramètres ou de la ligne *FIRST START* du journal, **changez le mot de passe tout de suite** (Mon profil), et poursuivez avec le chapitre 6.
