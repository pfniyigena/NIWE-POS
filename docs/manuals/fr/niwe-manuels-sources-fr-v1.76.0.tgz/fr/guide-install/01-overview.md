# De quoi se compose un déploiement

## À qui s'adresse ce guide

Ce guide s'adresse à la personne chez NIWE (ou chez un partenaire) qui **installe NIWE ERP pour une entreprise cliente** et le maintient en service : un développeur, un administrateur système ou un consultant techniquement à l'aise. Il suppose que vous savez utiliser un shell Linux, modifier un fichier texte et lire un journal. L'administrateur du client utilise le **Manuel de l'administrateur** ; les premières semaines avec un nouveau client sont dans le **Guide d'intégration d'un client**, les versions et mises à jour dans les **Notes de version et de mise à jour pour les clients**, et les problèmes dans le **Guide d'assistance et de dépannage**.

L'objectif est un déploiement **identique pour chaque client**, à l'exception d'une courte liste d'éléments propres à ce client. Faites les mêmes étapes dans le même ordre à chaque fois, notez ce que vous avez fait dans le registre des clients (chapitre 8), et aucune installation ne dépendra de la mémoire de quelqu'un.

## Les éléments

Chaque installation chez un client comporte quatre éléments :

| Élément | Ce que c'est | Où il tourne |
|---|---|---|
| **Backend** | Un seul programme Java 21 / Spring Boot (`pos-app-<version>.jar`) qui contient toutes les règles de gestion et la partie serveur de la boutique publique. | Un service sur le serveur, sur un port local (par exemple 9101). |
| **Base de données** | Une base PostgreSQL réservée à ce client. La structure est créée et mise à jour par le programme lui-même (migrations Flyway). | PostgreSQL sur le même serveur, ou une base gérée. |
| **Frontend** | Un dossier de fichiers statiques produit par `ng build`. Les mêmes fichiers servent les écrans du personnel, la boutique publique et l'application installable. | Servi par nginx (ou un autre serveur web). |
| **Serveur web** | Termine le **HTTPS**, sert les fichiers du frontend, transmet `/api/` au backend et porte les règles pour les aperçus de partage. | nginx sur le même serveur. |

Le personnel et les clients n'ont besoin que d'un navigateur récent. Un poste de caisse qui imprime directement sur une imprimante thermique a besoin de Chrome ou Edge en https (ou sur localhost).

## Un client, un jeu complet

Ne partagez jamais aucun de ces éléments entre deux clients :

- la **base de données** (chaque client a sa propre base, son propre utilisateur et son propre mot de passe) ;
- le **secret qui signe les connexions** (`app.jwt.secret`) : quiconque le connaît peut falsifier une connexion sur cette installation ;
- le **fichier de licence** (il est signé pour l'identifiant de cette installation seulement) ;
- les **clés des fournisseurs de paiement** (MTN, Airtel, une passerelle de cartes sont enregistrés au nom de l'entreprise du client) ;
- le **compte e-mail** depuis lequel la boutique envoie, et le compte du **fournisseur de SMS** ;
- le **nom de domaine et son certificat**.

Ce qui est identique pour chaque client : le **jar**, la **version compilée du frontend** (la version de production demande l'API à l'adresse relative `/api`, donc une seule version fonctionne derrière n'importe quel domaine) et la **procédure**.

## Deux dispositions

**Un serveur par client** (un petit serveur virtuel pour chaque entreprise). C'est le plus simple à comprendre et à déplacer, et un problème chez un client ne peut pas toucher un autre. Choisissez-le quand un client aura beaucoup d'utilisateurs ou une boutique, ou quand le client possède le serveur.

**Plusieurs clients sur un serveur.** Chaque client a quand même son dossier, son processus jar sur son propre port, sa base, son site nginx et son domaine. Choisissez-le pour de petits clients qui partagent un coût. Prévoyez la mémoire : comptez environ 1 Go de mémoire par backend en marche, plus la base de données. Ne partagez pas le superutilisateur d'un serveur de base de données entre eux.

Quelle que soit la disposition, le plan de dossiers et de noms ci-dessous garde les clients séparés.

## Plan de nommage

Choisissez un court **code client** (en minuscules, sans espace, par exemple `acme`) et utilisez-le partout :

| Élément | Nom |
|---|---|
| Dossier Linux du backend | `/opt/niwe/acme/` (le jar, `config/`, `logs/`, `backups/` s'y trouvent) |
| Fichiers du frontend | `/var/www/niwe/acme/` |
| Base de données et utilisateur de la base | `niwe_acme` et `niwe_acme` |
| Service du backend | `niwe-acme.service` |
| Port local | un numéro par client, par exemple 9101, 9102, ... (notez-le dans le registre) |
| Site nginx | `/etc/nginx/sites-available/acme.conf` |
| Domaine | par exemple `erp.acme.com` (personnel et boutique sur la même adresse) |

Tenez le **registre des clients** (chapitre 8) : une ligne par client avec ces noms, le port, la version en service, le numéro de licence, les modules, le lieu de sauvegarde et la personne à appeler.
