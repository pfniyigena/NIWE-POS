# La base de données du client

Une base par client, avec son propre utilisateur. Exécutez ceci en tant qu'administrateur PostgreSQL (`sudo -u postgres psql`), en remplaçant `acme` par le code client et le mot de passe par un mot de passe long et aléatoire créé sur-le-champ (par exemple `openssl rand -base64 24`) :

```sql
CREATE ROLE niwe_acme LOGIN PASSWORD 'METTEZ-ICI-UN-LONG-MOT-DE-PASSE-ALEATOIRE';
CREATE DATABASE niwe_acme OWNER niwe_acme ENCODING 'UTF8';
```

Remarques :

- La base doit être **vide**. Au premier démarrage, le programme crée lui-même toutes les tables (Flyway : la migration V1 est la base de départ, V2 les tables de licence, puis toutes les migrations suivantes). Cela prend environ une minute. Ne créez jamais de tables à la main.
- L'utilisateur est propriétaire de la base et n'a besoin d'aucun autre droit. Ne donnez **pas** à l'application le superutilisateur PostgreSQL.
- Écrivez le mot de passe dans le **fichier de paramètres privé** du client (chapitre 5) ou dans l'environnement du service, et dans votre gestionnaire de mots de passe. Il ne doit **pas** se trouver dans un dépôt, un e-mail ou une discussion.
- PostgreSQL n'écoute que sur `localhost`. Si une base gérée est utilisée, n'autorisez que l'adresse du serveur d'application.

## Vérifications

- `psql -h localhost -U niwe_acme niwe_acme -c "select 1"` fonctionne.
- Après le premier démarrage du backend, `\dt` liste des centaines de tables et `select count(*) from flyway_schema_history;` indique les migrations appliquées. La migration la plus récente de la version installée doit être la dernière ligne, avec `success` à vrai.

## Sauvegardes au niveau de la base

Le programme fait **sa propre sauvegarde nocturne** (un `pg_dump` dans le dossier `backups` à côté du jar ; voir le chapitre 7). C'est une bonne première ligne de défense. Pour un client important, faites aussi une sauvegarde **au niveau du serveur** : une tâche cron qui lance `pg_dump -Fc` vers un autre disque et la copie hors de la machine. Les deux sont décrites au chapitre 7. Une sauvegarde qui n'a jamais été restaurée n'est pas une sauvegarde : restaurez-en une dans une base de secours pendant l'installation (chapitre 6, étape 12).
