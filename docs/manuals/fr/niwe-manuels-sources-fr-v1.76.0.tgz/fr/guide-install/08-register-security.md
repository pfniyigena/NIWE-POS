# Le registre des clients et la routine de sécurité

## Le registre des clients

Tenez un seul tableau (une feuille de calcul gardée dans un lieu partagé que seule l'équipe peut atteindre) avec une ligne par client. C'est la première chose que vous ouvrez quand il se passe quelque chose. **Il ne contient ni mots de passe ni clés** : ceux-ci sont dans le gestionnaire de mots de passe.

| Colonne | Exemple |
|---|---|
| Code client, nom, pays | `acme`, Acme Ltd, Rwanda |
| Personne de contact pour l'informatique et pour l'activité | noms, téléphones, e-mails |
| Serveur, adresse et domaine | server-3, erp.acme.com |
| Port du backend, dossier, nom de la base | 9101, /opt/niwe/acme, niwe_acme |
| Version en service, date d'installation ou de mise à jour | 1.76.0, 2026-11-24 |
| Identifiant d'installation, numéro de licence et échéance, modules | ..., LIC-0007, 2027-11-30, Ventes, Achats, Comptabilité, POS, Boutique en ligne |
| Plan comptable (Rwanda ou Tchad), devise, langue | Rwanda, RWF, anglais |
| Fournisseurs de paiement actifs, et qui a enregistré chacun | MTN MoMo (Acme Ltd), Airtel Money (Acme Ltd) |
| Sauvegardes : où vont les copies, durée de conservation, date du dernier test de restauration | bucket-acme, 30/12/12, 2026-11-24 |
| Contrat de support et horaires | |

## Les secrets

- **Un seul gestionnaire de mots de passe** pour l'équipe, avec un dossier par client : mot de passe de la base, secret JWT, compte e-mail, clés des fournisseurs, identifiants du serveur.
- **Changez** les secrets d'un client quand une personne qui les connaissait part, quand un secret a déjà été collé dans une discussion, un e-mail ou un dépôt, et une fois par an. Changer le secret JWT déconnecte tout le monde (sans conséquence). Changer le mot de passe de la base veut dire le changer dans PostgreSQL et dans `config/application.properties`, puis redémarrer.
- Une clé de fournisseur de paiement qui a déjà été versée dans un dépôt ou envoyée sans protection est **compromise** : demandez-en une nouvelle au fournisseur et révoquez l'ancienne.
- La **clé de signature des licences** appartient à NIWE : elle ne va jamais sur la machine d'un client et est sauvegardée à deux endroits.

## La routine annuelle de sécurité

Pour chaque client, une fois par an (et après tout incident) : la liste de contrôle du Manuel de l'administrateur (chapitre 13) ; les mises à jour du système d'exploitation, de Java, de PostgreSQL et de nginx ; une revue de la liste du personnel et la suppression des départs ; un coup d'œil au journal de connexions et au journal d'audit ; un exercice de restauration ; une vérification que les ports de la base et du backend ne sont pas joignables de l'extérieur (`nmap` depuis une autre machine) ; et une vérification que le compte de démonstration et le profil `dev` ne sont pas utilisés.

## Vie privée

L'installation d'un client contient des données personnelles : le personnel, les clients, et pour une Boutique en ligne les noms, numéros de téléphone, adresses et adresses e-mail des acheteurs, des abonnés à la lettre d'information et des visiteurs aux paniers abandonnés. Dites au client que les **règles de protection des données de son pays** s'appliquent à lui en tant que propriétaire des données, que les pages de la boutique (Politique de confidentialité, Conditions) doivent être adaptées à son activité et relues, que les sauvegardes doivent rester privées, et que le compte d'un acheteur peut être supprimé depuis le portail et un abonné retiré de l'écran Lettre d'information sur demande.

## Lacunes connues à garder à l'esprit

- La valeur par défaut de `app.jwt.secret` intégrée au jar est publique. Fixez **toujours** une valeur à vous dans les paramètres du client.
- Les vrais paiements MTN Mobile Money, Airtel Money et par carte n'ont été testés que contre des imitations. Le premier fournisseur réel d'un client doit être testé avec de petits paiements réels avant l'ouverture de la boutique.
- Le fournisseur de SMS est un substitut tant qu'aucune vraie société n'est connectée ; les codes par SMS restent dans la liste des SMS jusque-là (l'e-mail part quand même).
