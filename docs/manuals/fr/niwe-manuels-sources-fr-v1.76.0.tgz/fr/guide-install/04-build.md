# Compiler le programme

Vous compilez **une fois par version**, pas une fois par client. Le même jar et le même dossier de frontend vont chez chaque client.

## Ce qu'il faut sur la machine de compilation

Java 21 et Maven pour le backend ; Node.js (la version utilisée par le projet) et npm pour le frontend ; les sources du projet à l'étiquette (tag) de la version que vous compilez.

## Backend

```bash
cd backend
mvn clean verify          # compile, lance les tests, produit target/pos-app-<version>.jar
```

Le résultat est `backend/target/pos-app-<version>.jar` (par exemple `pos-app-1.76.0.jar`). Il contient le programme et ses migrations. Vérifiez que le numéro de version dans le nom du fichier est bien celui que vous vouliez compiler. Gardez le jar : le même fichier va chez chaque client, et l'ancien jar est votre chemin de retour (chapitre 7).

> **Attention :** Ne démarrez pas le serveur d'un client avec le profil `dev`. Il active des données de démonstration, un mot de passe administrateur connu et le réglage qui traite chaque module comme sous licence. Les serveurs des clients n'utilisent aucun profil, ou le fichier de paramètres privé du client.

## Frontend

```bash
cd frontend
npm ci
npx ng build --configuration production
```

Le résultat est le dossier `frontend/dist/pos-frontend/browser/` (le dossier qui contient `index.html`). Empaquetez-le pour l'expédition : `tar -czf niwe-1.76.0-frontend.tgz -C dist/pos-frontend/browser .`. La version de production demande l'API à l'**adresse relative `/api`**, donc elle fonctionne derrière n'importe quel domaine et n'importe quel certificat sans changement.

- N'utilisez **pas** les configurations de compilation `niweSoft`, `accounting` ou `store` pour un client : ce sont les propres sites de NIWE et ils peuvent pointer vers des adresses de NIWE.
- Les fichiers portent un hachage dans leur nom, donc un navigateur récupère les nouveaux fichiers après chaque version ; la page `index.html` elle-même est toujours demandée d'abord au réseau.
- **Logos de paiement.** Si le client utilise MTN Mobile Money ou Airtel Money, placez les fichiers de logo officiels dans `frontend/src/assets/payment/mtn_momo.png` et `airtel_money.png` **avant** de compiler (les logos sont des marques déposées et ne sont pas fournis). Sans eux, les boutons affichent le nom du fournisseur, ce qui fonctionne.

## Quoi conserver

Pour chaque version, conservez : le jar, le dossier de frontend compressé, les notes de version et la sortie de la compilation (pour pouvoir montrer qu'elle était propre). Nommez-les avec la version, par exemple `niwe-1.76.0-backend.jar` et `niwe-1.76.0-frontend.tgz`, à un endroit unique accessible à toute personne qui déploie. Les serveurs des clients reçoivent ces fichiers ; ils ne compilent pas.

## Avant d'envoyer une version aux clients

1. La compilation est propre et les tests passent.
2. La version a été essayée sur une **copie de la base d'un vrai client** (une sauvegarde restaurée) : les migrations se sont exécutées, vous avez pu vous connecter et les écrans principaux se sont ouverts.
3. Les notes de version listent chaque **action ponctuelle** (un nouveau paramètre, une nouvelle règle du serveur web, une nouvelle clé) et disent à quelles versions elle s'applique.
4. Les **Notes de version et de mise à jour pour les clients** ont une nouvelle ligne pour la version.
