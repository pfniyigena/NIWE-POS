# Premier démarrage et recette

Après le chapitre 5, le programme tourne. Ces étapes transforment un programme qui tourne en installation d'un client. Faites-les dans cet ordre et cochez chacune dans le registre des clients.

## La liste de contrôle

1. **Connectez-vous** en tant que `admin` en https et **changez le mot de passe** (Mon profil). Supprimez ou désactivez tout compte de démonstration s'il en existe (il ne devrait pas y en avoir avec `app.seed-demo-data=false`).
2. **Paramètres > Modules** : copiez l'**identifiant d'installation** et envoyez-le à NIWE avec la liste des modules achetés par le client. NIWE émet un fichier de licence `.niwelic` signé pour cet identifiant ; **téléversez-le**. Le message *Licence installée* apparaît. Une licence d'une autre installation ne fonctionnera pas, et une installation restaurée depuis une sauvegarde garde son identifiant.
3. **Activez** les modules dont le client a besoin. L'activation est **définitive** : n'activez donc que ce que l'entreprise utilisera. Seuls les modules de base (Ventes, Achats, Comptabilité) fonctionnent sans licence.
4. **Comptabilité** : l'écran initial demande le **pays du plan comptable** (Rwanda ou Tchad). Il fixe les numéros de compte et la devise (RWF ou XAF) et il est verrouillé ensuite : mettez-vous d'abord d'accord avec le comptable du client.
5. **Paramètres > Informations de l'entreprise** (nom, adresse, numéro fiscal, logo), **Paramètres système** (symbole monétaire, format de date, langue : le Tchad démarre en français, le Rwanda en anglais), **Taxes** (TVA 18 % pour le Rwanda) et **Modes de paiement**.
6. **Agences et entrepôts**, si l'entreprise a plus que le siège.
7. **Rôles et personnel** : un compte par personne, des rôles personnalisés pour le comptable, le magasinier et les caissiers, et les permissions d'approbation seulement pour ceux qui en ont besoin (Manuel de l'administrateur, chapitre 4).
8. **Paramètres e-mail** : saisissez le compte d'envoi et appuyez sur **Envoyer un e-mail de test** ; un vrai message doit arriver à une vraie adresse. Les réinitialisations de mot de passe, les rapports et les messages de la boutique en dépendent.
9. **Réglages du serveur visibles à l'écran** : **Paramètres > Modules** ne doit pas dire *L'interrupteur développeur est activé* ; la page doit être servie en https (le cadenas).
10. **Sauvegarder maintenant** (Paramètres > Sauvegarde et données) et vérifiez que le fichier apparaît dans la liste et dans `/opt/niwe/acme/backups/`.
11. **Copiez la sauvegarde hors du serveur** (une autre machine ou un stockage en ligne), et mettez en place la routine du chapitre 7.
12. **Test de restauration** : restaurez cette sauvegarde dans une **base vide distincte** (une base de secours sur ce serveur), démarrez une seconde copie du backend sur un autre port contre cette base, connectez-vous et regardez les données. Puis supprimez la copie de test. Une restauration qui n'a jamais fonctionné n'est pas une sauvegarde.
13. **Test rapide** des modules utilisés : faites une vente en caisse et imprimez un ticket, créez une facture, recevez un achat, et vérifiez que les écritures apparaissent dans le Journal. Pour la Boutique en ligne : ouvrez `/shop`, passez une commande en espèces, acceptez-la et terminez-la, puis lisez les écritures.
14. **Notez** dans le registre des clients : la version, le numéro de licence et son échéance, l'identifiant d'installation, les modules, le port, le lieu de sauvegarde, la date du test de restauration et la personne à appeler.

## Lire le journal du premier démarrage

Lors d'un premier démarrage propre, vous devez voir, dans cet ordre : Flyway créant le schéma et appliquant chaque migration (la dernière est la plus récente de cette version), la ligne **Started PosApplication**, puis quelques secondes plus tard le rattrapage comptable qui ajoute les comptes manquants. Si le mot de passe de l'administrateur n'a pas été fixé, une ligne commençant par **FIRST START** donne le mot de passe à usage unique : copiez-le une fois, puis changez-le.

## Quand le premier démarrage échoue

| Ce que dit le journal | Que faire |
|---|---|
| *Connection refused* ou *password authentication failed* | La base ne tourne pas, l'adresse est fausse, ou l'utilisateur ou le mot de passe de `config/application.properties` est faux. Testez avec `psql` en utilisant les mêmes valeurs. |
| *Migration checksum mismatch* | Un fichier de migration diffère de celui que cette base a appliqué. Vous exécutez une autre compilation que celle avec laquelle la base a été créée. Utilisez le bon jar ; ne modifiez jamais une migration. |
| *Detected applied migration not resolved locally* ou *a migration it does not know* | La base a été créée par une version **plus récente** que ce jar. Déployez la version plus récente. |
| *Schema-validation: missing column / table* | La base est en retard sur le code. Cela ne devrait pas arriver sur une base vide ; si c'est une ancienne base, voir le chapitre sur les mises à jour du Manuel de l'administrateur (le démarrage ponctuel `dbsync`, après une sauvegarde). |
| *Address already in use* | Un autre programme (souvent une seconde copie du même client) utilise le port. Vérifiez le plan de ports. |
| *Failed to create backup directory* | Le compte de service ne peut pas écrire dans le dossier à côté du jar. Corrigez le propriétaire de `/opt/niwe/acme`. |

## La remise au client

Avant de quitter le client : remettez à l'administrateur le **Manuel de l'administrateur**, le **Manuel utilisateur** et les **Fiches de démarrage rapide** des rôles utilisés ; dites-lui qui appeler ; et convenez de la date de la première fenêtre de mise à jour. Le **Guide d'intégration d'un client** prend le relais à partir d'ici.
