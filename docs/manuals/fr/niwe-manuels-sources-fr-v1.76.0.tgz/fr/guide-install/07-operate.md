# L'exploitation : sauvegardes, mises à jour et supervision

## Sauvegardes : trois niveaux

1. **La sauvegarde nocturne du programme.** Une sauvegarde complète de la base se lance chaque nuit (à 2 h, heure du serveur, sauf changement par `app.backup.cron`) dans le dossier `backups` à côté du jar. Le personnel peut aussi appuyer sur **Sauvegarder maintenant** dans Paramètres > Sauvegarde et données. Ces fichiers incluent l'historique des migrations, donc une restauration ramène ensemble les données et la structure.
2. **Une copie au niveau du serveur, hors de la machine.** Les fichiers nocturnes sont sur le même serveur : si le serveur est perdu, les sauvegardes le sont avec lui. Copiez le dossier `backups` vers une autre machine ou un stockage en ligne chaque jour (par exemple `rclone` ou `rsync` dans une tâche cron), et conservez les copies : **tous les jours pendant 30 jours, une par semaine pendant trois mois, une par mois pendant un an**. Chiffrez la copie si elle quitte le pays du client ou votre contrôle, car une sauvegarde contient les noms, numéros de téléphone et adresses des clients.
3. **Les fichiers hors de la base.** Si le client utilise un dossier de stockage pour des documents téléversés, incluez-le dans la même copie. Les bannières et les images de produits sont dans la base, donc dans la sauvegarde.

> **Attention :** Restaurer une sauvegarde faite par une version **plus récente** dans une version **plus ancienne** échoue (« a migration it does not know »). Restaurez dans la version qui l'a faite, ou une plus récente.

**Exercice de restauration.** Chaque trimestre, et une fois à l'installation : restaurez la dernière copie dans une base de secours, démarrez un backend de secours contre elle, et vérifiez que vous pouvez vous connecter et que les ventes du jour sont là. Notez la date dans le registre.

**Restaurer en urgence.** Dans le programme : Paramètres > Sauvegarde et données > **Restaurer** (ou téléversez un fichier). Cela met tout le système en mode maintenance pendant l'opération, et vous redémarrez l'application à la fin. Si le programme lui-même ne démarre pas, restaurez avec les outils de la base : arrêtez le service, supprimez et recréez la base vide (chapitre 3), lancez `pg_restore` avec la sauvegarde, puis démarrez le service de la même version que la sauvegarde.

## Mettre à jour un client

La même routine pour chaque client, que l'écart soit d'une version ou de vingt :

1. **Lisez les notes de version** de chaque version entre celle du client et la cible, et les **actions ponctuelles** des *Notes de version et de mise à jour pour les clients* (un nouveau paramètre, une nouvelle règle nginx, une nouvelle clé, une vérification du plan comptable).
2. **Annoncez** une courte fenêtre au client.
3. **Sauvegarde** : appuyez sur Sauvegarder maintenant, puis copiez le fichier hors du serveur. Notez la version actuelle et gardez l'**ancien jar**.
4. Pour un client très en retard, **essayez d'abord la mise à jour sur une copie** : restaurez la sauvegarde dans une base de secours et démarrez le nouveau jar contre elle. Regardez les migrations s'exécuter.
5. **Arrêtez** le service : `sudo systemctl stop niwe-acme`.
6. **Remplacez** le jar (copiez le nouveau sur `/opt/niwe/acme/pos-app.jar` en gardant l'ancien sous le nom `pos-app.jar.prev-1.75.0`) et le dossier du frontend (remplacez les fichiers dans `/var/www/niwe/acme`).
7. Appliquez les **actions ponctuelles** (paramètres dans `config/application.properties`, règles nginx, puis `nginx -t && systemctl reload nginx`).
8. **Démarrez** le service et surveillez le journal : chaque nouvelle migration appliquée, puis **Started PosApplication**.
9. **Vérifiez** : connectez-vous, Paramètres > Modules (licence et modules), ouvrez quelques écrans, faites une vente de test ; après quelques secondes, regardez **Comptabilité > Plan comptable** pour de nouveaux comptes quand les notes de version l'indiquent.
10. Notez la nouvelle version et la date dans le registre des clients.

**Revenir en arrière.** Si la mise à jour échoue *avant* l'exécution des migrations, remettez l'ancien jar et l'ancien frontend et démarrez. Si les migrations se sont exécutées, la base est déjà plus récente : **restaurez la sauvegarde** faite à l'étape 3 dans une base vide (le programme ne peut pas annuler une migration), remettez l'ancien jar et l'ancien frontend et démarrez. Communiquez au développeur l'erreur exacte du journal.

Ne modifiez ni ne supprimez jamais une migration, n'exécutez jamais de SQL à la main sur la base d'un client sans sauvegarde, et ne faites jamais de mise à jour le vendredi après-midi.

## Supervision

Il ne faut pas grand-chose pour repérer tôt un problème :

- **Est-il en ligne ?** Un contrôle de disponibilité sur `https://erp.acme.com/` (un moniteur gratuit suffit) qui vous écrit.
- **L'espace disque** du disque de données et du disque des sauvegardes, avec une alerte à 80 %.
- **Les journaux** : `logs/niwe-erp-error.log` contient les erreurs, `logs/niwe-erp.log` tout, `logs/niwe-access.log` les requêtes. Le personnel peut lire le journal du serveur dans Paramètres > Journaux du serveur. Regardez le journal d'erreurs après chaque mise à jour et une fois par semaine.
- **Les sauvegardes sont arrivées** : un contrôle quotidien (ou automatique) que le fichier de la nuit existe hors du serveur et n'est pas vide.
- **Échéance de la licence** : l'administrateur voit un avertissement dans les 30 derniers jours ; vous devez aussi connaître la date par le registre.
- **Échéance du certificat** : certbot renouvelle tout seul ; vérifiez que `systemctl list-timers` montre le minuteur de renouvellement.

## Déplacer un client vers un autre serveur

Faites une sauvegarde ; installez la même version sur le nouveau serveur comme aux chapitres 2 à 5 (le **même identifiant d'installation accompagne la base**, donc la licence continue de fonctionner) ; restaurez la sauvegarde dans la nouvelle base vide ; copiez le fichier de paramètres (ne changez les adresses que si elles ont changé) ; faites pointer le domaine vers le nouveau serveur ; démarrez. Gardez l'ancien serveur inchangé jusqu'à ce que le client ait travaillé une journée sur le nouveau.
