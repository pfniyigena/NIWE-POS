# Préparer le serveur

Ces étapes se font **une fois par serveur**, pas une fois par client. Les commandes sont pour Ubuntu Server 22.04 ou 24.04 LTS ; utilisez l'équivalent sur un autre système.

## Dimensionnement

Pour un client avec jusqu'à 20 employés environ et une boutique publique à trafic modéré : **2 vCPU, 4 Go de mémoire, 40 Go de disque**, le disque grandissant avec le nombre de factures, d'images de produits et de sauvegardes. Ajoutez 1 Go de mémoire et un vCPU pour chaque client supplémentaire sur le même serveur. Mettez les sauvegardes sur un **autre disque ou une autre machine** que la base de données.

## Installer les programmes

1. **Mettez le système à jour** et réglez le **fuseau horaire** sur celui du client : `sudo timedatectl set-timezone Africa/Kigali` (Rwanda) ou `Africa/Ndjamena` (Tchad). Les rapports, les tâches quotidiennes et le « aujourd'hui » de la boutique utilisent le fuseau horaire du serveur. Un serveur dans le mauvais fuseau place les ventes le mauvais jour.
2. **Java 21** : `sudo apt install openjdk-21-jre-headless`. Vérifiez avec `java -version`.
3. **PostgreSQL** (une version prise en charge, par exemple 16) : `sudo apt install postgresql postgresql-client`. La fonction de sauvegarde lance `pg_dump` et `psql` depuis le serveur d'application ; les **outils clients doivent donc être installés sur la machine qui exécute le backend** et être de la **même version majeure que la base**.
4. **nginx** : `sudo apt install nginx`. Et **certbot** pour les certificats gratuits : `sudo apt install certbot python3-certbot-nginx`.
5. **Un compte de service** : `sudo useradd --system --home /opt/niwe --shell /usr/sbin/nologin niwe`, puis `sudo mkdir -p /opt/niwe /var/www/niwe && sudo chown niwe:niwe /opt/niwe`.

## Pare-feu et accès

- N'autorisez que **22** (SSH, idéalement depuis des adresses connues ou par clés seulement), **80** et **443**. Les ports du backend et **PostgreSQL (5432) ne doivent pas être joignables depuis internet** : liez la base à `localhost` (le réglage par défaut) et laissez nginx être la seule porte publique.
- Désactivez la connexion SSH par mot de passe et utilisez des clés.
- Activez les mises à jour de sécurité automatiques (`unattended-upgrades`).

## Vérifications : heure, disque et mémoire

- L'heure doit être correcte (`timedatectl` indique « System clock synchronized: yes ») : les jetons de connexion et les vérifications de paiement en dépendent.
- Assurez-vous d'avoir assez d'espace disque pour au moins trois sauvegardes nocturnes plus la base. Un disque plein arrête la base.
- Donnez assez de mémoire à Java : par défaut c'est un quart de la mémoire ; pour un serveur avec plusieurs clients, réglez `-Xmx1g` pour chaque service (voir le fichier de service).

## Le serveur web en frontal

Le backend ne doit jamais faire face directement à internet. Pour chaque client, nginx fait ce qui suit (le chapitre 5 donne le fichier de site complet) :

1. répond en **HTTPS** avec le certificat du client et redirige http vers https ;
2. sert le frontend statique, tout chemin inconnu revenant à `index.html` (les écrans du personnel et la boutique forment une seule application monopage) ;
3. transmet `/api/` au port du backend du client, en ajoutant les en-têtes qui indiquent au backend l'adresse réelle du visiteur et que la connexion était en https ;
4. autorise les envois jusqu'à 100 Mo (`client_max_body_size 110m`), car le programme accepte des fichiers de sauvegarde et des imports de cette taille ;
5. porte les règles qui fournissent les aperçus de partage, `/sitemap.xml` et `/robots.txt` à la boutique.

Comme nginx se place devant, réglez `server.forward-headers-strategy=native` dans les paramètres du client, pour que les limites « par connexion » voient l'adresse réelle de chaque visiteur (sinon tout le monde partage une seule adresse et est limité ensemble).
