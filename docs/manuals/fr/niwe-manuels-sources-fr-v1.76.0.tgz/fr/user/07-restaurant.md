# Restaurant

Le groupe **Restaurant** comprend : **Annulations et offerts, Analyse des ventes, Fin de journée, Rapports, Tables, Menu, Paramètres**, et les écrans de travail accessibles depuis le **plan de salle** : *Toutes les commandes, À emporter / Livraison, Tableau des livraisons, Écran cuisine, Réservations, Reçus, Pertes, Rapports*.

## Une journée de service en bref

1. Les serveurs ouvrent le **plan de salle**, touchent une table et **ouvrent une commande**.
2. Ils ajoutent des plats du menu, notent les allergies et **Envoyer en cuisine**. La cuisine prépare sur l'**Affichage cuisine**.
3. Quand les clients demandent l'addition, le serveur imprime l'**Addition**, encaisse à l'**Encaissement** (espèces, carte, partagé ou mis sur une chambre d'hôtel).
4. À la fermeture, un responsable lance la **Fin de journée** (la clôture de caisse).

## Préparer le menu et les tables (responsable)

**Tables > Nouvelle table** : **Nom** (Table 1), **Section** (Salle principale), **Capacité**, **Actif**. Une table peut être marquée *Hors service* puis de nouveau *Disponible*.

**Menu** : créez des **Catégories**, puis ajoutez des produits à chaque catégorie. Pour chaque article, réglez :

- **Poste** (par exemple *Grill* ou *Bar* ; sert à diriger les tickets de cuisine), **Service** (entrée, plat, dessert), **Prép. (min)**.
- **Allergènes** et **Choix** (tailles, cuisson, suppléments : chaque option peut s'ajouter au prix ; un groupe peut être *Choix obligatoire* ou *Jusqu'à n*).
- **Prix au menu**. Une **recette** (depuis Production > Nomenclatures) fait déduire les ingrédients du stock quand le plat est vendu.

## Prendre une commande

Sur le **plan de salle**, touchez une table libre, saisissez le nombre de **Couverts** et appuyez sur **Ouvrir la commande**. L'écran de commande montre le menu à gauche et la commande à droite.

- Touchez un plat du menu pour l'ajouter. Les articles à choix ouvrent une fenêtre pour sélectionner les options. Ajoutez une **Note pour la cuisine** (les boutons de notes rapides comme *Sans oignons* se règlent dans les paramètres du Restaurant).
- Affectez une **Place** et un **Service** à chaque ligne pour que l'addition puisse être partagée par place et que les services soient lancés à tour de rôle. Les articles d'un service ultérieur attendent **en suspens** jusqu'à ce que vous appuyiez sur **Lancer le service**.
- **Allergies** : notez les allergies des clients ; le ticket de cuisine affiche des alertes ALLERGIE et les articles qui en contiennent.
- **Envoyer en cuisine** imprime ou affiche des tickets pour chaque poste. La ligne passe à *envoyé*.
- Avant l'envoi, une ligne peut être retirée. Après son départ en cuisine, la retirer demande l'**approbation d'un responsable** et un **motif** (**L'annuler**). **Offrir** demande un motif. **Renvoyer** enregistre une refaite.

### À emporter, livraison et service en chambre

**Nouvelle commande** (plan de salle) : choisissez **À emporter**, **Livraison** ou **Service en chambre**. Saisissez le nom et le téléphone du client ; la livraison demande une **adresse** ; le service en chambre demande la **chambre du client** (un client doit être enregistré). Puis **Ouvrir la commande**. Le **Tableau des livraisons** liste les livraisons avec **Livreur**, **En cours de livraison** et **Marquer comme livrée**.

### Commandes en ligne et codes QR

Si la page de commande publique est activée, les clients commandent sur votre page `/order` (à emporter / livraison) ou scannent le **code QR de la table** et envoient une commande que le personnel **accepte** sous **Commandes en ligne**. Réglez les **Zones de livraison** (frais, commande minimale, minutes supplémentaires) et imprimez les **codes QR des tables** sous *Zones de livraison et codes QR*. Un nouveau code remplace et annule l'ancien.

## Déplacer, fusionner et diviser

- **Déplacer la table** : déplace toute l'addition vers une table libre.
- **Fusionner dans** : fusionne cette commande dans la commande d'une autre table ouverte.
- **Diviser / déplacer des articles** : déplace des lignes choisies vers une nouvelle note à la même table (par place, ou une par une) pour que les clients paient séparément.

## L'addition et le paiement

La commande affiche **Sous-total, Remises accordées, Frais de service, Taxe, Arrondi, Total, Pourboire, Acompte de réservation déjà payé** et **Solde dû**.

1. **Addition** imprime l'addition du client (marquée « pas un reçu »).
2. **Remise** : un pourcentage ou un montant sur toute l'addition avec un **Motif**. Une remise supérieure à la limite du serveur, ou l'annulation des frais de service, demande un responsable.
3. **Encaissement** : ajoutez des paiements avec **+ Ajouter un paiement** : choisissez le mode et le montant, ou utilisez **Montant personnalisé**, **Partager à parts égales**, **Partager par article** ou **Partager par parts de clients**. Choisissez un **Pourboire** (boutons de pourcentage rapides ou **Pas de pourboire**). **Mettre sur quelle chambre ?** le met sur le compte d'un client de l'hôtel.
4. L'écran affiche la **Monnaie à rendre**. Un acompte déjà payé est déduit.
5. Terminez le paiement. Le reçu s'imprime ; la table est libérée.

**Annuler la commande** libère la table sans vente ; si une partie est partie en cuisine, un motif et l'approbation d'un responsable sont exigés.

## Écran cuisine et passe

- **Affichage cuisine** : tickets par statut *en attente, en cuisson, prêt*. Boutons : **Commencer la préparation**, **Marquer comme prêt**, **Marquer comme servi**, **Tout valider pour cette commande**, **Refaire**. Les tickets passent à l'orange puis au rouge à mesure que le temps s'écoule. **Épuisé (86)** permet à la cuisine de marquer un article comme indisponible, avec un motif.
- **Passe** : le comptoir de sortie. Montre chaque commande avec ce qui est complet ; **Tout marquer comme prêt**, **Servir**, **Refaire**.

## Réservations et liste d'attente

- **Réservations > Nouvelle réservation** : nom du client, téléphone, e-mail (pour les rappels), **Nombre de personnes**, **Date et heure**, **Minutes à table**, **Table** facultative, et un **Acompte** qui peut être pris tout de suite avec un mode de paiement. L'écran liste les **Heures libres ce jour-là**.
- Actions sur une réservation : **Installer**, **Modifier**, **Encaisser l'acompte**, **Rappeler**, **Absent**, **L'annuler**. **Marquer les réservations en retard comme absences** les traite d'un clic. **Installer par numéro de réservation** fonctionne quand le client montre son code.
- **Liste d'attente** : **Ajouter un groupe** (nom, téléphone, nombre de personnes, attente annoncée, note). Quand une table est libre, la liste affiche *Table prête* ; **Installez-les** ou marquez *Parti*.
- Si la page publique `/reserve` est activée, les clients réservent en ligne et la liste affiche *réservé en ligne*.

## Pertes

**Pertes > Enregistrer une perte** : choisissez le **Produit**, la **Quantité perdue** (un nombre positif), le **Motif** (*Détérioration, Brûlé / trop cuit, Tombé / renversé, Périmé, Parures, Plainte d'un client, Autre*) et une note. L'entrée est consignée ; quelqu'un qui a le droit *Confirmer les pertes du restaurant* la confirme ou la rejette. Alors seulement le stock et les comptes changent.

## Annulations et offerts

**Annulations et offerts** est le journal de chaque annulation, article offert et commande annulée : Quand, Genre, Table / client, Article, Qté, Valeur, Motif, Par, Approuvé par. Les responsables le contrôlent pour repérer des habitudes inhabituelles.

## Fin de journée

La **Fin de journée** est la clôture de caisse de la journée d'activité.

1. Réglez ou annulez les commandes encore ouvertes : l'écran les liste et ne se clôturera pas tant qu'elles ne sont pas réglées.
2. Passez en revue les **Ventes** (notes, couverts, brut, remises, net, frais de service, taxe, arrondi, total facturé, pourboires), **Modes de paiement**, **Par type de commande**, **Pourboires par serveur**, les **acomptes** de réservation et les **Annulations, offerts et commandes annulées**.
3. Dans **Espèces dans le tiroir**, l'écran calcule *fond d'ouverture + ventes en espèces + acomptes encaissés - acomptes remboursés + entrées - sorties - pourboires versés = devrait être dans le tiroir*. Saisissez le montant **Compté** ; la **Écart** s'affiche, puis **Laissé dans le tiroir** et **Remis en banque**. Ajoutez une note.
4. **Clôturer la journée**. Elle devient un rapport **Z** numéroté que vous pouvez **Imprimer**, ou exporter vers Excel, PDF ou CSV.

Si quelque chose est payé après la clôture de la journée, **Rouvrir la journée** (donnez un motif) et clôturez-la de nouveau.

## Analyse des ventes

**Analyse des ventes** montre, pour une période : ventes nettes, notes, couverts, note moyenne, par couvert, marge, pourboires et temps à table ; les ventes **par heure, jour de la semaine, type de commande, mode de paiement, par jour, par catégorie**, et le **Mix du menu** : *Vedette* (se vend bien et rapporte bien, à protéger), *Cheval de labour* (se vend bien, rapporte peu : augmentez le prix ou utilisez une recette moins chère), *Énigme* (rapporte bien, se vend peu : à promouvoir) et *Poids mort* (se vend peu et rapporte peu : à retravailler ou à retirer).

## Reçus

**Reçus** liste les additions payées avec **Voir / Imprimer**. Une réimpression est marquée COPIE et n'ouvre jamais le tiroir-caisse.

## Paramètres

Un administrateur règle les **frais de service** par type de commande, la limite de remise du serveur, les pourboires, les notes rapides de cuisine, les délais de cuisine, l'arrondi et les réservations de tables (Manuel de l'administrateur, chapitre 7).

## Rapports

**Restaurant > Rapports** : Ventes par type de commande, Commandes (tous types), Ventes par plat du menu, Ventes par catégorie du menu, Profit par plat du menu, Profit par catégorie du menu, Ventes par serveur, Commandes annulées et Pertes, avec export Excel, PDF et CSV.
