# Ventes

Le groupe **Ventes** (la vente en arrière-boutique, par opposition à la caisse) comprend : **Devis, Commandes clients, Listes de prix, Groupes de clients, Retours de commandes clients, Factures, Factures récurrentes, Avoirs, Rapports, Paramètres**. Les promotions, cartes cadeaux et la fidélité (activées dans **Ventes > Paramètres**) ont leurs propres pages.

## Le parcours de vente

Pour la vente entre entreprises ou sur compte, le parcours habituel est :

**Devis** (une offre) → **Commande client** (le client est d'accord) → **Préparer** (livrer les marchandises) → **Facture** (demander le paiement) → **Enregistrer le paiement**.

Vous pouvez commencer à n'importe quelle étape : une facture peut être établie sans devis ni commande.

## Devis

Un devis est une offre avec une date de validité. Il ne déplace ni le stock ni la comptabilité.

1. **Ventes > Devis > Nouveau**.
2. Choisissez le **Client** (ou appuyez sur **+ Nouveau client** pour en ajouter un : nom, téléphone, e-mail, numéro fiscal).
3. Réglez éventuellement **Valable jusqu'au**, l'**Agence** (si vous en avez plusieurs) et les **Notes**.
4. Réglez éventuellement une **Remise (devis entier)** en **Pourcentage** ou **Montant fixe** (ce champ n'apparaît que quand votre administrateur a réglé les remises sur *Globale* ; en mode *Par ligne*, chaque ligne a sa propre **Remise %**).
5. Sous **Lignes**, cherchez un produit par nom, référence ou code. La liste montre le stock et le prix. Réglez la **Quantité** et le **Prix unitaire**. **+ Nouveau produit** ajoute un produit rapide (nom, prix unitaire, description) que vous complétez plus tard.
6. Vérifiez les totaux (**Sous-total, Taxe, Remise, Total général**) et appuyez sur **Enregistrer le brouillon**.

Sur le devis, les boutons suivent son statut : **Modifier**, **Envoyer au client** (envoie le PDF par e-mail, statut *Envoyé*), **Marquer comme accepté**, **Marquer comme expiré**, **Rejeter**, et **Convertir en commande client**. Statuts : *Brouillon, Envoyé, Accepté, Refusé, Expiré*.

> **Conseil :** Si le client appartient à un *groupe de clients*, la liste de prix du groupe est utilisée automatiquement pour les prix.

## Commandes clients

Une commande client enregistre ce que le client a accepté d'acheter. Elle ne réserve rien tant que vous ne la préparez pas.

1. **Ventes > Commandes clients > Nouveau** (ou **Convertir en commande client** sur un devis). Le formulaire est le même que pour un devis, avec la **Date prévue**.
2. **Enregistrer le brouillon**. Appuyez sur **Confirmer** quand c'est convenu. Une commande confirmée ne peut pas être modifiée librement ; utilisez **Annuler la commande** si elle n'aura pas lieu.
3. **Préparer la commande** : choisissez **Préparer depuis** (l'entrepôt ou l'emplacement), saisissez **Préparé maintenant** pour chaque ligne (la quantité restante est affichée), saisissez les **Numéros de série livrés** si le produit est suivi par numéro de série (sinon le plus ancien en stock est utilisé), et appuyez sur **Enregistrer la préparation**. Le stock baisse. Les commandes livrées en partie sont *Partiellement honorées* ; quand tout est livré, elle est *Préparée*. Vous pouvez imprimer un **bon de livraison**.
4. **Générer la facture** crée la facture de la commande ; **Voir la facture** l'ouvre.

La page de la commande montre **Payé**, **Reste à payer**, **Retourné** et **Remboursement dû au client**.

### Retours sur une commande client

**Traiter un retour** vous permet de choisir ce que le client retourne (**Retourné maintenant**), où remettre le stock (**Remettre le stock dans**) et un **Motif**. Le retour apparaît sous **Historique des retours** et dans **Ventes > Retours de commandes clients**. Un **Remboursement dû** est créé si la commande était déjà payée.

## Factures

**Ventes > Factures** liste toutes les factures (recherche par numéro de facture, client ou commande client ; filtre par statut, date et agence).

- **Nouvelle facture** : même formulaire qu'une commande, plus la **Date d'échéance**. Appuyez sur **Enregistrer le brouillon**.
- Un **Brouillon** peut encore être modifié ou supprimé (**Supprimer le brouillon**). Appuyez sur **Émettre la facture** pour la rendre officielle : elle reçoit son numéro, est comptabilisée, réduit le stock s'il ne l'a pas déjà été par la préparation, et peut être envoyée par e-mail au client et à la liste des destinataires de factures définie dans les paramètres des Ventes.
- **Enregistrer le paiement** : saisissez le **Montant du paiement** (jusqu'au reste à payer), le **Mode de paiement** et une **Note** facultative. Les paiements partiels sont normaux. **Historique des paiements de cette facture** montre chaque encaissement. **Enregistrer un autre paiement** pour les échéances suivantes.
- **Payer en plusieurs fois** (si le module Paiements échelonnés est actif) transforme une facture impayée en plan de paiement.
- Erreurs après l'émission : **Annuler la facture** (donnez un motif ; rien n'a été payé) ou **Annuler et créditer la facture** (quand il y a des paiements : vous choisissez de **Rembourser** par un mode ou de transférer l'argent vers le **Crédit client**). Les deux créent un **avoir**.

Statuts : *Brouillon, Émise, Partiellement payée, Payée, Annulée, Résiliée*.

## Avoirs

**Ventes > Avoirs** liste les avoirs (N° d'avoir, N° de facture, Client, Annulé, Motif, Montant) avec **Voir la facture** et **Imprimer**. Un avoir est émis automatiquement quand une facture est annulée ; vous n'en créez pas à la main.

## Factures récurrentes

Pour une facturation régulière (une provision mensuelle, un loyer, des frais de service).

1. **Ventes > Factures récurrentes > Nouveau**.
2. Donnez-lui un **Nom**, le **Client**, la **Fréquence** (*Chaque semaine, Chaque mois, Chaque trimestre, Chaque année*), la **Prochaine exécution** et **Échéance en jours**.
3. Ajoutez les lignes ; le **Total général (chaque cycle)** est affiché.
4. Cochez **Actif** et enregistrez.

Une tâche quotidienne génère la facture suivante à la date de prochaine exécution ou après, puis avance la date d'un cycle. Décochez **Actif** pour mettre en pause.

## Listes de prix et groupes de clients

- Les **Listes de prix** contiennent des prix spéciaux. Une liste peut fixer un prix pour des produits précis (même un prix plus bas pour de plus grandes quantités) et augmenter ou diminuer tous les autres produits d'un pourcentage (**Ajuster tous les autres produits de (%)** : -10 veut dire 10 % en dessous du normal). Elle peut être limitée par **Valable du / Valable au** et activée ou désactivée.
- Les **Groupes de clients** placent des clients dans un groupe et donnent au groupe une liste de prix. En caisse, et sur les factures, devis et commandes clients, ces clients obtiennent alors les prix de la liste. Utilisez **Ajouter des clients** sur le groupe pour affecter des membres.
- Un prix que vous saisissez à la main n'est jamais remplacé par une liste de prix.

## Promotions et coupons

**Ventes > Promotions** (quand elles sont activées). Appuyez sur **Nouvelle promotion** :

- **Ce qu'il fait** : *Pourcentage de remise*, *Montant de remise*, ou *Achetez-en quelques-uns, obtenez-en gratuitement* (par exemple achetez 2 obtenez 1 gratuit, répété).
- **S'applique à** : *Un produit*, *Une catégorie* ou *Tout le panier*.
- Facultatif : **Dépense minimale requise**, **Valable du/au**, **Code promo** (avec un code, la promotion ne fonctionne que si le caissier le saisit), **Groupe de clients**, et limites sur le total d'utilisations et les utilisations par client.
- La liste montre le nombre d'**Utilisations** de chaque promotion ; **Ventes** liste les ventes qui l'ont utilisée.

La caisse calcule les promotions toute seule : chaque ligne reçoit la meilleure promotion pour son produit ou sa catégorie, puis la meilleure promotion sur tout le panier est retirée de ce qui reste, après toute remise saisie par le caissier. Les promotions s'appliquent en caisse, pas sur les factures, devis ou commandes clients. La Boutique en ligne les utilise aussi : un produit sans prix en ligne suit la liste de prix choisie dans les paramètres de la boutique et la meilleure promotion en pourcentage ou en montant pour tout le monde sur le produit ou sa catégorie (les promotions qui demandent un coupon, un groupe de clients, une limite, un minimum, « achetez X obtenez Y » ou qui couvrent tout le panier ne sont pas appliquées en ligne ; voir le chapitre Boutique en ligne).

## Cartes cadeaux

**Ventes > Cartes cadeaux** (quand elles sont activées). **Vendre une carte cadeau** : le **Montant**, **Payé par** (ou *Offerte*), **Acheté par**, **Pour**, **Expire le** et un **Code de la carte** (fabriqué pour vous s'il est vide).

> **Remarque :** L'argent payé pour une carte cadeau n'est **pas encore une vente**. La boutique le doit en marchandises, affiché comme **Dû sur les cartes cadeaux**. Il devient une vente quand la carte est dépensée en caisse.

Dans la liste, vous pouvez voir l'**Historique** d'une carte, **Ajouter de l'argent**, changer son **Expiration**, la **Bloquer** ou la **Débloquer**. Filtres : *Peut être dépensée maintenant, Argent restant, Vide, Bloquée, Expirée*. **Libérer les soldes expirés** fait passer les soldes expirés et non dépensés de « dû » en produit.

## Points de fidélité

**Ventes > Fidélité** (quand elle est activée). Un client nommé gagne des points sur chaque vente (le client de passage n'en gagne pas). Les points peuvent payer une partie d'une vente ultérieure en caisse.

Règles (fixées par un responsable) : dépense par point, points gagnés, ce que **vaut un point**, le **nombre minimal de points dépensables en une fois** et le pourcentage maximal d'une vente que les points peuvent payer. Ouvrez un client dans la liste pour voir son **Historique** ou **Ajouter ou retirer des points** (utilisez un moins pour retirer) avec un **Motif**.

## Paramètres des Ventes

Réservé à l'administrateur : activer ou désactiver **Promotions, Cartes cadeaux, Points de fidélité** et régler les **E-mails destinataires des factures**.

## Rapports

**Ventes > Rapports** : Commandes clients, Ventes par client, Ventes par produit, Ventes par catégorie, Factures, Avoirs, Retours de commandes clients, Paiements des clients, **Ancienneté des créances clients**. Chacun a des filtres de dates et autres et s'exporte vers Excel, PDF et CSV.
