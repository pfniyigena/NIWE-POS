# Immobilisations

Le groupe **Actifs** (registre des immobilisations) comprend : **Registre des immobilisations, Vue d'ensemble, Nouvelle immobilisation, Depuis les achats, Catégories, Vérification, Rapports, Paramètres**. Il suit ce que l'entreprise possède pour des années (véhicules, ordinateurs, mobilier, équipement), l'amortit et comptabilise les écritures en Comptabilité.

## Catégories (à configurer d'abord)

**Actifs > Catégories** définit les valeurs par défaut pour chaque sorte d'immobilisation : **Nom**, **Mode**, **Durée d'utilité** (en mois), **Valeur résiduelle (% du coût)** et **Calculer le premier mois au prorata des jours**. Une nouvelle immobilisation de cette sorte démarre avec ces valeurs. Modifier une catégorie plus tard ne change pas les immobilisations déjà enregistrées. Une catégorie peut avoir ses propres comptes (actif, amortissements cumulés, dotation aux amortissements) ; laissés vides, les comptes standard sont utilisés. Exemples : *Ordinateurs* (36 mois), *Véhicules* (60), *Mobilier* (84).

## Enregistrer une immobilisation

**Actifs > Nouvelle immobilisation** :

| Champ | Signification |
|---|---|
| **Nom de l'immobilisation** et **Étiquette** | Par exemple *Camionnette de livraison*. Si l'étiquette est vide, une est générée (IM-0001...). |
| **Agence**, **Catégorie** | À quoi elle appartient et de quelle sorte elle est. |
| **Date d'achat**, **Coût** | Quand et pour combien. |
| **Méthode d'amortissement** | *Linéaire* (même montant chaque mois) ou *Dégressif* (plus élevé au début). **Durée d'utilité (mois)**, **Valeur résiduelle**, **Début de l'amortissement en**, **Calculer le premier mois au prorata des jours**. |
| **Amortissement déjà comptabilisé avant ce système** | Pour une immobilisation que vous possédez déjà : réglez *Début de l'amortissement en* sur le premier mois encore à comptabiliser. Ce montant d'ouverture n'est pas comptabilisé en Comptabilité. Enregistrez-le par une écriture si nécessaire. |
| **Comptabilisation de l'achat** | *Ne pas comptabiliser* (l'achat est déjà dans les comptes), *Comptabiliser : payé en espèces*, ou *Comptabiliser : dû au fournisseur*. |
| **Emplacement, Détenu par, Numéro de série, Fournisseur** | Où elle se trouve et qui l'a. |
| **Fin de garantie, Fin d'assurance, Police d'assurance** | Le registre et la vue d'ensemble vous avertissent avant ces dates. |
| **Notes** ; photos et fichiers | Joignez plusieurs photos et fichiers, comme la facture et la carte de garantie. |

**À partir d'un achat** transforme en une étape un article d'un bon de commande reçu en immobilisation.

## Le registre des immobilisations

Le registre liste les immobilisations avec **Étiquette, Immobilisation, Catégorie, Acheté, Coût, Cumulé, Valeur comptable, Agence, Lieu, Détenu par, Statut** et des totaux en haut. Utilisez la recherche (étiquette, nom, numéro de série, détenteur, lieu), les filtres (catégorie, agence, lieu, détenu par) et les **vues rapides** : *Toutes les immobilisations, Actives, Totalement amorties, Cédées, Garantie bientôt expirée, Garantie expirée, Assurance bientôt expirée, Assurance expirée*.

**Lancer l'amortissement** comptabilise tous les mois entiers jusqu'à la date choisie qui n'ont pas encore été comptabilisés et les passe en Comptabilité. Il se lance aussi tout seul chaque jour pour les mois terminés.

Cochez plusieurs immobilisations pour des actions groupées : **Déplacer...** (vers une autre agence ou un autre lieu, avec date et motif), **Remettre...** (à un utilisateur ou à un nom saisi), **Reprendre**, **Imprimer les étiquettes**.

## Travailler avec une immobilisation

Ouvrez une immobilisation pour voir ses détails et l'**historique de tout ce qui lui a été fait**. Boutons :

- **Imprimer l'étiquette** : une étiquette QR imprimable à coller sur l'immobilisation.
- **Historique de maintenance**.
- **Modifier** : détails seulement. Si l'amortissement ou la comptabilisation de l'achat existe déjà, le coût, les dates et les conditions d'amortissement ne peuvent pas être modifiés ici ; utilisez les actions ci-dessous.
- **Transférer...** : la déplacer vers une autre agence (l'amortissement jusqu'au mois précédent reste avec l'ancienne agence ; les mois suivants vont à la nouvelle) et/ou un nouvel emplacement.
- **Ajouter une amélioration** : l'argent dépensé qui rend l'immobilisation plus précieuse ou plus durable est ajouté à son coût ; l'amortissement est de nouveau réparti sur la durée restante à partir du mois suivant.
- **Déprécier la valeur (dépréciation)** : en cas de dommage ou quand elle vaut moins que la valeur comptable. Elle est passée en charge et ajoutée aux amortissements cumulés.
- **Modifier les conditions d'amortissement** : nouvelle durée restante, valeur résiduelle ou méthode, à partir du mois suivant la date choisie. Les mois déjà comptabilisés ne changent pas.
- **Annuler le dernier mois d'amortissement** : retire la dernière dotation par une écriture d'extourne. Impossible si une amélioration, une dépréciation ou un changement de conditions est daté après ce mois.
- **Confier cette immobilisation à quelqu'un** : confie la garde à un utilisateur ou à une personne nommée et imprime une **fiche de remise**.
- **Céder...** : saisissez la **Date de cession**, le **Produit de la vente** (0 = mise au rebut) et une note. L'amortissement est comptabilisé jusqu'au mois précédant la cession, puis la Comptabilité enregistre l'argent reçu, retire l'immobilisation et ses amortissements cumulés, et comptabilise le gain ou la perte. **Une valeur comptable au-dessus du plafond d'approbation demande un administrateur ou un utilisateur qui a le droit *Approuver les grosses cessions d'immobilisations*.**
- **Annuler la cession...** : une personne qui a les droits d'approbation peut annuler une cession faite par erreur. La Comptabilité reçoit une écriture d'extourne et l'immobilisation redevient active.
- **Supprimer** : seulement pour une immobilisation qui n'a aucune écriture.

## Vérification (comptage physique)

**Actifs > Vérification** contrôle que les immobilisations sont bien là où les comptes le disent.

1. **Commencer une tournée** : donnez-lui un **Nom** (par exemple *Inventaire de fin d'année*) et limitez-la par **Agence, Catégorie** ou **Lieu**. **Démarrer la tournée** liste les immobilisations qui devraient être là.
2. Faites le tour et marquez chaque immobilisation **Trouvé**, **Manquante** ou **Endommagé** (avec **trouvée à** et une note). **Marquer tout ce qui reste non vérifié comme Trouvé** accélère une tournée calme. **Déplacer les immobilisations vers le lieu où elles ont été trouvées** corrige les emplacements.
3. **Clôturer la tournée** une fois tout vérifié.
4. Une immobilisation **Manquante** peut être **Mise au rebut...** depuis la tournée.

## Vue d'ensemble

**Actifs > Vue d'ensemble** : **Immobilisations en service, Coût total, Amortissements cumulés, Valeur comptable, Amortissement du mois prochain, Totalement amorties, Cédées, Sans détenteur, Tournées de vérification ouvertes**, une alerte si l'amortissement a **des mois de retard**, des ventilations **par catégorie** et **par agence**, et une liste de surveillance : garantie ou assurance bientôt expirée, et immobilisations qui seront bientôt totalement amorties.

## Rapports

**Actifs > Rapports** : Registre des immobilisations, Immobilisations par catégorie, Immobilisations par emplacement, Immobilisations par détenteur, Expiration des garanties et assurances, Prévision d'amortissement, Mouvements des immobilisations, Vérification des immobilisations, Tableau d'amortissement, Cessions d'immobilisations, Transferts d'immobilisations.

## Paramètres (administrateur)

Les jours d'alerte pour la garantie et l'assurance, la fenêtre *bientôt totalement amortie*, et le **plafond d'approbation des cessions**.
