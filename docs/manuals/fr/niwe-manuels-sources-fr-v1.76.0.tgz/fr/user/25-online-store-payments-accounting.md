# Boutique en ligne : paiements, comptabilité et rapports

Ce chapitre s'adresse à la personne qui surveille l'argent de la boutique : le propriétaire, le caissier qui enregistre les versements, et le comptable. Il explique l'écran **Paiements en ligne**, comment chaque fournisseur de paiement est comptabilisé, ce que le programme comptabilise à chaque étape d'une commande, les contrôles hebdomadaires et mensuels, la publicité et les rapports de ventes.

## Paiements en ligne (écran)

**Boutique en ligne > Paiements en ligne** liste chaque paiement en ligne d'une période, avec des cartes pour **Payé**, **En comptabilité**, **Conservé pour les commandes ouvertes**, **Remboursements à faire**, **Remboursé**, **À vérifier** et **Échoués ou expirés**. Utilisez les filtres (**À vérifier**, **Remboursements à faire**, **Bloqués en attente**, **Payé**, **En attente**, **Échec**, **Expiré**) pour voir ce qui demande une personne :

- **À vérifier** : de l'argent est arrivé qui demande une personne, par exemple un montant différent de celui de la commande, ou un second paiement pour la même commande. Un tel paiement n'est **pas dans les comptes** tant qu'une personne ne l'a pas traité. Regardez-le, traitez-le (par exemple remboursez l'excédent), écrivez ce que vous avez fait et appuyez sur **Marquer comme traité**.
- **Remboursements à faire** (appuyez sur *Aller aux commandes pour le rembourser*) et **Bloqués en attente** (un paiement encore en attente bien après le moment où il aurait dû se clore).

La carte **Nécessite une attention** sur l'écran Commandes en ligne montre combien de paiements attendent une personne.

### Fournisseurs de paiement

Le client choisit un fournisseur au paiement quand plus d'un peut prendre le mode de paiement. Les fournisseurs sont activés par votre administrateur (Manuel de l'administrateur, chapitre 7) et choisis dans **Paramètres de la boutique > Paiements en ligne** :

- **MTN Mobile Money (MoMo)** pour le Rwanda : le client tape un numéro MTN et approuve sur le téléphone. Les remboursements peuvent repasser par MTN.
- **Airtel Money** pour le Rwanda : le client tape un numéro Airtel et approuve sur le téléphone. **Les remboursements se font à la main** : remboursez depuis le compte Airtel Money, puis enregistrez-le avec **Je l'ai remboursé moi-même** et la référence Airtel.
- **Carte**, quand un fournisseur de cartes a été connecté.
- **Un fournisseur simulé** existe pour les tests seulement ; ne l'utilisez jamais avec de vrais clients.

Un rappel (callback) d'un fournisseur n'est jamais cru sur parole : la boutique demande au fournisseur l'état du paiement et n'accepte le rappel que lorsque la réponse du fournisseur concorde. Un rappel perdu est couvert par une vérification de l'état environ une fois par minute.

## Où va l'argent : les comptes de chaque fournisseur

L'argent payé en ligne n'est **pas** de l'argent liquide dans votre main. Le fournisseur le garde jusqu'à ce qu'il vous le verse. Chaque fournisseur a donc deux comptes dans votre plan comptable :

- **Ce que le prestataire vous doit encore** (le compte d'*attente*) : les paiements que le fournisseur a confirmés et n'a pas encore versés.
- **Les versements arrivent sur** (le compte de *versement*) : le portefeuille ou le compte bancaire où le fournisseur verse.

Avec le plan du Rwanda, MTN Mobile Money utilise le compte d'attente 1021 et le portefeuille 1011 ; Airtel Money utilise 1022 et 1012 ; Carte utilise 1030 et le compte bancaire 1013 pour les règlements par carte. (Plan du Tchad : 5215 et 5217, 5216 et 5218, 5213 et 5219.) L'ancien compte d'attente commun Mobile Money (1020, Tchad 5212) reste pour le fournisseur de test et pour les commandes payées avant que ces comptes existent.

Ouvrez **Boutique en ligne > Paiements en ligne > Comptes par fournisseur** pour voir chaque fournisseur, activé ou non, et choisir ses deux comptes. Chacun peut être un compte d'actif existant ou un nouveau compte créé sur-le-champ (**Créer un nouveau compte...**, avec un nom suggéré et le prochain code libre). **Aucun** pour le compte de versement signifie Caisse et banque. Quand vous ajoutez un nouveau fournisseur (MOOV, ORANGE, une passerelle bancaire), il apparaît dans cette liste dès qu'un développeur l'a connecté, et vous choisissez ses comptes ici.

Règles que l'écran impose :

- un compte d'attente appartient à **un seul** fournisseur et doit être un compte d'actif ordinaire (pas Caisse et banque ni un autre compte système) ;
- un compte d'attente **ne peut pas être changé tant que le fournisseur vous doit encore de l'argent dessus** : enregistrez d'abord ses versements ;
- un compte de versement peut être partagé (par exemple un seul compte bancaire pour tous les versements par carte) ;
- les comptes d'attente et de versement d'un fournisseur doivent être différents.

Les commandes payées avant que vous fixiez ou changiez les comptes continuent d'utiliser les comptes sur lesquels elles ont été comptabilisées, de sorte qu'aucun solde ne bouge.

## Ce que le programme comptabilise pour une commande en ligne

Vous ne comptabilisez rien de tout cela à la main ; c'est ici pour que le comptable puisse suivre les écritures. Le libellé de chaque écriture se termine par le code de la commande, par exemple *(commande en ligne 9FMMY2MC)*, de sorte que chercher le code dans le journal trouve toutes les écritures d'une commande.

| Quand | Débit | Crédit |
|---|---|---|
| Le fournisseur confirme le paiement | Le compte d'attente du fournisseur | Acomptes clients en ligne (2810) |
| La commande est livrée : l'acompte est appliqué à la facture | Acomptes clients en ligne | Clients (créances) |
| La commande est livrée : marchandises, TVA et coût | Clients (créances) ; Coût des marchandises vendues | Chiffre d'affaires des ventes, TVA à payer ; Stock |
| La commande est livrée : la remise et les frais de livraison sont présentés à part | Remises accordées sur ventes (4040) ; Chiffre d'affaires des ventes (les frais) | Chiffre d'affaires des ventes (la remise) ; Produits de livraison (4030) |
| Une commande payée est annulée ou rejetée et l'argent est rendu | Acomptes clients en ligne | Le compte d'attente du fournisseur (remboursement via le fournisseur) ou Caisse et banque (remboursé à la main) |
| Une partie d'une commande payée n'est pas livrée et la différence est rendue | Acomptes clients en ligne | Idem |
| Des marchandises sont retournées et remboursées | Chiffre d'affaires des ventes, TVA à payer, Stock (au coût vendu) ; Clients (créances) | Clients (créances), Coût des marchandises vendues ; le compte d'attente du fournisseur ou Caisse et banque |
| Une commande en espèces est livrée | Espèces chez les livreurs (1050) | Clients (créances) |
| Le livreur remet les espèces | Caisse et banque (ce qu'il a remis) ; Écarts de caisse s'il manque | Espèces chez les livreurs ; Écarts de caisse s'il y a un excédent |
| Un client gagne des points de fidélité | Charges de récompenses clients | Dette de points de fidélité (2820) |
| Des points sont dépensés sur une commande livrée | Dette de points de fidélité | Charges de récompenses clients |
| Le fournisseur verse | Le compte de versement du fournisseur (net) ; Frais des fournisseurs de paiement (5240) | Le compte d'attente du fournisseur (brut) |

À savoir :

- **Le chiffre d'affaires des ventes montre le prix complet des marchandises.** La remise de coupon et de points est dans **Remises accordées sur ventes**, avant taxe, et les frais de livraison sont dans **Produits de livraison**, avant taxe. Le produit total d'une commande ne change pas.
- **Un retour extourne aussi la TVA**, pas seulement le prix net, et les marchandises retournent au Stock au coût qu'elles avaient quand elles ont été vendues, pas au prix de revient du jour. Une commande payable en espèces à la livraison dont le paiement n'a jamais été encaissé n'a rien à rendre : pas d'écriture de caisse.
- Rien n'est comptabilisé pour une commande **annulée ou rejetée** avant livraison, sauf l'acompte rendu quand elle était payée en ligne.
- **Agence** : avec plus d'une agence, les écritures de la boutique portent l'agence choisie dans Paramètres de la boutique > *Agence pour laquelle la boutique vend*.
- **Commandes d'avant les versions comptables.** Les commandes payées avant la version 1.71.0 n'ont pas d'acompte : leur paiement est comptabilisé sur le compte d'attente du fournisseur quand elles sont livrées. Les commandes livrées avant la version 1.72.0 règlent les espèces des livreurs avec la différence seulement. Les retours faits avant la version 1.70.0 gardent leur ancien chiffre de remboursement net. Les points de fidélité gagnés avant la version 1.73.0 ne sont pas dans la dette : passez une écriture manuelle d'ouverture pour les points que les clients détiennent déjà (Débit Charges de récompenses clients, Crédit Dette de points de fidélité, un point = une unité de monnaie).

## Versements : enregistrer ce que le fournisseur vous a payé

Ouvrez **Boutique en ligne > Paiements en ligne > Versements des fournisseurs**. Il montre un solde par fournisseur qui a un compte d'attente, puis Carte : **ce que le fournisseur vous doit encore**. Ces soldes viennent directement du grand livre (débits moins crédits), ils concordent donc toujours avec les comptes.

Pour enregistrer un versement, choisissez le fournisseur (**Mode**), tapez **Payé par les clients (brut)** (le total des paiements que ce versement couvre), les **Frais du prestataire**, la **Date** et une **Référence** du relevé du fournisseur, et appuyez sur **Enregistrer le versement**. **Arrivé à la banque** est calculé pour vous (brut moins frais). Le net va au compte de versement du fournisseur et les frais à **Frais des fournisseurs de paiement**. Si un fournisseur verse net de ses frais et des remboursements, saisissez quand même le brut que le versement couvre et les frais, pour que le reste arrive au bon compte.

Pour déplacer de l'argent du portefeuille d'un fournisseur vers votre banque principale, ou pour payer un fournisseur avec, passez un transfert par une écriture manuelle sur ces comptes.

Un solde sur l'ancien compte commun Mobile Money (paiements d'avant les comptes par fournisseur) est soldé par un versement du mode *Mobile money (paiements antérieurs)*, qui arrive dans Caisse et banque.

## Routines pour l'argent de la boutique

**Chaque jour** (propriétaire ou caissier) : comptez la caisse et enregistrez la différence ; comparez **Espèces chez les livreurs** avec le total *À remettre* d'**Espèces des livreurs** ; regardez **Paiements en ligne** pour les paiements *À vérifier* et les *Remboursements à faire*.

**Chaque semaine** (une personne désignée) : enregistrez chaque versement de fournisseur reçu, avec ses frais. Le solde de chaque fournisseur doit être à peu près ce qu'il a encaissé depuis son dernier versement ; un solde qui ne cesse de grossir ou devient négatif signifie qu'un versement ou un paiement manque. Cherchez les commandes bloquées dans un même statut, les livraisons échouées et les retours en attente.

**Chaque mois** (comptable) : les relevés de la banque, de MTN, d'Airtel et de la carte concordent avec leurs comptes ; la balance est équilibrée ; la TVA à payer concorde avec la déclaration fiscale ; les Clients (créances), les Fournisseurs (dettes) et le Stock (par rapport à un comptage de quelques produits) sont justes ; **Crédit clients à payer**, **Dette de cartes cadeaux** et **Dette de points de fidélité** concordent avec leurs listes de clients ; passez en revue **Écarts de caisse**, **Frais des fournisseurs de paiement** et **Suspens** (Suspens doit être à zéro : tout ce qui s'y trouve est une erreur à trouver). Puis verrouillez le mois en Comptabilité et faites une sauvegarde portant le nom du mois.

## Publicité

La boutique peut vendre de l'espace à d'autres entreprises. Ouvrez **Boutique en ligne > Publicité**, qui a trois onglets :

- **Annonceurs** : les entreprises qui vous paient.
- **Annonces** : une image, un lien (une simple adresse web, http ou https), les emplacements où elle apparaît, les dates, une note sur le tarif et un drapeau *payé*. L'image est vérifiée d'après son contenu et un gros JPEG ou PNG est réduit ; images jusqu'à 5 Mo.
- **Rapport** : vues, clics et taux de clic de chaque annonce sur une période, pour un annonceur ou tous, avec le tarif et si elle est payée. Imprimez-le ou enregistrez-le en PDF, ou téléchargez-le en CSV.

Il y a trois **emplacements** : le haut de la première page, au-dessus de la liste de produits (aussi sur les pages produit), et la page de suivi de commande. Plusieurs annonces dans un emplacement se relaient, chaque annonce est étiquetée **Publicité**, et les liens s'ouvrent dans un nouvel onglet. Une annonce compte comme *vue* quand elle est réellement à l'écran (une fois par visiteur et par demi-heure). Un clic passe par la boutique, qui le compte et envoie le visiteur à l'adresse enregistrée.

## Rapports de ventes en ligne

**Boutique en ligne > Rapports de ventes** a six rapports, chacun avec une date de début et de fin et le téléchargement habituel **Excel** et **PDF**. Ils figurent aussi dans la liste des rapports que vous pouvez recevoir par e-mail selon un calendrier (Rapports > Programmés).

**Une commande compte comme une vente le jour où elle a été terminée**, le jour où elle a été remise et où la facture a été émise, pas le jour où le client a commandé ou payé. L'argent est ce que dit la facture, de sorte que les totaux concordent avec vos factures. Les remboursements de retours sont montrés le jour où ils ont été remboursés.

- **Ventes en ligne par jour** : pour chaque jour, les commandes terminées, combien en livraison et combien en retrait, marchandises, remises de coupons, frais de livraison, **Facturé**, retours remboursés ce jour-là et **Net** (facturé moins remboursé).
- **Commandes des ventes en ligne** : chaque commande terminée avec son numéro de facture, **Facturé**, **Payé** et **Remboursé**, pour que vous puissiez vérifier un total commande par commande.
- **Ventes en ligne par moyen de paiement** : comment ces factures ont été payées (espèces, mobile money, carte), et **Pas encore encaissé** pour la part des factures que personne n'a payée.
- **Commandes en ligne non comptées comme ventes** : les commandes passées dans la période qui ne sont pas des ventes : **Ouvertes (en cours de traitement)**, **En attente de paiement en ligne**, **Jamais payées (annulées)**, **Annulé** et **Rejetée**, avec leur valeur, ce qui a été payé en ligne et ce qui a été remboursé. Utilisez-le pour voir l'argent qui attend encore ou qui doit être rendu.
- **Ventes en ligne par coupon** : pour chaque coupon, les commandes, la remise accordée, les frais de livraison offerts et le montant facturé.
- **Produits les plus vendus en ligne** : quantité vendue, chiffre d'affaires après coupons, quantité retournée et remboursements, et le net, le meilleur d'abord.

> **Remarque :** Une commande dont la facture a été annulée apparaît toujours comme une commande mais avec **Facturé** à 0, et un paiement sur une facture annulée n'est pas compté. Les rapports par jour et par paiement sont coupés à minuit dans le fuseau horaire du serveur.

## Limites connues

- Un paiement à vérifier n'est pas dans les comptes tant que le personnel ne l'a pas traité.
- Les vrais paiements MTN, Airtel et par carte dépendent des clés et de l'approbation du fournisseur. Avant d'ouvrir la boutique aux clients, faites un test avec chaque fournisseur : une petite vraie commande livrée, une annulée et remboursée, une partiellement retournée, et un versement enregistré et comparé au relevé du fournisseur lui-même.
- Un fournisseur qui verse net de ses frais : saisissez le brut et les frais, comme ci-dessus.
