# Ressources humaines et paie

Les menus RH sont : **Employés** (*Employés, Nouvel employé, Documents, Intégration, Rapports RH*), **Organisation** (*Services et postes, Organigramme*), **Présences** (*Présences, Congés, Calendrier de l'équipe, Paramètres*), **Contrats**, et **Paie** (*Campagnes de paie, Ajustements, Avances et prêts, Impôts et sécurité sociale, Règles et tranches d'impôt*).

L'accès aux RH demande le domaine *Ressources humaines*, et celui aux contrats et à la paie le domaine distinct *Paie et contrats*, parce qu'ils contiennent des données de salaire.

## Employés

### Ajouter un employé

**Employés > Nouvel employé** :

- **Informations personnelles** : prénom et nom, date de naissance, pièce d'identité nationale, téléphone, e-mail, adresse, contact en cas d'urgence et son téléphone.
- **Poste** : **Numéro d'employé** (automatique : EMP-0001...), **Date d'embauche**, **Type d'emploi** (*Temps plein, Temps partiel, Occasionnel, Stagiaire*), **Intitulé du poste**, **Département**, **Poste**, **Rattaché à**, **Agence**.
- **Identifiant du personnel (leur permet de pointer eux-mêmes)** : liez l'employé à un compte utilisateur, ou créez-en un avec **Donner un identifiant**. Le mot de passe est affiché une seule fois ; donnez-le à l'employé. Il utilise ensuite **Mes RH**.
- **Suivre la présence pour la paie** : une fois cochée, la paie déduit les jours d'absence et paie les heures supplémentaires d'après les relevés de présence. Laissez-la décochée pour le personnel salarié qui ne pointe pas.
- **Numéros bancaires et obligatoires** : banque, numéro de compte, numéro fiscal, numéro de sécurité sociale.

Plusieurs employés peuvent être chargés d'un coup avec l'**import des employés** (Excel/CSV avec un modèle ; utilisez d'abord *Vérifier le fichier*).

### La page de l'employé

Elle montre les détails, les **Soldes de congés**, les **Demandes de congé**, les **Contrats** (avec **+ Nouveau contrat**), les documents, les listes de tâches et l'**Attestation annuelle de revenus et d'impôt** (mois par mois le salaire brut, l'impôt sur le revenu et les cotisations des paies approuvées et payées pour une année).

Actions : **Modifier**, **Marquer inactif**, **Supprimer** (seulement s'il n'y a pas d'historique), **Donner un identifiant**, et **Employé parti** (saisissez le **Dernier jour** et le **Motif** ; cela met aussi fin au contrat actif à cette date et peut préparer le **Solde de tout compte**).

### Documents

**Employés > Documents** conserve les contrats, pièces d'identité, certificats et autres fichiers par employé, avec une **date d'expiration** ; les documents qui expirent sont résumés pour que vous puissiez les renouveler. Un employé peut voir les documents que les RH partagent avec lui dans **Mes RH**.

### Intégration et départ

**Intégration** contient des listes de tâches. Un **modèle** est une liste prête (nom, *Pour* les nouveaux arrivants ou les partants, tâches avec le responsable et une échéance comptée en jours à partir de la date d'embauche ou du dernier jour de travail). Démarrez une liste depuis la page d'un employé. **Tâches ouvertes** liste ce qui attend, avec **En retard seulement** et **Marquer comme terminé**.

## Organisation

- **Services et postes** : créez des services et des postes que vous choisissez sur les employés.
- **Organigramme** : montre les services et les **lignes hiérarchiques** à partir du champ *Responsable hiérarchique*.

## Présences

**Présences** a deux onglets. **Relevés journaliers** liste pour chaque jour *Arrivée, Départ, Heures, Heures supplémentaires, Statut* (*Présent, En retard, Absent*) avec des filtres. Les employés qui ont une connexion voient **Ma journée** et appuient sur **Pointer l'arrivée** et **Pointer le départ**. Les RH utilisent **Ajouter ou corriger un jour** pour saisir ou corriger un relevé (enregistrer une journée qui a déjà un relevé le remplace). Les heures et les heures supplémentaires sont calculées d'après les heures d'arrivée et de départ et les horaires de travail dans les **Paramètres**. **Récapitulatif** montre pour chaque employé les jours attendus, présents, en retard, absents, en congé, les heures et les heures supplémentaires sur une période.

## Congés

**Congés** a **Demandes** et **Soldes**.

- **Nouvelle demande de congé** : employé, type de congé, **Du**, **Au**, motif, et cochez *le premier / dernier jour est une demi-journée*. Les week-ends et jours fériés ne sont pas comptés ; les jours ouvrés sont affichés. Un employé peut demander un congé lui-même dans **Mes RH**.
- Les RH ou un responsable appuient sur **Approuver** ou **Rejeter**, ou **Annuler**.
- Les **Soldes** montrent pour l'année : **Droit, Acquis à ce jour, Reporté, Utilisé, En attente, Restant**. Les types acquis mensuellement ajoutent un douzième des jours par mois travaillé. Les jours reportés viennent des jours non utilisés des années précédentes, jusqu'à la limite du type.
- Le **Calendrier d'équipe** montre qui est absent et quand.

## Contrats

**Contrats > Nouveau** : **Employé**, **Type** (*CDI, CDD, Période d'essai, Occasionnel, Stage*), **Intitulé du poste**, **Date de début**, **Date de fin**, **Salaire de base mensuel**, et **Indemnités et retenues fixes (mensuelles)** : chacune a un nom, un genre (*Indemnité (ajoutée)* ou *Retenue (déduite)*), un montant et si elle est **Imposable**. Une retenue, par exemple le remboursement d'un prêt, est prélevée sur le net après impôt. Un nouveau contrat est un **brouillon** ; **activez-le depuis la liste des contrats quand il est signé**. Un rapport liste les contrats qui expirent dans les 60 prochains jours.

## Paie

### Routine mensuelle

1. Avant la clôture du mois : assurez-vous que les contrats, congés, présences, **Ajustements** et **Avances et prêts** sont à jour.
2. **Paie > Campagnes de paie > Lancer la paie d'un mois** : choisissez le mois. Le système calcule la paie de toute personne qui a un contrat ce mois-là.
3. Passez la campagne en revue : **Salaire brut, Impôt sur le revenu (IRPP), Cotisations, Salaire net, Coût employeur** pour chaque employé. Si vous changez les contrats, congés ou présences, appuyez sur **Recalculer**.
4. **Approuver et comptabiliser** : la paie est comptabilisée en Comptabilité et verrouillée.
5. **Payer les salaires** : téléchargez le **Fichier de virements bancaires** (CSV ou Excel ; colonnes *N°, NOM, PRÉNOM, SALAIRE NET, N° DE COMPTE, NOM DE LA BANQUE*), chargez-le dans votre banque, puis appuyez sur **Marquer les salaires comme payés**. Les employés sans compte bancaire sont listés.
6. Les **Bulletins de paie** peuvent être envoyés par e-mail à chaque employé en PDF (demande que l'e-mail soit configuré).
7. **Documents** : le **Registre de paie** (Excel, PDF, CSV) et les **Déclarations pour les autorités** : impôt sur le revenu et sécurité sociale (Excel et PDF).
8. **Enregistrer les paiements** d'impôt et de sécurité sociale quand vous payez les autorités (ci-dessous).

Si quelque chose était faux : **Rouvrir** une paie approuvée (les écritures sont extournées et les remboursements de prêts rendus), ou **Annuler le paiement** si le virement bancaire a échoué. Ni l'un ni l'autre n'est possible tant que des paiements d'impôt ou de sécurité sociale sont enregistrés pour ce mois.

### Ajustements

**Paie > Ajustements** : un élément ponctuel pour un employé et un mois : une **prime, un rappel de salaire ou une indemnité** (ajoute) ou une **amende ou retenue pour tenue** (retire), avec un nom, un montant, un mois, si elle est imposable et une note. Il est inclus à la prochaine génération de la paie de ce mois. Après approbation, il ne peut plus être modifié.

### Avances et prêts

**Avances et prêts > Donner une avance ou un prêt** : choisissez l'**employé**, le **Nature** (*Avance sur salaire (prise en une fois)* ou *Prêt (remboursé sur plusieurs mois)*), le **Montant accordé**, **Retenu chaque mois** et la date. Les espèces données sont enregistrées en Comptabilité. Chaque paie prélève ensuite la mensualité jusqu'à ce qu'il ne reste plus rien (la dernière n'est que ce qui reste). Une avance commence le mois où elle est donnée, un prêt le mois suivant. Ouvrez un prêt pour voir les **Remboursements**, **Enregistrer** un remboursement en espèces, **Passer en perte** le reste (il devient une charge de salaire) ou **Annuler ce prêt** (seulement si rien n'a été remboursé).

### Impôts et sécurité sociale

**Paie > Impôts et sécurité sociale** liste, pour chaque mois de paie approuvé, ce qui est **Dû**, **Payé** et **Reste dû**, avec la date d'**Échéance** (l'impôt sur le revenu et les cotisations sont dus un certain jour du mois suivant), marqué *Soldé* ou *En retard*. Utilisez **Enregistrer le paiement** : **Montant, Payé le, Payé à, Reçu / référence, Note**. **Paiements effectués** les liste et vous permet d'en annuler un saisi par erreur.

### Règles et tranches d'impôt (administrateur ou responsable de la paie)

**Règles et tranches d'impôt** contient les **Tranches d'impôt sur le revenu** (chacune taxe la part du salaire imposable qui s'y trouve : De, À, Taux %) et les **Règles de cotisation** (nom, payée par l'employé ou l'employeur, taux %, calculée sur le brut, le de base ou le net, plafond mensuel, due à la *Sécurité sociale* ou autre, et si elle réduit le salaire imposable). **Les chiffres prêts à l'emploi sont un point de départ, pas un avis juridique. Confirmez chaque taux, plafond et tranche avec votre comptable avant de lancer une vraie paie.** Si aucune tranche d'impôt n'est fixée, l'impôt sur le revenu est de 0 pour tout le monde.

### Solde de tout compte

Quand un employé part, le **Solde de tout compte** ajoute la paie des jours restants, les **jours de congé non pris payés**, les **jours de préavis que l'entreprise paie** ou les **jours de préavis non effectués**, et peut reprendre les prêts sur cette paie (la paie n'est jamais réduite sous zéro ; ce qui reste demeure dû). Il est ajouté à la paie du mois et imposé comme le reste.

## Rapports

**RH > Rapports** : Répertoire des employés, Effectifs par service, Soldes de congés, Demandes de congé, Synthèse des présences, Contrats expirant (60 jours), **Registre de paie** et **Récapitulatif de paie**. Les rapports de salaire sont réservés aux personnes qui ont accès à la paie. Une **synthèse annuelle** (une ligne par employé) se trouve sur la page des campagnes de paie.
