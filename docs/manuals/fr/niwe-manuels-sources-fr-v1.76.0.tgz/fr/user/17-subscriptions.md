# Abonnements

Le groupe **Abonnements** comprend : **Formules d'abonnement, Abonnements, Vue d'ensemble, Rapports, Paramètres de la tâche**. Utilisez-le pour tout ce qui est facturé selon un cycle régulier : adhésions, contrats de support, logiciels, services de type loyer.

## Formules

**Formules d'abonnement > Nouveau** : **Nom** (par exemple *Adhésion Or*), **Description**, **Prix**, **Intervalle de facturation** (*Chaque semaine, Chaque mois, Chaque trimestre, Chaque année*), **Taux de taxe**, **Remise %** (valeur par défaut des nouveaux abonnements ; modifiable par client), et **Actif**. Les formules inactives restent sur les abonnements existants mais ne peuvent pas être choisies pour de nouveaux.

## Démarrer un abonnement

**Abonnements > Nouvel abonnement** :

1. **Client** (ou **+ Nouveau client**) et **Formule** (ou **+ Nouvelle formule**).
2. Le prix, la périodicité, la taxe et la remise sont préremplis d'après la formule ; changez-les pour accorder à ce client une autre condition.
3. **Quantité (postes / unités)** : chaque facture facture quantité × prix.
4. Les **Frais de mise en place (unique)** sont ajoutés à la première facture seulement. **Essai gratuit (jours)** : la facturation commence à la fin de l'essai.
5. **Date de début** et **Moment de facturation** : *Payé d'avance* (facturer à la date de début, avant le service de ce cycle) ou *Payé après le service* (facturer un cycle après le début).
6. **Durée (cycles de facturation)** : vide = jusqu'à résiliation ; pour une durée fixe, choisissez ce qui se passe **à la fin de la durée** : *Renouveler pour une autre durée* ou *Mettre fin à l'abonnement*.
7. **Créer l'abonnement**.

## Gérer un abonnement

La page montre le statut, le prix, la périodicité, la facturation suivante et dernière, la durée et des avis (*Essai gratuit jusqu'au...*, *En pause*, *Résiliation programmée*). Boutons :

- **Facturer maintenant** : émet tout de suite la facture suivante.
- **Modifier les conditions** : changez le prix, la quantité, la périodicité, la remise, la taxe, les frais de mise en service ou la durée. *Les changements s'appliquent à partir de la prochaine facture. Rien n'est facturé ni crédité maintenant.*
- **Changer de formule** : passer à une autre formule, avec l'option de **solder dès maintenant la partie non utilisée de la période en cours** (pour les abonnements payés d'avance déjà facturés). L'écran montre les jours restants et la valeur mensuelle avant et après.
- **Mettre en pause...** avec un motif facultatif et une date de **Reprise automatique le** ; **Reprendre** quand vous êtes prêt.
- **Sauter la prochaine facturation** : saute un cycle.
- **Résilier l'abonnement** : **Résilier maintenant**, ou **À la fin de la période payée**. Une résiliation programmée peut être retirée. Résilier maintenant ne peut pas être annulé.

L'**Historique de facturation** liste les factures et leur statut ; **Activité** enregistre chaque changement.

Les factures sont générées automatiquement chaque jour pour les abonnements dont la date de facturation est arrivée (si votre administrateur a laissé cela activé). La tâche peut aussi envoyer des rappels avant la facturation, mettre en pause ou résilier les abonnements dont la facture reste impayée, et envoyer un e-mail au client quand une facture est en retard.

## Vue d'ensemble

**Abonnements > Vue d'ensemble** : **Revenu récurrent mensuel**, valeur annuelle, **Abonnements payants**, moyenne, **En essai / suspendus**, **Partis au cours des 30 derniers jours**, **Taux de départ %** et les nouveaux, **Facturation dans 7 / 30 jours**, **Factures impayées**, **Se terminant**, et des listes *En essai, En résiliation, Fin de durée, Reprise, Prochaine facturation*, plus les factures d'abonnement impayées avec *Jours de retard* et *Rappels*.

## Rapports

**Abonnements > Rapports** : Abonnements par formule, Abonnements résiliés et terminés, Factures d'abonnement impayées.

## Paramètres de la tâche (administrateur)

L'heure d'exécution quotidienne, la facturation automatique, les rappels, que faire des factures impayées, le résumé quotidien et le rattrapage des cycles manqués.
