# Support client

Le groupe **Assistance** comprend : **Vue d'ensemble, Tickets, Réponses enregistrées, Catégories, Paramètres, Rapports**. Il traite les demandes des clients et des collègues (demandes internes), avec des délais, des réponses par e-mail et un historique complet.

## D'où viennent les tickets

- Le personnel les crée : **Tickets > Nouveau** (un appel téléphonique, un client qui se présente).
- Les clients envoient eux-mêmes une demande sur la page publique `/helpdesk` (si elle est activée) et peuvent suivre le ticket, répondre, ajouter des fichiers et noter l'aide reçue.

## Créer un ticket

**Tickets > Nouveau ticket** : **Type** (*Demande client* ou *Demande interne* ; le type ne peut pas être changé ensuite), **Client** (facultatif, un client existant ou non), **Nom, e-mail, téléphone du demandeur**, **Objet**, **Description**, **Catégorie**, **Priorité** (*Basse, Moyenne, Haute, Urgente*) et **Affecter à**.

## Traiter un ticket

La page d'un ticket montre son statut, sa priorité, sa catégorie, le demandeur, les dates et, si les délais sont activés, **Première réponse due** et **À résoudre avant**, avec une couleur en cas de retard.

- **Conversation** : choisissez **Note interne** (personnel seulement) ou **Répondre au client**. Une réponse est envoyée par e-mail au client quand le ticket a une adresse e-mail. **Insérer une réponse enregistrée...** insère une réponse prête ; les champs variables sont remplis d'après le ticket. Cochez **Puis attendre la réponse du client** pour mettre le statut en attente.
- **Attendre le client** : met en pause le compteur du délai jusqu'à ce que le client réponde.
- **Résoudre** (avec des *Notes de résolution* facultatives), **Fermer**, **Rouvrir**. Les tickets résolus sont clôturés automatiquement après le nombre de jours réglé dans les paramètres.
- **Affectée à** et **Étiquettes** (par exemple *facturation, vip*).
- **Liens** : joignez un **Numéro de facture** ou un **Numéro d'intervention (ordre de travail)** au ticket, et suivez le lien dans les deux sens.
- **Fusionner dans un autre ticket...** : utilisez-le quand le même problème a été signalé deux fois. La conversation et les fichiers passent au ticket que vous choisissez, et celui-ci est clôturé comme fusionné.
- **Fichiers** : ajoutez des images, PDF ou textes (jusqu'à 10 Mo chacun) ; cochez **Visible par le client** pour le partager sur la page publique du ticket.
- **Historique** : chaque changement, avec qui et quand.

## La liste des tickets

Filtrez par statut, priorité, catégorie, personne affectée et vues rapides (*en retard, non affectés, les miens*). Cochez plusieurs tickets pour des actions groupées comme l'affectation.

## Vue d'ensemble

**Assistance > Vue d'ensemble** montre : **Sans réponse**, **En retard** (délai dépassé), **Échéance proche**, **Non affecté**, **Ouverts / en cours**, **Les miens**, entrées et sorties des 7 derniers jours, **Dans les délais (30 jours)**, **Première réponse moy.**, **Temps de résolution moy.**, **Note des clients**, tickets par priorité et ancienneté, **Charge de travail** par agent (*Actifs, En retard, Résolus (30 jours)*) et une liste **Nécessite une attention** avec la raison.

## Réponses enregistrées

**Réponses enregistrées > Nouveau** : un **Titre**, le **Texte de la réponse** et une **Catégorie** facultative. Les champs variables pour les détails du ticket sont remplis quand vous insérez la réponse.

## Catégories

Les **Catégories** regroupent les tickets (par exemple *Facturation, Technique, Livraison*) pour l'orientation et les rapports.

## Rapports

**Assistance > Rapports** : Tickets du support client, Délais du support client (SLA), Support client par agent, Support client par catégorie, Satisfaction du support client, Tickets du support client en retard.

## Paramètres (administrateur)

Page publique activée ou non, e-mails de notification, réponses par e-mail, délais (SLA) par priorité, alertes et clôture automatique (Manuel de l'administrateur, chapitre 7).
