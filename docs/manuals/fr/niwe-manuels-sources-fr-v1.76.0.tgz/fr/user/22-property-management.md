# Gestion locative

Le groupe **Gestion locative** comprend : **Vue d'ensemble, Biens, Lots, Propriétaires, Locataires, Baux, Loyers, Impayés, Dépôts de garantie, Charges, Maintenance, Relevés propriétaires, Factures d'honoraires, Rapports, Paramètres**. Il est destiné aux agences qui gèrent des biens loués pour des propriétaires : encaisser les loyers, payer les propriétaires, facturer des honoraires de gestion et gérer les réparations.

## Le parcours locatif

**Propriétaire** et **bien / lots** → **Locataire** → **Bail** → facture de **loyer** mensuelle → **paiement** → **relevé propriétaire** mensuel → payer le propriétaire.

## Configuration

- **Propriétaires** : les personnes pour qui vous gérez (contact, coordonnées bancaires, pourcentage d'honoraires s'il est différent).
- **Biens** et **Lots** : un bien a des lots (appartements, boutiques). Réglez le **% d'honoraires de gestion** sur un bien, ou laissez vide pour que la valeur par défaut du propriétaire ou du module soit utilisée.
- **Copropriétaires** : sur la page d'un bien, le panneau **Propriétaires** montre qui le possède. **Changer les propriétaires** fixe les propriétaires et leurs pourcentages (ils doivent faire 100 %) à partir d'une date. Le loyer, les honoraires de gestion et les réparations sont répartis selon la répartition en vigueur. Chaque propriétaire reçoit son propre relevé et sa propre facture d'honoraires. Une répartition couverte par un relevé accepté est verrouillée.
- **Locataires** et **Baux** : **Baux > Nouveau** : locataire, lot, dates de début et de fin, montant du loyer et jour d'échéance, dépôt de garantie. Joignez des documents (bail, pièce d'identité, titres de propriété) avec des dates d'expiration facultatives ; une carte de la vue d'ensemble montre les documents qui expirent.

## Loyers

**Loyers** liste les loyers dus et reçus. Les factures de loyer sont faites **automatiquement chaque matin** (le nombre de jours avant l'échéance est réglé par un administrateur) ou en appuyant sur **Facturer les loyers prêts**. Chaque facture va au locataire comme à un client et se paie dans Factures comme d'habitude. Un **reçu de loyer** (PDF, e-mail) est disponible pour chaque paiement.

- **Relevé du compte du locataire** : un compte courant par locataire (PDF, e-mail).
- **Rappels et pénalités de retard** : une tâche du matin envoie un e-mail au locataire avant l'échéance et quand le loyer est en retard. Une **pénalité de retard** facultative (un pourcentage avec un plafond, ou un montant fixe) est facturée une fois par loyer, sur la partie loyer seulement.
- **Arriérés** : les locataires en retard, avec ancienneté et montants.

## Charges (services publics et charges locatives)

**Charges** définit des **types de charges** (mensuelles fixes ou au compteur, par exemple eau, charges de service). Ajoutez des charges à un bail, saisissez des **relevés de compteur** et des charges ponctuelles ; elles deviennent des lignes de la **facture de loyer** du locataire. L'argent appartient à l'agence : le relevé propriétaire ne compte que la partie loyer, et les pénalités de retard sont calculées sur le loyer seul. Les charges ne sont pas taxées.

## Dépôts de garantie et états des lieux

**Dépôts de garantie** conserve le dépôt de garantie de chaque bail comme un registre de mouvements : *reçu, retenu pour loyer, retenu pour dégâts ou autres motifs, remboursé, transféré à un renouvellement*, et annulations. Retenir un dépôt pour loyer impayé règle réellement la facture de loyer. Les **États des lieux** (entrée et sortie) : une liste de pièces avec les états, les coûts de réparation et la validation.

## Maintenance

**Maintenance** consigne les demandes de réparation avec priorité, prestataire, coût et qui paie (propriétaire ou agence). Des photos et documents peuvent être joints. Les réparations payées par le propriétaire apparaissent sur le relevé du propriétaire, réparties selon les pourcentages des propriétaires.

## Relevés propriétaires et factures d'honoraires

- **Relevés propriétaires** : chaque mois, le système prépare un **relevé en brouillon** pour chaque propriétaire qui a eu des loyers ou des réparations le mois dernier, montrant le loyer reçu, les honoraires de gestion (et la TVA dessus), les réparations et le **montant à verser au propriétaire**. Examinez les alertes, puis **acceptez** le relevé : il est comptabilisé et peut être envoyé par e-mail au propriétaire (PDF). Pour modifier un relevé accepté, **rouvrez-le**.
- **Factures d'honoraires** : quand un relevé est accepté, une **facture avec taxe** numérotée pour les honoraires de gestion est faite pour le propriétaire (un document seulement ; le relevé comptabilise déjà les honoraires et la TVA). Elle est annulée quand le relevé est rouvert et jointe au relevé envoyé par e-mail.
- Les relevés peuvent être créés automatiquement à partir d'un jour choisi chaque mois, et même acceptés et envoyés par e-mail quand ils n'ont aucune alerte et que le propriétaire doit recevoir quelque chose (un réglage).

## Vue d'ensemble et rapports

La **Vue d'ensemble** montre les loyers encaissés, les impayés, la vacance et les baux qui se terminent bientôt. **Rapports** (16) : état locatif, vacance, expiration des baux, propriétaires, impayés, encaissement des loyers, demandes de maintenance, coût de maintenance, relevés propriétaires, dépôts de garantie, factures d'honoraires, services publics et charges locatives, augmentations de loyer dues, tendance mensuelle, réparations par prestataire, documents. Les listes de propriétaires, locataires et baux s'exportent vers Excel, PDF et CSV.

## Paramètres (administrateur)

Zones, jours de « bail bientôt terminé », jour d'échéance du loyer, % d'honoraires de gestion habituel et TVA dessus, facturation des loyers, relevés propriétaires chaque mois, et règles de rappel du locataire et de pénalité de retard.
