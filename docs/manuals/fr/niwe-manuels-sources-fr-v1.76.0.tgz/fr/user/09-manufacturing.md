# Fabrication

Le groupe **Production** comprend : **Nomenclatures, Plans de production, Ordres de fabrication, Postes de travail, Gammes, Coûts indirects, Rapports**.

## Comment fonctionne la production

Une **nomenclature** est la recette d'un produit fini. Un **ordre de fabrication** dit « fabriquer tant ». Quand vous **enregistrez la production**, les composants sortent du stock, les produits finis entrent en stock, et le coût de fabrication est calculé à partir des matières, de la main-d'œuvre, du temps machine et des coûts indirects.

## Configuration (une fois)

### Postes de travail

**Postes de travail > Nouveau** : un **Code** (ne peut plus changer ensuite), un **Nom**, une **Description**, et un **Taux horaire** : le coût d'exploitation de cette machine ou zone de travail par heure.

### Gammes

Une gamme liste les étapes (opérations) pour fabriquer un produit. **Gammes > Nouveau** : **Nom**, **Description**, puis **+ Ajouter une opération** pour chaque étape : **Séq.** (ordre), **Nom de l'opération** (par exemple Découpe, Assemblage, Peinture, Emballage), **Poste de travail**, **Minutes est./unité** et **Taux de main-d'œuvre / heure**. Il faut au moins une opération.

### Coûts indirects

Frais généraux comme la part du loyer et l'électricité. **Coûts indirects > Nouveau** : **Code**, **Nom**, **Méthode d'affectation** et **Taux** :

- *Forfait* : un total fixe réparti sur les passes de l'ordre au prorata de la quantité.
- *Par unité produite* : le taux pour chaque unité produite.
- *Pourcentage du coût des matières* : un pourcentage du coût des matières de chaque passe.

### Nomenclature

**Nomenclatures > Nouveau** :

1. **Produit fini** : le produit que cette nomenclature fabrique (ne peut plus être changé après la création).
2. Facultatif : un **Nom** (par exemple *Standard*, *Variante sans noix* ; un produit peut avoir plusieurs nomenclatures) et une **Gamme**.
3. **Composants** : cherchez un produit et réglez la **Quantité par unité** : combien de ce composant il faut pour fabriquer exactement **une** unité du produit fini.
4. L'écran affiche le **Coût d'une unité (prix d'aujourd'hui)** : *Composants, Main-d'œuvre, Machines, Coût par unité, Après coproduits, Prix de vente, Marge*. Les coûts indirects sont ajoutés par ordre et ne sont pas inclus ici. Enregistrez pour actualiser après modification.
5. **Coproduits** (facultatif) : son, chutes, petit-lait. Chaque unité bonne met aussi la quantité indiquée du coproduit en stock, et une **Part du coût (%)** est retirée du coût unitaire du produit fini.
6. Cochez **Actif** et **Enregistrez**.

## Plans de production

Les **Plans de production** suggèrent quoi fabriquer. Un plan regarde les **ventes** et le **stock bas** et liste, pour chaque produit, la **Nomenclature**, les quantités **Issu des ventes** et **Issu du stock bas**, la **Qté suggérée** et les éventuels **Manques de composants**. Appuyez sur **Générer l'ordre** sur une ligne pour ouvrir **Générer un ordre de fabrication** : confirmez la **Quantité**, éventuellement une **Date prévue** et les coûts indirects, et appuyez sur **Créer l'ordre de fabrication**.

## Ordres de fabrication

### Créer

**Ordres de fabrication > Nouveau** : choisissez la **Nomenclature**, la **Quantité prévue**, une **Date prévue** facultative, **Produire à** (l'emplacement où les composants sont consommés et les produits finis ajoutés), une **Note**, et les **Coûts indirects à appliquer**. Les ordres sont numérotés *OF-0001*, *OF-0002*...

### Confirmer

Un ordre commence en brouillon. **Confirmer** fige la recette, les coûts indirects et l'emplacement ; ensuite seuls la quantité prévue, la date et la note peuvent changer. **Copier comme nouveau brouillon** répète un ordre. **Annuler la commande** l'abandonne. **Imprimer la fiche de travail** donne à l'atelier une feuille avec les étapes.

### Voir ce qu'il faut

L'ordre affiche **Composants pour les ... restant à fabriquer** : *Par unité, Nécessaire, En stock, Manque*. Il vous dit si le stock est insuffisant (« Le stock négatif est autorisé, la production passera donc quand même » si votre entreprise l'autorise).

### Enregistrer la production

Appuyez sur **Enregistrer la production** :

- **Quantité à produire maintenant** (la quantité restante est affichée). **Utiliser ce que le stock permet** remplit le maximum que vous pouvez fabriquer aujourd'hui.
- **Unités mises au rebut / rejetées** et un **Motif** (brûlé, mauvaise taille, contrôle non réussi).
- Facultatif : la **Quantité réellement utilisée** de composants (sinon la quantité de la recette est utilisée) et les **Minutes réellement passées**.

Vous pouvez enregistrer la production en plusieurs passes. Chaque passe déplace le stock et comptabilise le coût. L'ordre affiche **Produit, Rebut, Rendement %, Coût total des matières / frais généraux / main-d'œuvre / machines, Coût total, Crédit coproduits** et **Coût unitaire**, comparés au **Coût prévu**.

## Rapports

**Production > Rapports** : **Passes de production, Coût par produit, Consommation des composants par rapport à la recette, Temps et coût des postes de travail, Rebuts et rejets, Ordres : prévu et réel.** Export vers Excel, PDF et CSV. *Consommation des composants par rapport à la recette* et *Ordres : prévu et réel* montrent où se produisent les pertes et les dépassements.
