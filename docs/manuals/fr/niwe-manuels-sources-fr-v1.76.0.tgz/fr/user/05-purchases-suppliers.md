# Achats et fournisseurs

Le groupe **Achats** couvre l'achat : **Demandes d'achat, Bons de commande, Factures fournisseurs, Retours d'achats, Rapports**. **Fournisseurs** contient la liste des fournisseurs, les **Prix fournisseurs**, les **Paiements fournisseurs** et le **Relevé fournisseur**.

## Le parcours d'achat

**Demande d'achat** (une demande d'acheter, facultative) → **Bon de commande** (envoyé au fournisseur) → **Réception** (les marchandises arrivent, le stock monte) → **Facture fournisseur** (ce que vous devez) → **Paiement fournisseur**.

## Fournisseurs

**Fournisseurs > Nouveau fournisseur** : **Nom, Personne à contacter, Téléphone, E-mail, Numéro fiscal** (TVA ou numéro d'immatriculation fiscale), **Adresse**, **Notes**, et **Actif** (sélectionnable sur un nouveau bon de commande). Décochez *Actif* pour un fournisseur que vous n'utilisez plus ; ne supprimez pas un fournisseur qui a un historique.

Vous pouvez aussi ajouter un fournisseur sur-le-champ depuis un bon de commande avec **+ Nouveau fournisseur**.

### Prix fournisseurs

**Prix fournisseurs** enregistre les coûts convenus : **Fournisseur, Produit, Coût unitaire, Valable du, Valable au, Note**. Quand vous ajoutez ce produit à un bon de commande pour ce fournisseur, le coût convenu est proposé.

## Demandes d'achat

Une demande d'achat demande que quelque chose soit acheté, et va à quelqu'un qui peut l'approuver.

1. **Demandes d'achat > Nouveau** : ajoutez des **Notes**, puis cherchez les produits et réglez la **Quantité demandée** (avec une note facultative par ligne).
2. **Enregistrer le brouillon**, puis soumettez-la pour approbation.
3. Une personne qui a le droit *Approuver les demandes d'achat* l'approuve ou la rejette. Une demande approuvée peut être transformée en bon de commande.

> **Conseil :** L'écran **Réapprovisionnement** (Stock) peut créer d'un clic une demande d'achat pour tous les produits dont le stock est bas.

## Bons de commande

1. **Bons de commande > Nouveau**. Choisissez le **Fournisseur**, la **Date prévue** et, si vous avez plusieurs entrepôts, **Recevoir dans l'entrepôt**. (Le stock reçu arrive dans l'emplacement *Réception* de cet entrepôt ; déplacez-le vers un emplacement *Vente* par un transfert de stock.)
2. Ajoutez des lignes : cherchez un produit, réglez la **Quantité**, le **Coût unitaire** (et la **Remise %** ou une **Remise** sur toute la commande). Le formulaire peut être **prérempli avec les articles à stock bas** quand vous venez du Réapprovisionnement.
3. **Enregistrer le brouillon**. Sur la commande, appuyez sur **Envoyer au fournisseur** (envoie la commande par e-mail) ou **Imprimer**. Utilisez **Modifier** tant qu'elle est en brouillon, et **Annuler la commande** si elle n'aura pas lieu.

### Enregistrer une réception (les marchandises arrivent)

Sur la commande, **Enregistrer une réception** :

- Pour chaque ligne, saisissez **Reçu maintenant** (la quantité restante est affichée). Les livraisons partielles sont normales.
- Pour les produits à lot ou à numéro de série, saisissez le **N° de lot** et l'expiration, ou les **Numéros de série** (un par ligne ou séparés par des virgules).
- **Frais d'approche de cette livraison (facultatif)** : transport, droits, dédouanement. Ils sont répartis sur les produits livrés selon leur valeur et ajoutés à leur coût et au Stock dans les comptes. Enregistrez le transport ici, **pas** comme une dépense à part, sinon il serait compté deux fois. Cochez *Déjà payé* si vous l'avez payé tout de suite ; sinon il est enregistré comme dû.
- Appuyez sur **Enregistrer la réception**. Le stock monte. Quand toutes les lignes sont entièrement reçues, la commande est terminée et une facture fournisseur est générée.
- Vous pouvez imprimer un **bon de réception** pour la livraison.

### Retourner des marchandises à un fournisseur

Sur la commande, appuyez sur **Traiter un retour** : choisissez le produit, **Retourné maintenant** et un **Motif**. La commande affiche **Retourné** et **Remboursement dû par le fournisseur**. Tous les retours sont listés dans **Retours fournisseurs**.

## Factures fournisseurs

Une **facture fournisseur** est la facture que le fournisseur vous adresse. Elle est générée dès qu'une commande est entièrement reçue, ou à la main depuis la commande.

- **Factures fournisseurs** les liste : N° de facture, Bon de commande, Fournisseur, Date, Statut, Total, **Reste à payer**.
- Une facture en brouillon peut être modifiée ; appuyez sur **Émettre la facture** pour la rendre officielle (elle est alors comptabilisée). Utilisez **Supprimer le brouillon** pour retirer une facture non émise.
- **Enregistrer le paiement** depuis la facture ou depuis la page du fournisseur. **Annuler la facture** (avec un motif) si elle était erronée.

## Paiements fournisseurs

**Fournisseurs > Enregistrer un paiement** (ou depuis une facture) :

1. Saisissez le **Montant du paiement** et une **Note** facultative.
2. L'écran liste les commandes et factures impayées du fournisseur (Commande / N° de facture, Date, Coût total, Reste à payer). Appuyez sur **Suggérer du plus ancien au plus récent**, ou saisissez un montant dans **Affecter** pour chacune. Le total affecté doit être égal au montant du paiement.
3. Enregistrez. **Imprimer le reçu** donne un reçu de paiement fournisseur indiquant à quoi il a été appliqué et le **Solde restant**.

**Paiements fournisseurs** liste tous les paiements, avec l'**Historique des paiements**.

## Relevé fournisseur

**Fournisseurs > Relevé fournisseur** : choisissez un fournisseur et des dates pour voir ce que vous avez acheté, ce que vous avez payé et le solde. Exportez vers Excel ou PDF.

## Rapports

**Achats > Rapports** : Bons de commande, Rapport des dettes fournisseurs en cours, Achats par fournisseur, Achats par produit, Achats par catégorie, Factures fournisseurs, Retours d'achats, Paiements fournisseurs, **Ancienneté des dettes fournisseurs**. Tous se filtrent par date et s'exportent vers Excel, PDF et CSV.
