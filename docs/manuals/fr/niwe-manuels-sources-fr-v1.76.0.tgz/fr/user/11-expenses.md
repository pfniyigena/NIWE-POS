# Dépenses

Le groupe **Dépenses** (sous Comptabilité) comprend : **Vue d'ensemble, Dépenses, Budgets, Dépenses récurrentes, Rapports, Paramètres**. Il enregistre l'argent que l'entreprise dépense en dehors des bons de commande : loyer, services publics, transport, réparations, honoraires.

## Le parcours d'une dépense

**Saisir** la dépense → **Approuver** (si des approbations s'appliquent) → **Payer** (tout de suite, ou plus tard s'il s'agit d'une facture) → rapports.

## Saisir une dépense

**Dépenses > Nouvelle dépense** :

| Champ | Ce qu'il faut saisir |
|---|---|
| **Date** et **Catégorie** | Choisissez un *compte de charge* (ajoutez-en un au plan comptable d'abord si nécessaire). |
| **Payé à** | *Fournisseur, Employé, Client, Autre / ponctuel*, puis le fournisseur, l'employé ou le client, ou un **Nom du bénéficiaire** (par exemple la Société des eaux). |
| **Montant total (TVA comprise)** | Ce qui a été payé, TVA comprise. |
| **TVA comprise dans le total (facultatif)** | Saisissez la TVA, ou tapez un **%** et appuyez sur **Calculer**. Saisissez **seulement la TVA que vous pouvez récupérer**. Elle est conservée dans son propre compte, de sorte que la catégorie ne porte que le coût hors TVA. |
| **Référence** | Numéro de la facture ou du reçu du fournisseur. |
| **Payé immédiatement** | Cochez-le et choisissez le compte **payé depuis** (Caisse, une banque ou un compte de mobile money). Si décoché, la dépense est une **facture due au bénéficiaire** que vous pouvez payer plus tard, en totalité ou par parties. Réglez une **Date d'échéance** ; si elle est vide, elle vient du nombre de jours réglé dans les paramètres des Dépenses. |
| **Agence, Centre de coûts, Libellé** | Étiquettes et notes facultatives. |
| **Reçus et factures** | Joignez des photos, PDF ou fichiers texte, jusqu'à 10 Mo chacun. D'autres fichiers peuvent être ajoutés plus tard sur la page de la dépense. |

Chaque dépense reçoit un **numéro**. Appuyez sur **Enregistrer**.

## Approbation

Selon les paramètres, une nouvelle dépense est **En attente** jusqu'à son approbation.

- Une personne qui a le droit *Approuver/rejeter les dépenses* appuie sur **Approuver** ou **Rejeter** (avec un motif). Elle peut aussi **Annuler** une dépense approuvée.
- Les dépenses **au-dessus du plafond d'approbation** demandent un administrateur ou quelqu'un qui a le droit *Approuver les grosses dépenses*.
- Les paramètres peuvent vous empêcher d'approuver une dépense que vous avez saisie vous-même, et peuvent bloquer l'approbation quand elle **dépasserait le budget mensuel** (un administrateur peut quand même utiliser **Approuver malgré tout (hors budget)** ; la dérogation est écrite dans l'historique).
- Une dépense en attente ou rejetée peut être **supprimée** ; une dépense approuvée ne peut qu'être annulée.

## La liste des dépenses

Filtres : recherche (bénéficiaire, libellé, numéro, référence), statut (*En attente, Approuvée, Rejetée, Annulée*), catégorie, dates, plage de montants, agence. Les vues rapides comprennent les factures *en retard* et *bientôt dues*. Cochez plusieurs lignes pour **Approuver la sélection** ou **Rejeter la sélection** d'un coup. Les colonnes montrent **Numéro, Date, Bénéficiaire, Catégorie, Montant** (TVA comprise), **Paiement** (*Payée, Soldée, Impayée, Partiellement payée* et *En retard / Bientôt due*), **Approbation**, et un trombone pour les pièces jointes. **Excel** et **PDF** exportent la liste filtrée.

## Payer une facture

Ouvrez une dépense impayée ou partiellement payée et utilisez **Payer cette facture** : **Montant**, **Date**, **Payé depuis** (le compte), **Note**. Payer moins que le montant dû laisse le reste ouvert. **Paiements** liste chaque paiement, et **Fichiers** et **Historique** montrent les pièces jointes et chaque modification.

## Budgets

**Budgets** : fixez un **Budget mensuel** pour une **catégorie de dépense** ou un **centre de coûts**, pour une année et un mois choisis. L'écran montre **Dépensé** (dépenses approuvées datées du mois, sans TVA récupérable), **En attente d'approbation** (pas encore compté), **Reste** et **Utilisé %**. Utilisez **Modifier** ou **Retirer**. Pour faire respecter les budgets, un administrateur active *Bloquer l'approbation quand elle dépasserait le budget mensuel*.

## Dépenses récurrentes

Pour les coûts réguliers comme le loyer. **Dépenses récurrentes > Nouveau** : **Nom**, **Catégorie**, **Payé à**, **Montant**, **Payé immédiatement (en caisse)** (sinon chaque dépense générée est une facture), centre de coûts, libellé, **Fréquence** (*Chaque semaine, Chaque mois*), **Prochaine exécution**, **Actif**. Une tâche quotidienne crée la dépense suivante à cette date ou après et avance la date. Les dépenses générées sont marquées *Générée automatiquement par un modèle de dépense récurrente* et passent par l'approbation comme les autres.

## Vue d'ensemble

**Dépenses > Vue d'ensemble** donne un résumé : **Ce mois-ci / Le mois dernier / Cette année**, **TVA à récupérer (ce mois-ci)**, **En attente d'approbation**, **Factures impayées**, **En retard**, **Échéance proche**, les six derniers mois, les **Principales catégories** et **Principaux fournisseurs**, **Décaissé ce mois-ci, par compte**, **Budgets proches ou au-dessus de la limite** et **Factures à surveiller**. Cliquez sur un chiffre pour ouvrir la liste correspondante.

## Rapports

**Dépenses > Rapports** (quatre rapports) : **Registre des dépenses**, **Factures impayées par ancienneté**, **Budget et réalisé** et **Dépenses par compte de paiement**. Les dépenses par catégorie, fournisseur, employé et période sont sous **Comptabilité > Rapports**.

## Paramètres (administrateur)

Le plafond d'approbation, la règle « pas votre propre dépense », le blocage de l'approbation au-delà du budget, le nombre de jours avant l'échéance d'une facture et les jours d'alerte avant l'échéance. Voir le Manuel de l'administrateur, chapitre 7.
