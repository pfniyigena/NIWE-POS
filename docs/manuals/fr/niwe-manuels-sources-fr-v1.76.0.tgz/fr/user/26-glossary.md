# Glossaire et questions fréquentes

## Glossaire

| Terme | Signification |
|---|---|
| **Commande en ligne** | Une commande qu'un client a passée sur la boutique publique à `/shop`. Elle attend le personnel, puis devient une commande client. |
| **Vendable maintenant** | Ce que la boutique en ligne peut encore vendre d'un produit : le stock dans les emplacements d'entrepôt vendables, moins les quantités réservées sur des commandes clients confirmées, moins la marge de la boutique. |
| **Marge (Unités gardées pour la caisse)** | Le nombre d'unités par produit que la boutique ne vend jamais, pour que la dernière unité ne soit pas vendue deux fois. 1 sauf changement. |
| **Code de livraison** | Un code à 4 chiffres que le client reçoit quand la commande part. Le livreur le saisit pour remettre la commande. Le personnel ne le voit jamais. |
| **Code de retour** | La même idée pour le ramassage d'un retour : le client le donne au livreur qui récupère les marchandises. |
| **Feuille de tournée / Bon de livraison** | Listes imprimées pour un livreur : tous ses arrêts de la journée (feuille de tournée) et une page par commande (bon). |
| **Lien et PIN du livreur** | L'adresse web privée et le PIN à 4 chiffres qui permettent à un livreur d'utiliser sa propre page sur un téléphone sans connexion du personnel. |
| **Espèces des livreurs** | Les espèces qu'un livreur a prises à la porte et n'a pas encore remises. Suivies dans Boutique en ligne > Espèces des livreurs et dans le compte Espèces chez les livreurs. |
| **Fournisseur de paiement** | L'entreprise qui prend un paiement en ligne : MTN Mobile Money, Airtel Money, une passerelle de carte. |
| **Compte d'attente** | Le compte qui montre ce qu'un fournisseur de paiement doit encore à la boutique jusqu'à son versement. |
| **Versement** | Le fournisseur paie ce qu'il a encaissé, moins ses frais, sur le portefeuille ou le compte bancaire de la boutique. |
| **Acomptes clients en ligne** | L'argent qu'un client a payé en ligne pour une commande pas encore livrée. |
| **Dette de points de fidélité** | Ce que la boutique doit aux clients pour les points de fidélité qu'ils détiennent. |
| **Plage de livraison** | Un créneau horaire (par exemple 08:00-11:00) que le client peut choisir pour la livraison. |
| **Coupon** | Un code qu'un client saisit au paiement sur la boutique en ligne pour un pourcentage ou un montant de remise sur les articles, ou la livraison gratuite. |
| **Webhook (rappel)** | L'adresse qu'un fournisseur de paiement appelle pour dire qu'un paiement a été fait. La boutique vérifie aussi elle-même les paiements en attente. |
| **Caisse** | Un point de vente physique. |
| **Session / Poste** | Une période de travail sur une caisse, ouverte avec un fond et clôturée avec un comptage. |
| **Fond de caisse** | Les espèces mises dans le tiroir au début d'un poste. |
| **Rapport X / Rapport Z** | Un instantané de milieu de poste (X) et le rapport de clôture numéroté (Z). |
| **Annulation** | Annuler un document avant ou à la place de le corriger ; laisse une trace. |
| **Avoir** | Un document qui réduit ce qu'un client doit, émis quand une facture est annulée. |
| **Devis / Commande client / Facture** | Une offre / une commande confirmée / une demande de paiement. |
| **Facture fournisseur** | La facture qu'un fournisseur vous adresse. |
| **Bon de réception** | Document imprimé quand du stock est reçu. |
| **Nomenclature** | La recette d'un produit fabriqué. |
| **Référence (SKU)** | Unité de gestion de stock : le code propre d'un produit. |
| **Frais d'approche** | Transport, droits et dédouanement ajoutés au coût des marchandises reçues. |
| **Seuil de réapprovisionnement** | Le niveau de stock auquel un produit doit être racheté. |
| **Entrepôt / Emplacement** | Un lieu où le stock est conservé, et une étagère ou une zone à l'intérieur (Réception, Vente, Stockage, Endommagé). |
| **Agence** | Un site de l'entreprise pour les rapports : les ventes, achats et dépenses en portent l'étiquette. |
| **Centre de coûts** | Une étiquette (service, projet) pour l'analyse des coûts. |
| **Plan comptable** | La liste des comptes sur lesquels le grand livre comptabilise. |
| **Écriture comptable** | Un ensemble de lignes de débit et de crédit qui s'équilibrent. |
| **Approbateur / PIN du responsable** | Une personne qui a le droit d'approuver ; son PIN le confirme sur votre écran. |
| **Régularisation / Amortissement** | Constater un coût quand il est engagé / répartir le coût d'une immobilisation sur sa durée de vie. |
| **PMC / RevPAR** | Prix moyen par chambre louée / revenu par chambre disponible (hôtels). |
| **SLA** | Un délai promis de réponse ou de résolution (délais du Support client). |
| **MRR / Taux de départ** | Revenu mensuel récurrent / part des abonnements perdus (Abonnements). |
| **Compte de tiers** | Le compte qui détient l'argent d'un client, séparé de celui du cabinet (Cabinet d'avocats). |

## Questions fréquentes

**Je ne vois pas une entrée de menu mentionnée dans ce manuel.** Votre entreprise n'utilise peut-être pas ce module, ou votre rôle ne l'inclut pas. Demandez à votre administrateur.

**J'ai fait une erreur sur une facture.** Si c'est encore un brouillon, modifiez-la ou supprimez-la. Si elle est émise, annulez-la (ou annulez-la et créditez-la s'il y a des paiements) et refaites-la.

**Une vente a été refusée à cause du stock.** Le stock est peut-être bas et le stock négatif n'est pas autorisé. Recevez ou ajustez d'abord le stock, ou demandez à un responsable.

**Une remise demande un responsable.** La remise dépasse votre limite autorisée. Un responsable saisit son PIN sur votre écran.

**La caisse affiche Hors ligne.** Continuez à vendre ; les ventes se mettent en file d'attente et se synchronisent automatiquement au retour de la connexion. N'effacez pas les données du navigateur entre-temps.

**J'ai oublié mon mot de passe ou mon PIN.** Utilisez *Mot de passe oublié ?* si votre e-mail est sur votre profil ; sinon demandez à un administrateur. Changez votre propre PIN dans **Mon profil**.

**Comment sortir les chiffres vers Excel ?** Chaque liste et chaque rapport a des boutons **Excel, PDF et CSV** ; ils exportent exactement ce qui est à l'écran, avec les mêmes filtres.

**Qui a modifié cela ?** Demandez à un administrateur de consulter le **Journal d'audit** ; la plupart des actions importantes sont enregistrées avec la personne et l'heure.
