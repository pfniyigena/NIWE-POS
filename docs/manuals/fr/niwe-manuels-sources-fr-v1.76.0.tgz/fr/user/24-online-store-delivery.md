# Boutique en ligne : livraison, livreurs et espèces

Ce chapitre suit une commande en livraison depuis le moment où le personnel fixe les règles de livraison jusqu'au moment où les espèces prises par le livreur sont remises. Tout se trouve dans **Boutique en ligne > Paramètres de la boutique** (les cartes de configuration) et **Boutique en ligne > Commandes en ligne**, **Mes livraisons**, **Espèces des livreurs** et **Retours**.

## Zones de livraison, frais et taxe

Dans **Paramètres de la boutique > Zones de livraison**, ajoutez chaque zone où vous livrez. Pour chaque zone :

- **Frais** : ce que le client paie pour la livraison dans cette zone. Sans zone, la boutique livre partout gratuitement ; avec des zones, le client en choisit une.
- **Commande minimale** : facultative, pour cette zone.
- **Taxe** : choisissez l'une de vos taxes existantes, ou laissez *La taxe du produit de livraison*. Les frais que vous saisissez sont **le montant que paie le client** ; la taxe que vous choisissez est la part de ce montant qui est de la taxe, **comprise dans les frais**. Exemple : des frais de 2 000 avec une TVA de 18 % font 1 694,92 de frais plus 305,08 de taxe ; le client paie toujours 2 000. Ainsi la commande client, la facture et les espèces encaissées sont toujours égales au total que le client a vu.
- **Jours de livraison** : *de* et *à*, en jours après l'acceptation de la commande par la boutique (0 = le jour même). Laissez les deux vides pour utiliser l'estimation de toute la boutique (Paramètres de la boutique > Page d'accueil). Le client voit l'estimation de **sa** zone au paiement (sous forme de dates), sur la page de la commande et dans les messages « reçue » et « acceptée ». L'estimation est conservée sur la commande quand elle est passée.

Sous **La boutique**, choisissez le **Produit de service pour les frais de livraison** : un produit de *service* (sans stock) qui porte les frais de livraison sur la commande client et la facture. Sans lui, une commande qui a des frais de livraison ne peut pas être acceptée. Quand la zone a sa propre taxe, la taxe de ce produit n'est pas utilisée ; sinon donnez-lui une taxe **incluse** (ou aucune), parce qu'une taxe ajoutée en sus rendrait la facture, et les espèces que le livreur doit remettre, plus élevées que le total que le client a vu.

## Heures de livraison

**Paramètres de la boutique > Heures de livraison** permet aux clients de choisir un jour et une plage horaire. C'est désactivé jusqu'à ce que vous le configuriez.

- **Plages** : une heure de début et de fin (par exemple 08:00-11:00, 11:00-14:00, 14:00-17:00, 17:00-20:00), les **commandes par jour** (0 = sans limite), les **jours de la semaine** où la plage existe, et *active*.
- **Interrupteurs** : *les clients choisissent une heure de livraison*, *ils doivent en choisir une* (désactivé = « Dès que possible » est permis), **jours à l'avance** (0 à 60) et **préavis** (heures avant le début d'une plage où elle se ferme, 0 à 72).
- **Jours sans livraison** : des dates (un jour férié, un inventaire) avec un motif facultatif. Aucune plage ne peut être choisie ce jour-là.

Au paiement, sous l'adresse, le client choisit un jour (Aujourd'hui, Demain, ...) et une plage. Une plage pleine affiche *Complet* et une qui commence trop tôt affiche *Trop tard* ; ni l'une ni l'autre ne peut être choisie, même quand deux clients commandent au même instant. Les commandes en retrait n'ont pas de plage. Une commande rejetée ou annulée libère sa place.

Après la commande, la plage s'affiche sur la page de la commande, dans les messages, sur **Commandes en ligne** (où **Changer l'heure** permet au personnel de choisir n'importe quelle plage et jour, ou de revenir à *Dès que possible* ; la limite n'arrête pas le personnel), sur la page du livreur, sur le **bon de livraison**, et la **feuille de tournée** est triée par plage puis par zone.

## Livreurs

Un livreur est une simple entrée de liste, pas une fiche d'employé. Dans **Paramètres de la boutique > Livreurs**, ajoutez le **nom**, le **téléphone** et une **note**, et laissez *actif* coché. Un livreur qui a encore des commandes à livrer ne peut pas être retiré : désactivez-le plutôt.

### Confier la commande à un livreur

Chaque commande de livraison (Nouvelle, Acceptée, Emballée, En cours de livraison) a un choix de **Livreur** sur **Commandes en ligne**. Réglez-le ou changez-le à tout moment avant la livraison ; le changement est écrit dans l'historique. **En cours de livraison** demande un livreur quand aucun n'est réglé, tant que la boutique a des livreurs actifs. Trois impressions et raccourcis aident le livreur :

- **Bon de livraison (PDF)** : une page par commande avec le client, le téléphone, l'adresse, la zone, la note, le livreur, l'heure de livraison, les marchandises, le total, le montant à encaisser (ou *Déjà payé en ligne : rien à encaisser*) et des lignes de signature. Non disponible pour les commandes en retrait.
- **Feuille de tournée (PDF)** : choisissez un livreur (ou *Non affecté*) dans le filtre au-dessus des commandes et appuyez sur **Feuille de tournée** : toutes ses commandes encore à livrer, regroupées par zone et triées par plage horaire, avec le nombre d'arrêts, les espèces à encaisser et une colonne à cocher.
- **WhatsApp au livreur** : un lien sur la commande ouvre WhatsApp vers le livreur avec le code de la commande, le client, le téléphone, l'adresse et le montant à encaisser.

Une fois la commande en cours de livraison, la page de commande du client affiche **Votre livreur : nom, téléphone**, et le message « en route » les ajoute.

### La page privée du livreur (sans connexion du personnel)

Un livreur n'a pas besoin d'un compte du personnel. Dans **Paramètres de la boutique > Livreurs**, appuyez sur **Donner un lien** sur le livreur. Le programme fabrique un lien privé (par exemple `https://votre-boutique/driver/...`) et un **PIN** à 4 chiffres. Le PIN n'est montré qu'**une fois**, à ce moment ; personne ne peut le relire ensuite. Des boutons envoient le lien, et le PIN séparément, au livreur sur WhatsApp. Le personnel peut plus tard appuyer sur **Afficher le lien**, faire un **Nouveau code PIN**, ou **Désactiver** le lien ; chacune de ces actions déconnecte le livreur aussitôt.

Le livreur ouvre le lien sur son téléphone, tape son PIN, et ne voit que **ses propres** commandes en cours de livraison : client, téléphone (touchez pour appeler), adresse et carte, l'heure de livraison, ce qu'il faut encaisser, et les marchandises. La page montre aussi :

- **Espèces que je détiens** : le total des espèces qu'il a prises à la porte et n'a pas remises (orange quand il y a quelque chose à remettre, vert quand il n'y a rien), les commandes derrière, et ses dix dernières remises avec la différence. C'est la même liste que le personnel règle dans **Espèces des livreurs**. La page se rafraîchit toutes les 20 secondes.
- **Retours à récupérer** : les retours de clients qui lui sont confiés (voir plus bas).

> **Remarque :** Sécurité : le lien porte un long secret et le PIN est vérifié en plus. Cinq PIN faux verrouillent le lien pendant 30 minutes (un nouveau PIN du personnel le déverrouille). Après le PIN, le téléphone garde une session jusqu'à 14 heures d'utilisation. Ouvrir le lien sur un second téléphone déconnecte le premier. Un livreur désactivé (pas *actif*) ne peut pas utiliser son lien. Le site doit être servi en HTTPS et `app.frontend-url` doit être l'adresse publique, pour que le lien soit complet.

Le personnel qui préfère utiliser un téléphone lui-même a l'écran **Mes livraisons** dans le menu : choisissez votre nom une fois et il liste les commandes en cours de livraison avec les mêmes détails.

### La remise : le code de livraison

Quand une commande part en livraison (ou est prête pour le retrait), le client reçoit un **code de livraison** à 4 chiffres par e-mail et par texto, dans le portail et sur la page de sa commande. Le livreur, ou le personnel au comptoir, demande le code au client et le saisit sous **Remettre**. La commande est alors terminée exactement comme si le personnel avait appuyé sur **Terminer** : stock sorti, facture, espèces enregistrées comme encaissées (elles attendent alors dans **Espèces des livreurs**), client remercié. Le code n'est **jamais** montré au personnel ni aux livreurs et n'est pas sur le bon de livraison.

- Cinq codes faux bloquent le code pendant 30 minutes. Un client qui a perdu le code, ou dont le code a été bloqué, en reçoit un nouveau avec **Envoyer un nouveau code au client** sur la commande ; l'ancien code cesse de fonctionner.
- Le client peut aussi terminer lui-même la commande : **J'ai reçu ma commande** sur la page de sa commande, avec une signature dessinée facultative. Une signature donnée là est conservée et imprimée sur le bon de livraison. Les livreurs et l'écran du personnel ne proposent pas de signatures : la remise se fait par le code. Une commande terminée montre comment elle a été reçue (client, code ou signature) et **Voir la signature** quand il y en a une.
- Un appui du client ne prouve pas que le livreur a encaissé l'argent : contrôlez les espèces du livreur avec la feuille de tournée comme avant.

## Quand la livraison ne se passe pas comme prévu

Seul le **personnel** enregistre une livraison échouée ou partielle (écran **Commandes en ligne**). La page du livreur lui dit d'appeler la boutique.

### Livraison échouée

Sur une commande en cours de livraison, appuyez sur **Livraison échouée**, choisissez le motif (client absent, client a refusé les marchandises, adresse erronée ou introuvable, pas de réponse au téléphone, autre) et ajoutez des détails si vous voulez. La commande revient à **Emballée** avec le motif et le nombre d'essais ; le stock reste réservé et le livreur reste sur la commande ; le client est prévenu. Renvoyez-la plus tard (ou donnez-la à un autre livreur) ou annulez-la ; à partir du troisième essai raté, l'écran suggère d'annuler.

Quand les heures de livraison sont activées, l'ancienne plage est **libérée tout de suite** et le client est invité, dans le message et sur la page de sa commande, à **choisir une nouvelle heure de livraison** (un jour, puis une plage libre, puis **Confirmer cette heure de livraison**). Le personnel voit *En attente d'une nouvelle heure* jusqu'à ce qu'elle soit fixée et peut quand même utiliser **Changer l'heure** après avoir téléphoné au client. Si vous avez rendu les heures de livraison obligatoires, la commande ne peut pas repartir tant qu'une plage n'est pas fixée.

### Le client ne garde qu'une partie des marchandises

Cochez la case sur une commande en cours de livraison (ou prête pour le retrait), saisissez la quantité **gardée** pour chaque ligne, puis **Terminer** (ou confirmez avec le code du client). La facture, le stock et les espèces à encaisser ne couvrent que ce que le client a gardé ; ce qui n'a pas été livré n'est plus réservé. Les frais de livraison restent sur la facture. Les points de fidélité sont gagnés sur ce qui a été livré.

Si la commande a été **payée en ligne**, la partie payée mais non livrée apparaît sous **Remboursements à faire** comme *Remboursement dû pour les marchandises non livrées* : remboursez via le fournisseur ou enregistrez le remboursement que vous avez fait vous-même, avec sa référence. Le client est prévenu. Ne rien livrer du tout est refusé : utilisez **Livraison échouée** ou annulez la commande.

## Ramassage des retours

Un retour d'une commande **livrée** est **récupéré chez le client par un livreur**, gratuitement. Dans **Boutique en ligne > Retours**, quand vous **Approuvez** le retour d'une commande de livraison, un **code de retour** à 4 chiffres est fabriqué et envoyé au client par e-mail et par texto (« Un livreur viendra récupérer les marchandises ... Donnez le code au livreur seulement quand vous lui remettez les marchandises »). Choisissez le **livreur** en même temps, ou plus tard dans la zone **Un livreur récupère les articles** (vous pouvez le changer ou le retirer jusqu'à la récupération des marchandises, et faire un **Nouveau code de retour (renvoyer)**).

Le livreur voit le retour sous **Retours à récupérer** sur sa page, avec le client, le téléphone, l'adresse, le motif et les marchandises. Il appuie sur **Récupérer les articles**, saisit le code de retour que le client lui donne et confirme. Le retour passe à **Collectée** (un nouvel onglet les liste), le client et la boutique sont prévenus, et vous appuyez ensuite sur **Articles reçus : remettre en stock et rembourser** comme d'habitude. Cinq codes faux verrouillent ce retour pendant 30 minutes ; un nouveau code le déverrouille. Un retour d'une commande retirée à la boutique n'a ni adresse, ni code, ni livreur : le client rapporte les marchandises.

## Les espèces que détient le livreur

Une commande de livraison payée **en espèces à la livraison** et terminée garde ses espèces comme **espèces à remettre**. Ouvrez **Boutique en ligne > Espèces des livreurs** :

- l'onglet **À remettre** montre, pour chaque livreur, le total et les commandes derrière (client, heure de livraison, espèces encaissées) ;
- l'onglet **Réglé** montre les 200 derniers règlements : encaissé, remis, différence, qui et quand, et le motif.

Pour régler : choisissez le livreur (ou *Tous les livreurs*), et pour chaque commande saisissez ce que le livreur a **réellement remis** (cela commence au montant encaissé). Une différence demande un **motif** d'au moins 3 caractères. Cochez les commandes (ou **Tout sélectionner**) et appuyez sur **Régler la sélection**. Toutes les commandes sélectionnées sont réglées ensemble ou aucune.

Dans les comptes, les espèces que le livreur a prises restent dans **Espèces chez les livreurs** jusqu'à ce qu'il les remette ; le règlement déplace ce qu'il a remis vers **Caisse et banque** et comptabilise un manque ou un excédent dans **Écarts de caisse**. L'historique de la commande dit *Espèces du livreur remises : X (différence Y)*. Un règlement ne peut pas être annulé sur cet écran ; corrigez une erreur par une écriture.

Seules les commandes de livraison payées en espèces apparaissent ici. Les commandes payées en ligne ou par mobile money, et les espèces prises au comptoir pour un retrait, n'y apparaissent jamais. Les commandes livrées avant la version 1.72.0 se règlent avec la différence seulement (voir le chapitre comptabilité).

> **Conseil :** Contrôlez chaque jour **Espèces chez les livreurs** dans les comptes avec le total *À remettre*. Ils doivent concorder ; une différence signifie qu'une commande a été réglée deux fois ou qu'une remise a été comptabilisée à la main.
