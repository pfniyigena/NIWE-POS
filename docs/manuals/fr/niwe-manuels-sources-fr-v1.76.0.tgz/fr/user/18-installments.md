# Paiements échelonnés

Le groupe **Échéanciers** comprend : **Accords, Recouvrements, Nouveau plan, Rapports, Paramètres**. Il permet à un client de payer une facture existante en plusieurs parties dans le temps, avec intérêts et pénalités de retard facultatifs.

## Créer un plan

1. Émettez d'abord la facture (Ventes > Factures). Sur la facture, appuyez sur **Payer en plusieurs fois**, ou utilisez **Échéanciers > Nouveau plan** et choisissez une **Facture** (une facture émise avec un client et un solde impayé).
2. L'écran montre le **Total de la facture, payé** et **encore dû**.
3. Facultatif : prenez un **Acompte maintenant** (et son **mode de paiement**). L'acompte est enregistré comme paiement sur la facture.
4. Réglez le **Nombre d'échéances**, **Tous les** (semaine, 2 semaines, mois, 3 mois) et la **Première échéance**.
5. **Intérêts** : *Aucun*, *Forfaitaires (sur le montant total)* ou *Sur solde dégressif*, avec un **Taux annuel %**. Ajoutez des **Jours de grâce**, une **Pénalité de retard (fixe)** et/ou une **Pénalité de retard (% du impayé)**. Cochez **Montants entiers (sans centimes)** pour les monnaies sans centimes ; la dernière échéance absorbe l'arrondi.
6. Cochez **Envoyer au client des rappels par e-mail pour ce plan** si vous le souhaitez.
7. Appuyez sur **Aperçu de l'échéancier** pour voir la date d'échéance, le principal, les intérêts et le total de chaque échéance, puis enregistrez. Les valeurs de départ viennent des paramètres des Paiements échelonnés.

## Encaisser

Sur un plan, **Enregistrer un paiement** : montant, mode et note. Un paiement va à l'**échéance impayée la plus ancienne d'abord** ; les intérêts et pénalités de retard sont réglés avant le principal. Le plan montre le **Total à payer, Payé, Reste dû, En retard**.

Documents : **Échéancier (PDF)**, **Relevé (PDF)**, **Accord (PDF)** (imprimé avec les conditions), **Envoyer le relevé par e-mail** (éventuellement avec l'accord), **Envoyer un rappel**.

## Gérer un plan

- **Modifier la planification** : changez les dates et les montants, ajoutez ou retirez des échéances impayées. Ce qui est déjà payé reste tel quel ; le principal doit toujours s'additionner et les intérêts ne peuvent pas descendre sous ce qui a été payé. **Répartir le principal également** aide.
- **Rembourser par anticipation** : règle toutes les échéances impayées aujourd'hui. Une partie des intérêts des échéances pas encore dues peut être annulée (un pourcentage, modifiable à chaque solde). Il montre *Principal restant, Intérêts restants, Pénalités restantes, Intérêts annulés* et **À payer maintenant** ; appuyez sur **Recevoir ... et clôturer le plan**.
- **Marquer en défaut** : le client a cessé de payer. Plus aucune pénalité ni aucun rappel n'est ajouté ; les paiements sont toujours acceptés ; utilisez **Remettre en actif** pour annuler. Vos paramètres peuvent mettre automatiquement les plans en défaut après un certain nombre de jours de retard.
- **Passer en perte** : comptabilise le principal impayé comme créance irrécouvrable et la facture n'affiche plus rien de dû. Un motif est exigé. Cela ne peut pas être annulé d'ici.
- **Annuler le plan** : ce qui est impayé reste sur la facture comme une dette ordinaire ; les intérêts et pénalités impayés sont abandonnés.

## Recouvrements

**Échéanciers > Recouvrements** est la liste de travail du recouvreur : **En retard dans cette liste**, **Promesses non tenues**, **Promis pour aujourd'hui**, **Jamais contactés**. Pour chaque plan, elle montre le client, le montant en retard et son ancienneté, la prochaine échéance, le dernier contact et la promesse de paiement. **Consigner un contact** : *Appel téléphonique, Visite* ou *Promesse de paiement* (avec une date et un montant) et une note. Chaque envoi est ajouté au journal de recouvrement.

## Rapports

**Échéanciers > Rapports** : Accords d'échelonnement, Échéances à venir (30 prochains jours), Échéances en retard, Échéances en défaut et passées en perte, Recouvrement des échéances.

## Paramètres (administrateur)

Le moment des rappels, les valeurs de départ des nouveaux plans, l'annulation d'intérêts au solde anticipé, le défaut automatique et le texte de l'accord.
