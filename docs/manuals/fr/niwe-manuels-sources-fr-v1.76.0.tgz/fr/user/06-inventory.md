# Stock

Le groupe **Inventaire** comprend : **Produits, Catégories, Marques, Ajustements de stock, Inventaires, Réapprovisionnement, Agences, Entrepôts, Transferts de stock, Règles de conditionnement, Décomposition du stock, Rapports, Paramètres du stock**.

## Produits

**Inventaire > Produits > Nouveau produit**. Les champs importants :

| Champ | Signification |
|---|---|
| **Nom, Référence, Code-barres, Code** | Comment le produit est identifié. Le *Code* est un second identifiant facultatif et doit être unique s'il est utilisé. Utilisez **Imprimer l'étiquette** pour imprimer des étiquettes de code-barres. |
| **Icône, Description** | Une image pour la caisse et le texte par défaut des lignes de facture. |
| **Catégorie, Marque, Taux de taxe** | Catégorie et marque pour les rapports ; *Taux de taxe* : *Aucun (exonéré)* ou l'un de vos taux. |
| **Prix unitaire** | Le prix de vente. |
| **Prix de revient** | Ce que le produit vous coûte. Jamais montré aux clients ; utilisé pour les rapports de bénéfice. Suit automatiquement les achats selon la méthode de calcul du coût. |
| **Code de marchandise EFRIS** | Seulement si vous transmettez à EFRIS. |
| **Il s'agit d'un service, pas d'un bien physique** | Pour les services et les articles préparés à la commande. |
| **Suivre le stock de ce produit** | Décochez pour un service ; il peut toujours être vendu et sa vente ne change jamais le stock. |
| **Quantité en stock** | Le stock actuel. Après le démarrage, changez le stock par des ajustements, inventaires, réceptions ou transferts, pas en modifiant ici. |
| **Seuil de réapprovisionnement, Stock maximal** | Quand le stock vendable plus les bons de commande ouverts descend au seuil de réapprovisionnement, le produit apparaît dans **Réapprovisionnement** ; la quantité à commander proposée ramène le stock au maximum (par défaut : le double du seuil). |
| **Suivi par lot / numéro de série** | *Aucun*, *Lots avec date d'expiration* (vendus par expiration la plus proche d'abord) ou *Numéros de série* (un par unité). Les numéros de lot et de série se saisissent à la réception d'un bon de commande ou à l'ajout de stock par ajustement. |

La page du produit a un **Historique des mouvements de stock**, qui liste chaque mouvement du produit et d'où il vient.

> **Conseil :** Importez beaucoup de produits d'un coup avec **Paramètres > Sauvegarde et données > Import en masse** (demandez à votre administrateur). Appuyez toujours d'abord sur **Vérifier le fichier**.

### Variantes

Pour les produits qui existent en tailles ou en couleurs, ouvrez **Variantes** : ajoutez des **Options** (par exemple *Taille*) avec des **Valeurs** (S, M, L), appuyez sur **Générer**, et un produit est créé pour chaque combinaison (en copiant prix, coût, catégorie, marque et taxe). L'original devient un modèle inactif et ne doit contenir aucun stock. Modifiez ensuite la référence, le code-barres et le prix de chaque variante.

### Étiquettes

**Imprimer l'étiquette** depuis un produit, ou depuis la liste des produits pour plusieurs produits, imprime des étiquettes de code-barres sur votre imprimante.

## Catégories et marques

Les **Catégories** et **Marques** regroupent les produits pour les tuiles de la caisse, les rapports et les promotions. Créez une marque avant de la choisir sur un produit.

## Ajustements de stock

Utilisez un ajustement pour corriger le stock en dehors d'un achat ou d'une vente normaux (casse, vol, expiration, recomptage).

1. **Ajustements de stock > Nouveau**. Cherchez le **Produit** ; le stock actuel est affiché.
2. Choisissez l'**Emplacement** (par défaut : le stock de vente de l'entrepôt principal) et saisissez la **Variation de quantité** : positive pour ajouter, négative pour retirer. Le nouveau niveau de stock est affiché.
3. Pour les produits à lot, saisissez le lot et l'expiration ; le retrait prend d'abord l'expiration la plus proche. Pour les produits à numéro de série, listez les numéros de série.
4. Choisissez le **Motif** : *Casse, Vol, Expiration, Recomptage, Autre*, et ajoutez une **Note**.
5. **Enregistrer l'ajustement**.

> **Remarque :** L'ajustement est seulement *consigné pour vérification*. Le stock et la comptabilité ne changent pas tant que quelqu'un qui a le droit *Approuver les ajustements de stock* ne le confirme depuis la liste des ajustements de stock. Les ajustements rejetés ne changent rien.

## Inventaires

Un inventaire compare le rayon avec le système.

1. **Inventaires > Démarrer un inventaire** : choisissez l'**Entrepôt**, éventuellement une **Catégorie**, et ajoutez des notes. **Démarrer le comptage** fige les quantités actuelles du système sur une **feuille de comptage**.
2. **Imprimer la feuille** et comptez. Les ventes et réceptions peuvent continuer pendant le comptage.
3. Saisissez **Compté** pour chaque ligne (la feuille montre **Qté système, Compté, Écart, Valeur**). Utilisez **Ajouter un produit à la feuille** pour quelque chose trouvé qui n'était pas listé. **Enregistrer les comptages**.
4. **Soumettre pour approbation**. Un approbateur appuie sur **Approuver et comptabiliser les écarts** : seule la *différence* entre ce que vous avez compté et le chiffre figé est comptabilisée, de sorte que tout ce qui a bougé entre-temps est préservé. Utilisez **Rouvrir pour comptage** pour le renvoyer ou **Annuler le comptage** pour l'abandonner.

## Réapprovisionnement

**Inventaire > Réapprovisionnement** liste les produits dont le stock vendable plus les bons de commande ouverts est au niveau du seuil de réapprovisionnement ou en dessous (Référence, Produit, Catégorie, En stock, En commande, Seuil, Max, Qté à commander). Si votre entreprise utilise la Boutique en ligne, deux colonnes de plus apparaissent : **Commandes en ligne** (unités retenues par des commandes de la boutique auxquelles personne n'a encore répondu, qui sont retirées du stock) et **Clients en attente** (personnes qui ont demandé à être prévenues du retour du produit ; comptées comme demande). Appuyez sur **Créer une demande d'achat** pour transformer la liste (ou les lignes cochées) en demande d'achat. Votre administrateur peut aussi faire créer chaque jour une demande d'achat en brouillon automatiquement.

## Entrepôts, emplacements et transferts

- Les **Agences** et **Entrepôts** sont créés par un administrateur (Manuel de l'administrateur, chapitre 5). Un entrepôt peut avoir des emplacements *Réception, Vente, Stockage* et *Endommagé*. Le stock endommagé est suivi mais jamais compté comme vendable.
- **Transferts de stock > Nouveau** : choisissez le **Produit**, l'**Emplacement d'origine**, l'**Emplacement de destination** (le même entrepôt ou un autre) et la **Quantité**. Le transfert est consigné ; le stock ne bouge que lorsque quelqu'un qui a le droit *Approuver les transferts de stock* appuie sur **Confirmer** (ou **Rejeter**). Les transferts **entre agences** sont ensuite reçus à l'autre bout : l'agence destinataire appuie sur **Réceptionner** et saisit ce qui est réellement arrivé (tout manque est affiché comme *manquant*), ou **Retourner à l'expéditeur** avec une note (par exemple *endommagé*). Un **bordereau de transfert** (la colonne *Papier*) peut être imprimé pour accompagner les marchandises.
- Après une réception d'achat, les marchandises restent dans l'emplacement *Réception* jusqu'à ce qu'un transfert les déplace vers un emplacement *Vente*. Si une caisse vend depuis un emplacement précis, c'est là que le stock doit se trouver.

## Conditionnement et décomposition

Pour vendre des parties d'un produit (une bouteille en verres, un carton en bouteilles). Un administrateur doit activer *Conditionnement et décomposition des produits* dans les paramètres du stock.

- **Règles de conditionnement > Nouveau** : choisissez le **Produit parent** (ce qui est décomposé) et le **Produit enfant** (ce qu'il devient ; **+ Nouveau produit** le crée sur-le-champ), et les **Unités par parent** (25 verres par bouteille).
- **Décomposition du stock** : choisissez la **Règle de conditionnement**, la **Quantité** à décomposer et l'**Emplacement**, éventuellement une note, et lancez-la. Le stock du parent baisse, celui de l'enfant monte, et le coût unitaire de l'enfant est calculé. Le tableau liste toutes les décompositions précédentes.

## Stock négatif et multi-entrepôts

Le fait que la caisse et les ajustements puissent faire passer le stock sous zéro, et que l'entreprise utilise plusieurs entrepôts, est réglé par un administrateur dans les paramètres du stock. Si une vente est refusée pour cause de stock, recevez ou ajustez d'abord le stock.

## Rapports

**Inventaire > Rapports** : **Stock disponible et valorisation** (avec une colonne **Commandes en ligne** quand la Boutique en ligne est utilisée), **Ancienneté du stock**, **Stock dormant** (aucune vente en 90 jours), **Stock par lot** (lots et expiration), **Stock expirant** (60 jours), **Registre des numéros de série**, **Historique des mouvements de stock** (pour un produit).
