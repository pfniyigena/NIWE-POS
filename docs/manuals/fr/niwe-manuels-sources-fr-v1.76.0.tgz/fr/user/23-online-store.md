# Boutique en ligne

Le module **Boutique en ligne** donne à votre entreprise une boutique publique sur internet à l'adresse `/shop` (par exemple `https://erp.votreentreprise.com/shop`). Quand le module est activé, `/shop` est aussi la première page que voit un visiteur à l'adresse principale, avec un lien **Connexion du personnel** pour vos propres employés. Les clients choisissent des produits, commandent en **livraison** ou en **retrait**, et paient **en espèces** ou **en ligne** (MTN Mobile Money, Airtel Money ou carte, quand votre administrateur a configuré un fournisseur de paiement). Vous répondez à chaque commande, et une commande acceptée devient une commande client, une facture et un paiement ordinaires, de sorte que le stock, la comptabilité et les rapports restent au même endroit.

Le module doit figurer dans votre licence et être activé par un administrateur (Paramètres > Modules). Le groupe **Boutique en ligne** apparaît alors dans le menu. Le personnel a besoin du domaine **Opérations** pour l'utiliser. Les chapitres sur la Boutique en ligne sont :

- **Ce chapitre** : à quoi ressemble la boutique, comment la configurer, pourquoi un produit peut afficher *Épuisé*, ce que fait le client, comment le personnel répond aux commandes, remboursements, coupons, retours, avis, messages, lettre d'information, paniers abandonnés, points de fidélité et messages texte.
- **Boutique en ligne : livraison, livreurs et espèces** (chapitre suivant) : zones de livraison et taxe, heures de livraison, livreurs et leur page privée, le code de livraison, livraisons échouées et partielles, ramassage des retours et espèces détenues par les livreurs.
- **Boutique en ligne : paiements, comptabilité et rapports** (le chapitre d'après) : fournisseurs de paiement, versements, comment une commande arrive dans les comptes, publicité, rapports de ventes et contrôles du comptable.

Les entrées du menu sont : **Commandes en ligne**, **Mes livraisons**, **Espèces des livreurs**, **Paiements en ligne**, **Retours**, **Codes promo**, **Avis**, **Messages**, **Clients en attente**, **Pages de la boutique**, **Lettre d'information**, **Envoyer une newsletter**, **Paniers abandonnés**, **Points de fidélité**, **Publicité**, **Rapports de ventes**, **Messages texte**, **Paramètres de la boutique** et **Ouvrir la boutique**.

## Ce que voit un visiteur

### La première page

De haut en bas, la première page de la boutique montre :

1. une **barre d'annonce** (un court message, avec éventuellement un lien) ;
2. l'**en-tête** avec le nom ou le logo de la boutique, une zone de **recherche**, le cœur de la liste de souhaits, le panier, le bouton de **compte** et **Connexion du personnel** ;
3. la **bannière** : vos images qui défilent l'une après l'autre, avec un titre, un texte et un bouton ;
4. une **publicité** (quand vous vendez de l'espace publicitaire, voir le chapitre paiements et rapports) ;
5. des rangées de produits que vous choisissez : **Produits à la une**, **Meilleures ventes**, **Offres spéciales et remises**, **Nouveautés** et, pour un visiteur qui revient, **Consultés récemment**. Chaque rangée reste sur une ligne et se déplace avec ses boutons fléchés, la molette de la souris ou un glissement du doigt. Par défaut elle ne bouge pas toute seule ; vous pouvez l'activer dans Paramètres de la boutique > Page d'accueil (**Les rangées de produits défilent toutes seules**) ;
6. **Acheter par catégorie** : une tuile pour chaque catégorie avec l'image de l'un de ses produits et le nombre de produits ;
7. la **note globale** de la boutique (la moyenne des étoiles, le nombre de notes, et combien il y en a de chaque étoile) et les **avis des clients** écrits ;
8. une inscription à la **lettre d'information** ;
9. le **pied de page** avec des liens rapides, les coordonnées, les heures d'ouverture, un texte « à propos », des liens vers vos pages sociales et les pages d'information (Conditions générales, Politique de confidentialité, Retours et remboursements, Livraison et expédition, Nous contacter) ;
10. sous les rangées, **Tous les produits** avec les boutons de catégorie.

Une partie qui n'a rien à montrer (aucun produit à l'honneur, pas encore d'avis, pas d'annonce) est simplement omise. Quand un visiteur cherche ou choisit une catégorie, la page va directement aux produits correspondants.

### Trouver un produit

- **Rechercher** : chaque mot saisi doit se trouver dans le nom, le titre sur la boutique, la référence, le code-barres, la marque, la catégorie ou la description, dans n'importe quel ordre, de sorte que « tuyau jardin » trouve « Tuyau de jardin 20 m ». Des suggestions (produits, catégories et marques) apparaissent pendant la saisie.
- **Filtres** : fourchette de prix (telle que la voit le client, taxe comprise), marque, note (4, 3 ou 2 étoiles et plus) et *en stock seulement*. **Tri** par recommandés, plus récents, plus populaires (unités vendues sur les commandes en ligne), mieux notés, ou prix. **Effacer les filtres** les réinitialise.
- Les **fiches produit** ont la même taille partout : image, nom, prix (le prix normal barré et un badge **-NN %** sur une offre), étoiles avec le nombre de notes, **En stock**, **Presque épuisé** ou **Rupture de stock**, une fenêtre d'**Aperçu rapide** et **Ajouter au panier**. Un produit vendu au poids ou à la longueur affiche « / kg » ou « / m » à côté du prix.

### La page produit

Ouvrir un produit mène à sa propre page, à `/shop?product=ID`, qui peut être partagée ou mise en favori. Elle montre une grande image avec une galerie (zoom au survol, vue plein écran), le prix, le mot de stock, une zone de quantité et **Ajouter au panier**, la description complète, un tableau de caractéristiques, les étoiles avec leur répartition et les avis approuvés, un encadré **Livraison** (les frais les moins chers, le montant de livraison gratuite, l'adresse de retrait et une plage de dates de livraison estimée), **Partager sur WhatsApp**, un cœur pour la liste de souhaits, **Produits liés**, **Souvent achetés ensemble** (avec **Tout ajouter au panier**) et **Consultés récemment**.

- **Produits à options.** Un produit avec des tailles, des couleurs ou des modèles (Produits > Variantes) est **une seule fiche**, avec un bouton par valeur. Le prix, le stock, la référence et les images changent selon le choix. Une option épuisée reste visible, grisée, et ne peut pas être ajoutée. Une fiche affiche **À partir de** quand les options ne coûtent pas toutes le même prix.
- **Épuisé ? « Prévenez-moi du retour ».** Sur un produit (ou une option) épuisé, le client laisse une adresse e-mail et/ou un numéro de téléphone. La boutique le prévient une fois quand le produit peut de nouveau être vendu (voir *Clients en attente* plus bas).
- **Prix.** Un produit sans prix en ligne suit la **liste de prix** de la boutique et la meilleure promotion des Ventes (un pourcentage ou un montant de remise sur le produit ou sa catégorie) ; le prix normal est barré. Voir *Prix* plus bas.

## Configurer la boutique (responsable)

Ouvrez **Boutique en ligne > Paramètres de la boutique**. La page est une série de cartes ; chacune a son propre bouton **Enregistrer**.

### Produits sur la boutique

Cherchez un produit et appuyez sur **Ajouter**. Seuls les produits que vous ajoutez ici sont affichés ou vendus en ligne. Pour chaque produit, vous pouvez régler :

- **Titre sur la boutique** et **Prix en ligne** (laissez le prix vide pour utiliser le prix normal ou l'offre des Ventes ; un prix en ligne inférieur au prix normal affiche le prix normal barré comme une offre) ;
- **Ordre** : le nombre le plus petit passe en premier ;
- **Affiché** : décochez pour masquer le produit un temps ;
- les quatre cases de rangée **Mis en avant**, **Meilleure vente**, **Offre** et **Nouveau** : la boutique ne choisit jamais de produits elle-même, c'est vous qui décidez quels produits apparaissent dans chaque rangée (jusqu'à 8 par rangée ; les trois premières rangées suivent le numéro d'**Ordre**, **Nouveautés** montre d'abord les plus récemment ajoutés). Appuyez sur **Enregistrer** à la fin de la fiche du produit ;
- **Vendu au (kg, m ...)** : pour le riz, le tissu, le fromage et autres marchandises vendues au poids ou à la longueur. Le client peut commander des décimales (0,1 à 100, trois décimales) ;
- **Marge de ce produit** : sa propre marge de sécurité (vide = celle de toute la boutique) ;
- **Page produit : photos, description, caractéristiques** : rédigez la description, ajoutez jusqu'à 5 images de plus (5 Mo chacune, réordonnables, supprimables) et jusqu'à 20 lignes de caractéristiques (nom et valeur). L'image propre du produit est toujours la première.

Un produit à options est **une seule ligne** : **Options : prix, stock, photos** ouvre la liste de ses options avec référence, prix normal, stock, un **Prix en ligne** pour chacune, un interrupteur **Vendu en ligne** et leurs propres images. Mettez le modèle du produit sur la boutique et toutes ses options suivent ; les nouvelles options ajoutées dans Produits > Variantes apparaissent d'elles-mêmes dans les cinq minutes.

L'image est l'image propre du produit : ajoutez-en une sur l'écran du produit. Sous chaque produit, l'écran montre d'où vient son chiffre de stock (voir *Pourquoi la boutique dit-elle « Épuisé » ?* plus bas).

### Textes de la page d'accueil

Dans **Page d'accueil**, écrivez ce que dit la première page. Tout est facultatif.

- **Barre d'annonce** et son **lien** ; **Titre de la bannière**, **Texte de la bannière**, **Texte du bouton de la bannière** et **Lien du bouton de la bannière** (vide = vers les produits).
- **Images de la bannière** : choisissez jusqu'à **8 images** (JPEG, PNG, WebP ou GIF, 8 Mo chacune ; vous pouvez en choisir plusieurs à la fois). Utilisez les flèches pour les ordonner et **Retirer** pour en enlever une. Une image large, d'environ 1600 × 600 pixels, rend le mieux. Sans image, la bannière est d'une couleur unie.
- **À propos de la boutique**, **E-mail de contact**, **Numéro WhatsApp de la boutique** et **Heures d'ouverture**.
- **Couleur de la boutique** pour les boutons et la barre d'annonce, et le **délai de livraison estimé** en jours (par exemple 2 à 4), que la page produit utilise (une zone de livraison peut avoir le sien, voir le chapitre suivant).
- **Liens du pied de page** et **Liens sociaux** : un par ligne, écrit **Libellé|adresse**, par exemple `Livraison|/shop` ou `Facebook|https://facebook.com/votreboutique`. Au plus 8 et 6. Une adresse doit commencer par `/` (une page de ce site), `https://`, `http://`, `mailto:` ou `tel:` ; toute autre est refusée.

Appuyez sur **Enregistrer la page d'accueil**, puis **Ouvrir la boutique** pour la regarder.

### Les interrupteurs de la boutique

1. **La boutique** : réglez **Livraison**, **Retrait** et **Paiement en espèces à la livraison ou au retrait**, l'**Adresse de retrait**, la **Commande minimale**, la **Livraison gratuite à partir de** un montant, et le **Produit de service pour les frais de livraison** (voir le chapitre suivant).
2. Les **Comptes clients**, **Messages texte**, **Retours** (combien de jours après la fin d'une commande un client peut retourner des marchandises ; 0 = pas de retours via la boutique) et **Paiements en ligne** s'activent aussi ici. Votre administrateur configure les fournisseurs (Manuel de l'administrateur, chapitre 7).
3. **Agence pour laquelle la boutique vend** : affiché seulement quand l'entreprise a plus d'une agence. Les commandes clients, factures, paiements et écritures de fidélité de la boutique portent cette agence, de sorte que les rapports par agence incluent la boutique. Le siège est la valeur par défaut.
4. Cochez **La boutique est ouverte au public** et **Enregistrer les paramètres**. Utilisez **Suspendre les commandes pour l'instant** pour cesser de prendre des commandes sans retirer la page ; le message que vous écrivez est montré aux visiteurs.
5. Appuyez sur **Ouvrir la boutique** et passez une commande d'essai avant d'en parler aux clients.

*Conseil :* Les prix de la boutique incluent la taxe.

### Pages de la boutique

**Boutique en ligne > Pages de la boutique** contient les quatre pages d'information dont toute boutique a besoin : Conditions générales, Politique de confidentialité, Retours et remboursements, et Livraison et expédition. Chacune commence par un texte de départ général en anglais et en français où le nom, le téléphone, l'e-mail et l'adresse de la boutique sont remplis. Vous pouvez modifier le titre et le texte de chacune (des paragraphes ; une ligne qui commence par `## ` est un titre, une qui commence par `- ` est une puce ; `{shop}`, `{phone}`, `{email}` et `{address}` sont remplacés par les coordonnées de la boutique), désactiver une page, ou revenir au texte de départ.

> **Attention :** Les textes de départ sont un début général, **pas un avis juridique**. Lisez-les, adaptez-les à votre entreprise et à votre pays, et faites-les vérifier avant d'ouvrir la boutique. Une page que vous avez enregistrée est montrée telle que vous l'avez écrite à tous les visiteurs, dans une seule langue. La page de paiement dit « En passant votre commande vous acceptez ... » avec des liens vers les pages qui sont affichées.

### Installer la boutique comme application

Tout le site, boutique comprise, peut être installé sur un téléphone ou un ordinateur comme une application (Chrome, Edge et Android proposent une carte **Installer l'application** ; sur un iPhone utilisez Partager > Sur l'écran d'accueil). La boutique s'installe sous son propre nom et sa propre couleur, les écrans du personnel sous « NIWE ERP ». L'application installée s'ouvre même sans connexion, avec une bande rouge « Vous êtes hors ligne », mais **rien du serveur n'est conservé** : les ventes, le stock et les prix viennent toujours du serveur, une commande ne peut donc pas être passée hors ligne. (La caisse a sa propre file d'attente pour les ventes quand la connexion tombe ; voir le chapitre POS.)

## Pourquoi la boutique dit-elle « Épuisé » ?

Vous n'avez **pas** besoin d'un stock séparé pour la boutique. La boutique utilise le même stock que la caisse et les entrepôts :

> stock dans les **emplacements vendables** de vos entrepôts − quantités **réservées** sur des commandes clients confirmées − unités **retenues** par des commandes de la boutique auxquelles personne n'a répondu − la **marge** du produit − la **part gardée pour la caisse** = ce que la boutique peut encore vendre

La ligne sous chaque produit dans **Produits de la boutique** montre chacun de ces chiffres : dans les emplacements vendables, réservé sur des commandes confirmées, retenu par des commandes sans réponse, la marge, la part gardée pour la caisse, ce qui est périmé ou trop proche de sa date d'expiration, et **vendable maintenant**. Quand ce dernier est 0 ou moins, la boutique dit *Épuisé*. Le mot sur la fiche, *Plus que n*, le filtre *En stock*, la vérification au paiement et les alertes de retour en stock utilisent tous ce même chiffre. Si la ligne dit *Le stock n'est pas suivi pour ce produit*, la boutique le montre toujours comme disponible.

Ce qui compte comme **emplacements vendables** : quand plusieurs entrepôts sont utilisés, seulement les emplacements **Ventes** en dehors de l'**Entrepôt principal**. Paramètres de la boutique > **Stock vendu par la boutique** vous permet de choisir un seul emplacement Vente, ou *Automatique* (tous). Les marchandises dans *Réception*, *Stockage*, *Endommagé* ou un emplacement inactif ne sont pas comptées. Avec un seul entrepôt, rien ne change.

Ce que font les réglages :

- **Unités gardées pour la caisse** (marge de toute la boutique, 1 sauf si vous l'avez changée) et **Marge de ce produit** (la sienne propre, qui l'emporte sur celle de la boutique).
- **Part gardée pour la caisse (%)** : cette part des unités disponibles de chaque produit est gardée pour la caisse (arrondie au supérieur), en plus de la marge.
- **Libérer les commandes sans réponse après (heures)** : 24 par défaut, 0 = jamais. Une commande de la boutique **retient ses unités dès qu'elle est passée**, afin que deux clients ne se voient pas vendre les mêmes dernières unités. Une commande qui attend un paiement, ou une commande en espèces que personne n'a acceptée, est annulée après ce nombre d'heures et son stock est de nouveau libre ; le client est prévenu. Une commande **payée en ligne** n'est jamais annulée ainsi : le personnel doit y répondre.
- **Ne pas vendre les produits ayant moins de jours restants que** (0 par défaut) : pour les produits suivis par lot, les lots expirés ne sont jamais vendus ; avec un nombre ici, les lots plus proches de leur date d'expiration sont aussi écartés. Les livraisons prennent d'abord les lots que la boutique peut vendre, à l'expiration la plus proche d'abord.
- **Cartons** : quand la décomposition est activée dans le Stock, les unités qu'on peut obtenir en ouvrant des cartons comptent comme du stock, et les cartons sont ouverts automatiquement quand une commande est acceptée ou livrée.

Quand un produit dit épuisé et que vous croyez avoir du stock, cherchez :

| Ce que vous voyez | Raison habituelle | Que faire |
|---|---|---|
| Vendable maintenant est exactement 0 et le stock est 1 | La marge de 1 | Baissez **Unités gardées pour la caisse** (ou la marge propre du produit) à 0 |
| Le chiffre de stock est 0 mais le produit a du stock | Le stock est dans un emplacement non vendable (*Réception*, *Endommagé*, l'Entrepôt principal, un emplacement inactif) ou n'a jamais été saisi par entrepôt | Ouvrez le **Stock** et le stock du produit ; déplacez les marchandises vers un emplacement de vente par un transfert de stock (voir le chapitre Stock) |
| Stock et réservé sont tous deux élevés | Les marchandises sont déjà promises sur des commandes clients confirmées, y compris des commandes en ligne acceptées | Terminez ou annulez ces commandes, ou ajoutez du stock |
| *Retenu par des commandes sans réponse* est élevé | Les commandes passées mais pas encore acceptées retiennent leurs unités | Répondez aux commandes dans **Nouveau** |
| *Périmé ou trop proche de l'expiration* affiche un nombre | Ces lots sont écartés du chiffre | Vendez-les à la caisse, ou changez le réglage |

Le stock qui arrive sur une réception d'achat reste dans l'emplacement *Réception* jusqu'à ce qu'il soit déplacé vers un emplacement *Vente*. L'écran **Réapprovisionnement** soustrait les unités des commandes de la boutique auxquelles personne n'a encore répondu et compte les clients qui attendent un e-mail de retour en stock comme de la demande (colonnes **Commandes en ligne** et **Clients en attente**) ; le rapport de valorisation du stock a une colonne **Commandes en ligne**.

## Prix

Un produit avec un **Prix en ligne** est vendu à ce prix. Un produit sans prix en ligne suit **Paramètres de la boutique > Liste de prix utilisée par la boutique** et la meilleure **promotion** des Ventes qui s'applique à tout le monde sur le produit ou sa catégorie ; le prix normal est barré. Les prix sont recalculés toutes les 2 minutes ; appuyez sur **Appliquer maintenant** pour voir un changement tout de suite. Les promotions qui demandent un coupon, un groupe de clients, une limite, un minimum, « achetez X obtenez Y », ou qui s'appliquent à tout le panier, ne sont **pas** appliquées en ligne. La ligne du produit affiche « Offre des Ventes : prix (nom) ».

## Ce que fait le client

Le client ouvre `/shop`, cherche ou choisit une catégorie, ajoute des produits au panier, et appuie sur **Passer la commande**. Il choisit **Livraison** ou **Retrait**, donne un nom et un numéro de téléphone (une adresse e-mail est facultative), et pour la livraison une zone, une adresse et, quand la boutique propose des heures de livraison, un jour et une plage horaire. Un client connecté choisit l'une des **adresses enregistrées** ou en enregistre une nouvelle. Puis il choisit comment payer :

- **Espèces à la livraison** ou **Espèces au retrait**. Après **Passer la commande**, la commande vous parvient tout de suite.
- **Mobile money** (il tape le numéro depuis lequel payer et approuve sur son téléphone) ou **Carte**. Quand plus d'un fournisseur peut prendre le mode de paiement choisi, une ligne **Payer avec** montre un bouton par fournisseur (avec son logo si vous l'avez ajouté). Après **Commander et payer**, la commande ne vous parvient qu'une fois le paiement **confirmé**.
- Un **code coupon** peut être saisi et vérifié avec **Appliquer** avant de commander (quand vous avez un coupon actif), et un client connecté peut **utiliser ses points de fidélité**.
- Quand les messages texte sont activés, une case propose des nouvelles de la commande par texto (ou WhatsApp).

Il voit ensuite un **code** de commande. La page `/shop/order/<code>` montre où en est la commande, l'estimation de livraison, le livreur une fois la commande en route, le **code de livraison**, lui permet de l'annuler tant qu'elle est nouvelle, de **commander de nouveau**, de **Télécharger la facture (PDF)** une fois terminée, d'**Envoyer cette commande à la boutique sur WhatsApp**, de demander un **retour** et de **noter** les produits. S'il a donné une adresse e-mail, il reçoit un message quand la commande est reçue, acceptée, en route ou prête, terminée ou refusée, chacun se terminant par un lien **Voir votre commande**.

### Le compte du client

Un client peut **se connecter** (le bouton de compte en haut de la boutique) : il saisit son adresse e-mail (ou un numéro de téléphone enregistré), reçoit un code à usage unique valable 10 minutes, et entre dans le portail. Aucun mot de passe n'est nécessaire, et acheter en invité fonctionne toujours. Le portail est à `/shop/account` et a un menu avec une page pour chacun :

- **Mes commandes** : toutes les commandes, filtrées Toutes / En cours / Livrées / Annulées, avec **Suivre**, **Commander à nouveau** (remplit le panier avec les produits et prix du jour) et **Facture** (PDF) sur chaque commande terminée, et le code de livraison d'une commande en route.
- **Mes factures** : une ligne par facture, avec **Télécharger (PDF)**.
- **Ma liste de souhaits** : les produits mis en cœur avec prix et stock et **Ajouter au panier**. Les invités gardent leurs cœurs dans leur navigateur ; ils rejoignent le compte à la connexion.
- **Mes retours** : chaque retour demandé, avec son statut, les articles, le motif, la note de la boutique, le code et le livreur du retour, et le montant remboursé.
- **Mes adresses** : jusqu'à 10 adresses de livraison (nom, zone, adresse, une par défaut).
- **Points de fidélité** (quand la boutique en a) et **Mon profil**, avec déconnexion et **supprimer mon compte**.

### Notes et avis

Un client qui a acheté un produit sur une commande **terminée** peut le noter depuis la page de la commande, une fois par produit et par commande. La **note** (1 à 5 étoiles) compte **tout de suite** ; l'**avis** (des mots facultatifs) n'est affiché qu'après approbation par le personnel. Une note sans mots n'a rien à vérifier, donc rien n'attend. Seules les vraies notes existent : le personnel ne peut pas en ajouter.

## Répondre aux commandes (personnel)

Ouvrez **Boutique en ligne > Commandes en ligne**. Les onglets sont **Nouveau**, **En attente de paiement**, **Ouvert**, **Remboursements à faire**, **Terminée**, **Rejetée**, **Annulé** et **Tout**, chacun avec son nombre. L'onglet **Nouveau** liste les commandes qui attendent une réponse, avec une marque *en retard* quand l'une attend depuis trop longtemps. La liste se rafraîchit toute seule, elle peut donc rester ouverte sur un écran de comptoir. Des boutons en haut mènent à **Retours**, **Paiements en ligne** (avec le nombre qui demande de l'attention) et **Paramètres de la boutique**.

- **Accepter** crée une commande client confirmée qui retient le stock. Si le stock ne couvre pas la commande, l'écran le dit et propose **Accepter quand même** ; la commande client est alors sur-promise jusqu'à l'arrivée de stock. Appelez le client en cas de doute. Une commande payée en ligne est déjà payée : il n'y a pas d'espèces à encaisser.
- **Rejeter** demande un motif ; le client le voit. Une commande payée en ligne et rejetée apparaît sous **Remboursements à faire**.
- **Livreur** : sur une commande de livraison, choisissez le livreur (voir le chapitre suivant), imprimez le **Bon de livraison** ou la **Feuille de tournée**, ou envoyez la commande au livreur sur WhatsApp.
- **Marquer comme emballée** (facultatif), puis **En cours de livraison** pour une livraison ou **Prête pour le retrait** pour un retrait. Le client est prévenu et reçoit un **code de livraison** (ou de retrait) à 4 chiffres par e-mail et par texto.
- **Terminer** remet la commande. La personne qui reçoit les marchandises donne le code à 4 chiffres, que vous saisissez ; cela sort le stock par la commande client, émet la facture, enregistre le paiement, envoie la facture par e-mail et donne les points de fidélité. Pour une commande en espèces, les espèces sont enregistrées comme encaissées. Un client qui a perdu le code peut le recevoir de nouveau avec **Envoyer un nouveau code au client** : le personnel ne voit jamais le code lui-même.
- **Livraison échouée** et **Le client ne garde qu'une partie des marchandises** sont décrits dans le chapitre suivant.
- **Annuler la commande** (acceptée mais pas terminée) annule la commande client et libère le stock.
- **En attente de paiement** liste les commandes dont le client n'a pas encore payé. Elles passent dans **Nouveau** quand le paiement est confirmé. Un paiement que le client n'approuve pas dans les **Minutes dont le client dispose pour payer** (30 sauf changement dans les paramètres de la boutique) expire, et le client peut réessayer depuis la page de la commande.
- Un client qui a aussi donné un téléphone compatible WhatsApp a un lien **WhatsApp** à côté du numéro.

Une remise de coupon ou de points de fidélité est montrée sur la commande. **Historique** liste chaque étape avec qui l'a faite et quand, y compris si le message du code est parti par e-mail et par texto.

Les marchandises suivies par lot ou par **numéro de série** livrées affichent leurs numéros de série sur la commande, sur la page de commande du client et sur la facture.

## Remboursements des paiements en ligne

Quand un client qui a payé en ligne annule, ou que vous rejetez la commande, la commande passe sous **Remboursements à faire**. Ouvrez-la et appuyez sur **Rembourser via le fournisseur** pour rendre l'argent par le fournisseur de paiement. Si le fournisseur ne peut pas le faire (les remboursements Airtel Money se font à la main), remboursez à la main en dehors du programme, saisissez la **référence** de votre remboursement et appuyez sur **Je l'ai remboursé moi-même**. Une fois qu'une commande est terminée, les marchandises qui reviennent passent par **Retours** (ci-dessous). Les écritures comptables de chaque remboursement sont décrites dans le chapitre paiements et comptabilité.

## Coupons

**Boutique en ligne > Coupons** contient les codes qu'un client saisit au paiement. Quand au moins un coupon est actif, la boutique affiche une zone de coupon.

- Un coupon donne **Pourcentage de réduction sur les articles** (avec un montant *Jamais plus que* facultatif), **Montant de réduction sur les articles**, ou **Livraison gratuite**.
- Limites facultatives : **Commande minimale**, **Valable à partir du**, **Valable jusqu'au**, **Commandes sur lesquelles il peut servir**, et **Une fois par client** (le même numéro de téléphone ou compte).
- Une commande rejetée ou annulée rend son utilisation. La remise fait partie de la commande client et de la facture, de sorte que la facture est toujours égale à ce que le client a payé. Dans les comptes, la remise apparaît dans **Remises accordées sur ventes**, et n'est pas retirée du chiffre d'affaires.
- Un coupon par commande, et il s'applique à toute la commande, pas à un seul produit.

## Retours

Un client peut demander à retourner des marchandises d'une commande **terminée**, dans le nombre de jours réglé dans les paramètres de la boutique (14 sauf changement), depuis la page de sa commande ou depuis **Mes retours**. Il choisit les articles et les quantités, donne un motif et le numéro de téléphone de la commande (pas nécessaire quand il est connecté).

1. Ouvrez **Boutique en ligne > Retours**. L'onglet **En attente** liste les nouvelles demandes. Appuyez sur **Approuver** ou **Refuser** (une note pour le client est exigée pour refuser).
2. Pour une commande en **livraison**, un livreur récupère les marchandises à la porte du client, gratuitement (chapitre suivant). Pour une commande que le client a **retirée** à la boutique, le client rapporte les marchandises.
3. Quand les marchandises sont revenues, appuyez sur **Articles reçus : remettre en stock et rembourser** (cela fonctionne depuis **Approuvée** et depuis **Collectée**), choisissez où les marchandises sont remises, et rendez l'argent : **Rembourser via le fournisseur** pour un paiement en ligne, ou la même chose à la main avec sa référence ; pour une commande en espèces, l'écran dit combien d'espèces rendre. Pour les lignes à **numéro de série**, cochez les numéros de série revenus ; ils sont de nouveau en stock.
4. Les marchandises retournent en stock par un retour de commande client ordinaire, de sorte que le stock, le chiffre d'affaires, la TVA et les rapports suivent. Les marchandises retournent au Stock au **coût auquel elles ont été vendues**. Une remise de coupon suit les marchandises (le client récupère ce qu'il a payé pour elles) ; les **frais de livraison ne sont pas remboursés**. Les points de fidélité suivent aussi les marchandises.

Le client reçoit un e-mail (et un texto) à chaque étape. Les échanges, les avoirs en magasin et les frais de réapprovisionnement ne font pas partie de cet écran.

## Avis

Ouvrez **Boutique en ligne > Avis**. Les onglets sont **En attente** (nouveaux avis écrits), **Affiché**, **Note seule**, **Masqué** et **Tout**. **Approuver** affiche les mots sur la boutique, **Masquer** les garde sans les afficher, **Supprimer** retire l'entrée pour de bon. Deux autres boutons agissent sur les étoiles : **Retirer la note** garde une note injuste hors des moyennes et **Recompter la note** la ramène. La note globale de la boutique et les étoiles sur les fiches et les pages produit suivent tout de suite.

## Messages (formulaire de contact)

La boutique a une page **Contactez-nous** avec le téléphone, l'e-mail, le WhatsApp, l'adresse et les heures d'ouverture de la boutique et un formulaire (nom, e-mail, téléphone, objet, message, un code de commande facultatif). Le visiteur doit donner un e-mail ou un numéro de téléphone pour que vous puissiez répondre. Ouvrez **Boutique en ligne > Messages** : les onglets **Nouveau**, **Traité** et **Tout** ont une zone de recherche. Pour chaque message, vous pouvez **Répondre par e-mail** (une fenêtre s'ouvre : écrivez la réponse, appuyez sur **Envoyer la réponse** ; elle part de l'e-mail de la boutique, dans la langue du client, avec le message cité, et le message devient Répondu), utiliser le bouton **WhatsApp**, écrire une note, **Marquer comme traité** ou **Remettre en nouveau**, ou **Supprimer**. La boutique est prévenue de chaque nouveau message par e-mail (et par texto quand l'alerte propriétaire est configurée), et le visiteur qui a donné un e-mail en reçoit une copie. Un visiteur qui n'a donné qu'un numéro de téléphone ne peut pas être joint par e-mail : utilisez le téléphone ou WhatsApp.

## Clients en attente (alertes de retour en stock)

**Boutique en ligne > Clients en attente** liste les produits dont les clients ont demandé à être prévenus, **les plus demandés d'abord**, pour que vous sachiez quoi réapprovisionner ; elle dit *de retour en stock* quand un produit peut de nouveau être vendu. En dessous se trouve la liste des personnes (**En attente**, **Prévenu**, **Impossible à prévenir**, **Tout**, avec une zone de recherche). La boutique vérifie toutes les cinq minutes : dès qu'un produit peut de nouveau être vendu, chaque client en attente reçoit **un** e-mail dans sa langue (et un texto quand les messages texte sont activés), et la demande est close. Si l'envoi échoue, il est retenté trois fois puis marqué **Impossible à prévenir**. Les clients dont le seul contact est un numéro de téléphone alors que les messages texte sont désactivés restent **En attente** pour vous : utilisez le bouton **WhatsApp** (le message et le lien sont déjà écrits), puis **Marquer comme prévenu**. **Les prévenir maintenant** lance l'avis tout de suite ; **Retirer** supprime une demande.

## Lettre d'information

Les visiteurs peuvent demander votre lettre d'information en bas de la première page. La boutique leur envoie un e-mail avec un lien ; ils ne sont comptés qu'après l'avoir ouvert. Ouvrez **Boutique en ligne > Lettre d'information** pour voir la liste (**Abonné**, **Non confirmé**, **Désabonné**), pour **Retirer** une adresse, et pour **Télécharger les adresses confirmées (CSV)**, avec le lien de désabonnement propre à chaque personne, pour un outil d'envoi.

### Envoyer une lettre d'information

Ouvrez **Boutique en ligne > Envoyer une lettre d'information** (aussi un bouton sur l'écran Lettre d'information) et appuyez sur **Nouvelle newsletter**.

1. Saisissez l'**Objet** et le **Message**. Une ligne vide commence un nouveau paragraphe. Le message est du texte brut : rien de ce que vous tapez n'est traité comme de la mise en forme ou du code. Vous pouvez ajouter un **bouton** avec son texte et un lien qui commence par `https://` ou `/` (par exemple `/shop`).
2. Choisissez **Qui le reçoit** : tous ceux qui ont confirmé, seulement les lecteurs anglophones, ou seulement les lecteurs francophones (la langue de chaque personne est celle qu'elle avait à l'inscription). Le nombre de personnes est affiché.
3. Appuyez sur **Enregistrer le brouillon**, saisissez votre propre adresse e-mail et appuyez sur **M'envoyer un test**. Le test ressemble au vrai e-mail et a [TEST] dans l'objet. Modifiez le brouillon et testez de nouveau autant de fois que vous voulez.
4. Appuyez sur **Envoyer à N personnes** et confirmez. La liste est figée à ce moment.

Le nom de la boutique et **le lien de désabonnement propre à chaque personne** sont ajoutés automatiquement en bas de chaque e-mail, dans la langue de la personne. Les e-mails ne partent pas tous d'un coup : un petit lot part environ chaque minute, et il y a une limite par 24 heures (500 sauf changement par votre administrateur) pour que votre serveur de messagerie ne vous bloque pas. Ouvrez la lettre d'information depuis la liste pour la suivre : une barre et les nombres **Envoyé**, **En attente**, **Échec** et **Ignorée**. La page se met à jour toute seule.

- **Arrêter l'envoi** arrête le reste. Ce qui est déjà parti reste parti, et une lettre arrêtée ne peut pas être relancée (écrivez-en une nouvelle).
- Les **Ignorée** sont les personnes qui se sont désabonnées (ou ont été retirées) après que vous avez appuyé sur envoyer mais avant leur tour : elles ne reçoivent rien.
- Les adresses **Échec** sont listées avec le motif donné par le serveur de messagerie. Après avoir corrigé la cause (par exemple les paramètres d'e-mail ; une adresse avec une faute de frappe ne peut qu'être retirée), appuyez sur **Réessayer les échecs** : seuls ceux-là sont réessayés, personne ne reçoit de deuxième copie. Si cinq e-mails échouent à la suite, l'envoi se met en pause et affiche le motif ; corrigez-le et appuyez sur **Réessayer les échecs**.
- Appuyer deux fois sur **Envoyer**, ou deux personnes qui appuient dessus, ne peut pas envoyer une lettre deux fois. Une lettre envoyée reste dans la liste comme trace ; seul un brouillon peut être modifié ou supprimé.

> **Remarque :** La lettre d'information demande que les paramètres d'e-mail de l'entreprise fonctionnent (Manuel de l'administrateur, chapitre 9), et que `app.frontend-url` soit l'adresse publique du site (Manuel de l'administrateur, chapitre 7), sinon les liens de désabonnement seront faux.

## Paniers abandonnés

Beaucoup de visiteurs remplissent un panier puis s'en vont. Quand votre responsable active **Envoyer des rappels pour les paniers abandonnés** (Paramètres de la boutique), la boutique peut relancer ceux qui ont saisi une **adresse e-mail** au paiement.

- **Ce que voit le client.** Sous la zone e-mail, un court avis dit que la boutique peut lui rappeler son panier par e-mail, et que chaque e-mail a un lien pour arrêter les rappels. Rien n'est enregistré tant que le client n'a pas saisi une adresse qui semble correcte (les invités aussi : aucun compte n'est nécessaire).
- **Deux rappels, pas de remise.** Le premier part environ **1 heure** après la dernière modification du panier par le client, le second **3 jours** après. L'e-mail liste le panier tel que la boutique est aujourd'hui (prix actuels ; ce qui est épuisé est indiqué comme n'étant plus disponible) avec un bouton **Retourner à mon panier**. L'e-mail est dans la langue que le client utilisait sur la boutique.
- **Personne n'est harcelé.** Une adresse qui **commande** n'est plus relancée. Un lien en bas de chaque e-mail (**Arrêter ces rappels**) les arrête tout de suite et pour toujours. Un panier dont tous les articles ont disparu, ou qui a plus de 2 jours quand son premier rappel devrait partir, est abandonné sans e-mail.
- **Votre écran.** **Boutique en ligne > Paniers abandonnés** montre les nombres (En attente, Relancés une fois, Relancés deux fois, Commandés, Arrêtés, Rien à rappeler) et une liste avec l'adresse e-mail, les produits et pièces, la dernière modification et le moment où chaque rappel est parti. Appuyez sur un nombre pour filtrer. **Retirer** supprime un panier et son adresse (par exemple quand un client demande à être oublié). Les paniers non touchés depuis deux mois sont supprimés d'eux-mêmes.

> **Remarque :** Les rappels demandent que les paramètres d'e-mail de l'entreprise fonctionnent et que `app.frontend-url` soit réglé sur l'adresse publique du site. Ils sont désactivés tant que vous ne cochez pas la case, et rien n'est enregistré tant qu'ils sont désactivés.

## Points de fidélité

Quand votre responsable active **Les clients gagnent et dépensent des points de fidélité** (Paramètres de la boutique ; cela demande que les Comptes clients soient activés), les clients **connectés** gagnent des points et les dépensent sur des commandes ultérieures. Les invités ne gagnent rien : les points appartiennent au compte. Ces points sont ceux de la boutique et sont distincts du programme de fidélité de la caisse (Ventes).

- **Gagner.** Quand une commande est **terminée**, le client gagne des points sur ce qu'il a payé pour les marchandises : **1 point pour 100** par défaut (votre responsable peut le changer), après toute remise de coupon ou de points et sans les frais de livraison. Sur une livraison partielle, il gagne sur ce qui a été livré.
- **Dépenser.** Au paiement, un client connecté qui a des points voit **Utiliser des points de fidélité** : il tape combien, ou appuie sur **Utiliser le maximum**. **Un point retire 1** (1 unité de la monnaie de la boutique), et les points peuvent payer au plus une part des marchandises (50 % par défaut) qui reste après un coupon. La boutique revérifie le solde quand la commande est envoyée, de sorte que les mêmes points ne peuvent jamais être dépensés deux fois.
- **Leur solde.** Dans le portail (**Points de fidélité**), le client voit le solde et l'historique (gagnés, utilisés, rendus).
- **Les commandes annulées ou refusées** rendent les points dépensés. **Les marchandises retournées** rendent la part correspondante des points dépensés pour elles et reprennent la part correspondante des points qu'elles ont fait gagner ; si le client a déjà dépensé ces points, le solde peut passer sous zéro jusqu'à ce qu'il en gagne d'autres.
- **Votre écran.** **Boutique en ligne > Points de fidélité** liste les comptes clients avec leurs points (les plus nombreux d'abord, avec une zone de recherche), montre l'historique d'un client, et vous permet d'**ajouter ou retirer des points** avec un motif.
- **Dans vos comptes.** Les points gagnés sont une charge et une dette (**Dette de points de fidélité**) ; les points dépensés sur une commande livrée libèrent la dette, et le coût apparaît alors dans **Remises accordées sur ventes**. Les points n'expirent jamais, et supprimer le compte d'un client supprime son historique de points. Les points gagnés avant la version 1.73.0 ne sont pas dans la dette ; votre comptable passe une écriture d'ouverture pour les points que les clients détiennent déjà.

## Messages texte

Quand votre administrateur a choisi un fournisseur de messages texte, la boutique peut envoyer des textos aux clients au sujet de leur commande (seulement ceux qui ont coché la case au paiement), des codes de connexion par texto, et vous envoyer des textos pour les nouvelles commandes. Le **code de livraison**, le **code de retrait**, le **code de retour** et le **nouveau code** font exception : ils sont envoyés par e-mail **et** par texto au numéro de téléphone de la commande que la case ait été cochée ou non, parce que le code fait partie de la livraison. **Boutique en ligne > Messages texte** liste chaque texto, y compris ceux qui ont échoué ou n'ont pas été envoyés, et a un formulaire **Envoyer un message de test**. Il y a une limite quotidienne pour maîtriser le coût. Tant qu'une vraie société de SMS n'est pas connectée, un expéditeur intégré garde chaque texto de code dans la liste marqué **En attente d'une société SMS** : rien ne quitte le serveur, et l'e-mail part quand même. Le code lui-même n'est jamais écrit dans la liste des textos.

## Bon à savoir

- Les commandes en ligne venant d'un numéro de téléphone qui existe déjà dans **Clients** se rattachent à ce client ; sinon un client est créé.
- Un client ne peut avoir que quelques commandes en attente de réponse à la fois, et un script qui envoie beaucoup de commandes depuis une même connexion est ralenti. Ces limites sont dans **Paramètres de la boutique**.
- Aperçus de liens : quand un lien de la boutique est collé dans WhatsApp, Facebook, Telegram et applications semblables, une carte apparaît avec l'image, le nom et le prix du produit, et Google peut afficher prix, stock et étoiles. L'administrateur ajoute une règle au serveur web pour cela (Manuel de l'administrateur, chapitre 7) ; sans elle la boutique fonctionne mais les liens n'affichent pas d'aperçu.
- Les lettres d'information sont en texte brut avec un bouton facultatif, sans images, et ne peuvent pas être programmées pour plus tard. Les commandes en ligne apparaissent aussi dans les rapports de ventes normaux.
