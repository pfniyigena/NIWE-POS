# Ordres de travail

Le groupe **Ordres de travail** comprend : **Ordres de travail, Tableau, Calendrier, Maintenance planifiée, Forfaits de service, Rapports**. Un ordre de travail (fiche d'intervention) enregistre un travail pour un client, ou une maintenance interne, avec ses intervenants, pièces, temps, coûts et facturation. Le personnel qui a une connexion voit ses propres travaux sous **Mes interventions**.

## Créer un travail

**Ordres de travail > Nouvel ordre de travail** :

- **Type** : *Travail client (facturé)* ou *Maintenance ou réparation interne*.
- **Priorité** : *Basse, Normale, Haute, Urgente*.
- **Partir d'un forfait de service** (facultatif) : copie la liste de contrôle, les pièces et le prix du forfait.
- **Titre**, **Description**, **Client**, **Immobilisation (facultatif)** (un élément du registre des immobilisations, pour les rapports de coût de maintenance), **Sur quoi on travaille** (par exemple *Ordinateur portable n° de série 123* ou *Véhicule RAB 123A*).
- **Affectée à**, **Planifié**, **Échéance**, **Taux horaire** et un **Prix forfaitaire** facultatif (laissez vide pour facturer les heures et les pièces).

## Devis et approbation du client

Si votre administrateur a activé *Les nouveaux travaux clients demandent l'approbation du client*, le travail ne peut pas commencer tant qu'un **devis** n'a pas été envoyé au client et **approuvé** (le travail affiche *Approuvé* ou *Refusé*). Vous pouvez désactiver cela pour un seul travail. Le client reçoit un devis en PDF, et la **fiche d'intervention** et une note de fin de travail sont des PDF que vous pouvez imprimer ou envoyer par e-mail.

## Travailler sur un travail

Sur la page du travail, vous avez :

- **Liste de contrôle** : des étapes à cocher (**Modifier les étapes** : une étape par ligne). Un travail ne peut pas être terminé avec des étapes ouvertes, sauf si vous cochez *Terminer même si ... étape(s) de la liste de contrôle ne sont pas faites*.
- **Pièces et matériaux** : cherchez un produit et ajoutez-le avec une quantité et un prix (ou marquez *Dans le prix fixe*). **Les mouvements de stock et le coût sont comptabilisés quand le travail est terminé**, enregistrez donc d'abord chaque pièce.
- **Coûts externes** : le travail d'un fournisseur ou un article acheté (date, quoi, fournisseur, coût, **Facturer au client**), éventuellement **Enregistrer comme dépense dans** un compte, ou *Ne pas enregistrer*.
- **Heures** : temps saisi sur le travail par les personnes via *Saisir du temps* (les heures internes sont enregistrées à titre d'information ; les salaires sont payés par la paie ; avec un prix fixe, les heures ne sont pas facturées).
- **Coût et prix** : coût des pièces, coûts externes, coût total et prix.
- **Ordre de fabrication** : pour fabriquer quelque chose pour le travail, créez un ordre de fabrication lié depuis une nomenclature ; le travail ne peut pas être terminé tant que l'ordre n'est pas produit.
- Des photos et des fichiers peuvent être joints.

Boutons : **Mettre en attente**, **Saisir du temps**, **Modifier les détails**, **Terminer...**, **Rouvrir**, **Annuler l'intervention**, **Supprimer**.

### Terminer et facturer

**Terminer...** sort les pièces du stock et comptabilise leur coût, avec une note facultative. Ensuite **Facturer** : prévisualisez ce qui sera facturé (lignes et total hors taxe), fixez une échéance et **Créez la facture en brouillon**. Le travail affiche **Sur la facture**. **Libérer (facturer à nouveau)** le libère si le brouillon a été supprimé.

## Tableau et calendrier

- **Tableau** : colonnes par statut. **Faites glisser une carte vers En cours pour le démarrer, ou vers En attente**. Filtrez par **Tout le monde / Non affectés**, **Clients et interne**, **Interventions clients**, **Maintenance interne**, ou cherchez. Les cartes montrent *Échéance ... (en retard)*, l'urgence et l'avancement de la liste de contrôle.
- **Calendrier** : les travaux par date planifiée, pour organiser la semaine.

## Maintenance planifiée

La **Maintenance planifiée** crée des travaux à votre place selon un calendrier répété (par exemple l'entretien d'un groupe électrogène tous les 3 mois). **+ Nouveau calendrier** : **Titre**, **Type**, **Priorité**, **Client**, **Actif**, **Forfait de service**, **Affectée à**, prix, **Répéter tous les n jours/semaines/mois**, **La prochaine est due le**, **Créer l'intervention ce nombre de jours à l'avance**, **Le travail est dû après n jours**, et *Ne pas créer de nouveau travail tant que le dernier est encore ouvert*. Un contrôle tourne chaque matin ; **Exécuter maintenant** crée tout de suite les travaux dus.

## Forfaits de service

Les **Forfaits de service** sont des modèles : **Nom, Code, Description, Prix fixe** (0 = facturer les heures et les pièces), **Heures estimées**, une **Liste de contrôle** et des **Pièces habituelles** (avec la quantité et si elles sont dans le prix).

## Rapports

**Ordres de travail > Rapports** : Ordres de travail, Rentabilité des ordres de travail, Coût de maintenance par immobilisation, Ordres de travail en retard.
