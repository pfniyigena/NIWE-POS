# Hôtel

Le groupe **Hôtel** comprend : **Réception, Réservations, Plan des réservations, Ménage, Maintenance, Clients, Registre des clients, Chambres, Types de chambre, Tarifs, Comptes entreprises, Groupes, Réservation en ligne, Rapports, Paramètres**.

> **Remarque :** Un hôtel est configuré une fois par un administrateur dans cet ordre : **types de chambre** (nom et tarif par nuit), puis **chambres**, puis **Paramètres** (comment le revenu des chambres arrive en comptabilité, taxe, heures d'arrivée et de départ, politique de frais). Une fois le module Hôtel activé, un mode de paiement **Mettre sur la chambre** est disponible dans le POS et le Restaurant.

## La réception

**Hôtel > Réception** est l'écran d'accueil du réceptionniste. Il montre **Occupées, Occupation %, Libres ce soir, Arrivées prévues, Départs prévus, À nettoyer** et **Hors service**, puis trois listes : **Arrivées, En séjour, Départs** (Réservation, Client, Chambre, Séjour, Solde). Une étoile marque les clients VIP et un drapeau les clients sur liste noire. Boutons : **Nouvelle réservation** et **Client sans réservation** (un client qui arrive sans avoir réservé).

## Faire une réservation

**Réservations > Nouvelle réservation** (ou **Client sans réservation** à la réception) :

1. **Client** : choisissez un **Client existant** (recherche par nom, téléphone ou numéro de pièce d'identité) ou saisissez un **Nouveau client** (nom complet, téléphone, e-mail, numéro de pièce d'identité).
2. **Séjour** : **Arrivée**, **Départ**, **Type de chambre**, **Adultes**, **Enfants**. Choisissez une **Chambre**, ou *Affecter plus tard*. Si aucune n'est libre, l'écran le dit.
3. **Formule tarifaire** : *Tarif standard* ou une formule comme Entreprise. L'écran montre le prix de chaque nuit, le total hors taxe, la taxe, et le total TTC.
4. **Origine** : d'où vient la réservation (téléphone, site web, agent), utilisée dans les rapports.
5. Facultatif : **Convenir d'un autre prix avec le client** (un tarif par nuit hors taxe), ajoutez des **Notes** et un **Acompte** (montant et mode de paiement).
6. Enregistrez.

## Travailler avec une réservation

Ouvrez une réservation pour voir le client, la chambre, le séjour, le tarif par nuit, l'acompte et les **Notes**. Les boutons changent selon le statut de la réservation (*Réservée, Arrivée enregistrée, Départ enregistré, Absent, Annulée*) :

- **Enregistrer l'arrivée** : choisissez la **Chambre**. Vous pouvez enregistrer l'arrivée même si la chambre n'est pas marquée propre (cochez l'option).
- **Modifier**, **Changer de chambre**, **Modifier le départ**.
- **+ Frais** ajoute un extra (minibar, blanchisserie, service) à la note du client. **Payer les frais dus** encaisse des frais d'annulation ou d'absence.
- **Enregistrer le départ** : clôture la note, encaisse et comptabilise la facture.
- **Absent** et **Annuler la réservation** appliquent la politique de frais réglée dans les paramètres de l'Hôtel ; la réception peut renoncer à tous les frais.
- Documents : **Imprimer la facture**, **Note (PDF)**, **Fiche de police**, **Confirmation**, **Confirmation par e-mail**.

### Notes séparées et facturation d'une entreprise

Un séjour a une seule note par défaut. **+ Diviser la note / facturer une entreprise** ajoute une autre note (par exemple *Extras*, *Entreprise*, *Conjoint*). Choisissez à qui chaque note est **Facturée à** : le client, une entreprise dont le crédit est activé, ou le groupe. Une entreprise doit d'abord être configurée pour le crédit sous **Clients**. **Nuitées ici** déplace les frais de chambre vers une note précise.

## Plan des réservations

Le **Planning des réservations** montre les chambres sur le côté et les jours en travers (deux semaines, avec les boutons « et » pour avancer). Les barres vertes sont les clients en séjour, les orange sont les réservations ; chaque barre va du jour d'arrivée jusqu'au jour de départ non compris. Les chambres hors service sont marquées. Utilisez-le pour voir les trous et déplacer les réservations.

## Ménage

**Ménage** liste les chambres avec leur statut : **Sale, Nettoyage en cours, Propre, Inspectée**, plus *Occupée*, *NPD* (ne pas déranger), *Vacante* et *Hors service*. Les femmes de chambre appuient sur **Commencer le nettoyage**, **Propre** ; un superviseur marque **Inspectées**. L'arrivée suppose une chambre propre. L'entretien ménager a aussi des tableaux pour les fournitures et pour les **objets trouvés**.

## Maintenance

**Maintenance** consigne les problèmes de chambre. Saisissez la **Chambre**, le **Problème** (par exemple *La climatisation ne refroidit pas*), la **Priorité** (*Basse, Normale, Haute, Urgente*) et des détails. Cochez **Mettre la chambre hors service jusqu'à la réparation** et réglez **Hors service à partir du** / **Remise en service le**. Avec des dates, seules ces nuits sont bloquées ; sans dates, la chambre est bloquée tout de suite jusqu'à ce que la demande soit **Terminé**. Si des réservations existantes tombent dans les dates bloquées, l'écran vous avertit ; déplacez ces clients ou changez les dates. Boutons : **Commencer**, **Terminé**, **Rouvrir**, **Supprimer**.

## Clients et registre des clients

- **Clients** liste les clients. Ouvrez un client pour voir **Séjours, Dépense totale, Moyenne par séjour, Dernier séjour, Réserve habituellement via**, et les **Pièces d'identité** (passeport, carte d'identité nationale, permis de conduire, visa ; téléversez des scans). Marquez un client **VIP** ou **Sur liste noire**.
- **Fusionner un doublon dans** combine deux fiches de la même personne : toutes les réservations, groupes, objets trouvés et pièces d'identité passent à l'autre fiche et la fiche fusionnée est supprimée. **Cela ne peut pas être annulé.**
- **Registre des clients** est le registre officiel des arrivées et départs, avec export, pour les autorités qui l'exigent.

## Chambres, types de chambre et tarifs (configuration)

- **Types de chambres** : nom et tarif par nuit (le prix standard).
- **Chambres** : numéro de chambre, type, étage et statut.
- **Tarifs** : les **Règles saisonnières** changent le prix d'un type de chambre pour une plage de dates et, facultativement, certains jours de la semaine (un prix fixe, une variation en pourcentage, ou un montant ajouté/retiré ; **Nuits min.** ; **Priorité** : la règle de priorité la plus haute l'emporte). Les **Formules tarifaires** donnent une remise en plus (pourcentage ou montant). Le **Calendrier des prix** montre le prix d'une nuit qui en résulte pour chaque jour. Les réservations existantes gardent leur prix.

## Comptes entreprises

**Comptes entreprises** liste les séjours facturés à une entreprise au départ : **Entreprise, Facturé, Reçu, Dû, En retard, Notes ouvertes**. Ouvrez une entreprise, **Afficher les notes**, et quand elle paie utilisez **Recevoir de l'argent** : **Montant, Mode, Référence** (numéro de chèque ou de virement), **Date**. Les notes en retard sont en surbrillance.

## Groupes

Pour les mariages, conférences et circuits. **Groupes > Nouveau** : **Nom du groupe**, **Arrivée**, **Départ**, **Personne à contacter**, téléphone, e-mail, **Qui paie** (*Chaque client paie sa propre note ; Le groupe paie les chambres, les clients paient les extras ; Le groupe paie tout*) et un client à facturer.

- **Blocs de chambres** : retirent des chambres de la vente générale (**Type de chambre, Chambres, Tarif de groupe / nuit, Du, Au**, et une date **Libérer les chambres non réservées le** ; les chambres non réservées retournent alors à la vente, ou **Libérer maintenant**).
- **Ajoutez des chambres** pour le groupe, puis **Liste d'hébergement** : collez les noms des clients, un par ligne, avec **Affecter les noms aux chambres**. Exportez la liste de répartition vers Excel, PDF ou CSV.
- **Relevé** montre ce que le groupe doit. **Confirmer**, **Terminer** ou **Annuler le groupe** (annule chaque chambre qui n'est pas arrivée ; vous pouvez renoncer aux frais d'annulation).

## Réservation en ligne

Si la page de réservation publique de l'hôtel est activée, les clients choisissent des types de chambre et des dates et réservent en ligne. Les réservations arrivent dans **Réservations** avec la source *Site web*. Un administrateur règle les textes et règles de la page sous **Réservation en ligne**.

## Audit de nuit

À l'**heure de l'audit de nuit** réglée dans les paramètres de l'Hôtel, le système comptabilise les frais de chambre de chaque nuit. Le rapport **Audit de nuit** vérifie les espèces, le revenu, la taxe, les acomptes, le compte clients et le compte groupes de l'hôtel avec la Comptabilité, et c'est le contrôle de fin de journée du responsable.

## Rapports

**Hôtel > Rapports** : le rapport **Quotidien** ; **Occupation** avec **Nuitées vendues, Nuitées disponibles, Revenu des chambres, PMC** (prix moyen par chambre louée) et **RevPAR** (revenu par chambre disponible) ; **Revenu par source de réservation** ; **Prévisions et réservations à venir** ; et l'**Audit de nuit**. Choisissez *7 derniers jours, 30 derniers jours* ou *Ce mois-ci*, ou saisissez des dates. Tous s'exportent vers Excel, PDF et CSV.
