# À propos de ce manuel et prise en main

## À qui s'adresse ce manuel

Voici le **Manuel utilisateur** de NIWE ERP. Il s'adresse à toutes les personnes qui utilisent le système au quotidien : caissiers, personnel de vente, magasiniers, comptables, responsables RH, personnel de réception et de rendez-vous, responsables et propriétaires. Il explique **ce que vous faites** dans chaque partie du système, pas à pas, avec les mots que vous voyez à l'écran.

Vous n'avez pas besoin de le lire du début à la fin. Lisez *Prise en main* (ce chapitre), puis le ou les chapitres de votre propre travail. La dernière page de chaque chapitre liste les **rapports** de ce module.

La configuration du système (utilisateurs, licences, imprimantes, sauvegardes) est traitée dans le **Manuel de l'administrateur**, distinct. Si vous êtes caissier, comptable ou magasinier, la **Fiche de démarrage rapide** d'une page pour votre rôle est le moyen le plus rapide de commencer.

> **Remarque :** Vous ne voyez que les parties du système que votre entreprise a activées et dont votre travail a besoin. Si un menu de ce manuel manque sur votre écran, votre entreprise n'utilise peut-être pas ce module, ou votre rôle ne l'inclut pas. Demandez à votre administrateur.

## Se connecter

1. Ouvrez l'adresse du système dans votre navigateur (Chrome ou Edge est recommandé). La page d'accueil affiche un bouton **Connexion du personnel** et, si votre entreprise les a activées, des tuiles pour des pages publiques comme les rendez-vous ou les demandes d'assistance.
2. Appuyez sur **Connexion du personnel** et saisissez votre **Nom d'utilisateur** et votre **Mot de passe**.
3. Après la connexion, vous arrivez sur l'écran qui convient à votre rôle : les caissiers sur la liste des caisses, les responsables sur le tableau de bord, etc.

Si vous oubliez votre mot de passe, appuyez sur **Mot de passe oublié ?** sur l'écran de connexion. Un lien est envoyé par e-mail à l'adresse de votre profil. Si votre profil n'a pas d'adresse e-mail, demandez à un administrateur de vous fixer un nouveau mot de passe.

> **Attention :** Ne partagez jamais votre mot de passe ni votre PIN. Tout ce que vous faites est enregistré à votre nom dans le journal d'audit.

## Votre profil

Ouvrez **Mon profil** depuis le menu pour :

- Changer votre **Nom complet** et votre **E-mail**. Votre e-mail est nécessaire pour utiliser *Mot de passe oublié ?*.
- **Changer le mot de passe** : saisissez votre **Mot de passe actuel**, un **Nouveau mot de passe** et **Confirmer le nouveau mot de passe**.
- **Changer le code PIN** : votre PIN (4 à 6 chiffres) vous identifie au terminal de vente et quand vous approuvez quelque chose en caisse. Il doit être différent du PIN de tout autre employé actif.

## Apparence

**Apparence** (sous vos paramètres) vous permet de choisir **Clair**, **Sombre** ou vos propres couleurs (un fond de page et une couleur d'accent). Le choix est enregistré pour votre compte et vous suit sur tous les appareils. Les tickets imprimés, les bons de commande et les rapports restent toujours blancs pour s'imprimer proprement.

## Langue

Utilisez le sélecteur de langue de la barre du haut (ou de la page de connexion) pour passer entre **English** et **Français**. Votre choix est conservé sur ce navigateur et l'emporte sur la valeur par défaut de l'entreprise. Si vous n'avez rien choisi, vous voyez la langue que votre entreprise a fixée (les entreprises du Tchad démarrent en français). Les écrans, messages et titres de rapports de chaque module sont traduits ; les documents imprimés (PDF), les e-mails et la plupart des messages du serveur sont écrits dans la langue de votre **entreprise** (Paramètres > Paramètres du système), pas dans la langue que vous avez choisie sur votre propre écran, afin qu'un client reçoive un document dans la langue de l'entreprise. Quelques messages qui portent un mot de statut peuvent encore afficher ce mot en anglais.

## L'installer comme application

Le système peut être installé sur un ordinateur ou un téléphone comme une application, pour démarrer depuis sa propre icône. Dans Chrome ou Edge, ou sur Android, une carte **Installer l'application** apparaît (appuyez sur **Plus tard** pour la masquer pendant deux semaines) ; sur un iPhone ou un iPad, utilisez le bouton Partager de Safari puis **Sur l'écran d'accueil**. L'application démarre plus vite et s'ouvre même sans connexion, avec une bande rouge **Vous êtes hors ligne**. Elle n'affiche jamais un ancien chiffre comme actuel : les ventes, le stock, les prix et les clients viennent toujours du serveur. (Une caisse continue à vendre et met ses ventes en file d'attente quand la connexion tombe ; voir le chapitre POS.) Une nouvelle version attend que vous appuyiez sur **Recharger** ; une caisse n'est jamais rechargée au milieu d'une vente. Le système installé demande que le site soit servi en **https**.

## S'orienter

- Le **menu de gauche** est regroupé par module (POS, Ventes, Clients, Stock, Comptabilité, etc.). Cliquez sur un groupe pour l'ouvrir. Sur un téléphone, ouvrez le menu avec le bouton de menu en haut.
- La plupart des listes ont en haut une **zone de recherche**, des **filtres** et des **vues rapides**, une pagination en bas, et des boutons d'export **Excel, PDF et CSV** qui exportent exactement ce qui est filtré à l'écran.
- La plupart des enregistrements suivent un parcours : *Brouillon* (vous pouvez encore le changer), puis confirmé ou émis, puis payé ou terminé. Les erreurs après cela se corrigent par une **annulation**, un **avoir** ou un **retour**, pas par une suppression, pour que les comptes restent honnêtes.
- Là où un bouton est grisé ou absent, soit vous n'avez pas la permission, soit l'enregistrement est dans un état qui ne le permet pas.

## Approbations (PIN d'un responsable)

Certaines actions demandent une seconde personne : une grosse remise, une annulation, un retour après de nombreux jours, un prix modifié à la main, un gros décaissement, une dépense au-dessus d'un plafond. Quand cela arrive, l'écran demande un **PIN du responsable**, ou dit qu'un approbateur est nécessaire. Un responsable saisit son propre PIN sur votre écran ; son nom est enregistré comme approbateur. Vous n'avez jamais besoin de connaître son PIN.

## Mes RH (pour chaque employé)

Si votre identifiant est lié à une fiche d'employé, **Mes RH** affiche vos **bulletins de paie**, votre **solde de congés**, vos **présences** et vos documents, et vous permet de **Pointer l'arrivée** et **Pointer le départ**, de **Demander un congé** (choisissez le type, les dates, si le premier ou le dernier jour est une demi-journée, et un motif), et de mettre à jour vos propres **coordonnées** (téléphone, e-mail, adresse, contact en cas d'urgence). Votre compte bancaire, votre numéro fiscal et les informations sur votre poste ne peuvent être modifiés que par les RH. Si vous voyez « Votre identifiant n'est pas lié à une fiche d'employé », demandez aux RH de le lier.

## Tableau de bord

Les responsables et comptables qui y ont accès voient le **Tableau de bord**, qui résume les ventes, le stock et les sommes dues, et comporte une section **À traiter** : factures en retard, stock bas, approbations en attente et éléments semblables qui demandent une action.

## Conseils valables partout

- **Tapez pour chercher** dans tout sélecteur (client, produit, fournisseur) au lieu de faire défiler.
- Les boutons **Exporter** donnent la même liste que celle que vous regardez, filtrée de la même façon.
- Les boutons **Imprimer** et **PDF** se trouvent sur les documents comme les factures, devis, bons de commande et relevés.
- **Pièces jointes** : de nombreux enregistrements permettent de joindre des fichiers ou des photos ; servez-vous-en comme preuve (un bon de livraison signé, la facture d'un fournisseur).
- Si quelque chose semble faux, ne supprimez pas pour ressaisir. Demandez à un responsable comment le corriger, et gardez le numéro de référence.
