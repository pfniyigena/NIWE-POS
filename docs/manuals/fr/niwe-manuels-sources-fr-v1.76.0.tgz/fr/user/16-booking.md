# Rendez-vous

Le groupe **Réservation** comprend : **Calendrier, Rendez-vous, Services, Salles et équipements, Horaires de travail, Rapports, Paramètres**. Il est destiné aux entreprises qui vendent des créneaux horaires : salons, cliniques, studios, terrains. Le personnel qui réalise les services voit sa propre liste sous **Mes rendez-vous**. Les clients peuvent aussi réserver seuls sur la page publique, si votre entreprise l'a activée.

## Configuration (responsable)

### Services

**Services > Nouveau** : **Nom**, **Description** (affichée sur la page publique), **Durée (minutes)**, **Battement après (minutes)** (temps de nettoyage ou de repos), **Prix**, **Paiement requis pour confirmer** (*Aucun : payer pendant la visite ; Un acompte ; Le prix complet*, avec **Acompte (% du prix)**), s'il **Demande une salle ou un équipement** d'un genre (par exemple Salle, Fauteuil, Terrain), une **Couleur dans le calendrier**, **Qui peut l'effectuer** (laissez vide pour n'importe qui), **Réservable** et **Afficher sur la page de réservation publique**.

### Salles et équipements

**Salles et équipements** : ajoutez une salle ou un équipement (Nom, Genre, Capacité, Notes) seulement si vos services en demandent un. **Période bloquée** empêche les réservations pour tout (un jour férié), une personne (congé) ou une salle (réparations) : choisissez *S'applique à*, les dates et un motif.

### Horaires de travail et congés

Par défaut, toute personne qui réalise un service peut être réservée pendant les heures d'ouverture de l'entreprise. **Horaires de travail** vous permet de donner à une personne ses propres jours et heures (à l'intérieur des heures d'ouverture) et d'ajouter des **Congés** pour les jours où elle est absente.

## Prendre un rendez-vous

**Calendrier > Nouveau rendez-vous** :

1. Choisissez le **Prestation**. Sa durée et son prix sont affichés.
2. Choisissez la **Date**, éventuellement **Préférer une personne** (*Quiconque est libre*), et choisissez une **Heure** parmi les créneaux libres. Si rien n'est libre, essayez un autre jour ou une autre personne.
3. **Personne** et **Salle / équipement** : *Affecter automatiquement* ou choisissez.
4. **Pour qui ?** Un client existant, ou un client de passage (nom, téléphone, e-mail pour la confirmation) et des notes.
5. Si le service demande un paiement pour confirmer, une **facture est émise** et le créneau est **retenu** le temps que le client paie. Cochez **Confirmer maintenant sans attendre le paiement** pour sauter cette étape.

## Le calendrier

Le **Calendrier de réservation** montre la journée heure par heure, **Par personne** ou **Par salle / équipement**, avec des compteurs pour *Aujourd'hui, 7 prochains jours, En attente de paiement* et *Absences ce mois-ci*. Les rendez-vous impayés et les absences sont marqués. **Imprimer la feuille du jour** donne une feuille pour la journée.

## Travailler avec un rendez-vous

Ouvrez un rendez-vous pour voir l'heure, la personne, un **Code**, combien de temps il est retenu, et les autres visites du client (une alerte s'affiche si le client a manqué des rendez-vous précédents). Actions :

- **Confirmer sans paiement**, **Marquer comme terminé**, **Absent**.
- **Déplacer à un autre horaire** : choisissez un créneau libre.
- **Annuler le rendez-vous** (motif facultatif). Une facture impayée de cette réservation est annulée ; l'argent déjà reçu reste sur la facture pour que vous le remboursiez ou le gardiez.
- **Paiement** : montre le prix et l'acompte, la **Facture**, ce qui est payé ; **Enregistrer le paiement** ou **Créer la facture**.
- **Rappel et calendrier** : **Envoyer le rappel maintenant** (e-mail avec un fichier de calendrier) ou **Télécharger le fichier de calendrier**. Un rappel est envoyé automatiquement avant la visite quand le réglage est activé. Les clients peuvent aussi déplacer eux-mêmes leur réservation en ligne.
- **Notes**.

## Rapports

**Réservation > Rapports** : Rendez-vous, Taux d'utilisation des réservations, Réservations par service.

## Paramètres (administrateur)

Heures d'ouverture, règles de réservation (au plus tôt, au plus loin à l'avance, retenue pour paiement, annulation en ligne), rappels, la page publique à `/book` et la manière de payer.
