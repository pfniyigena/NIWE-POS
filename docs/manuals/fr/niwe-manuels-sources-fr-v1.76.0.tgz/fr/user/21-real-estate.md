# Immobilier (ventes et courtage)

Le groupe **Immobilier** comprend : **Vue d'ensemble, Biens, Prospects, Mes relances, Visites, Transactions, Projets, Ventes d'unités, Recouvrements, Commissions, Rapports, Paramètres**. Il est destiné aux agents et promoteurs qui mettent des biens en annonce, travaillent avec des acheteurs et locataires, et vendent des unités dans des projets de construction.

## Le parcours de vente

**Bien** (une annonce) et **Prospect** (une personne intéressée) → **Visite** → **Transaction** (offre, réservation, accord, commission) → argent encaissé. Pour un promoteur : **Projet** → **Unités** → **Vente d'unité** → **Recouvrement**.

## Biens

**Biens > Nouveau bien** : type, adresse et zone, prix (vente ou location), surface et caractéristiques, description, **photos** (plusieurs ; l'une est l'image principale), coordonnées du propriétaire et **statut** (par exemple disponible, réservé, vendu). Ajoutez des **documents** comme les titres de propriété avec des dates d'expiration facultatives. Un bien peut avoir des **évaluations** enregistrées au fil du temps. Imprimez une **brochure avec photos** pour un bien.

## Prospects

**Prospects > Nouveau prospect** : coordonnées, ce qu'ils veulent (acheter, louer, budget, zone), la **source** et l'**agent**. Chaque prospect a un **journal** où les appels, visites et notes sont consignés.

### Mes relances

**Mes relances** est la liste quotidienne de l'agent : **en retard, à faire aujourd'hui, à venir, devenus silencieux** (un prospect est « silencieux » après le nombre de jours réglé dans les paramètres). Consignez un appel ou faites avancer le prospect ; fixez la **date de la prochaine relance**. Si c'est activé, chaque agent reçoit un **e-mail du matin** (vers 06 h 30) listant les appels en retard et dus et les prospects silencieux.

## Visites

**Visites** est l'agenda : planifiez la visite d'un bien pour un prospect, avec la date, l'heure et l'agent. Un **e-mail de rappel** part au client et une liste à l'agent avant la visite (nombre d'heures à l'avance réglé dans les paramètres) ; utilisez **Rappeler** pour en envoyer un à la main. Un **calendrier hebdomadaire** (du lundi au dimanche) montre l'agenda.

## Transactions

**Transactions > Nouvelle transaction** : choisissez le **bien** et le **prospect ou client**, le type (vente ou location), le prix convenu, les **parts de commission** entre agents (personnel ou extérieurs), et l'échéancier de paiement. Les étapes vont de l'offre à la finalisation en passant par la réservation et l'accord.

Documents imprimables pour une transaction : **offre, réservation, contrat de vente (avec l'échéancier de paiement), liste des paiements et reçu de paiement**. Le texte peut être remplacé dans les paramètres.

## Projets et ventes d'unités (promoteurs)

- **Projets** : un immeuble ou un programme avec ses **unités** (type, surface, prix). **Imprimez une liste de prix** pour un projet.
- **Ventes de lots** : vendez une unité à un acheteur avec un échéancier de paiement (**Ventes d'unités > Nouveau**). Imprimez le **contrat de vente, la liste des paiements et les reçus**.
- **Recouvrement** : liste les acheteurs qui doivent encore (**en retard, bientôt dus, sans échéancier**). Consignez les **appels, promesses de paiement et notes** sur chaque unité vendue, envoyez un **e-mail de rappel** à l'acheteur, et imprimez ou envoyez par e-mail un **relevé de l'acheteur**.

## Commissions

**Commissions** regroupe chaque part de commission par personne (personnel ou extérieur) avec son étape : **pas encore gagnée, gagnée, en attente d'approbation, approuvée pour paiement, payée, rejetée**. **Comptabiliser toutes les gagnées** envoie les commissions gagnées aux **Dépenses**, où elles sont approuvées et payées. Un **relevé PDF** par personne peut être envoyé par e-mail au personnel. Les ventes d'unités n'ont pas de parts de commission ; cet écran couvre les transactions.

## Importer

**Importer** sur les écrans **Prospects** et **Biens** charge des fichiers Excel ou CSV : téléchargez un modèle, choisissez un fichier, lisez le contrôle (rien n'est enregistré), puis importez. Chaque ligne ignorée est listée avec son numéro de ligne dans la feuille et son motif ; les doublons sont repérés.

## Rapports

**Immobilier > Rapports** (10) : annonces, prospects, visites, transactions, commissions, projets, liste de prix, ventes d'unités, évaluations et documents. Les listes ont aussi l'export Excel, PDF et CSV.

## Paramètres (administrateur)

Zones, durée des visites, jours de prospect silencieux, e-mail du matin aux agents, rappels de visite et texte standard des documents imprimés.
