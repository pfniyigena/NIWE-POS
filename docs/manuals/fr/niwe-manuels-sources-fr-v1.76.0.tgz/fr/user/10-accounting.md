# Comptabilité

La **Comptabilité** est le grand livre sur lequel tous les autres modules comptabilisent. Le groupe comprend : **Plan comptable, Centres de coûts, Écritures comptables, Contrôles, Produits, Rapports**, et, quand le module Dépenses est utilisé, les pages des Dépenses (chapitre suivant).

> **Remarque :** La plupart des écritures sont comptabilisées **automatiquement** : une vente comptabilise le chiffre d'affaires, la taxe et le coût du stock ; un achat comptabilise le stock et les dettes ; la paie, l'amortissement, l'audit de nuit de l'hôtel, etc., se comptabilisent seuls. Les écritures manuelles sont pour les exceptions. La configuration du plan comptable et des contrôles est décrite dans le Manuel de l'administrateur (chapitre 6).

## Plan comptable

**Comptabilité > Plan comptable** liste les comptes (Code, Nom, Description, Statut). Les comptes marqués *système* sont alimentés automatiquement et ne peuvent pas être désactivés.

**Nouveau compte** : **Code** (ne peut plus être changé ; par exemple 5300), **Nom** (Loyer), **Type** (*Actif, Passif, Capitaux propres, Produit, Charge*), **Description**, **Actif**. Appuyez sur **Grand livre** sur un compte pour voir chaque opération qui le touche entre deux dates, avec un **Solde** cumulé.

### Comptes utilisés par la Boutique en ligne

Quand la Boutique en ligne est utilisée, ces comptes apparaissent d'eux-mêmes dans le plan quelques secondes après le démarrage du programme (code du plan du Rwanda d'abord, code du plan du Tchad entre parenthèses). Ne les utilisez pour rien d'autre.

| Compte | Ce qu'il contient |
|---|---|
| Acomptes clients en ligne 2810 (4197) | L'argent que les clients ont payé en ligne pour des commandes pas encore livrées |
| MTN Mobile Money, compte d'attente 1021 (5215), Airtel Money, compte d'attente 1022 (5216), Carte, compte d'attente 1030 (5213), Mobile Money, compte d'attente 1020 (5212) | Ce que chaque fournisseur de paiement doit encore à la boutique jusqu'à son versement |
| Portefeuille MTN Mobile Money 1011 (5217), Portefeuille Airtel Money 1012 (5218), Banque, règlements par carte 1013 (5219) | L'endroit où arrivent les versements de chaque fournisseur |
| Espèces chez les livreurs 1050 (5214) | Les espèces que les livreurs ont prises à la porte et n'ont pas encore remises |
| Produits de livraison 4030 (7071) | Frais de livraison, hors taxe |
| Remises accordées sur ventes 4040 (7091) | Remises de coupons et de points de fidélité, hors taxe |
| Dette de points de fidélité 2820 (4198) | Ce que la boutique doit en points de fidélité |
| Frais des fournisseurs de paiement 5240 (631) | Frais que les fournisseurs retiennent sur les versements |

Les chapitres de la Boutique en ligne expliquent les écritures. Dans **Contrôles**, les fournisseurs de la boutique peuvent être rapprochés comme n'importe quel compte : comparez chaque compte d'attente et de portefeuille avec le relevé du fournisseur.

## Centres de coûts

Les **Centres de coûts** sont des étiquettes (service, agence, projet) que les lignes d'écriture, dépenses et produits peuvent porter, pour que vous puissiez établir les coûts par centre. **Nouveau centre de coûts** : Code, Nom. Utilisez *Inactif* pour en retirer un.

## Écritures comptables

**Écritures comptables > Nouvelle écriture manuelle** :

1. **Date** et **Libellé** (par exemple *Apport du propriétaire* ou *Loyer de mars*).
2. Pour chaque ligne, choisissez le **Compte**, une **Description**, un **Centre de coûts** facultatif, et un **Débit** ou un **Crédit**. **+ Ajouter une ligne** en ajoute d'autres.
3. **Les débits et les crédits doivent faire le même total** avant que vous puissiez enregistrer ; l'écran affiche les totaux.
4. **Enregistrer**.

La liste montre les écritures de tous les modules ainsi que les écritures manuelles ; ouvrez-en une pour voir ses lignes et son origine.

> **Attention :** Les écritures comptabilisées ne se modifient pas. Pour corriger une erreur, saisissez une écriture d'extourne ou annulez le document d'origine. Si les comptes sont clôturés jusqu'à une date, vous ne pouvez rien enregistrer à cette date ni avant.

## Produits (argent reçu qui n'est pas une vente)

**Produits > Nouveau produit** : **Date**, **Catégorie** (un compte de type produit ; ajoutez d'abord *Autres produits* au plan comptable si nécessaire), **Reçu de** (*Client, Fournisseur, Employé, Autre / ponctuel*), la personne ou le **Nom du payeur**, **Montant**, **Reçu immédiatement (en caisse)** (si décoché, il est comptabilisé comme de l'argent encore dû à la boutique), centre de coûts, agence et libellé facultatifs.

## Contrôles (comptable et administrateur)

**Comptabilité > Contrôles** a trois onglets :

- **Clôturer les comptes** : clôturez les comptes jusqu'à une date quand une période est définitive (par exemple une fois les comptes de mars approuvés). Plus rien de daté à ce jour ou avant ne peut alors être enregistré : factures, factures fournisseurs, dépenses, écritures, imports. L'annulation ou la correction fonctionne toujours parce qu'elle est enregistrée aujourd'hui. Saisissez la date et **Motif**. **Seul un administrateur peut clôturer ou rouvrir les comptes**, et chaque changement est consigné avec le motif et son auteur.
- **Rapprochement bancaire** : **Démarrer un rapprochement** en choisissant le compte, la **Date du relevé** et le **Solde final du relevé**. Cochez les lignes du grand livre qui figurent sur votre relevé bancaire ou de mobile money ; l'écran affiche **Solde du relevé, Pointé jusqu'ici, Différence**. Quand la différence est nulle, enregistrez et terminez. **Annuler** défait un rapprochement. Le système enregistre toutes les espèces, la banque et le mobile money dans un seul compte appelé *Caisse et banque* ; pour rapprocher une banque séparément, ajoutez-la comme compte d'actif et déplacez-y l'argent par une écriture.
- **Soldes d'ouverture** : saisissez les soldes des comptes quand vous démarrez en cours d'année.

## Rapports

**Comptabilité > Rapports** est un menu de rapports. Tous peuvent être exportés vers Excel et PDF.

| Groupe | Rapports |
|---|---|
| **Rapports comptables** | Rapport de taxe, Déclaration de taxe, Compte de résultat, Bilan, Pertes et profits, Opérations financières, Flux de trésorerie, Immobilisations |
| **Rapports de journaux** | Grand livre (avec solde d'ouverture et de clôture par compte), Balance et soldes nets, Balance, Soldes nets, Compte, Centres de coûts, Rapport des journaux, Répertoire du plan comptable |
| **Rapports des dépenses** | Dépenses par catégorie, par fournisseur, par employé, par client, Dépenses quotidiennes, hebdomadaires, mensuelles et annuelles |

Choisissez les dates **Du** et **Au**. Pour la **Balance**, cliquez sur une ligne pour voir les écritures qui la composent. Le **Bilan** et le **Compte de résultat** utilisent tout le grand livre jusqu'à la date de fin.

> **Conseil :** Chaque mois : passez en revue la balance, rapprochez la caisse et la banque, lancez le rapport de taxe, puis **Clôturer les comptes** jusqu'à la fin du mois.
