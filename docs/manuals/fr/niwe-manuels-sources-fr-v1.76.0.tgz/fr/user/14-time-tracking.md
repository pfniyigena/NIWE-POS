# Suivi du temps

Le groupe **Suivi du temps** comprend : **Projets, Approbations, Facturer le temps, Rapports, Paramètres**. Chaque personne qui saisit du temps utilise **Mon temps**.

## Le parcours d'un temps de travail

**Saisir** (chronomètre ou manuellement) → **Soumettre pour approbation** en fin de semaine → **Le responsable approuve** → **Facturer le temps** crée une facture en brouillon → émettre la facture.

## Saisir votre temps (tout le monde)

Ouvrez **Mon temps**. Le haut montre les heures d'**Aujourd'hui, Cette semaine, Ce mois-ci** et ce qu'il vous reste à soumettre.

**Avec le chronomètre** : choisissez le **Projet** (et la **Tâche**), écrivez *Sur quoi travaillez-vous ?* et appuyez sur **Démarrer**. Une fois fini, appuyez sur **Arrêter et enregistrer**, ou **Abandonner**. Un chronomètre laissé en marche est arrêté automatiquement après un nombre d'heures fixé par votre administrateur, et conservé en brouillon pour que vous le vérifiiez. Si vous avez oublié un chronomètre, arrêtez-le et corrigez le temps.

**À la main** : choisissez la **Date**, le **Projet**, la **Tâche**, saisissez le **Temps** (tapez 1:30, 1.5, 90m ou 2h), *Qu'avez-vous fait ?*, et cochez **Facturable** s'il est facturable. Les tarifs viennent du projet ; vous n'en saisissez aucun.

**Votre semaine** : utilisez **Semaine précédente / Semaine suivante** pour naviguer. **Copier la semaine dernière** répète les saisies de la semaine dernière. Modifiez ou supprimez une ligne tant qu'elle est en brouillon. Quand la semaine est complète, appuyez sur **Soumettre ... pour approbation**. Une saisie **Renvoyées** montre le motif du responsable : corrigez-la et soumettez de nouveau.

> **Remarque :** Votre administrateur peut verrouiller le temps jusqu'à une date (les semaines approuvées et facturées ne peuvent plus être changées), plafonner les heures par jour et envoyer par e-mail un rappel hebdomadaire aux personnes qui n'ont pas remis le temps de la semaine dernière.

## Projets (responsable)

**Projets > Nouveau** :

- **Nom**, **Code**, **Client (qui est facturé)**, **Statut** (*Actif : le temps peut être saisi ; Terminé : plus de nouveau temps ; Archivé : masqué*), **Description**.
- **Taux horaire** (ou utilisez celui par défaut), **Budget (heures)**, **Début** et **Fin**.
- **Le temps passé sur ce projet est facturable au client**, et **Refuser le temps qui dépasserait le budget** (demande un budget ; les responsables peuvent quand même corriger les saisies).
- **Équipe du projet** : seules les personnes listées peuvent saisir du temps sur le projet (les administrateurs le peuvent toujours).
- **Tâches** : découpage facultatif avec une **Estimation (h)** et les heures saisies jusqu'ici.
- **Tarifs par personne** : toute personne non listée est facturée au tarif du projet. Un tarif est fixé sur une saisie au moment où elle est soumise, de sorte qu'un changement ultérieur ne modifie pas le temps déjà remis.

La page du projet résume les **heures saisies, facturables, prêtes à facturer** et le **budget utilisé %**, et renvoie à la facturation.

## Approbations et temps de l'équipe (responsable)

**Approbations** montre :

- **Non soumis** : pour la semaine choisie, les personnes qui saisissent normalement du temps mais n'ont pas tout remis, avec **Rappeler** par personne ou **Envoyer un rappel à toutes les personnes listées**.
- **En attente d'approbation** : filtrez par statut (*Pas encore soumis, Approuvé, Renvoyé, Facturé*), personne et projet. Cochez des saisies et **Approuvez**, ou **Renvoyez** avec un motif. **Corriger** permet à un responsable de rectifier le temps ou la description avant d'approuver.

## Facturer le temps

**Facturer le temps** liste **Projet, Client, Heures facturables, Prêt à facturer**. Appuyez sur **Préparer la facture** pour un projet : choisissez la période et l'échéance. L'écran montre une ligne par personne et par tarif (Heures, Tarif, Montant). **Créer la facture en brouillon** crée un brouillon dans Ventes que vous pouvez encore modifier avant de l'émettre. La taxe suit le produit de service réglé dans les paramètres du Suivi du temps. **Annuler une facture de temps** libère le temps pour qu'il puisse être refacturé après la suppression d'un brouillon de facture ou l'annulation d'une facture émise.

## Rapports

**Suivi du temps > Rapports** : Synthèse des feuilles de temps, Heures du projet et budget, Temps non facturé, Taux d'utilisation, Saisies de temps.

## Paramètres (administrateur)

Interrupteur d'approbation, arrondi des chronomètres, tarif par défaut, limite d'heures par jour, arrêt du chronomètre oublié, verrouillage du temps, rappel hebdomadaire, % d'alerte de budget et produit de service (Manuel de l'administrateur, chapitre 7).
