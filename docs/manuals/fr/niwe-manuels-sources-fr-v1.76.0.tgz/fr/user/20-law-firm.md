# Cabinet d'avocats

Le groupe **Cabinet d'avocats** comprend : **Vue d'ensemble, Dossiers, Clients, Échéances et tâches, Facturation, Recouvrement des honoraires, Fonds des clients, Modèles, Rapports, Paramètres**. Les avocats ont aussi **Mon travail** (leurs propres échéances et tâches) et saisissent leurs heures dans **Mon temps**.

## Clients et dossiers

Un **dossier** est une affaire ou une mission. Un client apparaît sous **Clients** dès qu'un dossier est ouvert pour un client ; les clients sont des clients ordinaires, partagés avec les Ventes.

### Ouvrir un dossier

**Dossiers > Nouveau dossier** :

- **Titre** (par exemple *Mukamana c. Habimana, litige foncier*), **Client**, **Avocat responsable** (par défaut : vous).
- **Domaine de pratique**, **Juridiction**, **Tribunal ou instance**, **Numéro de l'affaire**, date d'**Ouvert**.
- **Mode de facturation** : *À l'heure, Forfait, Provision, Honoraires de résultat, Gratuit / aide juridictionnelle*, et une **Convention d'honoraires** en toutes lettres.
- **Description**.
- **Restreint : seuls l'équipe et les administrateurs peuvent ouvrir ce dossier**. Les dossiers restreints sont cachés à tous les autres, y compris dans les listes, rapports et recouvrements d'honoraires.

**Lancez la vérification de conflit à l'écran suivant avant de commencer le travail.** La **vérification des conflits** cherche parmi les clients, contacts et les parties adverses, avocats et témoins enregistrés sur les dossiers, et consigne la recherche. Enregistrez chaque **partie** sur le dossier (nom, rôle, téléphone, e-mail, pièce d'identité, note) pour que la vérification puisse les voir.

### Sur le dossier

La page du dossier a des onglets et des sections pour l'**équipe**, les **échéances**, les **tâches**, les **parties**, les **documents**, la **facturation**, les **fonds du client** et les **pièces**. Boutons de statut du dossier : **Mettre en attente, Reprendre, Clôturer le dossier** (saisissez l'**Issue**, comment il s'est terminé), **Rouvrir**, **Supprimer**. Un dossier qui détient encore des fonds de client ne peut pas être clôturé.

- **Échéances et tâches** : ajoutez les dates d'audience, de dépôt et de prescription pour que rien ne soit manqué : **Quoi, Type, Date, Heure, Affecté à**, notes. **Terminé**, **Rouvrir**, **Modifier**, **Supprimer**. Les tâches ont **Échéance, Affecté à, Priorité** (*Basse, Normale, Haute, Urgente*) et **Début**.
- **Pièces** : une page de garde du dossier, une lettre de mission et d'honoraires, et une lettre de clôture. Imprimez-les, gardez-les dans les documents du dossier, ou envoyez les deux lettres par e-mail au client.
- **Documents** : téléversez et conservez des fichiers sur le dossier ; un portail client peut partager des documents choisis.

## Échéances, tâches et calendrier

**Échéances et tâches** liste tout ce qui est dû, avec des filtres pour les miennes ou celles de tous. Le **Calendrier** montre des vues par mois et par semaine des échéances (les miennes ou celles de tous), avec les tâches et les éléments terminés à la demande, et un **fichier de calendrier (.ics)** que vous pouvez télécharger dans Outlook, Google Agenda ou un téléphone. Les avocats voient un **e-mail quotidien** des échéances et tâches bientôt dues ou en retard si votre administrateur l'a activé.

> **Attention :** Les **Dates de prescription** sont spéciales. En manquer une peut faire perdre l'affaire. L'avocat responsable et la personne affectée reçoivent des avertissements par e-mail à l'intervalle réglé dans les paramètres du Cabinet d'avocats (un premier avertissement, un second 3 jours avant, et un si la date est passée et que l'échéance est encore ouverte). **Marquez l'échéance comme terminée pour les arrêter.**

## Temps et facturation

- Les avocats saisissent leurs heures dans **Mon temps** et choisissent le dossier. Les heures sur les dossiers à l'heure et sur provision sont facturées ; sur les autres genres elles sont suivies mais pas facturées.
- Sur l'onglet **Facturation** d'un dossier : **Heures saisies, Temps approuvé à facturer, Frais à facturer, Étapes forfaitaires à facturer, Facturé (hors taxe), Provision restante**. **Conditions d'honoraires** montre et vous permet de changer le taux, le forfait, la provision ou le % d'honoraires de résultat. Les **Tarifs par personne** remplacent le tarif du dossier. Approuvez le temps en attente (**Approuver la sélection** ou **Renvoyer** avec un motif).
- **Frais avancés pour le client** (frais de justice et de dépôt, déplacements, coursier) : enregistrez la date, quoi, payé à, coût, **Facturer au client**, et éventuellement **Enregistrer aussi dans les Dépenses**. Les frais facturés vont sur la prochaine facture.
- Les **Étapes à forfait** sont facturées à mesure que chaque étape se termine.
- Créez la facture depuis le dossier ; **Ouvrir la facture** pour la vérifier et l'émettre. Le menu **Facturation** montre une vue d'ensemble de tous les dossiers, et **Facturation juridique et travaux en cours** est un rapport.

## Recouvrement des honoraires

**Recouvrement des honoraires** liste les factures émises impayées avec les jours de retard et un tableau de l'ancienneté. Vous pouvez **envoyer des e-mails de rappel** (un par client, avec le relevé d'honoraires en pièce jointe), produire un **relevé d'honoraires PDF** par client (et l'envoyer par e-mail), et exporter la liste. Les rappels automatiques peuvent être activés dans les paramètres.

## Fonds des clients (compte de tiers)

L'argent des clients appartient au client, pas au cabinet, et est conservé séparément. S'il est désactivé, un administrateur doit l'activer dans les paramètres du Cabinet d'avocats.

Sur l'onglet **Fonds clients** d'un dossier :

- **Recevoir de l'argent** : **Montant, Date de réception, Mode de paiement, Référence, Versé par, À quoi il sert**. Un **reçu** peut être imprimé. *Ne mettez jamais l'argent du cabinet ni ses honoraires dans le compte de tiers.*
- **Verser** : **Montant** (jamais plus que ce que le client a), **Date**, **Mode de paiement**, **Référence**, **Payé à**, **Objet**. L'argent ne part **qu'après l'approbation d'une autre personne** (l'avocat responsable du dossier ou un administrateur) : vous appuyez sur **Demander l'approbation**. Un **bon de paiement** peut être imprimé.
- **Payer une facture depuis le compte de tiers** : choisissez la facture et le montant ; elle est marquée payée et le solde du client baisse quand une autre personne approuve. Un **bon de transfert d'honoraires** est imprimé.
- **Relevé du client** : choisissez les dates, **Imprimer le relevé** ou **E-mail au client**.

**Fonds des clients > Vue d'ensemble** montre ce qui est détenu par client et par dossier et ce qui attend d'être versé. **Rapprocher** compare le compte de tiers avec le relevé bancaire ; une feuille imprimable existe pour tout rapprochement passé.

## Modèles

Les **Modèles** conservent des lettres et documents standard dont les champs sont remplis depuis le dossier.

## Importer des clients et des dossiers

Un administrateur ou un responsable peut **Importer des clients** et **Importer des dossiers** depuis Excel ou CSV : téléchargez le modèle, choisissez le fichier, **Vérifier** (rien n'est enregistré), puis **Importer**. Le temps, les échéances, les documents, les factures, les montants d'honoraires et les étapes ne sont pas importés ; réglez ensuite les honoraires sur le dossier.

## Rapports

**Cabinet d'avocats > Rapports** (13) : Dossiers, Échéances, Facturation et travaux en cours, Honoraires facturés, Fonds des clients détenus, Grand livre des fonds des clients, Charge de travail, Productivité des avocats, Rentabilité des dossiers, Factures impayées par ancienneté, Documents et portail client, Journal des vérifications de conflits, Charge de dossiers par domaine de pratique et tribunal. Les dossiers, clients, contacts, échéances, tâches, facturation, soldes et grand livre peuvent aussi être exportés depuis leurs propres listes (les dossiers restreints restent cachés aux personnes qui ne sont pas dans l'équipe).

## Paramètres (administrateur)

Domaines de pratique et juridictions, base de facturation par défaut, restreint par défaut, avertissements de prescription, rappels d'honoraires impayés et interrupteur des fonds des clients (Manuel de l'administrateur, chapitre 7).
