# Clients

Le groupe **Clients** comprend : **Relevé client, Paiements des clients, Recouvrement**. La liste des clients elle-même se trouve sous **Clients** (la liste des personnes et entreprises à qui vous vendez).

## Ajouter et modifier un client

**Clients > Nouveau** (ou le bouton **Ajouter** en caisse pour un client rapide). Champs :

- **Nom**, **Téléphone**, **E-mail**, **N° d'identification fiscale** (nécessaire pour les factures avec taxe aux entreprises).
- **Groupe de clients (liste de prix)** : *Aucun (prix normaux)* ou un groupe (voir le chapitre Ventes).
- **Autoriser ce client à acheter à crédit** : crédit client. **Seul un administrateur peut le modifier.** Quand il est activé, fixez la **Plafond de crédit** et le **Délai de paiement par défaut (jours)** ; laissez le délai vide pour aucune date d'échéance par défaut.

La page du client affiche **Crédit activé / Crédit désactivé** et les boutons **Modifier, Factures, Paiements, Relevé, Enregistrer un paiement**.

> **Remarque :** Les clients ne sont jamais supprimés s'ils ont un historique. Décochez ou désactivez plutôt. Pour fusionner des doublons, demandez à un administrateur.

## Ventes à crédit et limites

Un client dont le crédit est activé peut acheter sur compte en caisse ou sur une facture, jusqu'à la **Plafond de crédit**. Le terminal affiche **Doit ...** et le **crédit disponible** à côté du client. Une vente qui dépasserait la limite est refusée (les ventes hors ligne sont contrôlées à leur synchronisation).

## Enregistrer un paiement de client

Depuis la page du client, appuyez sur **Enregistrer le paiement**, ou depuis une facture utilisez **Enregistrer le paiement**.

1. Saisissez le **Montant du paiement** et le **Mode de paiement**.
2. Ajoutez éventuellement une **Note**.
3. Le paiement est appliqué d'abord aux éléments impayés les plus anciens du client, sauf si vous payez une facture précise.

**Clients > Paiements des clients** liste tous les paiements (Type, N° de reçu, Client, Date, Montant, Mode, Enregistré par, Note, Appliqué à), avec **Voir le détail**. Activez **Afficher les paiements de tous les clients** pour voir ceux de tout le monde.

## Relevé client

**Clients > Relevé client** : choisissez le **Client** et les dates **Du** et **Au**. Le relevé liste chaque facture (Facture, Date, Caisse, Caissier, Articles, Sous-total, Taxe, Total général, Paiement, Crédit, Date d'échéance, **Reste à payer**) avec les totaux. **Exporter en Excel** ou **Exporter en PDF**, ou envoyez-le par e-mail depuis Recouvrement.

## Recouvrement (qui vous doit de l'argent)

**Clients > Recouvrement** est l'écran quotidien du responsable du crédit.

- En haut : **Les clients doivent ...** au total et la part **en retard**, répartie par **Retard** : *Pas encore échu, 1 à 30 jours, 31 à 60 jours, 61 à 90 jours, Plus de 90 jours*. Cliquez sur un montant pour lister les éléments qui le composent.
- Trois onglets : **Par client**, **Éléments impayés**, **Relances envoyées**.
- Filtres : recherche par client, téléphone ou numéro ; **En retard seulement** ; **Toutes les agences**.
- **Envoyer un rappel** : cochez les clients à relancer et appuyez sur **Envoyer un rappel aux ... choisis**. Chaque client reçoit un e-mail listant tout ce qui est en retard, avec son relevé en pièce jointe. Ou utilisez les boutons **PDF** et **E-mail** sur une seule ligne.
- Des **rappels automatiques** peuvent être activés par l'administrateur.
- Les boutons **Exporter** donnent Excel, PDF et CSV.

Sont comptés ici : les factures émises et les ventes en caisse à crédit qui ne sont pas payées en totalité. Un élément sans date d'échéance échoit après le délai de paiement par défaut du client (ou immédiatement s'il n'y en a pas).

> **Attention :** L'e-mail doit être configuré (Manuel de l'administrateur, chapitre 9) pour que les rappels et les relevés soient envoyés. La page vous le dit s'il ne l'est pas.

## Rapports

Les rapports liés aux clients sont dans **Ventes > Rapports** : Ventes par client, Paiements des clients, Balance âgée des créances ; et dans **POS > Rapports** (Crédit) : Rapport des ventes à crédit, Rapport quotidien des encaissements de crédit, Rapport des crédits en cours, Rapport des crédits en retard.
