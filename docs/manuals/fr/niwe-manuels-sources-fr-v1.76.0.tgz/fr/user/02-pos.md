# POS : caisses, terminal de vente et postes

Le groupe **POS** (point de vente) est l'endroit où les caissiers vendent, comptent la caisse et traitent les retours. Son menu comprend : **Caisses et terminal, Postes, Annulations et retours, Mouvements de caisse, Paramètres du POS, Appareils, Rapports**.

## Comment se déroule une journée en caisse

1. Un responsable ou un administrateur **ouvre une session (un poste)** sur une caisse et l'affecte à un caissier, avec un **fond de caisse d'ouverture**.
2. Le caissier ouvre le **terminal** avec son **PIN** et enregistre les ventes. Les paiements se prennent à l'**Encaissement**.
3. Pendant le poste : espèces **entrées ou sorties**, **dépôts au coffre**, retours, et rapports X au besoin.
4. À la fin, le poste est **clôturé** : le tiroir est compté et l'écart est enregistré. Un **rapport Z** est imprimé.

Une **caisse** est le point de vente physique. Une **session** (ou **poste**) est une période de travail sur une caisse. Un poste peut avoir plusieurs **caissiers**, chacun avec son propre PIN et ses propres paniers.

## Ouvrir une session

Allez dans **POS > Caisses et terminal**. La liste montre pour chaque caisse le **Nom, Emplacement, Entrepôt, Fond, Caissiers, Appareil** et le **Statut** (*Désactivée*, *Session ouverte*, *Fermée*).

1. Appuyez sur **Ouvrir une session** sur la caisse.
2. Dans **Affecter à**, choisissez l'employé qui tiendra la caisse.
3. Saisissez le **Fond de caisse d'ouverture**. (Le maximum avec lequel la caisse peut s'ouvrir est affiché.)
4. Appuyez sur **Ouvrir la caisse**.

Si une caisse est liée à un PC, une note affiche *Fonctionne sur ... seulement* et *Aller au terminal* n'est disponible que sur ce PC.

## Ouvrir le terminal

Appuyez sur **Aller au terminal** sur la session ouverte. Le terminal demande d'abord votre **PIN** : saisissez-le et appuyez sur Entrée. Un PIN faux laisse l'écran du PIN affiché. Si vous n'avez pas de PIN, demandez à un administrateur d'en fixer un, ou fixez le vôtre dans **Mon profil**.

> **Remarque :** Votre PIN ouvre *votre propre* session de travail sur le poste. Un autre caissier peut utiliser le même terminal en appuyant sur **Changer de caissier** et en saisissant son PIN ; les paniers restent séparés.

## Vendre au terminal

### Ajouter des articles

- **Scannez un code-barres** dans la zone de code-barres (saisissez-le et appuyez sur Entrée), ou touchez une **tuile de produit**, ou **cherchez par nom ou référence**. Les tuiles de catégorie filtrent les tuiles de produits. « Affichage des 200 premiers résultats » signifie : saisissez davantage pour affiner la recherche.
- Chaque ligne montre **Article, Qté, Remise, Prix**. Utilisez le crayon pour changer la quantité, la corbeille pour supprimer une ligne. Pour les marchandises à numéro de série, le terminal demande le ou les **Numéros de série**. Les quantités peuvent être décimales quand le produit le permet (par exemple 2,5).
- Le panier montre le **Sous-total**, la **Taxe**, toute **Remise sur la vente** et le **Total**.

### Client

Utilisez la zone client pour **chercher par nom ou téléphone**, ou appuyez sur **Ajouter** pour en créer un sur-le-champ (nom, téléphone, e-mail, **N° d'identification fiscale**), qui est alors sélectionné pour cette vente. La zone indique si le client **Doit** de l'argent, son **crédit disponible**, ses **points de fidélité** et ce qu'ils valent.

### Remises

- **% de remise** accorde une remise sur la vente : choisissez **Pourcentage** ou **Montant**, saisissez-la et un **Motif**.
- Un caissier ne peut accorder une remise que jusqu'à la limite des paramètres du POS. Une remise plus grosse demande le PIN d'un responsable (la zone **PIN du responsable**). Un motif est demandé quand les paramètres du POS le disent.
- Les **Promotions** (comme achetez X obtenez Y) s'appliquent automatiquement et le panier affiche *Économisé avec les promotions*. Saisissez un **Code promo** et appuyez sur **Appliquer** pour les coupons.
- Si votre prix diffère du prix du produit, la ligne affiche *Prix modifié*. Un responsable peut devoir approuver, et les prix inférieurs au coût peuvent être refusés.

### Plusieurs paniers : mettre en attente et abandonner

- **+** démarre un autre onglet de panier. **Suspendre** met le panier de côté avec une note et en ouvre un nouveau. **Abandonner** annule net un panier ouvert (le stock n'est pas touché).

### Paiement (encaissement)

Appuyez sur **Paiement**. À l'**Encaissement**, choisissez comment le client paie. Touchez un mode de paiement pour saisir un montant ; vous pouvez **répartir le paiement entre plusieurs modes**.

- **Carte cadeau** : saisissez le **Code de la carte cadeau**, appuyez sur **Vérifier le solde**, puis **Utiliser pour cette vente**.
- **Points de fidélité** : affiche les points disponibles et ce qu'ils valent ; saisissez les **Points** et appuyez sur **Utiliser les points**. Les points ne peuvent être utilisés que lorsque le montant atteint le minimum.
- **Crédit client** (vente à crédit) : sélectionnez d'abord un client. Le client doit être autorisé au crédit (réglé sur la fiche client) et rester dans sa limite. Vous pouvez fixer une **Date d'échéance** ; sinon le délai de paiement propre au client est utilisé.
- **Mettre sur la chambre** (hôtels) : choisissez le client enregistré à l'hôtel et la **Chambre**.

Appuyez sur le bouton final pour terminer la vente. Le ticket s'imprime. La monnaie à rendre s'affiche pour les espèces.

### Tickets et réimpressions

**Reçus** montre les ventes terminées de ce poste (Heure, Facture, Client, Total, Paiement) avec **Voir / Réimprimer**. La première impression est l'original ; chaque impression suivante est marquée **COPIE 1, COPIE 2...** et est listée dans **Annulations et retours**.

### Cartes cadeaux en caisse

**Carte cadeau** vous permet de **Vérifier / ajouter de l'argent** (saisissez le code et appuyez sur **Vérifier**, voyez le solde et l'expiration, puis **Ajouter de l'argent**) ou de **Vendre une nouvelle carte** (montant, comment elle a été payée, pour qui), et vous donne le code à remettre.

### Afficheur client

**Afficheur client** ouvre une seconde fenêtre pour le client montrant le panier et le total, puis *Merci*. Faites-la glisser vers l'écran tourné vers le client.

### Mode hors ligne

Si la connexion tombe, le terminal affiche **Hors ligne** et continue de fonctionner avec le catalogue de la dernière synchronisation. Les ventes que vous enregistrez sont **mises en file d'attente** sur le PC (**File hors ligne**) et se synchronisent automatiquement au retour de la connexion. Les limites de crédit et certains contrôles ne s'appliquent qu'à la synchronisation de la vente ; une vente qui ne peut pas être acceptée apparaît comme *Échouée* dans la file pour examen, où vous pouvez l'**Abandonner** ou demander à un responsable.

> **Attention :** N'effacez pas les données du navigateur et ne fermez pas le navigateur tant que des ventes attendent dans la file hors ligne.

### Autres boutons du terminal

**Espèces** (contrôle de caisse), **Rapport X**, **Ouvrir le tiroir**, **Périphériques** (configuration de l'imprimante), **Changer de caissier**, **Terminer ma session** (termine *votre* session sur le poste et abandonne les paniers que vous n'avez jamais encaissés) et **Quitter**.

## Les espèces pendant le poste

Appuyez sur **Espèces** pour ouvrir l'écran du tiroir-caisse. Il montre le **Fond d'ouverture, Ventes en espèces, Remboursements en espèces, Entrées, Sorties, Déposé au coffre** et **Espèces qui devraient être dans le tiroir**.

- **Enregistrez** un mouvement : choisissez le type (*entrée*, *sortie*, *dépôt au coffre*), le **Montant** et **C'était pour quoi ?** Une sortie au-dessus de la limite demande le **PIN du responsable**. Si le tiroir contient plus que le niveau de rappel, on vous dit de déposer des espèces au coffre.
- **Compter le tiroir sans clôturer le poste** donne un contrôle ponctuel : rien ne bouge, et l'écart est conservé dans l'historique.
- Un mouvement erroné peut être **annulé** (un responsable peut être nécessaire). Les mouvements annulés restent visibles.

La page a aussi des boutons pour le **Rapport X** et le **Rapport Z**, et **Clôturer le poste**.

## Rapports X et Z

- **Rapport X** : un instantané du milieu de poste des ventes, paiements, retours et espèces. Lancez-le aussi souvent que vous voulez ; il ne change rien.
- **Rapport Z** : le rapport de clôture, numéroté. Il est imprimé quand le poste est clôturé.

Les deux s'impriment sur l'imprimante de tickets si l'une est configurée.

## Clôturer une session

1. Enregistrez toutes les espèces entrées, sorties ou déposées, **avant de compter**.
2. Ouvrez l'écran de clôture. Il montre le **Fond d'ouverture, Ventes en espèces, Remboursements en espèces, Entrées, Sorties, Déposé au coffre** et les **Espèces attendues dans le tiroir**, plus les **Ventes hors espèces (carte/mobile/banque)** et le **Total des ventes de cette session**.
3. **Comptez le tiroir** par billets et pièces (saisissez le nombre de chaque valeur, ou utilisez **+ Autre valeur**). Le système fait le total.
4. Si le comptage diffère des espèces attendues de plus que le montant autorisé, une note est exigée : **Pourquoi le comptage est-il faux ?**
5. Appuyez sur **Clôturer la session**, puis imprimez le **Rapport Z**.

Les administrateurs peuvent **Forcer la clôture** d'un poste ou **Fermer toutes les sessions** depuis **POS > Postes** si un caissier est parti sans clôturer.

## Annulations et retours

### Retourner des marchandises

Utilisez **Traiter un retour** : saisissez le **Numéro de facture** (par exemple le numéro du ticket) et appuyez sur **Trouver**. Choisissez les lignes et la **Qté retournée** (ou **Retourner tous les articles**), le **Mode de remboursement** et le **Motif**. Les retours de ventes anciennes (plus anciennes que la limite des paramètres du POS), ou les remboursements au-dessus d'une limite, demandent le **PIN du responsable**. Appuyez sur **Traiter le retour** ; un ticket de retour s'imprime.

### Annuler une vente

Une vente ne peut être annulée que tant que son poste est ouvert (ensuite c'est un retour). L'annulation demande la connexion ou le PIN d'un responsable, et en général un motif.

### Le journal

**POS > Annulations et retours** liste chaque annulation, retour, remise, changement de prix et réimpression de ticket : Quand, Quoi, Référence, Client, Caisse, Par, Montant, Motif et **Approuvé par**. Utilisez la zone de recherche et le filtre de caisse. C'est là que les responsables regardent quand une caisse est en déficit.

## Liste des postes (superviseurs)

**POS > Postes** liste les postes avec **Caisse, Z, Caissier, Ouvert, Clôturé, Statut, Ventes, Écart**, avec des filtres par caisse et par date, et des boutons **Espèces**, **Rapport X** et **Rapport Z**. Développez un poste pour voir ses **Caissiers** et ajouter ou terminer des sessions de caissiers.

## Liste des mouvements de caisse

**POS > Mouvements de caisse** liste chaque entrée, sortie et dépôt au coffre (Quand, Caisse, Quoi, Motif, Montant, Par, Approuvé par), y compris les mouvements annulés.

## Appareils

**POS > Appareils** configure l'imprimante de tickets, les imprimantes de cuisine et de bar, le tiroir-caisse et l'afficheur client **pour ce PC**. Les paramètres sont conservés dans le navigateur de ce PC. Votre administrateur le fait normalement une fois (voir le Manuel de l'administrateur, chapitre 8). Utilisez **Imprimer une page de test** et **Ouvrir le tiroir-caisse** pour vérifier.

## Rapports

**POS > Rapports** propose ces rapports, chacun avec des filtres et un export vers Excel, PDF et CSV :

- **Ventes et transactions** : Ventes totales des catégories POS, Ventes totales des marques POS, Ventes totales des produits POS, Ventes des postes POS, Transactions détaillées des postes POS.
- **Marge** : Marge des postes POS, Marge totale des catégories POS, Marge totale des marques POS, Marge totale des produits POS.
- **Opérations** : Ventes POS par caissier, Ventes POS par heure, Ventes POS par mode de paiement, **Exceptions POS** (annulations, retours, remises, changements de prix, réimpressions) et Comparaison des postes POS.
- **Crédit** : Rapport des ventes à crédit, Rapport quotidien des encaissements de crédit, Rapport des crédits en cours, Rapport des crédits en retard.

> **Conseil :** Les responsables devraient lire **Exceptions POS** et **Comparaison des postes POS** chaque semaine. Ils montrent par caissier les annulations, remises et écarts de caisse inhabituels.
