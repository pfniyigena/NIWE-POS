# Personnel de la boutique en ligne

*Répondre aux commandes, garder la boutique à jour, surveiller l'argent.*

## Chaque jour

- **Boutique en ligne > Commandes en ligne**, onglet **Nouveau** : **Accepter** (réserve le stock) ou **Rejeter** (donnez un motif). Une commande en livraison reçoit un **Livreur** ; puis **Marquer comme emballée**, **En cours de livraison** ou **Prête pour le retrait**. Le client reçoit un **Code de livraison** de 4 chiffres.
- **Terminer** en saisissant le code que le client vous lit. Le personnel ne voit jamais le code ; **Envoyer un nouveau code au client** s'il l'a perdu. Imprimez le **Bon de livraison** (une commande) ou la **Feuille de tournée** (la journée d'un livreur).
- **Livraison échouée** (choisissez un motif) quand personne n'était là ; le client choisit une nouvelle heure. **Le client ne garde qu'une partie** quand il ne prend qu'une partie des marchandises.
- **Remboursements à faire** : **Rembourser via le fournisseur**, ou remboursez à la main (toujours pour Airtel) et saisissez la référence avec **Je l'ai remboursé moi-même**.
- **Boutique en ligne > Paiements en ligne** : regardez *À vérifier* (argent qui demande une personne ; il n'est pas dans les comptes tant que vous ne l'avez pas traité), *Remboursements à faire* et *Bloqués en attente*.
- **Boutique en ligne > Messages** (formulaire de contact) et **Boutique en ligne > Clients en attente** (personnes à prévenir quand un produit revient) : répondez-leur.

## L'argent, chaque semaine

- **Boutique en ligne > Espèces des livreurs** : saisissez ce que chaque livreur a réellement remis, écrivez un motif pour tout écart, **Régler la sélection**. Cela doit correspondre au compte *Espèces chez les livreurs*.
- **Boutique en ligne > Paiements en ligne > Versements** : enregistrez chaque versement d'un fournisseur (brut, frais du fournisseur, date, référence du relevé du fournisseur).
- **Boutique en ligne > Rapports de ventes** : une vente compte le jour où la commande a été **terminée**.

## À la demande

- **Boutique en ligne > Retours** : **Approuver** (un livreur récupère les marchandises avec un code de retour) ou **Refuser** ; quand les marchandises sont revenues, appuyez sur **Articles reçus : remettre en stock et rembourser** (cochez les numéros de série revenus).
- **Boutique en ligne > Avis** : **Approuver** ou **Masquer** les nouveaux avis écrits ; **Retirer la note** pour une note injuste.

## Garder la boutique à jour

- **Paramètres de la boutique > Produits de la boutique** : titres, prix en ligne, page produit, et les cases **Mis en avant**, **Meilleure vente**, **Offre**, **Nouveau**.
- **Page d'accueil** : annonce, images de bannière, couleur, liens de pied de page. **Boutique en ligne > Pages de la boutique** : lisez et adaptez les pages Conditions, Confidentialité, Retours et Livraison.
- **Zones de livraison** (frais, taxe, jours), **Heures de livraison**, **Livreurs** (**Donner un lien** donne une page privée et un PIN).
- **Boutique en ligne > Paniers abandonnés**, **Boutique en ligne > Points de fidélité**, **Boutique en ligne > Codes promo**, **Boutique en ligne > Lettre d'information**, **Boutique en ligne > Envoyer une newsletter** (un test pour vous d'abord), **Boutique en ligne > Publicité**.

## « Il est écrit Épuisé »

- Sous le produit : *stock vendable − réservé − retenu par les commandes non traitées − tampon − part gardée pour la caisse = vendable maintenant*. Baissez le tampon, déplacez le stock vers un emplacement de vente, traitez les commandes de **Nouveau**, ou regardez les lots périmés.

> **Besoin de plus ?** Voir **Boutique en ligne** (chapitres 23 à 25) dans le Manuel utilisateur, ou demandez à votre administrateur.
