# Rendez-vous et accueil

*Rendez-vous et clients sans réservation.*

## Prendre un rendez-vous

- Réservation > **Nouveau rendez-vous** : service, date, personne souhaitée, un créneau libre, pour qui. Si un acompte est demandé, une facture bloque le créneau ; cochez **Confirmer maintenant** pour l'ignorer.

## La journée

- **Calendrier** par personne ou par salle ; **Imprimer la feuille du jour**.
- Lors de la visite : **Marquer comme terminé** ou **Absent**. **Déplacer à un autre horaire** ou **Annuler le rendez-vous** (la facture impayée est annulée).

## Rappels

- **Envoyer le rappel maintenant** ou **Télécharger le fichier de calendrier**. Des rappels automatiques partent avant la visite.
