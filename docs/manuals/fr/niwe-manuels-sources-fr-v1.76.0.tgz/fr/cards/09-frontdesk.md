# Réception d'hôtel

*Réserver, enregistrer l'arrivée, facturer, enregistrer le départ.*

## Début de journée

- **Hôtel > Réception** : arrivées, clients présents, départs, chambres à nettoyer, chambres hors service.

## Réservation

- **Nouvelle réservation** ou **Client sans réservation** : choisissez ou ajoutez le client, l'arrivée et le départ, le type de chambre et la chambre, le plan tarifaire, la source, l'acompte.

## Arrivée

- Ouvrez la réservation > **Enregistrer l'arrivée** > confirmez la chambre (elle doit être propre). Imprimez la **Fiche de police**.

## Pendant le séjour

- **+ Frais** pour les extras. **Changer de chambre**, **Modifier le départ**.
- **+ Diviser la note / facturer une entreprise** quand quelqu'un d'autre paie une partie.

## Départ

- Ouvrez la réservation > **Enregistrer le départ**, encaissez, **Imprimer la facture**.

## À retenir

- Les marques VIP et liste noire s'affichent sur la fiche du client. Les frais d'annulation, d'absence et de départ tardif suivent la politique de l'hôtel ; la réception peut les annuler.
