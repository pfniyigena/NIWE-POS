# Serveur de restaurant

*Prendre les commandes, les envoyer en cuisine, présenter l'addition.*

## Ouvrir une table

- Plan de salle > touchez une table libre > saisissez **Clients** > **Ouvrir la commande**. Notez les **Allergies**.

## Commander

- Touchez les plats du menu ; choisissez les options ; ajoutez une **Note pour la cuisine** ; réglez **Installer** et **Service**.
- **Envoyer en cuisine**. Les services suivants restent *en attente* jusqu'à **Lancer le service**.

## Modifications

- Une fois un article envoyé, le retirer demande un **Responsable** et un motif (**L'annuler**). **Offrir** demande un motif.
- **Déplacer la table…**, **Fusionner dans…**, **Diviser / déplacer des articles…** pour les convives qui paient séparément.

## Addition et paiement

- **Facture** imprime la pré-addition. **Encaissement** : ajoutez les paiements (partage égal, par article ou par parts), choisissez le **Pourboire**, ou **Mettre sur la chambre** pour les clients de l'hôtel. Rendez la monnaie affichée.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
