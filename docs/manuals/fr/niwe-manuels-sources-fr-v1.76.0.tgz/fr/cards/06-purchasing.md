# Responsable des achats

*Commander, suivre et payer les fournisseurs.*

## Commander

- **Demandes d'achat** pour demander, **Bons de commande > Nouveau** pour acheter : fournisseur, date prévue, entrepôt de réception, lignes avec coût unitaire.
- **Envoyer au fournisseur** par e-mail ou **Imprimer**.

## Recevoir et facturer

- Les livraisons partielles sont acceptées. Quand tout est reçu, une **Facture** est générée. **Émettre la facture**, puis **Enregistrer le paiement**.
- Mauvaise marchandise ? **Traiter un retour** sur la commande.

## Payer

- **Fournisseurs > Enregistrer le paiement** : montant, puis **Suggérer du plus ancien au plus récent** pour répartir. Imprimez le reçu.

## Prix

- **Prix fournisseurs** conserve les coûts convenus avec leurs dates de validité.

## Rapports

- Dettes en cours, Balance âgée des dettes, Achats par fournisseur ou par produit.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
