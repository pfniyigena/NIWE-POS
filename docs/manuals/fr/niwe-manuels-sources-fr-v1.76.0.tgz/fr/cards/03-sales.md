# Commercial

*Devis, commande, facture, encaissement.*

## Le parcours

- **Devis** (offre), puis **Commande client** (accord), puis livraison, puis **Facture**, puis **Enregistrer le paiement**. Vous pouvez commencer à n'importe quelle étape.

## Devis ou commande

- **Ventes > Devis** ou **Ventes > Commandes clients** > **Nouveau**. Choisissez le client (ou **+ Nouveau client**), ajoutez les produits par nom, référence ou code, vérifiez les totaux, **Enregistrer le brouillon**.
- Sur un devis : **Envoyer au client**, **Marquer comme accepté**, **Convertir en commande client**.
- Sur une commande : **Confirmer**, **Préparer la commande**, **Générer la facture**.

## Facture

- **Émettre la facture** la rend officielle. **Enregistrer le paiement** (les paiements partiels sont acceptés).
- Facture erronée ? Brouillon : modifiez ou supprimez. Émise : **Annuler la facture**, ou **Annuler et créditer la facture** s'il y a des paiements.

## Clients

- **Clients > Recouvrement** montre qui doit et depuis combien de temps ; cochez les clients et **Envoyer un rappel**.
- **Relevé client** pour tout client et toute période.

## Prix

- Les clients d'un **groupe de clients** reçoivent automatiquement la **liste de prix** du groupe. Un prix saisi à la main n'est jamais remplacé.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
