# Caissier

*Vendre, encaisser, compter la caisse.*

## Début de poste

- Votre superviseur ouvre la session sur votre caisse avec le fond de caisse (POS > Caisses et terminal > Ouvrir la session).
- Appuyez sur **Aller au terminal** et saisissez votre **PIN**.

## Vendre

- Scannez le code-barres ou touchez la tuile d'un produit. Cherchez par nom ou par référence si besoin.
- Choisissez ou ajoutez le **Client** si nécessaire (crédit, points de fidélité).
- Appuyez sur **Paiement**, choisissez le mode de paiement (en répartissant sur plusieurs si besoin), terminez la vente.
- Une remise au-dessus de votre limite, une annulation ou un prix modifié à la main demande le **PIN du responsable**.

## Retours et erreurs

- **Reçus** montre les ventes du poste avec **Voir / Réimprimer** (les réimpressions sont marquées COPIE).
- Un retour : **Traiter un retour**, saisissez le numéro de facture, choisissez les articles, le mode de remboursement et le motif.

## Espèces

- Appuyez sur **Espèces** pour les entrées, sorties et dépôts au coffre. Déposez des espèces au coffre quand le tiroir est trop plein.
- **Rapport X** à tout moment ; il ne modifie rien.

## Fin de poste

- Enregistrez d'abord les entrées, sorties et dépôts. Ouvrez l'écran de clôture, **Compter le tiroir** par billets et pièces, expliquez tout écart, **Clôturer la session**, imprimez le **Rapport Z**.

## Si la connexion tombe

- Continuez à vendre : les ventes sont mises en file d'attente et se synchronisent d'elles-mêmes. N'effacez pas le navigateur et ne le fermez pas tant que la file contient des ventes.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
