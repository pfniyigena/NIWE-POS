# Agent du support client

*Répondre vite, tenir les délais.*

## Démarrer

- **Assistance > Vue d'ensemble** : sans réponse, en retard, bientôt dus, les miens. Ouvrez d'abord **Nécessite une attention**.

## Traiter un ticket

- **Répondre au client** (envoyé par e-mail) ou ajoutez une **Note interne** ; **Insérer une réponse enregistrée…** pour les réponses courantes.
- En attente du client ? **Attendre le client** arrête le chronomètre du délai.
- **Résoudre** avec des notes ; **Fermer** ; **Rouvrir** si nécessaire.

## Rangement

- **Fusionner dans un autre ticket…** pour les doublons. Liez une **Facture** ou une **Intervention**. Ajoutez des **Étiquettes**. Ne cochez **Visible par le client** que sur les fichiers à partager.
