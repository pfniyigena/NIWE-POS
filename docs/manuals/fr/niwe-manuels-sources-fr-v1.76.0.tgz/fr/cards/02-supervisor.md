# Superviseur de poste et responsable

*Ouvrir et fermer les caisses, approuver les exceptions, surveiller les pertes.*

## Ouvrir et fermer

- **POS > Caisses et terminal > Ouvrir une session** : affectez le caissier, saisissez le fond de caisse.
- **POS > Postes** : voyez chaque poste avec son écart ; **Forcer la clôture** ou **Fermer toutes les sessions** si quelqu'un est parti sans clôturer.

## Approbations à la caisse

- Saisissez votre **PIN** sur l'écran du caissier pour approuver une grosse remise, une annulation, un ancien retour, un prix modifié ou une grosse sortie de caisse. Votre nom est enregistré comme approbateur.

## Contrôle quotidien

- **POS > Annulations et retours** : chaque annulation, retour, remise, changement de prix et réimpression, avec l'approbateur.
- **POS > Mouvements de caisse** et l'écart de chaque poste.
- Rapports : **Exceptions POS**, **Comparaison des postes POS**, **Ventes POS par caissier**.

## Responsables de restaurant

- **Fin de journée** : régler les commandes ouvertes, compter le tiroir, clôturer la journée (rapport Z).
- Journal **Annulations et offerts** ; confirmations de **Pertes**.

## À retenir

- Vous voyez la liste **À traiter** du tableau de bord : traitez les retards, les stocks bas et les approbations en attente.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
