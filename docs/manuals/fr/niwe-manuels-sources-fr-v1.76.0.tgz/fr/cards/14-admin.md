# Administrateur

*Configurer, sécuriser, sauvegarder.*

## Premier jour

- Changez le **mot de passe admin** et le secret JWT ; renseignez **Informations de l'entreprise**, **Paramètres du système**, **Taxes**, **Modes de paiement**.
- **Paramètres > Modules** : copiez l'identifiant d'installation, installez la licence, n'activez que les modules nécessaires.

## Les personnes

- **Employé > Rôles** pour les zones d'accès (Aucun / Consulter / Gérer). Sur chaque personne : rôle, permissions d'approbation supplémentaires, accès aux agences, **PIN**.

## Chaque semaine

- Vérifiez que la **sauvegarde** existe et téléchargez-en une hors du serveur. Examinez le **Journal des connexions** et le **Journal d'audit**. Regardez les **Journaux du serveur** si quelque chose a échoué.

## Pour une boutique en ligne

- Réglez `app.frontend-url` sur l'adresse publique en https. Activez chaque fournisseur de paiement avec ses propres clés dans l'environnement du serveur, jamais dans un fichier qu'on copie. Donnez à chaque fournisseur ses **comptes** (**Boutique en ligne > Paiements en ligne > Comptes par prestataire**).
- Donnez à chaque livreur un **Lien et code PIN** (**Paramètres de la boutique > Livreurs**). Ajoutez la règle du serveur web pour les aperçus de liens. Lisez et adaptez les pages Conditions et Confidentialité de la boutique.

## Avant une mise à jour

- **Sauvegarder maintenant**, téléchargez la sauvegarde, puis suivez les notes de version.

## À retenir

- L'activation d'un module est définitive. Restaurer une sauvegarde remplace tout et demande un redémarrage.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
