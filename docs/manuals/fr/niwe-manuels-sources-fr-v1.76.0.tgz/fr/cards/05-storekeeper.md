# Magasinier

*Savoir ce que l'on a et où c'est.*

## Réception

- **Achats > Bons de commande**, ouvrez la commande, **Enregistrer une réception** : quantités reçues, numéros de lot ou de série, **Frais d'approche**. Imprimez le bon de réception.
- Les marchandises arrivent dans l'emplacement **Réception** de l'entrepôt. Déplacez-les vers un emplacement de **Ventes** avec un transfert de stock.

## Corrections

- **Ajustements de stock > Nouveau** : produit, variation de quantité (+/-), motif. Elle reste *enregistrée* jusqu'à ce qu'un approbateur appuie sur **Confirmer**.
- **Inventaires** : **Démarrer un inventaire**, imprimez la fiche, saisissez les quantités comptées, **Soumettre pour approbation**.

## Réapprovisionnement

- **Inventaire > Réapprovisionner** liste ce qui est au niveau de réapprovisionnement ou en dessous. **Créer une demande d'achat** le transforme en demande d'achat.

## Si l'entreprise a une boutique en ligne

- La boutique ne vend que depuis les **emplacements de vente** hors de l'entrepôt principal. Le stock qui arrive reste dans *Réception* jusqu'à ce que vous le déplaciez vers un emplacement de vente. Les lots périmés ne sont jamais vendus.
- **Réapprovisionner** montre deux colonnes de plus : **Commandes en ligne** (unités retenues par des commandes non encore traitées) et **Clients en attente** (clients qui attendent le retour d'un produit).

## Déplacer du stock

- **Transferts de stock > Nouveau** : produit, emplacements de départ et d'arrivée, quantité. Entre agences, le destinataire appuie sur **Réceptionner** et note tout manquant.

## Retrouver une information

- Fiche produit > **Historique des mouvements de stock**. Rapports : Stock disponible et valorisation, Stock bientôt périmé, Stock dormant.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
