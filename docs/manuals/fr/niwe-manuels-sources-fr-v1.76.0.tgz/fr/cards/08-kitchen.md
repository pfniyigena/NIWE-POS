# Cuisine et bar

*Préparer, marquer prêt, refaire.*

## Écran de cuisine

- Les tickets passent par *en attente, en cuisson, prêt*. **Commencer la préparation**, **Marquer comme prêt**, **Marquer comme servi**, **Tout valider** pour une commande.
- Les tickets passent à l'orange puis au rouge quand le temps s'écoule. Les alertes **ALLERGIE** s'affichent en rouge.
- **Refaire** enregistre un plat refait (compté dans les rapports de pertes).

## Épuisé

- Appuyez sur **Épuisé (86)**, cherchez l'article, ajoutez un motif. Il disparaît du menu des serveurs jusqu'à ce qu'on le remette.

## Passe

- La passe : vérifiez qu'une commande est complète, **Tout marquer comme prêt** ou **Servir**.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
