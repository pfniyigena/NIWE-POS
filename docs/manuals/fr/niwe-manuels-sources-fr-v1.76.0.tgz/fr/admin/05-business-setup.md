# Configuration de l'entreprise

Ce chapitre couvre les paramètres communs que tous les modules utilisent. Tous se trouvent sous **Paramètres** sauf indication contraire.

## Informations de l'entreprise

**Paramètres > Informations de l'entreprise** contient le nom, l'adresse, le téléphone, l'e-mail et le **numéro d'identification fiscale** de l'entreprise, ainsi que son **logo**. Ils s'impriment sur les tickets, factures, devis, relevés et e-mails, et le nom de l'entreprise figure dans les demandes de modules envoyées à NIWE. Remplissez-les avant d'émettre le premier document.

## Paramètres du système

**Paramètres > Paramètres du système** (appuyez sur **Enregistrer** en bas ; *Paramètres du système enregistrés* le confirme) :

| Paramètre | Remarques |
|---|---|
| **Devise** | Choisissez la devise. Le **Symbole monétaire** se remplit à partir d'elle ; modifiez-le si vous préférez afficher un code (par exemple « UGX »). |
| **Langue de l'entreprise** | **English** ou **Français**. C'est la langue que tout le monde voit jusqu'à ce qu'il choisisse la sienne avec le sélecteur de langue de la barre du haut ou de la page de connexion. Elle est réglée pour vous quand vous choisissez le plan comptable du Tchad (Français) et reste English pour le Rwanda, mais seulement tant qu'elle n'a pas été changée. Depuis la version 1.26, elle décide aussi de la langue des documents imprimés (PDF), des e-mails que le système envoie et des messages renvoyés par le serveur, de sorte qu'un client reçoit une facture ou un rappel dans la langue de votre entreprise, quelle que soit la langue que la personne qui l'a envoyé utilise à l'écran. Un changement dans les Paramètres atteint les documents et les e-mails en quelques secondes. |
| **Fuseau horaire** | Utilisé pour les horaires des postes, les rapports planifiés et les tâches quotidiennes. |
| **Format de date** | La façon dont les dates s'affichent à l'écran et sur les documents. |
| **Remise max. (%)** | Le pourcentage de remise le plus élevé autorisé sur une ligne de vente, pour toute l'entreprise. Quelqu'un ayant la permission *Dépasser le plafond de remise de l'entreprise* peut le dépasser. |
| **Remise** | **Désactivée** : aucun champ de remise sur les devis, commandes clients, factures, bons de commande et factures fournisseurs. **Par ligne** : chaque ligne a sa propre remise. **Globale** : une remise pour tout le document. Un seul mode s'applique à la fois, pour toute l'entreprise. La remise propre au terminal POS est distincte et toujours disponible (sous réserve des règles de caisse du chapitre 8). |

> **Remarque :** Si vous choisissez le plan comptable du Rwanda ou du Tchad alors que la devise est encore la valeur par défaut intacte, la devise est réglée sur RWF ou XAF pour vous. De la même façon, la langue de l'entreprise devient **Français** pour le plan du Tchad tant qu'elle est encore la valeur par défaut English intacte.

## Taxes

**Paramètres > Taxes** liste vos taux de taxe (Code, Nom, Taux, Tarification, Statut). Appuyez sur **Nouveau taux de taxe** pour en ajouter un.

- La **Tarification** est soit *TTC* (le prix contient déjà la taxe) soit *Taxe ajoutée en sus*.
- Chaque produit choisit son propre taux de taxe, ou aucun pour les produits exonérés, dans **Inventaire > Produits**. Un nombre quelconque de taux peut être actif en même temps.
- Mettez un taux sur **Inactif** plutôt que de le supprimer quand il n'est plus utilisé ; les anciens documents le gardent.

## Modes de paiement

**Paramètres > Modes de paiement** liste les façons dont les clients paient (Ordre, Code, Nom, Équivalent espèces, Crédit client, Statut). Appuyez sur **Nouveau mode de paiement** pour en ajouter un.

- Cochez **Équivalent espèces** seulement pour les modes qui doivent compter comme *espèces dans le tiroir* lors du rapprochement d'une caisse. Tout le reste est traité comme non espèces à la clôture du poste.
- **Ordre** décide de la séquence des modes sur l'écran d'encaissement (le plus bas vient en premier). Réglez-le sur l'écran de modification.
- **Crédit client** marque un mode qui puise dans le solde de crédit d'un client.
- **Mise sur chambre** (« Mettre sur la chambre ») apparaît une fois le module Hôtel actif.
- Choix courants : Espèces, Carte, Mobile money, Virement bancaire, Chèque, Carte cadeau, Fidélité.

## Agences

**Inventaire > Agences** (ou la liste des Agences dans votre menu) liste vos agences. Une agence possède un ou plusieurs entrepôts ; les ventes, achats et dépenses sont étiquetés avec leur agence pour que vous puissiez faire des rapports par agence. Tout ce qui a été enregistré avant l'existence des agences appartient au **Siège** (marqué d'une étoile), qui ne peut pas être désactivé.

Appuyez sur **Nouvelle agence** et remplissez :

- **Code** (par exemple KLA), **Nom**, **Adresse**, **Téléphone**, **E-mail** facultatifs.
- **En-tête de ticket** (facultatif). Enregistré par agence.
- **Taxe et numérotation** (facultatif) : **Numéro fiscal / TIN**, **Code d'agence EFRIS**, **Préfixe des documents** (par exemple `KLA-`). Ils sont enregistrés pour chaque agence.
- **Actif**.

## Entrepôts et emplacements

**Inventaire > Entrepôts**. Un entrepôt est un lieu où le stock est conservé. Champs : **Nom**, **Adresse** facultative, l'**Agence** à laquelle il appartient (affichée quand vous avez plus d'une agence) et le **Seuil de stock bas**.

- **Seuil de stock bas** : un produit est signalé comme bas (sur le tableau de bord et dans le rapport de stock disponible), et un e-mail d'alerte est envoyé, quand le stock de cet entrepôt tombe sous ce nombre. Laissez vide pour utiliser la valeur par défaut de l'entreprise (fixée dans les paramètres du Stock).
- Votre entrepôt principal ne peut pas être désactivé.
- Un entrepôt peut avoir des **Emplacements** : étagères, casiers, une zone de réception. Chaque emplacement a un type qui pilote le comportement :

| Type | Rôle |
|---|---|
| **Réception** | Chaque achat ou réception arrive dans l'unique emplacement de Réception de l'entrepôt. |
| **Ventes** | Une vente ou un retour vise un emplacement de Ventes. Chaque entrepôt en a toujours au moins un actif. |
| **Stockage** | Une simple zone de conservation. |
| **Endommagé** | Le stock est suivi mais jamais compté comme vendable. |

Le type d'un emplacement ne peut pas être changé après sa création. Une caisse peut être épinglée à un emplacement de Ventes précis (chapitre 8), et les transferts de stock peuvent déplacer du stock directement entre deux emplacements quelconques.

## Applications (EFRIS)

**Paramètres > Applications** liste des intégrations comme la connexion EFRIS (administration fiscale) pour l'Ouganda, le Rwanda et le Tchad. Ouvrez une application et remplissez ses paramètres. Les ventes envoyées à EFRIS gardent leur propre code QR fiscal sur le ticket.
