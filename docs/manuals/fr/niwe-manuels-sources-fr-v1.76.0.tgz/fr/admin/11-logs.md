# Journaux et supervision

Le système garde trois traces de ce qui se passe. Elles répondent à des questions différentes.

| Trace | Question à laquelle elle répond | Où |
|---|---|---|
| **Journal d'audit** | Qui a changé quoi dans l'entreprise ? | Paramètres > Journal d'audit |
| **Journal des connexions** | Qui s'est connecté, et qui a échoué ? | Paramètres > Journal des connexions |
| **Journaux du serveur** | Que fait l'application elle-même, et pourquoi quelque chose a-t-il échoué ? | Paramètres > Journaux du serveur |

Les trois sont réservés à l'administrateur.

## Journal d'audit

Chaque action importante est enregistrée avec l'heure, l'utilisateur, un code d'action et une description. Exemples : annulations et retours, corrections de stock et leurs approbations, dérogations de prix et de remise, imports et exports, ouverture et clôture des postes, liaison d'une caisse, changements de rôles et d'employés, avertissements de budget du suivi du temps, et de nombreuses actions des modules.

Utilisez les filtres en haut : une **zone de recherche** (utilisateur ou description), une liste d'**actions** (*Toutes les actions*), des dates **Du** et **Au** et une taille de page (25, 50, 100, 200). Le tableau montre **Quand, Qui, Action, Ce qui s'est passé**.

Usages typiques : savoir qui a approuvé une remise, qui a annulé une vente, qui a changé un prix, qui a exporté la liste des clients.

## Journal des connexions

Chaque tentative de connexion est enregistrée, réussie ou non. Le haut de la page montre combien de personnes **se sont connectées au cours des dernières 24 heures**, combien de **tentatives ont échoué** et combien d'**adresses ont eu des échecs**. En dessous, filtrez par *Nom d'utilisateur*, par résultat (*Toutes les tentatives*, *Connecté*, *Échec*) et par dates. Colonnes : **Quand, Nom d'utilisateur, Résultat, Pourquoi, Adresse, Appareil**.

Surveillez les nombreux échecs depuis une même adresse ou pour un même nom d'utilisateur (signe que quelqu'un devine des mots de passe). Appuyez sur **Actualiser** pour mettre à jour.

## Journaux du serveur

Le serveur écrit des fichiers journaux tournants. Quand le backend tourne en jar, par exemple comme service, ils sont dans un dossier nommé **logs** à côté du jar (avant la version 1.26.2 ils étaient dans le dossier du jar lui-même). Quand il est lancé depuis un outil de développement sans jar, ils sont dans un dossier `logs` à l'endroit où il a été lancé. Le paramètre `app.logging.dir` (ou la variable d'environnement `APP_LOGGING_DIR`) peut les diriger vers un autre dossier, et il l'emporte alors.

Les fichiers sont :

- `niwe-erp.log` : le journal normal de l'application.
- `niwe-erp-error.log` : avertissements et erreurs seulement.
- `niwe-access.log` : une ligne par requête.

Chaque ligne porte un **identifiant de requête** et l'**utilisateur**. Le même identifiant de requête est renvoyé au navigateur dans l'en-tête `X-Request-Id`, de sorte qu'une personne du support peut rapprocher ce qu'un utilisateur a vu de la trace du serveur.

Dans **Paramètres > Journaux du serveur** :

- Choisissez un fichier, un niveau (*Tous les niveaux*, *Info et au-dessus*, *Avertissements et erreurs*, *Erreurs seulement*), saisissez un texte à chercher, et choisissez combien de lignes afficher (les 100, 300, 1000, 2000 dernières).
- **Actualisation automatique** continue de surveiller. **Télécharger le fichier** récupère tout le fichier (l'écran n'affiche que la dernière partie d'un gros fichier).
- Avant que le serveur ait écrit quoi que ce soit, la page dit *Aucun fichier journal pour l'instant*.
- Seuls les fichiers dont le nom commence par `niwe-` et se termine par `.log` apparaissent ici. Les autres fichiers du même dossier ne sont jamais affichés ni téléchargeables depuis l'écran.

Quand vous demandez de l'aide à NIWE, envoyez l'identifiant de requête et la partie utile de `niwe-erp-error.log`.

Le comportement des journaux est contrôlé par les propriétés `app.logging.*` dans les paramètres du backend (dossier, taille et nombre de fichiers à conserver). Le compte qui exécute le service doit avoir le droit d'écrire dans le dossier des journaux ; sinon, aucun fichier journal n'apparaît.

> **Conseil :** Après avoir installé le backend comme service, démarrez-le une fois, puis ouvrez **Paramètres > Journaux du serveur** pour confirmer que les fichiers apparaissent. Si la page dit *Aucun fichier journal pour l'instant*, vérifiez que le compte du service peut écrire dans le dossier du jar (il doit créer le dossier `logs`).

## Autres endroits où regarder

- Le **tableau de bord** a une section *À traiter* (factures en retard, stock bas, approbations en attente et semblables).
- **Paramètres > Modules** montre l'état de la licence et son échéance.
- La page **Vue d'ensemble** et la page **Rapports** de chaque module montrent sa santé de tous les jours.
