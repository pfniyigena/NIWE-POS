# Licence et modules

## Comment fonctionne la licence

Les modules qu'une entreprise peut utiliser sont décidés par un **fichier de licence** que NIWE signe pour cette seule installation. Un module n'est utilisable que s'il est **dans la licence** *et* qu'un administrateur l'a **activé**.

- Les **modules de base** sont toujours actifs : **Ventes, Achats et Comptabilité**.
- Les produits et le stock, les clients, les fournisseurs, le personnel et les paramètres sont communs à tous les modules et toujours disponibles.
- Tous les autres modules (par exemple Hôtel, Restaurant, Boutique en ligne, Paie, Immobilisations) doivent être dans la licence puis activés.

Le fichier de licence porte l'extension `.niwelic`. Il est signé avec une signature numérique (Ed25519) et vérifié à l'intérieur de l'application, donc il ne peut pas être modifié à la main. Il est vérifié hors ligne : aucune connexion internet n'est nécessaire.

## L'identifiant d'installation

Chaque installation reçoit un **identifiant d'installation** aléatoire la première fois qu'elle démarre. Il est conservé dans la base, donc il voyage avec les sauvegardes. Une licence est émise exactement pour cet identifiant et ne fonctionnera pas sur une autre installation.

Vous le trouvez dans **Paramètres > Modules**, dans la section *Licence*, à côté d'un bouton **Copier**.

## Obtenir et installer une licence

1. Ouvrez **Paramètres > Modules** et appuyez sur **Copier** à côté de l'identifiant d'installation.
2. Envoyez l'identifiant à NIWE avec la liste des modules achetés par l'entreprise.
3. NIWE renvoie un fichier `.niwelic`.
4. Dans **Paramètres > Modules**, téléversez le fichier. Le message *Licence installée* apparaît et la licence est listée sous *Licences installées* (numéro, date d'émission, date d'échéance, modules, qui l'a installée).
5. Activez les modules dont l'entreprise a besoin (section suivante).

L'écran montre à qui la licence est émise, son numéro, sa date d'émission et sa date d'échéance (ou *sans date d'échéance*).

## Activer les modules

Chaque carte de module dans **Paramètres > Modules** affiche un état :

| État à l'écran | Signification |
|---|---|
| **Base / Toujours actif** | Ventes, Achats, Comptabilité. Rien à faire. |
| **Dans votre licence** | Sous licence mais pas encore activé. Appuyez sur **Activer**. |
| **Actif** | En cours d'utilisation. Il ne peut plus être désactivé. |
| **Verrouillé (Demander)** | Pas dans votre licence. Vous pouvez appuyer sur **Demander**. |
| **Demandé** | Une demande a été envoyée ; elle attend NIWE. Vous pouvez **Retirer la demande**. |
| **Licence expirée** | Le module était dans une licence qui a expiré. |

> **Attention :** L'activation est définitive. Une fois qu'un module est activé, il ne peut plus être désactivé. N'activez que ce dont l'entreprise a vraiment besoin ; un module non activé est masqué dans tous les menus.

Certains modules fonctionnent ensemble. Quand vous en activez un, le système peut en activer un autre dont il dépend et vous le dit (« Également activé, car il fonctionne avec... »). Les cartes de module affichent les lignes *Fonctionne avec* et *Nécessaire à*.

Après avoir activé **Hôtel**, l'écran vous rappelle de le configurer dans cet ordre : d'abord les types de chambres (nom et tarif par nuit), puis les chambres, puis les paramètres de l'hôtel (mode comptable, taxe, horaires). Le mode de paiement *Mettre sur la chambre* devient alors disponible dans le POS et le Restaurant.

## Imprimer la liste des modules

Appuyez sur **Imprimer le PDF** en haut de **Paramètres > Modules** pour obtenir un PDF A4 de chaque module avec ce qu'il fait, les modules avec lesquels il fonctionne, et son état dans cette installation. Le haut de la page montre à qui la licence est émise, son numéro, sa date d'échéance et l'identifiant d'installation, suivis d'un décompte des modules de base, actifs, disponibles et verrouillés. C'est pratique pour l'envoyer à NIWE avec une demande, ou pour le garder avec les documents de l'entreprise.

## Demander un module que vous n'avez pas

Sur un module verrouillé, appuyez sur **Demander**, ajoutez éventuellement une note (pourquoi vous en avez besoin, combien d'utilisateurs, quand) et appuyez sur **Envoyer la demande**.

- Si l'e-mail est configuré (**Paramètres > Paramètres e-mail**) et que le paramètre `app.license.vendor-email` contient une adresse, la demande est envoyée par e-mail à NIWE avec l'identifiant d'installation et le nom de l'entreprise.
- Sinon l'écran affiche le texte pour que vous puissiez l'envoyer à la main.

> **Remarque :** Une demande ne déverrouille rien. Le module ne devient disponible que lorsque vous installez un nouveau fichier de licence qui le contient.

## Échéance

Une licence peut avoir une date d'échéance. Pendant les **30 derniers jours**, un administrateur voit un avertissement dans **Paramètres > Modules** (« La licence expire le ... (n jours). Demandez un renouvellement à NIWE à temps. »). Après la date :

- Les modules hors base se **verrouillent** ; Ventes, Achats et Comptabilité continuent de fonctionner.
- **Rien n'est supprimé.** Vos données restent intactes.
- Installer une licence renouvelée rétablit l'accès immédiatement.

## Ce que fait un module verrouillé

Il est grisé dans **Paramètres > Modules** et masqué dans les menus. Le serveur refuse les appels vers les données de ses propres écrans (HTTP 403, « X ne fait pas partie de votre licence »), ses pages publiques répondent « non disponible », et ses tâches du matin sont ignorées.

Les rapports, le tableau de bord, les produits, les clients, les factures et le stock sont communs et restent ouverts. Les rapports planifiés par e-mail ne sont pas arrêtés quand un module est verrouillé.

## Pour les développeurs seulement

Le paramètre `app.license.dev-all-modules=true`, avec le profil `dev`, fait que chaque module compte comme sous licence. Il est ignoré sauf si le profil `dev` est actif.

> **Attention :** Ne démarrez jamais l'installation d'un client avec le profil `dev`. Si l'écran affiche « L'interrupteur développeur est activé : chaque module compte comme sous licence », l'installation tourne en mode développement et doit être redémarrée normalement.
