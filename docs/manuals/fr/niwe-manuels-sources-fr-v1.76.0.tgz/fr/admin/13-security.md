# Liste de contrôle de sécurité

Parcourez cette liste avant que le système contienne de vraies données, et de nouveau une fois par an.

## Avant la mise en service

- [ ] **Changez le mot de passe admin** et supprimez ou désactivez le compte de démonstration `cashier` (ou changez son mot de passe et son PIN).
- [ ] Changez **tous les PIN de terminal** par rapport aux valeurs de démonstration (1234 et 5678).
- [ ] Fixez un long **`JWT_SECRET`** aléatoire (le paramètre `app.jwt.secret`). Quiconque le connaît peut falsifier une connexion.
- [ ] Réglez **`app.seed-demo-data=false`**.
- [ ] Utilisez votre propre utilisateur et mot de passe de base de données (`DB_USER`, `DB_PASSWORD`), ne les partagez jamais dans des fichiers que l'on copie, et n'exposez pas le port de la base au réseau.
- [ ] Servez le système en **https** (un certificat sur un proxy inverse ou un serveur web). C'est aussi nécessaire pour l'impression thermique directe sur les PC de caisse qui ne sont pas sur localhost.
- [ ] Réglez `app.cors.allowed-origins` sur votre vraie adresse seulement.
- [ ] Assurez-vous que le **profil `dev`** n'est jamais utilisé et que `app.license.dev-all-modules` est désactivé.
- [ ] Configurez les **Paramètres e-mail** pour que le personnel puisse utiliser *Mot de passe oublié ?*, et donnez une adresse e-mail à chaque personne.
- [ ] Confirmez qu'une sauvegarde nocturne existe et qu'une copie quitte le serveur.

## En continu

- Donnez à chaque personne son propre compte ; utilisez des rôles personnalisés et les permissions d'approbation plutôt que des administrateurs supplémentaires.
- Passez en revue les **Employés** chaque trimestre et décochez *Actif* pour les départs immédiatement.
- Passez en revue le **Journal des connexions** chaque semaine pour les échecs répétés.
- Passez en revue le **Journal d'audit** pour les annulations, retours, dérogations de prix et corrections de stock.
- Gardez à jour le système d'exploitation du serveur, Java, PostgreSQL et le navigateur.
- Restreignez qui peut accéder au serveur physiquement et à distance.
- Liez chaque caisse à son PC de caisse (chapitre 8) quand les caisses sont dans des espaces publics.
- Téléchargez une sauvegarde avant chaque mise à jour et gardez-en une hors site.

## Si vous ouvrez la Boutique en ligne à internet

La boutique publique est la seule partie de NIWE ERP destinée à des inconnus ; traitez donc le serveur comme exposé.

- Servez-la en **HTTPS uniquement** (un certificat sur le serveur web ou le répartiteur de charge) et gardez les écrans d'administration derrière la même adresse ou une adresse distincte que vous pouvez restreindre.
- Seuls `/shop`, `/shop/order/...` et les adresses `/api/public/...` sont censés être publics. Les écrans du personnel demandent toujours une connexion, et les appels serveur de la boutique ne renvoient jamais les coûts, les fournisseurs ni les autres clients.
- Réglez `server.forward-headers-strategy=native` quand un proxy est placé devant, pour que la limite par connexion fonctionne (chapitre 7).
- Gardez **Commandes en attente par téléphone** et **Commandes par connexion et par heure** bas, surveillez l'onglet **Nouvelles** des commandes, et téléphonez à un client avant de préparer une commande inhabituelle.
- Seuls `/shop`, `/shop/order/...`, `/shop/newsletter/...`, `/shop/cart/...` et les adresses `/api/public/...` sont publics. La connexion des clients utilise des codes à usage unique qui expirent et sont limités ; les avis, les inscriptions à la lettre d'information et les retours sont limités par connexion et par numéro de téléphone, et un champ caché attrape les robots simples.
- Paiements en ligne : gardez les clés du fournisseur de paiement dans l'environnement du serveur, jamais dans un fichier que l'on copie ou verse dans un dépôt, et n'utilisez les clés **de production** que sur le serveur de production. Un rappel de paiement n'est jamais cru tel quel : la boutique revérifie le paiement auprès du fournisseur.
- Les images de bannière sont vérifiées d'après leur contenu, pas leur nom, et réduites ; les liens du pied de page et de la bannière écrits par le personnel sont limités aux adresses `/`, `https://`, `http://`, `mailto:` et `tel:`.
- Les noms, numéros de téléphone, adresses, adresses e-mail de la lettre d'information et adresses e-mail conservées pour les rappels de panier abandonné sont des données personnelles : sauvegardez chaque jour, gardez les sauvegardes privées, et vérifiez ce que demandent les règles de protection des données de votre pays avant de lancer.
- **Liens privés des livreurs** : la page d'un livreur est protégée par un long secret dans le lien plus un PIN à 4 chiffres (cinq PIN faux la bloquent 30 minutes). Envoyez le lien et le PIN dans deux messages séparés, **Désactivez** le lien quand un livreur part, et faites un **Nouveau code PIN** si un téléphone est perdu. Le code de livraison n'est jamais montré au personnel ni aux livreurs.
- **Les clés des fournisseurs de paiement** appartiennent à chaque entreprise cliente et vivent dans l'environnement du serveur de ce client. Une clé qui a déjà été écrite dans un fichier versé dans un dépôt ou dans un e-mail est **compromise** : demandez-en une nouvelle au fournisseur. Utilisez les clés de test (sandbox) pour les tests seulement et les clés de production seulement sur le serveur de production.
- Réglez `app.frontend-url` sur la vraie adresse https pour que les liens des e-mails, les liens des livreurs et les aperçus de partage soient corrects.
- Faites tester le serveur par quelqu'un d'extérieur à l'équipe avant d'annoncer la boutique.

## Ce que le système fait pour vous

- Les mots de passe et les PIN sont conservés de façon sécurisée, pas en clair.
- La connexion utilise des jetons signés qui expirent ; chaque requête au serveur est vérifiée par rapport au rôle, aux zones et à l'accès aux agences de la personne, pas seulement masquée dans le menu.
- Les modules verrouillés sont refusés par le serveur, pas seulement masqués.
- La suppression est limitée : la plupart des enregistrements sont annulés, contrepassés ou désactivés, ce qui laisse une trace dans le journal d'audit.
