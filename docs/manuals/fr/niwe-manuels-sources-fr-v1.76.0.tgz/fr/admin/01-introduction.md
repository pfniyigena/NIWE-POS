# À propos de ce manuel

## À qui il s'adresse

Voici le **Manuel de l'administrateur** de NIWE ERP (le système NIWE POS/ERP). Il est écrit pour la personne qui installe, configure et surveille le système : le propriétaire de l'entreprise, le responsable informatique ou le responsable de bureau qui détient le compte **Admin**. Les instructions de tous les jours pour les caissiers, comptables, magasiniers et autres employés se trouvent dans le **Manuel utilisateur** distinct et dans les **Fiches de démarrage rapide par rôle**.

Vous n'avez pas besoin d'être programmeur pour suivre la plus grande partie de ce manuel. Les chapitres 2 et 12 (installation et mises à jour) sont techniques et s'adressent à la personne qui gère le serveur.

## Comment le manuel est organisé

| Chapitre | Ce qu'il couvre |
|---|---|
| 2. Installation et premier démarrage | Prérequis, base de données, démarrage du système, première connexion |
| 3. Licence et modules | Identifiant d'installation, fichier de licence, activation et demande de modules |
| 4. Utilisateurs, rôles et permissions | Comptes du personnel, rôles personnalisés, droits d'approbation par personne, accès aux agences |
| 5. Configuration de l'entreprise | Informations de l'entreprise, devise, taxes, modes de paiement, agences, entrepôts |
| 6. Configuration de la comptabilité | Plan comptable, centres de coûts, contrôles, soldes d'ouverture |
| 7. Paramètres des modules | Où chaque module garde ses propres paramètres |
| 8. Caisses, imprimantes et appareils | Impression thermique, tiroir-caisse, afficheur client, liaison d'une caisse à un PC |
| 9. E-mail, alertes et rapports planifiés | SMTP, alertes de l'entreprise, rapports planifiés, tâches quotidiennes de stock |
| 10. Sauvegarde, restauration, import et export | Sauvegarde nocturne, restauration, import en masse avec vérification préalable, archive de fin d'année |
| 11. Journaux et supervision | Journal d'audit, journal des connexions, journaux du serveur |
| 12. Mises à jour et migrations | Installer une nouvelle version, migrations de la base de données |
| 13. Liste de contrôle de sécurité | Ce qu'il faut changer avant la mise en service |
| 14. Dépannage | Problèmes courants et que faire |

## Conventions

- Les chemins de menu s'écrivent ainsi : **Paramètres > Modules**. Les mots sont exactement ceux qui apparaissent à l'écran.
- Les boutons et les champs sont écrits en **gras**.
- Les encadrés marqués *Remarque*, *Conseil* et *Attention* attirent l'attention sur ce qui compte. Une attention décrit quelque chose qu'on ne peut pas facilement défaire.

## Les nouveautés de cette édition

Cette édition couvre tout jusqu'à la **version 1.76.0**. Les principaux ajouts destinés aux administrateurs depuis la version 1.12 sont :

- **1.12** Impression thermique (Epson ESC/POS), tiroir-caisse et afficheur client COM.
- **1.13** Une caisse peut être liée à un appareil connu.
- **1.14** Journaux du serveur et journal des connexions ; davantage d'actions dans le journal d'audit ; la devise suit le plan comptable (RWF pour le Rwanda, XAF pour le Tchad).
- **1.15 à 1.22** Améliorations des Ordres de travail, du Suivi du temps, des Rendez-vous, des Paiements échelonnés, des Abonnements, du Support client, des Dépenses et des Immobilisations, avec de nouvelles permissions d'approbation (*Approuver les grosses dépenses*, *Approuver les grosses cessions d'immobilisations*) et de nouveaux rapports utilisables dans les rapports planifiés.
- **1.22.1 à 1.22.5** Corrections et durcissement : facturation des abonnements en fin de mois, administrateur du premier démarrage sur une vraie installation, aucun mot de passe ni secret conservé dans les fichiers livrés, journaux du serveur écrits à côté du jar, et un PDF imprimable de la liste des modules.
- **1.23** Le français. Chaque utilisateur peut passer de English à Français depuis la barre du haut ou la page de connexion, et l'entreprise a une langue par défaut (Paramètres > Paramètres du système) qui suit le plan comptable : le Tchad démarre en français, le Rwanda en anglais. Les écrans de base sont traduits : connexion, menus, tableau de bord, POS, Ventes, Achats, Stock, Clients, Comptabilité et Paramètres.
- **1.24** Le français pour les autres modules : Restaurant, Hôtel, Fabrication, Abonnements, Paiements échelonnés, Support client, RH et Paie, Suivi du temps, Ordres de travail, Rendez-vous, Cabinet d'avocats, Immobilier, Gestion locative, Immobilisations, Cartes cadeaux, Fidélité, Promotions, le portail client, Mon profil et la liste des factures. Une expression sans version française s'affiche en anglais. Demandez à un francophone de relire les formulations avant que les clients ne les utilisent.
- **1.25** Le français pour les messages écrits dans le code du programme (messages d'erreur, questions « Êtes-vous sûr ? », notifications), pour des listes comme les filtres de statut, les jours de la semaine et les noms de permissions, et pour les titres et les en-têtes de colonnes de chaque rapport. Une correction fait que les textes qui portent une valeur (par exemple « 3 jours restants ») s'affichent correctement en anglais. Les messages du serveur, les e-mails et les documents PDF imprimés étaient encore en anglais dans cette version.
- **1.26** Le français pour les textes écrits par le serveur : documents imprimés (factures, devis, tickets, relevés, bons de livraison et de réception, bulletins de paie, notes d'hôtel, courriers du cabinet d'avocats, contrats de paiements échelonnés, liste des modules, etc.), e-mails envoyés aux clients, locataires, propriétaires, hôtes, clients du cabinet et employés, et messages renvoyés par le serveur (par exemple « Client introuvable »). Ils suivent la **langue de l'entreprise** dans Paramètres > Paramètres du système, pas la langue qu'un utilisateur a choisie sur son propre écran. Les dates et les montants s'écrivent à la française (5 mars 2026, 1 234,50). Les entrées du journal d'audit et les noms déjà enregistrés dans la base restent tels qu'ils ont été écrits. Demandez à un francophone de relire les formulations avant que les clients ne les reçoivent.
- **1.26.1** Correction : « Failed to create backup directory ./backups » quand le serveur tourne comme service. Les sauvegardes vont désormais par défaut dans un dossier **backups** à côté du jar.
- **1.26.2** Les fichiers journaux vont dans un dossier nommé **logs** à côté du jar (au lieu du dossier du jar lui-même).
- **1.27.0** Nouveau module facultatif **Boutique en ligne** : une boutique publique à `/shop` où les clients commandent en livraison ou en retrait et paient en espèces. Voir *Paramètres de la Boutique en ligne* au chapitre 7 et les notes sur la partie publique au chapitre 13.
- **1.28 à 1.34** La Boutique en ligne s'enrichit : les commandes peuvent être **payées en ligne** (un fournisseur de test et MTN Mobile Money pour le Rwanda), les clients peuvent **se connecter** avec un code envoyé par e-mail, **coupons**, **SMS** (SMS ou WhatsApp, via un fournisseur qu'un développeur ajoute), et **retours et remboursements** des commandes terminées. E-mails de commande dans la langue du client, alertes pour les commandes sans réponse et photos redimensionnées.
- **1.35 et 1.36** La **page d'accueil** de la boutique a une barre d'annonce, un en-tête avec recherche, une bannière d'**images téléversées qui défilent**, quatre rangées de produits choisies par le personnel (les rangées défilent), des avis de clients (le personnel les approuve), une inscription à la lettre d'information avec confirmation par e-mail et un pied de page avec des liens ; nouveaux écrans **Avis** et **Lettre d'information** ; les chiffres **Vendable maintenant** sous chaque produit expliquent le stock que la boutique affiche. Voir *Paramètres de la Boutique en ligne* au chapitre 7.
- **1.37** Boutique en ligne : **Rapports de ventes** (par jour, commandes avec factures, modes de paiement, commandes non comptées comme ventes, coupons, meilleures ventes), comptés le jour où une commande est terminée et concordant avec les factures ; ils peuvent être envoyés par e-mail selon un calendrier. L'utilisateur doit avoir la zone Rapports ou la zone Opérations.
- **1.38** Boutique en ligne : **Envoyer une lettre d'information** depuis le programme (objet, texte, bouton facultatif ; tout le monde ou seulement les lecteurs anglophones ou francophones ; un e-mail de test d'abord ; envoyée par lots avec une limite quotidienne ; avancement, arrêt, nouvel essai des adresses échouées ; chaque e-mail a le lien de désinscription propre à la personne). Nouvelles tables par la migration V74.
- **1.39** Boutique en ligne : **rappels de panier abandonné** (e-mail après 1 heure et après 3 jours aux visiteurs qui ont saisi une adresse e-mail à la commande ; aucune remise ; un lien dans chaque e-mail les arrête ; **Boutique en ligne > Paniers abandonnés** les liste) ; désactivés tant qu'on ne les active pas dans les Paramètres de la boutique ; nouvelles tables (migration V75, exécutée d'elle-même au démarrage).
- **1.40** Boutique en ligne : **points de fidélité** pour les clients connectés de la boutique (gagnés quand une commande est terminée, dépensés à la commande comme remise ; rendus en cas d'annulation, ajustés lors des retours ; **Boutique en ligne > Points de fidélité** pour que le personnel les voie et les ajuste) ; désactivés tant qu'on ne les active pas dans les Paramètres de la boutique ; distincts du programme de fidélité de la caisse ; nouvelles tables (migration V76, exécutée d'elle-même au démarrage).
- **1.41 et 1.42** Boutique en ligne : **Airtel Money** comme deuxième fournisseur de paiement, et **plusieurs fournisseurs à la fois** : le client en choisit un à la commande. Les clés de chaque fournisseur ne vivent que dans l'environnement du serveur.
- **1.43** Boutique en ligne : **Publicité** (annonceurs, annonces à trois endroits de la boutique, rapport de vues et de clics). Migration V78.
- **1.44 à 1.48** Boutique en ligne : une **page produit** pour chaque produit, recherche et filtres, **notes (étoiles, immédiates) et avis (des mots, approuvés par le personnel)**, téléchargement de facture, carnet d'adresses, liste de souhaits, WhatsApp, rangées de produits qui défilent. Migrations V79 à V82.
- **1.49** Tout le site peut être **installé comme application** (PWA) ; rien du serveur n'est conservé hors ligne. Demande https.
- **1.50 à 1.51** Boutique en ligne : **variantes de produit** (taille, couleur, modèle) issues des variantes propres de l'ERP ; un **formulaire de contact** et quatre **pages d'information**. Migrations V84 à V86.
- **1.52 à 1.64** Livraison de la Boutique en ligne : **livreurs**, bons de livraison et feuilles de tournée ; le **code de livraison** ; la page du livreur avec **lien privé et PIN** ; remise des **espèces des livreurs** ; livraisons échouées et partielles ; **créneaux heures de livraison** ; **retours à récupérer** ; estimation de livraison et taxe par zone. Migrations V87 à V97. Une règle du serveur web est nécessaire pour les aperçus de liens (chapitre 7).
- **1.53 et 1.54** Aperçus de liens et moteurs de recherche (plan du site, robots.txt) ; **alertes de retour en stock**.
- **1.55** Le **portail** client (`/shop/account`).
- **1.65 à 1.69** Stock et prix de la Boutique en ligne : le **stock que la boutique vend** (emplacements de vente), stock **retenu dès la commande**, une marge pour chaque produit, libération automatique des commandes sans réponse, dates de péremption et numéros de série, cartons, réapprovisionnement avec la demande de la boutique, **prix et promotions des Ventes**, produits vendus au poids ou à la longueur. Migrations V98 à V101.
- **1.70 à 1.76** **Comptabilité** de la Boutique en ligne : les retours comptabilisent la TVA et le remboursement ; les paiements en ligne sont retenus et soldés par les **versements des fournisseurs** ; **Espèces chez les livreurs** ; **Remises accordées sur ventes**, **Produits de livraison** et **Dette de points de fidélité** ; retours au coût vendu ; une agence pour la boutique ; **un compte pour chaque fournisseur de paiement**, choisi à l'écran. Migrations V102 à V106. Les nouveaux comptes apparaissent d'eux-mêmes dans le plan comptable.

Pour une liste que peut lire un client, avec les étapes à suivre à chaque mise à jour, voir les **Notes de version et de mise à jour pour les clients**, document distinct.
