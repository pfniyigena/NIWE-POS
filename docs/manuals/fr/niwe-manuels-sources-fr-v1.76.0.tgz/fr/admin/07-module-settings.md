# Paramètres des modules

Chaque module qui demande des choix les garde sur sa propre page **Paramètres**, en bas du menu de ce module. Toutes ces pages sont **réservées à l'administrateur**. Ce chapitre les liste, dans l'ordre du menu, et explique les choix qui comptent. Appuyez sur **Enregistrer** sur chaque page ; la plupart affichent *Enregistré* une fois fait.

> **Conseil :** Configurez un module *avant* que le personnel commence à l'utiliser. Certains paramètres (par exemple les délais du Support client) ne s'appliquent qu'aux enregistrements créés après leur activation.

## Paramètres des Ventes (Ventes > Paramètres)

- **Fonctionnalités** : n'activez que ce que vous utilisez : **Promotions** (remises, achetez X obtenez Y, coupons), **Cartes cadeaux**, **Points de fidélité** (les règles de gain et de dépense se règlent sur la page Fidélité). Quand une fonctionnalité est désactivée, ses entrées de menu et ses éléments en caisse sont masqués et le serveur refuse de l'utiliser. Ce qui avait déjà été enregistré est conservé et fonctionne de nouveau quand vous la réactivez.
- **E-mails destinataires des factures** : une adresse par ligne. Chaque fois qu'une facture est émise, une copie PDF est envoyée par e-mail à l'adresse propre du client et à toutes les personnes de cette liste. Elle n'est envoyée que si l'e-mail est configuré (chapitre 9) ; un envoi échoué ne bloque ni n'annule jamais la facture.

## Paramètres du POS (POS > Paramètres du POS)

Les règles que la caisse fait respecter. Ce sont le principal contrôle contre les pertes au comptoir.

| Groupe | Paramètre |
|---|---|
| **Espèces en caisse** | Un écart de clôture jusqu'à un montant fixé est accepté sans commentaire ; un écart plus grand demande une note qui dit pourquoi. La clôture d'un poste demande que les billets et pièces soient comptés (option). Un décaissement du tiroir au-dessus d'un montant demande le PIN d'un responsable (0 = pas de limite). Rappeler au caissier de déposer des espèces au coffre quand le tiroir contient plus d'un montant (0 = pas de rappel). |
| **Annulations et retours** | Annuler une vente demande un responsable (sa connexion ou son PIN). Une vente ne peut être annulée que tant que son poste est ouvert (ensuite c'est un retour). Un retour demande un motif. Les retours de ventes plus anciennes qu'un certain nombre de jours demandent un responsable (0 = pas de limite). Un remboursement au-dessus d'un montant demande un responsable (0 = pas de limite). Les motifs proposés pour un retour (séparés par des virgules). |
| **Remises et prix en caisse** | Un caissier peut accorder seul une remise jusqu'à un pourcentage ; au-dessus, un responsable approuve (0 = toute remise demande un responsable). Une remise demande un motif. Un responsable peut changer un prix en caisse. Refuser un prix inférieur au coût de l'article. Les motifs proposés pour une remise. |
| **Tickets** | Papier : rouleau thermique de 80 mm ou 58 mm. Lignes supplémentaires sous les informations de l'entreprise (horaires d'ouverture, téléphone, mention de TVA). Texte au bas de chaque ticket. Imprimer le logo de l'entreprise. Imprimer un code QR du numéro de facture (les ventes envoyées à EFRIS gardent leur propre code QR). |

La première impression d'un ticket est l'original ; chaque impression suivante est marquée **COPIE 1, COPIE 2...** et listée dans **Annulations et retours**. « Un responsable » désigne un administrateur, ou une personne ayant les permissions *Approuver les annulations et retours / changements de prix / gros décaissements* du chapitre 4.

## Paramètres du Stock (Inventaire > Paramètres du stock)

- **Autoriser le stock négatif** (activé par défaut) : une vente ou une correction manuelle peut faire passer le stock sous zéro. Décochez pour que l'encaissement refuse une vente qui dépasserait le stock et que les Corrections de stock refusent une correction qui deviendrait négative.
- **Conditionnement et décomposition des produits** : permet de décomposer un produit en unités vendables plus petites (une bouteille en doses, un carton en bouteilles). Désactivé par défaut ; les règles de conditionnement peuvent être configurées mais une décomposition est refusée tant que cette option n'est pas activée.
- **Multi-entrepôts** : désactivé par défaut, l'entreprise reste sur un seul entrepôt (« Principal »). Quand il est activé, vous pouvez créer d'autres entrepôts, mais plus aucune vente ne peut se terminer sur Principal : chaque caisse doit être affectée à un autre entrepôt (**POS > Caisses et terminal**) avant de pouvoir encaisser une vente. Les achats arrivent toujours à l'emplacement par défaut de Principal.
- **Méthode de valorisation** : *Coût moyen pondéré* (recommandé), *Dernier coût d'achat*, ou *Manuel* (ne jamais changer le coût automatiquement). Les frais d'approche à la réception demandent le coût moyen pondéré ou le dernier coût d'achat.
- **Tâches quotidiennes de stock** : *Envoyer par e-mail un résumé quotidien du stock bas* (un e-mail par jour à l'adresse des notifications, rien les jours où rien n'est bas) ; *Préparer automatiquement des demandes d'achat* (chaque jour une demande BROUILLON pour les produits au niveau de réapprovisionnement ou en dessous ; elle ne soumet ni n'approuve jamais, et ignore les produits déjà sur une demande ouverte) ; *Exécuter à partir de* (heure de l'entreprise) ; et un bouton *Exécuter maintenant* qui utilise les paramètres enregistrés.
- **Emplacement de cuisine du restaurant** : d'où les commandes et les pertes du restaurant prennent leur stock (affiché quand l'entreprise a plus d'un emplacement).

## Paramètres des Dépenses (Dépenses > Paramètres)

- **Plafond d'approbation** : les dépenses au-dessus de ce montant ne peuvent être approuvées que par un administrateur ou quelqu'un ayant *Approuver les grosses dépenses*. 0 = pas de limite.
- **Personne n'approuve, ne rejette ni n'annule une dépense qu'il a lui-même saisie** (option).
- **Bloquer l'approbation quand elle dépasserait le budget mensuel** : un administrateur peut quand même approuver avec une dérogation, qui est écrite dans l'historique de la dépense.
- **Jours avant l'échéance d'une facture** (utilisé quand une facture impayée est saisie sans date d'échéance) et **Avertir ce nombre de jours avant l'échéance**.

## Paramètres des Immobilisations (Actifs > Paramètres)

- **Avertir avant la fin d'une garantie ou d'une assurance (jours)**.
- **« Bientôt totalement amorti » signifie dans les (mois)**.
- **Plafond d'approbation des cessions (valeur comptable)** : céder une immobilisation dont la valeur comptable dépasse ce plafond demande un administrateur ou un utilisateur ayant *Approuver les cessions d'immobilisations importantes*. 0 = pas de limite.

## Paramètres des Paiements échelonnés (Échéanciers > Paramètres)

- **Rappels par e-mail** : envoyer des rappels aux clients (demande l'e-mail), combien de jours avant une échéance, et à quelle fréquence relancer les échéances en retard.
- **Valeurs de départ d'un nouveau plan** : montants entiers (sans centimes) pour des devises comme RWF et XAF, intérêt annuel %, jours de grâce, pénalité de retard (fixe) et pénalité de retard (% de l'impayé).
- **Remboursement anticipé et défaut** : le pourcentage d'intérêts annulés lors d'un remboursement anticipé (modifiable pour chaque remboursement) ; marquer un plan en défaut après ce nombre de jours de retard (0 = jamais automatiquement).
- **Formulation du contrat** : une clause par ligne, imprimée sous « Conditions » sur le PDF du contrat. Laissez vide pour la formulation standard ; faites relire votre propre texte par un juriste.

## Paramètres des tâches d'Abonnements (Abonnements > Paramètres des tâches)

- **Exécuter à partir de (heure de l'entreprise)** : l'heure de la tâche quotidienne, selon le fuseau horaire des Paramètres du système. Si le serveur était éteint à ce moment-là, elle s'exécute à sa prochaine mise en marche le même jour.
- **Facturer automatiquement les abonnements à échéance** : chaque abonnement actif dont la prochaine date de facturation est arrivée reçoit sa facture. Désactivez pour ne facturer qu'à la main avec **Facturer maintenant**.
- **Envoyer par e-mail des rappels de prochaine facturation** : combien de jours avant, au client et/ou à l'e-mail des notifications.
- **Quand une facture reste impayée** : ne rien faire, suspendre l'abonnement, ou l'annuler après un nombre de jours depuis la date de la facture. La suspension peut être annulée avec **Reprendre** ; l'annulation, non.
- **Envoyer par e-mail un résumé quotidien des résultats** à l'e-mail des notifications (non envoyé les jours où rien ne s'est passé).
- **Rappels de retard et rattrapage** : envoyer un e-mail au client quand une facture d'abonnement est en retard (premier rappel après n jours, puis tous les n jours, au plus n rappels), et **Cycles de facturation manqués à facturer en une exécution** (1 = un par jour ; un nombre plus élevé rattrape tout de suite, chacun avec sa propre période).
- **Exécuter maintenant** utilise les paramètres enregistrés et compte comme l'exécution du jour.

## Paramètres du Support client (Assistance > Paramètres)

- **Site web public** : quand il est activé, n'importe qui peut envoyer une demande d'assistance et suivre un ticket à `/helpdesk` sur votre site sans se connecter ; des options permettent aux clients de répondre, de joindre des fichiers et de noter l'aide reçue. Désactivez-le pour fermer la page.
- **E-mails de notification** : une adresse par ligne ; elles reçoivent un e-mail pour chaque nouveau ticket, pour les réponses des clients à un ticket non affecté et pour les délais manqués.
- **Envoyer par e-mail chaque réponse au client** quand le ticket a une adresse e-mail.
- **Délais (SLA)** : donner à chaque nouveau ticket un délai de première réponse et un délai de résolution selon la priorité (Urgente, Haute, Moyenne, Basse), comptés en heures calendaires depuis la création ; le temps *d'attente du client* ne compte pas. Seuls les tickets créés après l'activation reçoivent des délais. Options : tickets internes aussi ; e-mail d'avertissement avant le délai et alerte quand il est manqué ; **Clore automatiquement un ticket résolu après (jours)**.

## Paramètres du Suivi du temps (Suivi du temps > Paramètres)

- Un responsable doit approuver le temps soumis (désactivez pour tout approuver automatiquement).
- **Arrondir les chronomètres arrêtés à** la minute exacte, 5, 6, 10, 15, 30 minutes ou 1 heure supérieure.
- **Taux horaire par défaut**, **maximum d'heures qu'une personne peut saisir par jour**, **heures de travail dans une journée** (pour le taux d'utilisation).
- **Garder les feuilles de temps en ordre** : arrêter un chronomètre qui tourne depuis plus de n heures (conservé comme brouillon pour que la personne le vérifie ; 0 = jamais) ; **Verrouiller le temps jusqu'à et y compris** une date pour que les semaines approuvées et facturées restent telles quelles ; un e-mail de rappel hebdomadaire aux personnes qui n'ont pas rendu le temps de la semaine passée ; un avertissement quand un projet a consommé n % de son budget (enregistré dans le journal d'audit).
- **Produit de service sous lequel le temps facturé est facturé** : le produit nommé « Services professionnels (temps) » peut être créé automatiquement ; son taux de taxe et sa comptabilisation suivent le produit.

## Paramètres des Rendez-vous (Réservation > Paramètres)

- **Horaires d'ouverture** : ouverture, fermeture, intervalle entre les heures de début, jours ouvrés.
- **Règles de réservation** : réservation au plus tôt (minutes à l'avance), au plus loin (jours), maintien en attente de paiement (minutes), annulation en ligne jusqu'à (heures avant).
- **Rappels et déplacement d'un rendez-vous** : envoyer au client un e-mail de rappel (avec un fichier de calendrier) n heures avant ; les clients peuvent déplacer eux-mêmes leur rendez-vous sur la page publique.
- **Site web public** : les clients choisissent eux-mêmes un service et une heure à `/book`. Aussi : e-mail de confirmation, nombre de rendez-vous par numéro de téléphone et par jour, titre de la page, texte d'introduction et façon de payer (affichée aux clients qui doivent un acompte).

## Paramètres des Ordres de travail (Ordres de travail)

- **Les nouvelles interventions pour des clients demandent l'approbation du client** : le travail ne peut pas commencer tant qu'un devis n'a pas été envoyé et approuvé (désactivable pour une seule intervention).
- **Envoyer un e-mail au client quand une intervention est terminée** : une note de fin (PDF) est envoyée. Si l'e-mail échoue, l'intervention est quand même terminée.

## Paramètres des Présences et congés (RH > Présences > Paramètres)

- **Temps de travail** : le travail commence à, délai de grâce (minutes), heures d'une journée normale, les heures supplémentaires sont payées (multiple du taux horaire normal), jours ouvrés. Pointer après l'heure de début plus le délai de grâce compte comme un retard.
- **Types de congés** : nom, jours par an, si les jours deviennent disponibles tous au début de l'année ou s'acquièrent mois par mois, report (jours max.), payé ou non payé, payé au départ.
- **Jours fériés** : ajoutez les jours fériés de chaque année ; ils ne comptent ni comme congés ni comme jours ouvrés.

## Paramètres de l'Hôtel (Hôtel > Paramètres)

- **Comment le revenu des chambres arrive en Comptabilité** : *Chaque nuit* (comptabilisé par l'audit de nuit ; le meilleur pour la plupart des hôtels), *Au départ*, ou *À la réservation et au départ* (la valeur réservée est conservée comme produit constaté d'avance jusqu'au départ). Le mode ne peut être changé que lorsqu'aucune réservation n'est ouverte.
- **Taxe sur les chambres et services (%)**, **heure d'arrivée**, **heure de départ**, **l'audit de nuit s'exécute à**.
- **Politique d'annulation et de frais** : annulation gratuite jusqu'à n jours avant l'arrivée ; frais d'annulation tardive, d'absence, de départ anticipé (en nuits) ; frais de départ tardif. La réception peut annuler n'importe quel frais. Voir aussi les paramètres de **Réservation en ligne** pour la page de réservation publique de l'hôtel.

## Paramètres du Restaurant (Restaurant > Paramètres)

Service par type de commande (sur place, à emporter, livraison) et TVA dessus ; le maximum qu'un serveur peut remiser sans responsable ; pourboires (pourcentages de choix rapide) ; notes rapides pour la cuisine ; temps de préparation habituel et seuils orange/rouge pour les tickets de cuisine ; arrondi de l'addition ; et réservations de tables depuis le site public à `/reserve`.

## Paramètres de la Boutique en ligne (Boutique en ligne > Paramètres de la boutique)

La Boutique en ligne demande que le module **Boutique en ligne** soit dans la licence et activé. Ses pages sont `/shop` (la boutique publique, aussi la première page du site pour un visiteur non connecté), `/shop/order/<code>` (où un client suit une commande), `/shop/account` (le compte du client), `/shop/info/...` (pages d'information), `/driver/<secret>` (la page privée d'un livreur) et quelques petites pages pour la lettre d'information et les paniers ; le personnel utilise le groupe **Boutique en ligne** du menu (**Commandes en ligne**, **Mes livraisons**, **Espèces des livreurs**, **Paiements en ligne**, **Retours**, **Coupons**, **Avis**, **Messages**, **Clients en attente**, **Pages de la boutique**, **Lettre d'information**, **Envoyer une lettre d'information**, **Paniers abandonnés**, **Points de fidélité**, **Publicité**, **Rapports de ventes**, **Messages texte**, **Paramètres de la boutique**). Tout démarre fermé : les pages publiques répondent « non disponible » tant que le module n'est pas activé et que **La boutique est ouverte au public** n'est pas coché. Le Manuel utilisateur (Boutique en ligne, chapitres 23 à 25) décrit les écrans pour le personnel de la boutique ; cette section s'adresse à la personne qui la configure.

Configurez, dans cet ordre :

1. **Produits de la boutique** : seuls les produits ajoutés ici sont affichés ou vendus. L'image est celle du produit ; le prix est le prix en ligne s'il est fixé, sinon la liste de prix de la boutique et la meilleure promotion, sinon le prix normal. Les prix sont affichés taxes comprises. Les cases **À la une**, **Meilleure vente**, **Offre** et **Nouveau** choisissent les produits des rangées de la page d'accueil. Les produits avec variantes apparaissent comme un seul produit avec des options.
2. **Zones de livraison** avec des frais, une commande minimale facultative, une taxe (comprise dans les frais) et une estimation en jours chacune. Sans zone, la boutique livre partout gratuitement.
3. **Produit de service pour les frais de livraison** : un produit de *service* (sans stock) qui porte les frais de livraison sur la commande client et la facture. Sans lui, une commande qui a des frais de livraison ne peut pas être acceptée. Donnez-lui une taxe **comprise**, ou aucune, et choisissez la taxe propre à chaque zone, pour que le total de la facture, et les espèces qu'un livreur doit remettre, correspondent à ce que le client a vu.
4. Les interrupteurs et limites de la boutique : **Livraison**, **Retrait**, **Payer en espèces à la livraison ou au retrait**, **Commande minimale**, **Livraison gratuite à partir de**, **Commandes en attente par téléphone** et **Commandes par connexion et par heure**. **Envoyer les e-mails de nouvelle commande à** et **Alerter par e-mail quand une commande attend ce nombre de minutes** disent à la boutique qui prévenir. **Numéro WhatsApp de la boutique** et l'**E-mail de contact** apparaissent sur la page de contact.
5. **Page d'accueil** : l'annonce, les textes et images de bannière, la couleur de la boutique, le texte et les liens du pied de page (voir le Manuel utilisateur). Les images de bannière sont conservées dans la base : jusqu'à 8, donc une sauvegarde est un peu plus grosse.
6. **Pages de la boutique** : lisez et adaptez les quatre pages d'information (Conditions, Confidentialité, Retours, Livraison). Ce sont des textes de départ, pas un conseil juridique.
7. **Agence pour laquelle la boutique vend** (seulement avec plus d'une agence).
8. **Livreurs** et **Heures de livraison**, si la boutique livre.
9. **Comptes par fournisseur** (Boutique en ligne > Paiements en ligne), une fois les fournisseurs activés.

### Le stock que vend la boutique

La boutique n'a pas de stock propre. Elle vend ce que les entrepôts détiennent dans des **emplacements vendables** (avec plusieurs entrepôts : les emplacements de Ventes hors de l'entrepôt Principal ; choisissez-en un dans **Stock d'où vend la boutique**, ou *Automatique*), moins les quantités réservées sur les commandes clients confirmées, moins les unités **retenues** par les commandes de la boutique auxquelles personne n'a encore répondu, moins la **marge** du produit, moins la **Part gardée pour la caisse (%)**. Les lots périmés ne sont jamais comptés et, avec **Ne pas vendre les marchandises dont il reste moins de jours que**, les lots proches de leur péremption sont écartés. Les cartons qui peuvent être ouverts (décomposition activée dans le Stock) comptent comme des unités. Sous chaque produit dans **Produits de la boutique**, l'écran montre chaque chiffre. Si des produits indiquent *Épuisé* alors que vous avez du stock, voir *La boutique en ligne* au chapitre 14.

- **Libérer les commandes sans réponse après (heures)** (24 par défaut, 0 = jamais) annule une commande en attente d'un paiement, ou une commande en espèces que personne n'a acceptée, pour que son stock soit de nouveau libre. Une commande payée en ligne n'est jamais annulée de cette façon. Une tâche vérifie toutes les 10 minutes.
- **Liste de prix utilisée par la boutique** et **Appliquer maintenant** : prix en ligne issus des Ventes (les promotions qui demandent un coupon, un groupe, une limite, un minimum, « achetez X obtenez Y » ou qui couvrent tout le panier ne sont pas appliquées en ligne). Les prix sont recalculés toutes les 2 minutes.
- Un produit peut être **vendu au poids ou à la longueur** (décimales de 0,1 à 100).

Accepter une commande crée une commande client confirmée pour le client (retrouvé par numéro de téléphone, ou créé), qui retient le stock. La terminer prépare la commande client depuis l'emplacement de Ventes de la boutique (ou celui choisi), émet la facture et enregistre le paiement : espèces pour une commande en espèces, ou le paiement en ligne déjà reçu. Le personnel a besoin de la zone **Opérations** pour répondre aux commandes. Si la fin d'une commande est refusée, par exemple faute de stock, le personnel voit la vraie raison ; les livreurs et les clients voient « appelez la boutique » et la raison est dans l'historique de la commande.

### Comptes clients

Cochez **Les clients peuvent se connecter pour voir leurs commandes**. Un client saisit une adresse e-mail et reçoit un code à usage unique (valable 10 minutes, 5 essais) ; il n'y a pas de mots de passe. Cela demande les **paramètres e-mail** de l'entreprise (chapitre 9), ou les SMS pour un code envoyé à un numéro de téléphone enregistré.

### Heures de livraison et livreurs

Les **Heures de livraison** sont désactivées tant que vous n'ajoutez pas des créneaux (de et à, commandes par jour, jours de la semaine), les interrupteurs (les clients choisissent une heure ; ils doivent en choisir une ; jours à l'avance ; préavis en heures) et les jours sans livraison. Un créneau de livraison est revérifié sur le serveur quand la commande est passée.

**Livreurs** : un livreur est une entrée de liste (nom, téléphone, note, actif). **Donner un lien** fabrique pour lui une adresse privée et un PIN à 4 chiffres (le PIN est affiché une fois et conservé brouillé) ; **Afficher le lien**, **Nouveau code PIN** et **Désactiver** le gèrent. Pour que le lien soit complet, **`app.frontend-url`** doit être l'adresse publique, et le site doit être servi en **HTTPS**. Cinq PIN faux bloquent le lien 30 minutes ; le téléphone garde une session jusqu'à 14 heures. Un livreur ne voit que ses propres commandes et retours et ses propres espèces. Le code qui termine une livraison (4 chiffres) est envoyé au client par e-mail et SMS et n'est jamais montré au personnel ni aux livreurs ; cinq essais faux le bloquent 30 minutes.

### Paiements en ligne

Dans **Paiements en ligne**, cochez chaque **fournisseur** que vous voulez proposer, cochez **Les clients peuvent payer en ligne**, et réglez **Minutes dont le client dispose pour payer**. Chaque fournisseur coché doit être activé et pourvu de ses clés sur le serveur, sinon l'enregistrement est refusé avec un message clair ; au moins un doit rester coché tant que les paiements en ligne sont activés. Quand plus d'un fournisseur peut prendre le moyen de paiement du client, l'encaissement affiche une rangée de boutons **Payer avec**. Un client qui paie en ligne a une commande qui n'arrive à la boutique qu'une fois le paiement confirmé ; une commande jamais payée est annulée. Réglez la **devise de l'entreprise** (Informations de l'entreprise) sur la devise dans laquelle vous facturez. Les fournisseurs sont :

- **Fournisseur simulé** (pour les tests seulement ; il existe quand le serveur est démarré avec `app.online-store.payments.simulated.enabled=true` et un `...simulated.secret`). Le client arrive sur une page de test avec **Payer** et **Refuser**. Ne l'utilisez jamais avec de vrais clients.
- **MTN Mobile Money (MoMo)** pour le Rwanda. Le client saisit un numéro MTN et approuve sur le téléphone. Il reste **indisponible** tant qu'il n'est pas activé et pourvu de ses clés dans l'environnement du serveur : `app.online-store.payments.mtn.enabled=true`, `...subscription-key`, `...api-user`, `...api-key`, `...base-url` (https seulement) et `...target-environment` (`sandbox` pendant les tests). Le guide pas à pas pour obtenir des clés de test (sandbox), tester et passer en production est `docs/online-store-mtn-momo.md` dans les fichiers du programme. Le bac à sable n'accepte que la devise EUR.
- **Airtel Money** pour le Rwanda. Le client saisit un numéro Airtel et approuve sur le téléphone. Clés : `app.online-store.payments.airtel.enabled=true`, `...client-id`, `...client-secret`, `...base-url` (https seulement) et `...country` (`RW`). Le remboursement d'Airtel rend un paiement entier et ne peut pas en rendre une partie, donc **les remboursements se font à la main** : l'écran dit au personnel de rembourser depuis le compte Airtel Money et de l'enregistrer avec **Je l'ai remboursé moi-même** et la référence Airtel. Le guide est `docs/online-store-airtel-money.md`.

Mettez les clés dans l'**environnement du serveur** ou dans les fichiers privés `config/application-<fournisseur>-production.properties` qui ne sont jamais versés dans un dépôt ; jamais dans un fichier que l'on copie. Le programme ne les affiche ni ne les journalise jamais. Remplacez les points et les tirets par des tirets bas et utilisez des majuscules pour une variable d'environnement (`APP_ONLINE_STORE_PAYMENTS_MTN_API_KEY`). **Chaque entreprise cliente a ses propres clés** : l'application d'un fournisseur est enregistrée au nom de l'entreprise.

> **Attention :** Les deux vrais fournisseurs n'ont été testés que contre des imitations de leurs systèmes. Avant d'ouvrir la boutique, faites un test en bac à sable, puis un petit achat réel, une commande annulée et remboursée, une commande partiellement retournée et un versement, et comparez chacun avec le relevé du fournisseur.

Donnez au fournisseur l'**adresse du webhook** affichée à l'écran : `<votre adresse>/api/public/store/payments/<code du fournisseur>/webhook`. Un rappel n'est jamais cru tel quel : la boutique demande au fournisseur le statut du paiement et n'accepte le rappel que lorsque la réponse du fournisseur concorde, et elle vérifie aussi chaque paiement en attente environ une fois par minute, de sorte qu'un rappel perdu ne retarde la commande que d'un peu. Un paiement qui ne correspond pas à sa commande (un autre montant ou une autre devise, ou un double paiement) va en **vérification** au lieu d'être accepté : surveillez **Boutique en ligne > Paiements en ligne**.

**Logos.** Le bouton de chaque fournisseur affiche son logo si le fichier existe à `frontend/src/assets/payment/<code en minuscules>.png` (`mtn_momo.png`, `airtel_money.png`). Les logos de MTN et d'Airtel sont des marques déposées et ne sont pas fournis : mettez-y les fichiers officiels et recompilez le frontend ; sans eux le bouton affiche le nom.

**Comptes par fournisseur.** Dans **Boutique en ligne > Paiements en ligne > Comptes par fournisseur**, chaque fournisseur reçoit un **compte d'attente** (ce qu'il doit encore à la boutique) et un **compte de versement** (le portefeuille ou compte bancaire sur lequel il paie). MTN et Airtel démarrent avec des comptes que le programme crée ; un fournisseur sans compte utilise le compte d'attente commun Mobile Money ou Carte et ses versements arrivent dans Caisse et banque. Décidez-le avec le comptable avant le premier vrai paiement (chapitre 6).

Un autre fournisseur (MOOV, ORANGE, une passerelle de cartes, IREMBO) est un petit morceau de programmation pour un développeur ; `docs/online-store-payment-providers.md` le décrit. Une fois qu'il existe, il apparaît dans la liste et dans Comptes par fournisseur.

### Messages texte (SMS ou WhatsApp)

Dans **Messages texte**, choisissez un **Fournisseur de SMS**, le canal (**Envoyer comme**), l'**Indicatif du pays** (250 pour le Rwanda ; il est placé devant les numéros qui commencent par 0), **Nombre maximal de SMS par jour** (300 par défaut ; 0 = pas de limite) et **Envoyer un SMS au propriétaire au** un numéro de téléphone. Rien n'est envoyé tant qu'un fournisseur n'est pas choisi. Le programme inclut un **émetteur de test** (il n'envoie rien : chaque SMS est listé dans **Boutique en ligne > Messages texte**) et demande à un développeur d'ajouter un vrai fournisseur (`docs/online-store-text-providers.md`). Les mises à jour de commande ne sont envoyées par SMS qu'aux clients qui ont coché la case à la commande. Les codes de livraison, de retrait, de retour et les nouveaux codes sont l'exception : ils sont envoyés par e-mail et par SMS au numéro de téléphone de la commande quoi que dise la case. Tant qu'aucune vraie société n'est connectée, l'émetteur intégré garde ces SMS avec le statut *En attente d'une société SMS* et rien ne quitte le serveur.

### Retours

**Les clients peuvent retourner des marchandises jusqu'à ce nombre de jours après la fin de la commande** (14 par défaut ; 0 = pas de retour par la boutique). Le retour d'une commande livrée est récupéré par un livreur, avec un code de retour à 4 chiffres.

### Lettre d'information et liens dans les e-mails

L'inscription à la lettre d'information et son envoi demandent que les paramètres e-mail fonctionnent. Le lien de confirmation dans l'e-mail, les liens de désinscription, le lien « Voir votre commande » dans chaque e-mail client, le lien du livreur, les aperçus de partage et le plan du site sont construits à partir du paramètre `app.frontend-url` : **réglez-le sur l'adresse publique du site** (par exemple `https://shop.votreentreprise.com`, sans barre oblique finale), sinon les liens pointeront au mauvais endroit (la valeur par défaut est `http://localhost:4200`).

**Limites d'envoi.** Une lettre d'information lancée dans **Boutique en ligne > Envoyer une lettre d'information** part par lots, par une tâche qui s'exécute chaque minute. Deux paramètres (propriétés ou variables d'environnement) règlent le rythme : `app.online-store.newsletter.batch-size` (e-mails par minute, 25 par défaut) et `app.online-store.newsletter.daily-limit` (maximum d'e-mails sur 24 heures, 500 par défaut, 0 = pas de limite). Réglez la limite sur ce que votre fournisseur de messagerie permet : quand elle est atteinte, le reste attend que les anciens e-mails aient plus de 24 heures, puis continue tout seul. Après cinq échecs de suite, le lot se met en pause et la lettre d'information montre la raison. Un e-mail est marqué comme pris avant d'être remis au serveur de messagerie, donc un plantage peut perdre un e-mail mais n'en envoie jamais un deux fois ; un envoi bloqué depuis plus de 10 minutes est affiché comme échoué (« Interrompu ») et peut être relancé par le personnel une fois vérifié.

**Rappels de panier abandonné.** Activés avec la case **Envoyer des rappels pour les paniers abandonnés** (désactivée par défaut ; rien n'est enregistré tant qu'elle est désactivée). Une tâche regarde toutes les 3 minutes les paniers qui méritent un rappel (le premier 1 heure, le second 3 jours après le dernier changement) et envoie au plus `app.online-store.cart-reminders.batch-size` e-mails par passage (20 par défaut). Ils utilisent les mêmes paramètres e-mail et `app.frontend-url`. Un rappel qui échoue est retenté 30 minutes plus tard, trois fois au plus. Un panier est supprimé après 60 jours sans changement. Les données conservées sont l'adresse e-mail, la langue, les produits et quantités, et les heures de rappel.

**Points de fidélité.** Activés avec **Les clients gagnent et dépensent des points de fidélité** (désactivé par défaut ; demande les **Comptes clients**). Deux nombres : **points gagnés par tranche de 100 payée pour les marchandises** (1 à 100, 1 par défaut) et **les points peuvent payer au plus % des marchandises** (0 à 100, 50 par défaut) ; un point vaut toujours 1 unité de la devise, et les points n'expirent pas. Ces points sont **distincts du programme de fidélité de la caisse** dans les Ventes. Dans les comptes ils sont une dette (**Dette de points de fidélité**) et la remise apparaît dans **Remises accordées sur ventes**. Changer ces deux nombres n'affecte que les commandes ultérieures.

### Aperçus de liens, moteurs de recherche et application installable

Quand un lien de la boutique est collé dans WhatsApp, Facebook, Telegram et des applications semblables, une carte avec l'image, le nom et le prix du produit doit apparaître, et Google doit pouvoir afficher prix, stock et étoiles. Ces programmes ne font pas fonctionner la boutique, donc le serveur web doit leur remettre une petite page construite par le backend. **Ajoutez la règle nginx de `docs/online-store-seo.md`** (un `map` pour les noms des robots, les blocs `location` pour `/shop`, `/shop/info/...`, `/_seo/...`, `/sitemap.xml` et `/robots.txt`, avec l'adresse de votre backend), puis `nginx -t && nginx -s reload`. Sans elle la boutique fonctionne comme avant mais les liens n'ont pas d'aperçu. Vérifiez avec `curl -A "facebookexternalhit/1.1" "https://votre-boutique/shop?product=12"` : il doit renvoyer une petite page avec `og:title` et `product:price:amount`. Dans Google Search Console, ajoutez `sitemap.xml`.

Le site peut être installé comme application (PWA) depuis Chrome, Edge, Android et Safari sur iPhone. Cela demande **HTTPS**. L'application ne garde que les fichiers propres du programme et les images de la boutique ; rien de `/api` n'est conservé, donc aucun ancien chiffre n'est jamais affiché comme actuel. Une nouvelle version est prise en compte à la visite suivante ; une caisse n'est jamais rechargée au milieu d'une vente.

### Derrière un proxy inverse

**Derrière un proxy inverse** (nginx, IIS, un répartiteur de charge en ligne) : ajoutez `server.forward-headers-strategy=native` aux paramètres du serveur pour que la limite par connexion voie l'adresse propre de chaque visiteur. Sans cela, tous les visiteurs partagent l'adresse du proxy et la limite s'applique à tout le monde ensemble.

## Paramètres du Cabinet d'avocats (Cabinet d'avocats > Paramètres)

Domaines d'activité et juridictions (un par ligne) ; fenêtre « échéance proche » ; base de facturation par défaut des nouveaux dossiers (Horaire, Forfait, Provision, Résultat, Pro bono) ; e-mail quotidien des échéances et tâches à chaque avocat ; nouveaux dossiers restreints par défaut ; **avertissements de date de prescription** (premier avertissement n jours avant, un second 3 jours avant, et un si la date est passée) ; et **honoraires impayés** : le délai de paiement habituel et les rappels automatiques aux clients listant les factures en retard avec un relevé joint.

## Paramètres de l'Immobilier (Immobilier > Paramètres)

Les zones où vous travaillez ; la durée d'une visite ; quand un prospect est « calme » ; un e-mail du matin à chaque agent sur les appels en retard et à faire et sur les prospects calmes (les agents ont besoin d'une adresse e-mail sur leur compte utilisateur) ; et des rappels de visite à la personne qui visite et à l'agent.

## Paramètres de la Gestion locative (Gestion locative > Paramètres)

Zones ; quand un bail est « bientôt terminé » ; le jour où le loyer est habituellement dû ; le pourcentage habituel des frais de gestion et la TVA dessus ; la facturation des loyers (combien de jours avant l'échéance, et automatiquement chaque matin) ; et les **relevés mensuels aux propriétaires** (faire automatiquement les relevés du mois précédent à partir d'un jour choisi, et éventuellement les valider et les envoyer par e-mail aux propriétaires quand ils n'ont pas d'avertissements). Il existe aussi une page distincte de rappels et de pénalités de retard pour les locataires.

## Paramètres qui ne sont pas dans un module

**Paramètres > Paramètres du système, Informations de l'entreprise, Paramètres e-mail, Modes de paiement, Taxes, Rapports planifiés, Applications, Sauvegarde et données** sont couverts aux chapitres 5, 9 et 10. Les pages **Fidélité**, **Promotions**, **Cartes cadeaux** et **Listes de prix** sont tenues par le personnel ayant la zone Ventes et sont décrites dans le Manuel utilisateur.
