# E-mail, alertes et rapports planifiés

## Paramètres e-mail

De nombreuses fonctions envoient des e-mails : factures, relevés, rappels, résumés quotidiens, rapports planifiés, liens de mot de passe oublié, confirmations de pages publiques. Elles dépendent toutes de **Paramètres > Paramètres e-mail**. Remplissez :

- **Hôte SMTP** et **port** : 587 (STARTTLS) ou 465 (SSL).
- **Nom d'utilisateur** et **Mot de passe** du compte de messagerie.
- **E-mail d'expéditeur** et **Nom d'expéditeur** : ce que les destinataires voient comme expéditeur.
- **Ignorer la vérification du certificat** : seulement pour un serveur de messagerie avec un certificat auto-signé ; évitez-le quand vous le pouvez.
- **E-mail des alertes de l'entreprise** (l'« e-mail des notifications ») : l'adresse qui reçoit les alertes du système, les résumés quotidiens, les e-mails de stock bas, etc.

Appuyez sur **Envoyer un e-mail de test** et vérifiez qu'il arrive. De nombreuses fonctions affichent un message comme « Nécessite la configuration de l'e-mail dans Paramètres » tant que cela ne fonctionne pas.

> **Conseil :** Pour les comptes Gmail ou Microsoft 365, il vous faut normalement un *mot de passe d'application* plutôt que le mot de passe normal de la personne. Utilisez une boîte dédiée au système, pas une boîte personnelle.

Un e-mail échoué ne bloque jamais le travail sous-jacent : une facture est quand même émise, une intervention quand même terminée. Regardez le journal du serveur (chapitre 11) si le courrier n'arrive pas.

## Rapports planifiés

**Paramètres > Rapports planifiés** envoie un rapport par e-mail en pièce jointe **Excel ou PDF** selon un calendrier.

1. Appuyez pour ajouter un calendrier et donnez-lui un **Nom** (par exemple *Valorisation du stock du lundi*).
2. Choisissez le **Rapport** et le **Format** (Excel .xlsx ou PDF).
3. Choisissez **Répéter** : Chaque jour, Chaque semaine (choisissez le jour) ou Chaque mois (choisissez le jour du mois), et l'**heure**.
4. Ajoutez des filtres facultatifs (Catégorie, Entrepôt, Agence, Jours) quand le rapport les gère.
5. **Envoyer à** : adresses séparées par des virgules, ou vide pour utiliser l'e-mail des notifications.
6. Cochez **Actif** et enregistrez.

Comment les périodes sont choisies : les rapports qui couvrent une plage de dates envoient la période qui **vient de se terminer** : hier pour le quotidien, les 7 jours précédents pour l'hebdomadaire, le mois civil précédent pour le mensuel. Les rapports instantanés (valorisation du stock, balances âgées et semblables) sont pris au moment de l'envoi.

La liste montre la dernière exécution de chaque calendrier. **Envoyer maintenant** l'envoie tout de suite ; un calendrier en pause est marqué *(en pause)*. Plus de quinze rapports sont disponibles, y compris les rapports d'immobilisations ajoutés dans la version 1.22.

> **Remarque :** Les rapports planifiés ne sont pas arrêtés quand le module du rapport est verrouillé par une licence expirée.

## Autres e-mails automatiques et tâches quotidiennes

| Tâche | Où elle est activée |
|---|---|
| Résumé de stock bas, demandes d'achat brouillon automatiques | Paramètres du Stock |
| Rappels de recouvrement clients (balance âgée) | Clients > Recouvrement |
| Facturation des abonnements, rappels et résumé | Paramètres des tâches d'Abonnements |
| Facturation des loyers, rappels aux locataires, relevés aux propriétaires | Paramètres de la Gestion locative |
| Suivi des prospects, rappels de visite | Paramètres de l'Immobilier |
| Avertissements de prescription, rappels d'honoraires, échéances quotidiennes | Paramètres du Cabinet d'avocats |
| Rappels de paiements échelonnés | Paramètres des Paiements échelonnés |
| Rappels de réservation et de rendez-vous | Paramètres des Rendez-vous |
| Avertissements de délais du Support client et clôture automatique | Paramètres du Support client |
| Rappel hebdomadaire de feuille de temps | Paramètres du Suivi du temps |

Les tâches s'exécutent une fois par jour à l'heure indiquée dans les paramètres de chaque module, dans le fuseau horaire des **Paramètres du système**. Si le serveur était éteint à ce moment-là, une tâche s'exécute à sa prochaine mise en marche le même jour.
