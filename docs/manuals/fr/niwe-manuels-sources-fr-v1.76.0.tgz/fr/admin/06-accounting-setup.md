# Configuration de la comptabilité

La Comptabilité est un module de base. Chaque vente, achat, dépense, passage de paie, immobilisation et mouvement de stock y est comptabilisé ; cela vaut donc la peine de la configurer soigneusement avant le début des vraies opérations.

## Choisir le plan comptable

La première fois que la Comptabilité est utilisée, un court assistant (l'écran du pays du plan comptable) demande quel plan standard utiliser comme point de départ. Le plan fixe les noms et numéros de comptes et, pour le Rwanda (RWF) et le Tchad (XAF), la devise. Après l'assistant, **Comptabilité > Plan comptable** vous permet d'ajouter, de renommer et de désactiver des comptes.

> **Conseil :** Convenez du plan avec votre comptable avant la première écriture. Les comptes qui ont déjà des écritures ne peuvent pas simplement être supprimés.

## Comptes nécessaires à la Boutique en ligne

Quand la Boutique en ligne est utilisée, ces comptes sont ajoutés d'eux-mêmes à un plan existant, quelques secondes après le démarrage du programme (**rattrapage**) : Acomptes clients en ligne, un compte d'attente et un compte de portefeuille ou bancaire pour MTN Mobile Money, Airtel Money et Carte, Espèces chez les livreurs, Produits de livraison, Remises accordées sur ventes, Dette de points de fidélité et Frais des fournisseurs de paiement. Le chapitre 25 du Manuel utilisateur (Boutique en ligne : paiements, comptabilité et rapports) liste leurs codes dans les plans du Rwanda et du Tchad. Ne les supprimez pas et ne les réutilisez pas. Après une mise à jour, ouvrez une fois **Comptabilité > Plan comptable** et vérifiez qu'ils sont là.

Pour chaque fournisseur de paiement utilisé par l'entreprise, ouvrez **Boutique en ligne > Paiements en ligne > Comptes par fournisseur** et assurez-vous qu'il a **son propre compte d'attente** et le **portefeuille ou compte bancaire** sur lequel arrivent ses versements (créez-en un nouveau sur-le-champ si l'entreprise a un compte physique distinct). Un compte d'attente appartient à un seul fournisseur et ne peut pas être changé tant que le fournisseur doit encore de l'argent dessus : décidez-le donc avant le premier vrai paiement. Avant d'ouvrir la boutique, passez les **soldes d'ouverture** de ces comptes (ce que chaque fournisseur doit à la date de bascule et le solde de chaque portefeuille) et, si la boutique avait déjà des clients avec des points de fidélité, une écriture d'ouverture pour les points qu'ils détiennent (Débit Charges de fidélisation, Crédit Dette de points de fidélité).

## Centres de coûts

**Comptabilité > Centres de coûts** sont des étiquettes facultatives (un département, un projet, une agence) que les dépenses, factures fournisseurs et lignes d'écriture peuvent porter, pour que vous puissiez suivre le coût par centre. Créez-les avant de commencer à saisir des dépenses si vous voulez des budgets par centre.

## Écritures comptables

**Comptabilité > Écritures comptables** sert aux écritures manuelles : régularisations, corrections, écritures d'ouverture. La plupart des écritures sont passées automatiquement par les modules ; les écritures manuelles doivent être rares et porter un libellé clair.

## Contrôles

**Comptabilité > Contrôles** contient les contrôles de période qu'utilise un comptable :

- **Clôturer les comptes** : verrouiller une période pour que plus rien ne puisse y être comptabilisé. À utiliser après la revue de fin de mois ou de fin d'exercice.
- **Rapprochement bancaire** : faire concorder le relevé bancaire avec le grand livre. L'écran montre au plus les 2 000 dernières lignes du grand livre.
- **Soldes d'ouverture du grand livre** : saisir le solde d'ouverture de chaque compte quand vous commencez à utiliser le système en cours d'exercice.

## Soldes d'ouverture (démarrer sur une entreprise en activité)

1. Décidez d'une date de bascule et clôturez l'ancien système à cette date.
2. Importez le **stock d'ouverture** (Stock) et les **soldes clients et fournisseurs** avec les imports de **Paramètres > Sauvegarde et données** (chapitre 10). Les soldes d'ouverture des clients et des fournisseurs deviennent de vraies factures et factures fournisseurs `OB-`, donc ils vieillissent et peuvent être encaissés et payés comme les autres.
3. Saisissez les **soldes d'ouverture du grand livre** sous Comptabilité > Contrôles pour les comptes que les imports ne couvrent pas (banque, capitaux propres, immobilisations et similaires).
4. Vérifiez la balance par rapport à votre ancien système avant le premier jour réel.

## Recettes

**Comptabilité > Recettes** enregistre l'argent reçu qui n'est pas une vente (intérêts, subventions). Les **Dépenses** ont leur propre module avec des règles d'approbation, la gestion de la TVA et des budgets, décrits dans le Manuel utilisateur.

## Fin d'exercice

En fin d'exercice : passez en revue les rapports, passez les régularisations et les amortissements (les immobilisations s'amortissent chaque mois), utilisez **Clôturer les comptes** pour la période close, et faites un export **Archive de fin d'exercice** (chapitre 10).
