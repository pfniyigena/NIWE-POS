# Caisses, imprimantes et appareils

## Caisses

Une **caisse** est un point de vente. Créez et modifiez les caisses sous **POS > Caisses et terminal** (réservé à l'administrateur). Chaque caisse a un nom, peut être épinglée à un emplacement de *Ventes* précis d'un entrepôt (et, quand le multi-entrepôts est activé, doit être affectée à un entrepôt autre que Principal), et peut être liée à un appareil (ci-dessous).

Il n'est pas nécessaire de donner l'accès à une caisse aux caissiers un par un : un poste est ouvert sur une caisse, et le terminal demande toujours un **PIN** avant de s'ouvrir. Le PIN identifie le caissier et démarre ou reprend sa propre session de travail sur ce poste.

## Lier une caisse à un appareil (version 1.13)

Vous pouvez lier une caisse à **un appareil connu** pour qu'elle ne puisse être utilisée que depuis ce PC.

1. Asseyez-vous au PC de la caisse et connectez-vous en tant qu'administrateur.
2. Allez dans **POS > Caisses et terminal** et appuyez sur **Lier à cet appareil** sur la caisse.
3. Donnez un nom au PC, et choisissez si son adresse réseau doit aussi correspondre (l'option *Contrôle de l'IP*).
4. À partir de là, tout autre appareil est refusé par le serveur pour cette caisse : le terminal, les ventes, l'ouverture d'un poste, la synchronisation hors ligne et les mouvements de caisse, chacun avec un message clair.

Appuyez sur **Délier** (un administrateur, depuis n'importe quel appareil) pour la libérer. Les rapports, tickets, l'historique et la clôture d'un poste restent disponibles depuis l'administration. Un appareil ne peut être la caisse que d'une seule caisse. Les caisses qui ne sont pas liées se comportent comme avant. La liaison et la déliaison sont écrites dans le journal d'audit (*REGISTER_DEVICE_BOUND* et *REGISTER_DEVICE_UNBOUND*).

Si le serveur se trouve derrière un proxy inverse et que vous utilisez le contrôle de l'IP, réglez `app.device-binding.trusted-proxies` sur l'adresse du proxy pour que l'adresse réelle de la caisse soit vue.

## Impression thermique et tiroir-caisse (version 1.12)

L'impression thermique se configure **par PC, dans le navigateur**, dans **POS > Appareils**, car chaque caisse a son propre matériel. Rien n'est conservé sur le serveur. Le guide complet est dans le fichier `THERMAL-PRINTING.md` fourni avec le système ; en voici un résumé.

### Types de connexion

| Connexion | À utiliser quand | Nécessite |
|---|---|---|
| **Pilote Windows** | Vous voulez la boîte de dialogue d'impression normale, mise en page pour le rouleau (exactement 80 mm ou 58 mm, sans marges). | N'importe quel navigateur, le pilote Windows de l'imprimante. |
| **Série / COM** | Vous voulez de l'ESC/POS brut : texte natif, logo, code QR, coupe, tiroir-caisse. | Chrome ou Edge en **https** ou **localhost** ; une imprimante avec un port série ou un port COM virtuel. |
| **USB** | La même impression brute par WebUSB. | Chrome ou Edge ; l'imprimante avec le pilote WinUSB (par exemple avec Zadig). |

Chrome ou Edge demandent une fois d'autoriser chaque appareil (**Connecter l'appareil...**) ; l'autorisation est mémorisée pour le site. Si une imprimante directe ne répond pas, le document est imprimé via le pilote Windows et une ligne rouge en explique la raison.

### Configurer une caisse, pas à pas

1. Ouvrez **POS > Appareils**.
2. **Imprimante de tickets** : choisissez la connexion, appuyez sur **Connecter l'appareil...**, choisissez l'imprimante. Pour COM, choisissez la vitesse (bauds) de l'imprimante (la page d'auto-test de l'imprimante l'indique).
3. **Papier et options** : largeur du papier (80 ou 58 mm), caractères par ligne, page de codes (utilisez *ASCII simple* si des caractères étranges s'impriment), couper après chaque document, ouvrir le tiroir lors des ventes en espèces.
4. Appuyez sur **Imprimer une page de test** et **Ouvrir le tiroir-caisse**.
5. Appuyez sur **Enregistrer**.

### Imprimantes du restaurant

L'**imprimante de cuisine** et l'**imprimante de bar** sont facultatives. Dans *Postes sur cette imprimante*, saisissez les noms des postes exactement comme sur les articles du menu (par exemple `Grill, Froid` pour la cuisine et `Bar` pour le bar). Cochez *Imprimer les tickets de cuisine / bar quand les articles sont envoyés en cuisine*. Sur l'écran de commande, **Addition** imprime l'addition du client (n'ouvre jamais le tiroir) et **Tickets** réimprime les tickets encore en cuisine, marqués RÉIMPRESSION.

### Ce qui s'imprime où

| Document | Imprimante |
|---|---|
| Ticket de vente et ses réimpressions COPIE, ticket de retour, addition du restaurant et ticket payé, rapports X et Z | Tickets |
| Tickets de cuisine et de bar | Cuisine / Bar |
| Impulsion du tiroir-caisse (vente en espèces, addition du restaurant payée en espèces, *Ouvrir le tiroir* en caisse) | Imprimante de tickets |

Les rapports et documents A4 s'impriment par le navigateur.

### Afficheur client sur un port COM

Sous *Afficheur client (COM)*, cochez *Utiliser un afficheur client sur ce PC*, appuyez sur *Connecter le port COM...*, choisissez le jeu de commandes (**ESC/POS**, **CD5220** ou **Texte simple**), la vitesse, les bits de données, la parité et les bits d'arrêt tels que réglés sur l'afficheur (usuel : 9600, 8, aucune, 1), les caractères par ligne (20 pour un afficheur 2 x 20) et les lignes d'accueil. Appuyez sur *Envoyer un message de test*. En caisse, l'afficheur montre l'article qui vient d'être ajouté, puis le total courant, puis PAYÉ avec MERCI ou MONNAIE, et de nouveau le texte d'accueil.

Il existe aussi un **Afficheur client** sur un second écran en caisse (une fenêtre du navigateur) qui montre au client le panier en cours et le total.

## Paramètres faits sur chaque PC

Comme les paramètres des appareils vivent dans le navigateur, ils doivent être répétés sur chaque PC de caisse et sont perdus si les données du site du navigateur sont effacées. Gardez une note des paramètres d'imprimante de chaque PC.
