# Sauvegarde, restauration, import et export

Tout cela se trouve dans **Paramètres > Sauvegarde et données** (réservé à l'administrateur).

## Sauvegardes

- Une **sauvegarde complète de la base se fait automatiquement chaque nuit**. Vous pouvez aussi appuyer sur **Sauvegarder maintenant** à tout moment.
- La liste montre chaque fichier de sauvegarde avec sa **taille** et son **heure de création**, avec les boutons **Télécharger**, **Restaurer** et **Supprimer**.
- **Où sont les fichiers :** quand le serveur tourne depuis son jar (par exemple comme service Windows), les sauvegardes sont écrites dans un dossier nommé **backups** à côté du jar, près du dossier **logs** ; le dossier est créé s'il manque. Pour utiliser un autre dossier, réglez `app.backup.directory` dans `application.properties`, comme variable d'environnement (`APP_BACKUP_DIRECTORY`) ou en ligne de commande.
- Les sauvegardes incluent l'historique des migrations Flyway, donc une restauration ramène ensemble les données et la version de leur structure.

> **Attention :** La sauvegarde vit sur le serveur. Si le serveur est perdu, les sauvegardes le sont aussi. **Téléchargez** régulièrement une sauvegarde et copiez-la sur un autre ordinateur ou un stockage en ligne, avec le dossier de stockage des documents du serveur.

### Restaurer

1. Faites d'abord une sauvegarde fraîche de l'état actuel (**Sauvegarder maintenant**), au cas où vous restaureriez le mauvais fichier.
2. Appuyez sur **Restaurer** à côté de la sauvegarde voulue, ou utilisez *Restaurer depuis un fichier de sauvegarde téléversé* pour un fichier téléchargé plus tôt ou apporté d'une autre machine.
3. Confirmez. **La restauration remplace toute la base actuelle.**
4. Pendant son exécution, tout le système passe en **mode maintenance** : tous les autres (caissiers, autres administrateurs) voient un écran « veuillez patienter ».
5. Quand elle est terminée, **redémarrez l'application** pour un démarrage propre.

> **Attention :** Restaurer une sauvegarde faite par une version *plus récente* dans une version *plus ancienne* fait échouer le contrôle des migrations (« a migration it does not know »). Déployez plutôt la version plus récente, puis restaurez.

### Bonnes pratiques

- Testez une restauration sur un ordinateur de secours au moins une fois, avant d'en avoir besoin.
- Gardez au moins une sauvegarde par semaine pendant un mois et une par mois pendant un an, en dehors du serveur.
- Sauvegardez avant chaque mise à jour (chapitre 12), chaque import, et avant de clôturer les comptes.

## Import en masse

**Import en masse** charge des données à partir d'un fichier CSV ou Excel. Les imports comprennent les produits, clients, fournisseurs, catégories, marques, **soldes clients**, **soldes fournisseurs** et **soldes du grand livre**, plus des imports de modules (employés, clients et dossiers du cabinet d'avocats, immobilier, et d'autres) à l'intérieur de leurs propres modules.

Le processus est toujours le même et conçu pour être sûr :

1. Appuyez sur **Télécharger le modèle** de l'import voulu et remplissez-le. Gardez la ligne d'en-tête.
2. Choisissez le fichier et appuyez d'abord sur **Vérifier le fichier**. Il traite le fichier exactement comme le vrai import, mais **n'enregistre rien**.
3. Lisez le résultat : combien de lignes ont été lues, combien **peuvent être importées** et combien **seront ignorées**, une liste des **Lignes qui seront ignorées** avec la raison de chacune, et un aperçu de **ce qui sera créé**.
4. Corrigez le fichier et vérifiez de nouveau jusqu'à ce que le résultat soit celui que vous voulez. Une ligne inutilisable est ignorée et listée avec la raison ; le reste du fichier est quand même importé.
5. Appuyez sur **Importer**. Le résultat montre combien ont été importées et ignorées.

Remarques :

- Les **soldes d'ouverture** (clients et fournisseurs) deviennent de vraies factures et factures fournisseurs `OB-`, donc ils vieillissent, apparaissent dans les relevés et le recouvrement, et sont payés comme les autres.
- Pour les **soldes du grand livre**, vous pouvez choisir *Mettre toute différence dans les Capitaux propres du propriétaire* pour que l'écriture d'ouverture soit équilibrée.
- Les imports de modules ne lisent que la première feuille, jusqu'à 2 000 lignes (.xlsx ou CSV).
- Les imports n'ont pas été testés sur de très gros fichiers ; découpez les gros fichiers.

## Export et archive de fin d'exercice

- **Exporter les produits** et **Exporter les clients** téléchargent les listes actuelles.
- **Archive de fin d'exercice** télécharge un instantané de l'activité d'une année (ventes, achats, paiements, corrections de stock) pour clôturer un exercice.

> **Remarque :** L'archive de fin d'exercice est un instantané choisi, **pas** une sauvegarde complète de la base. Gardez toujours aussi une vraie sauvegarde.

Chaque liste du système a aussi son propre export **Excel, PDF et CSV**, avec les mêmes filtres que l'écran.
