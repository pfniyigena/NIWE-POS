# Installation et premier démarrage

## De quoi se compose le système

NIWE ERP comporte deux parties qui fonctionnent ensemble :

- Le **backend**, une application Java 21 / Spring Boot, qui contient toutes les règles de gestion et dialogue avec la base de données. Il écoute sur le port **8080**.
- Le **frontend**, une application web Angular 18 que le personnel ouvre dans un navigateur. En développement il est servi sur le port **4200** ; en production il est normalement compilé en fichiers statiques et servi par un serveur web.
- Une base de données **PostgreSQL** qui conserve tout. La structure de la base est créée et mise à jour automatiquement par **Flyway**.

Le personnel n'a besoin que d'un navigateur récent (Chrome ou Edge est recommandé ; l'impression thermique exige l'un d'eux).

## Prérequis

- Java 21 et Maven (pour compiler ou exécuter le backend) ou le backend empaqueté qui vous a été remis.
- Node.js et npm (pour compiler le frontend).
- PostgreSQL, avec une base vide.
- Pour l'impression thermique depuis un PC de caisse : Chrome ou Edge, ouvert sur **https** ou sur **localhost** (voir le chapitre 8).

## Première installation

1. **Créez la base de données.** Par exemple : `createdb pos_app`.
2. **Réglez la connexion à la base.** Donnez au backend l'adresse, l'utilisateur et le mot de passe de votre base par des variables d'environnement : `DB_URL` (par exemple `jdbc:postgresql://localhost:5432/pos_app`), `DB_USER` et `DB_PASSWORD`, et réglez `JWT_SECRET` sur une longue valeur aléatoire. Vous pouvez aussi mettre les mêmes paramètres (`spring.datasource.url`, `.username`, `.password`, `app.jwt.secret`) dans un fichier privé `config/application.properties` à côté de l'endroit où le backend est démarré. Aucun mot de passe n'est conservé dans les fichiers livrés ; depuis la version 1.22.3, les fichiers livrés ne contiennent que des valeurs par défaut sans danger.
3. **Démarrez le backend.** Au tout premier démarrage, Flyway crée toutes les tables (migration V1, la base de départ) et les tables de licence (V2), puis applique toutes les migrations suivantes. Cela peut prendre une minute. Attendez le message *Started PosApplication*.
4. **Démarrez le frontend.** En développement : `npm install` puis `npm start`, et ouvrez `http://localhost:4200`. Si le backend est ailleurs que sur `localhost:8080`, changez `API_BASE` dans `frontend/src/app/core/constants.ts` avant la compilation, et ajoutez l'adresse du frontend à `app.cors.allowed-origins` dans les propriétés du backend.
5. **Connectez-vous** en tant que `admin` avec le mot de passe `admin123` (quand les données de démonstration sont activées, ce qui est le réglage par défaut). Sur une vraie installation sans données de démonstration, voir *Une vraie installation sans données de démonstration* ci-dessous.

> **Attention :** Les comptes de démonstration (`admin` / `admin123`, `cashier` / `cashier123`, avec les PIN de terminal 1234 et 5678) ne sont prévus que pour le premier démarrage. **Changez immédiatement le mot de passe admin**, et réglez `JWT_SECRET` (le paramètre `app.jwt.secret`) sur une longue valeur aléatoire qui vous est propre. Le chapitre 13 contient la liste de contrôle complète.

## Données de démonstration

Au premier démarrage, le système ajoute des données de démonstration : un admin et un caissier, quatre catégories, huit produits avec code-barres, un client de passage, les modes de paiement, un taux de taxe standard et une caisse. C'est utile pour apprendre ou pour un premier aperçu. Elles ne sont ajoutées qu'une seule fois.

### Une vraie installation sans données de démonstration

Pour une vraie entreprise, démarrez la toute première fois avec `app.seed-demo-data=false`. Sans données de démonstration et avec une base vide, le système crée un administrateur, `admin`, pour que vous puissiez vous connecter :

- Si vous réglez `app.initial-admin-password=` sur un mot de passe de votre choix, c'est ce mot de passe.
- Si vous le laissez vide, le système fabrique un mot de passe aléatoire et l'écrit **une seule fois** dans le journal, dans une ligne qui commence par *FIRST START* (chapitre 11). Copiez-le, connectez-vous et changez-le tout de suite dans votre profil.

Cela n'arrive que lorsqu'il n'y a aucun utilisateur, donc un redémarrage ne change jamais votre mot de passe et ne crée pas d'autre compte. Sans les données de démonstration, il n'y a pas non plus encore de modes de paiement, de taxes ou de caisse : créez-les dans **Paramètres** (étapes 5 et 11 ci-dessous). N'utilisez pas les comptes de démonstration sur un serveur que des personnes réelles peuvent atteindre.

## Ordre de configuration pour une nouvelle entreprise

Un ordre raisonnable qui évite de refaire le travail :

1. Changez le mot de passe admin (**Employés**, puis votre propre compte) et le secret JWT.
2. Remplissez **Paramètres > Informations de l'entreprise**.
3. Installez la licence et activez les modules (**Paramètres > Modules**, chapitre 3).
4. Réglez les **Paramètres du système** (devise, fuseau horaire, format de date, mode de remise).
5. Créez les **Taxes** et les **Modes de paiement**.
6. Créez les **Agences** et les **Entrepôts** (si vous en avez plus que le siège).
7. Choisissez le **plan comptable** et réglez les contrôles comptables (chapitre 6).
8. Créez les **Rôles** et les comptes **Employés** (chapitre 4).
9. Configurez les **Paramètres e-mail** (chapitre 9), puis les paramètres de chaque module que vous utilisez (chapitre 7).
10. Importez les produits, clients, fournisseurs et soldes d'ouverture (chapitre 10), en vérifiant chaque fichier d'abord.
11. Configurez les caisses, imprimantes et appareils (chapitre 8).
12. Faites une première sauvegarde manuelle (**Paramètres > Sauvegarde et données**).

## Installer pour plusieurs entreprises

La même compilation sert chaque client : la version de production du frontend demande l'API à la **même adresse** (`/api`), donc une seule compilation fonctionne derrière n'importe quel domaine, et chaque client a **sa propre base, son propre fichier de paramètres privé, ses propres secrets et sa propre licence**. Rien d'un client ne se trouve dans la base d'un autre. Le **Guide d'installation et de déploiement** distinct décrit une façon reproductible de préparer un serveur, d'installer un nouveau client, et ce qui diffère d'un client à l'autre. Le **Guide d'intégration d'un client** décrit les premières semaines avec une nouvelle entreprise.

## Où le système garde ses fichiers

Outre la base de données, le backend écrit ses fichiers journaux (chapitre 11) et conserve les documents et photos téléversés dans son dossier de stockage. Quand le backend tourne en jar, par exemple comme service, les fichiers journaux sont écrits dans un dossier nommé **logs** à côté du jar (`niwe-erp.log`, `niwe-erp-error.log`, `niwe-access.log`) et les sauvegardes de la base dans un dossier nommé **backups** à côté du jar ; les deux sont créés s'ils manquent, donc le compte qui exécute le service doit avoir le droit d'écrire dans le dossier du jar. Incluez à la fois la sauvegarde de la base et le dossier de stockage dans votre propre routine de sauvegarde du serveur.
