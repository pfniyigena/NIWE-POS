# Utilisateurs, rôles et permissions

## Les trois niveaux d'accès

NIWE ERP contrôle ce que chaque personne peut faire en trois niveaux. Les comprendre rend la configuration des utilisateurs facile.

1. **Le rôle de base** du compte : **Administrateur** ou **Caissier**. Un administrateur peut tout faire. Un caissier fait le travail de tous les jours (la caisse, et tout ce que les deux niveaux suivants ajoutent).
2. **Un rôle personnalisé** (facultatif, un par personne), construit dans **Employés > Rôles**. Il ajoute des *zones d'accès* à un compte de caissier, chacune réglée sur *Aucun accès*, *Lecture seule* ou *Gérer*. Exemples : Responsable, Comptable, Magasinier.
3. **Des permissions supplémentaires** (facultatives, par personne) : des droits d'approbation individuels, comme *Approuver/rejeter les dépenses* ou *Dépasser le plafond de remise de l'entreprise*, que vous accordez un par un sans faire de la personne un administrateur.

En plus de cela, un caissier peut être limité à des **agences** précises.

> **Remarque :** Le serveur fait respecter tout cela. Masquer un élément de menu n'est qu'une commodité ; une personne sans accès est aussi refusée par le serveur si elle essaie d'atteindre les données autrement.

## Créer un compte employé

Allez dans **Employés** et appuyez sur le bouton pour ajouter un nouvel employé. Le formulaire comporte ces champs :

| Champ | Que saisir |
|---|---|
| **Nom d'utilisateur** | Le nom de connexion. |
| **Mot de passe** | Le mot de passe initial. Demandez à la personne de le changer après la première connexion. |
| **Nom complet** | Tel qu'il doit apparaître dans les rapports et sur les approbations. |
| **E-mail** | Facultatif. Nécessaire seulement pour que la personne puisse utiliser **Mot de passe oublié ?** sur l'écran de connexion. |
| **Rôle** | **Caissier** ou **Administrateur**. |
| **Rôle personnalisé** | *Aucun, simple caissier*, ou un rôle que vous avez construit dans Employés > Rôles. Donne l'accès de ce rôle en plus du travail normal de caissier. Les administrateurs ont toujours un accès complet. |
| **Actif** | Décochez pour empêcher la personne de se connecter sans supprimer le compte. |
| **Permissions supplémentaires** | Droits d'approbation individuels (ci-dessous). |
| **Accès aux agences** | Visible quand vous avez plus d'une agence et que le rôle est Caissier. |

Appuyez sur **Enregistrer**. Pour empêcher quelqu'un de travailler, décochez **Actif** plutôt que de supprimer le compte : son nom reste sur les ventes passées, les approbations et les entrées d'audit.

> **Conseil :** Donnez à chaque personne son propre compte. Les comptes partagés rendent le journal d'audit et les rapports de caissiers inutiles.

### Les PIN de terminal

Les caissiers ouvrent le terminal de vente et changent de caissier en saisissant un **PIN**. Le PIN de chaque personne l'identifie, de sorte que deux caissiers peuvent encaisser sur un même poste sans se déconnecter. Dans la liste des **Employés**, chaque ligne indique si un PIN est **Défini** ou **Non défini**, avec un bouton **Définir le PIN** / **Changer le code PIN**. Un PIN doit comporter 4 à 6 chiffres et être unique parmi le personnel actif. Les comptes de démonstration ont les PIN 1234 (admin) et 5678 (caissier) ; changez-les.

### Accès aux agences

Si l'entreprise a plusieurs agences, cochez les agences dans lesquelles un caissier peut travailler. La personne ne verra et ne fera alors fonctionner que les caisses, ventes et approbations de ces agences. **Laissez tout décoché pour l'accès à toutes les agences.** Les administrateurs ne sont jamais limités.

## Rôles personnalisés

Ouvrez **Employés > Rôles** et appuyez sur **Nouveau rôle**.

- **Nom du rôle** : par exemple *Responsable*, *Comptable*, *Magasinier*.
- **Description** : facultative.
- **Actif** : un rôle inactif ne donne aucun accès supplémentaire à son personnel tant qu'il n'est pas réactivé.
- **Ce que ce rôle peut faire** : une ligne par zone d'accès, chacune réglée sur **Aucun accès**, **Lecture seule** ou **Gérer**. *Lecture seule* ouvre les écrans et les listes en consultation. *Gérer* permet aussi de créer et de modifier.

Deux rôles prêts à l'emploi, **Responsable** et **Comptable**, existent pour que vous les utilisiez ou les copiiez.

### Les zones d'accès

| Zone | Écrans typiques qu'elle ouvre |
|---|---|
| **Ventes et clients** | Clients, devis, commandes clients, listes de prix, promotions, cartes cadeaux, fidélité, retours de commandes clients, postes, mouvements de caisse, annulations et retours POS, caisses ; paiements clients et recouvrement |
| **Facturation et paiements** | Factures, factures récurrentes, avoirs, remboursements, factures fournisseurs, paiements fournisseurs, paiements échelonnés ; paiements clients et recouvrement ; transformer du temps approuvé en facture ; dépenses récurrentes |
| **Stock et achats** | Produits, catégories, marques, entrepôts, fournisseurs, demandes d'achat et bons de commande, retours d'achats, corrections de stock, inventaires, transferts, réapprovisionnement, conditionnement |
| **Opérations** | Fabrication, Restaurant, Abonnements, Support client, Suivi du temps, Ordres de travail, Rendez-vous, Cabinet d'avocats, Immobilier, Gestion locative ; appareils |
| **Comptabilité** | Plan comptable, centres de coûts, écritures comptables, contrôles, recettes, dépenses, **Immobilisations** |
| **Hôtel** | Tout le module Hôtel |
| **Ressources humaines** | Employés, documents, accueil des nouveaux, présences, congés, organigramme |
| **Paie et contrats** | Contrats et paie (ils portent des données de salaires, donc ils ont une zone à part) |
| **Rapports et tableau de bord** | Le tableau de bord et les rapports de chaque module (lecture seule). Certains rapports de salaires restent verrouillés même ici. |

Un écran de rapport s'ouvre pour une personne qui a *Lecture seule* sur **Rapports et tableau de bord** *ou* sur la zone propre du module, de sorte que vous pouvez laisser un magasinier voir les rapports de stock sans ouvrir toute la zone des rapports.

Un seul rôle personnalisé peut être donné à une personne. Si quelqu'un a besoin des pouvoirs de deux rôles, créez un rôle combiné.

### Les écrans qui ne peuvent pas être délégués

Les suivants sont toujours **réservés à l'administrateur**, quels que soient les rôles que vous construisez : **Employés et Rôles, Paramètres** (Modules, Modes de paiement, Taxes, Informations de l'entreprise, Paramètres du système, Paramètres e-mail, Rapports planifiés, Applications, Journal d'audit, Journal des connexions, Journaux du serveur), **Sauvegarde et données** y compris l'import et l'export, et la page **Paramètres** propre à chaque module. Les rôles ne les ouvrent jamais.

## Permissions d'approbation par personne

Certaines actions demandent un second regard : un responsable qui approuve une perte, par exemple. Au lieu de faire de ce responsable un administrateur, cochez les droits précis sous **Permissions supplémentaires** sur sa fiche d'employé. Un administrateur les a déjà tous.

| Permission | Ce qu'elle autorise |
|---|---|
| Confirmer/rejeter les pertes du restaurant | Examiner une perte enregistrée : appliquer son effet sur le stock et la comptabilité, ou l'écarter |
| Approuver les ajustements de stock généraux | Examiner une correction de stock enregistrée |
| Approuver les demandes d'achat | Approuver ou rejeter une demande en attente d'approbation |
| Dépasser le plafond de remise de l'entreprise | Appliquer une remise à la caisse et dépasser la remise maximale configurée |
| Approuver/rejeter les dépenses | Approuver ou rejeter une dépense en attente d'approbation, et annuler une dépense approuvée |
| Approuver les grosses dépenses | Approuver une dépense supérieure au plafond d'approbation fixé dans Dépenses > Paramètres |
| Approuver les cessions d'immobilisations importantes | Céder une immobilisation dont la valeur comptable dépasse le plafond fixé dans Immobilisations > Paramètres, et annuler une cession |
| Approuver/rejeter les transferts de stock | Examiner un transfert enregistré entre entrepôts |
| Approuver les annulations et retours en caisse | Approuver une annulation ou un gros retour en saisissant un PIN, sans aucun autre droit de responsable |
| Approuver les changements de prix en caisse | Approuver un prix modifié à la main en saisissant un PIN |
| Approuver les gros décaissements et corrections de caisse | Approuver un gros décaissement, et annuler un mouvement de caisse erroné |

> **Conseil :** Les trois permissions « en caisse » vous permettent de donner à un superviseur de poste juste assez de pouvoir pour approuver les exceptions en saisissant son PIN, sans lui ouvrir aucun écran d'administration.

## Bonnes pratiques

- Gardez le nombre d'administrateurs faible (deux est typique : le propriétaire et un adjoint).
- Passez en revue la liste du personnel chaque trimestre ; décochez **Actif** pour les départs le jour où ils partent.
- Utilisez le **Journal d'audit** (chapitre 11) pour voir qui a approuvé quoi.
- Préférez un rôle plus quelques permissions supplémentaires à faire des gens des administrateurs.
