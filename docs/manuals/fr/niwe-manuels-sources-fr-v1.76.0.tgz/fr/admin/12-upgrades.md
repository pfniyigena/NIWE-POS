# Mises à jour et migrations

## Comment la base de données reste en phase

La structure de la base appartient à **Flyway**. Chaque version porte des fichiers de migration SQL numérotés ; au démarrage, Flyway applique ceux que la base n'a pas vus et les enregistre dans la table `flyway_schema_history`. Hibernate ne fait que *valider* que le code et la base concordent (`ddl-auto=validate`) ; il ne modifie jamais les tables.

Règles qui comptent pour un administrateur :

1. **Ne modifiez ni ne supprimez jamais une migration déjà appliquée.** Flyway conserve une somme de contrôle et refuse de démarrer si un fichier a changé.
2. Une nouvelle version se démarre simplement : les nouvelles migrations s'exécutent une fois, chacune dans sa propre transaction.
3. **Sauvegardez d'abord.** Toujours (chapitre 10).

## Installer une nouvelle version

Chaque version est livrée sous forme de paquet (par exemple `niwe-pos-v1.76.0.tgz`) avec ses propres notes de version (`RELEASE-NOTES-v1.76.0.md`). Les étapes habituelles :

1. Annoncez une courte fenêtre de maintenance. Faites **Sauvegarder maintenant** et téléchargez la sauvegarde.
2. Arrêtez le backend.
3. Décompressez le paquet par-dessus le dossier du projet.
4. Exécutez le ou les scripts d'application de la version, comme indiqué dans les notes de version : `tools/apply-vXXXX.py` et `tools/wire-vXXX.py frontend/src/app`.
5. Compilez le frontend et le backend.
6. Démarrez le backend. Surveillez dans le journal Flyway qui applique les nouvelles migrations et *Started PosApplication*.
7. Ouvrez le système, connectez-vous, et vérifiez **Paramètres > Modules** (licence et états des modules) et quelques écrans.

Si une version ajoute une nouvelle permission (par exemple *Approuver les cessions d'immobilisations importantes*), personne ne l'a tant que vous ne l'accordez pas sous **Employés** ; les administrateurs ont automatiquement toutes les permissions.

## Mettre à jour un client qui a plusieurs versions de retard

Les migrations s'appliquent dans l'ordre, donc un client peut passer directement d'une ancienne version à la dernière : Flyway applique toutes les migrations que la base n'a pas vues. Faites d'abord une sauvegarde, vérifiez les **notes de version** de chaque version intermédiaire pour les **actions ponctuelles** (par exemple la règle nginx de la 1.53 ou le nouveau paramètre `app.frontend-url`), mettez d'abord à jour une **copie** de la base du client quand l'écart est grand, et gardez l'ancien jar et la sauvegarde jusqu'à ce que le client ait travaillé une journée sur la nouvelle version. Les *Notes de version et de mise à jour pour les clients* donnent le tableau des versions et les actions par version ; le *Guide d'installation et de déploiement* contient la routine de mise à jour pas à pas pour de nombreux clients.

## La première fois sur une ancienne base (une fois par base)

Les compilations actuelles démarrent avec la validation du schéma. Si une ancienne base a été créée avant Flyway et qu'il lui manque des tables ou des colonnes :

1. Faites une sauvegarde.
2. Démarrez le backend **une fois** avec le profil supplémentaire `dbsync` (par exemple `mvn spring-boot:run -Dspring-boot.run.profiles=dbsync`, ou votre profil habituel plus `dbsync`).
3. Attendez *Started PosApplication*, puis arrêtez-le.
4. Démarrez normalement. Flyway prend la base comme référence et continue.

> **Attention :** N'utilisez jamais `dbsync` sur une base que Flyway gère déjà.

Une base créée pendant le développement avec les anciennes 23 migrations doit être supprimée et recréée (sans risque seulement si elle ne contient pas de vraies données), car la migration de base unique V1 a une somme de contrôle différente.

## Historique des versions en bref

| Version | Thème principal |
|---|---|
| 1.1 | Licences de modules |
| 1.2 à 1.4 | Améliorations de la Gestion locative, de l'Immobilier et du Cabinet d'avocats |
| 1.5 | Base : pagination, recherche et exports partout ; recouvrement ; imports avec vérification préalable ; contrôles comptables ; listes de prix ; promotions, cartes cadeaux et fidélité |
| 1.6 à 1.10 | RH et Paie, Hôtel, Restaurant, POS, Fabrication ; quantités décimales |
| 1.11 | Numéro fiscal sur les tickets, pagination du tableau de bord, interrupteurs de fonctions des ventes |
| 1.12 | Impression thermique et afficheur client COM |
| 1.13 | Caisse liée à un appareil |
| 1.14 | Journaux du serveur, journal des connexions, journal d'audit élargi |
| 1.15 à 1.22 | Ordres de travail, Suivi du temps, Rendez-vous, Paiements échelonnés, Abonnements, Support client, Dépenses, Immobilisations |
| 1.23 à 1.26 | Le français partout : écrans, messages, listes, rapports et documents imprimés |
| 1.27 | Boutique en ligne : la boutique publique, commandes en espèces |
| 1.28 à 1.34 | Boutique en ligne : améliorations de la boutique, paiements en ligne (fournisseur simulé, puis MTN Mobile Money), comptes clients, coupons, SMS, retours et remboursements |
| 1.35 à 1.36 | Boutique en ligne : une page d'accueil complète (annonce, images de bannière qui défilent, rangées de produits, avis, lettre d'information, pied de page), écrans Avis et Lettre d'information, chiffres « Vendable maintenant » |
| 1.37 | Boutique en ligne : six rapports de ventes, aussi disponibles en rapports planifiés envoyés par e-mail ; aucun changement de base |
| 1.38 | Boutique en ligne : envoyer une lettre d'information depuis le programme ; nouvelles tables (migration V74, exécutée d'elle-même au démarrage) ; paramètres facultatifs `app.online-store.newsletter.batch-size` et `daily-limit` |
| 1.39 | Boutique en ligne : rappels de panier abandonné ; nouvelles tables et une nouvelle colonne de paramètres (migration V75, exécutée d'elle-même au démarrage) ; paramètre facultatif `app.online-store.cart-reminders.batch-size` ; la boutique doit avoir des paramètres e-mail fonctionnels et `app.frontend-url` |
| 1.40 | Boutique en ligne : points de fidélité pour les comptes de la boutique ; nouvelle table et colonnes (migration V76, exécutée d'elle-même au démarrage) ; désactivés tant qu'on ne les active pas dans les Paramètres de la boutique |
| 1.41 à 1.42 | Boutique en ligne : Airtel Money, plusieurs fournisseurs de paiement choisis à la commande ; nouvelle colonne de paramètres (migration V77). Les clés des fournisseurs vont dans l'environnement du serveur |
| 1.43 | Boutique en ligne : publicité ; trois nouvelles tables (V78) |
| 1.44 à 1.48 | Boutique en ligne : page produit, expérience de la boutique, notes et avis, téléchargement de facture, carnet d'adresses, liste de souhaits, WhatsApp, rangées de produits (V79 à V82) |
| 1.49 | Le site peut être installé comme application (PWA) ; aucun changement de base ; demande https |
| 1.50 à 1.51 | Boutique en ligne : variantes de produit, formulaire de contact, pages d'information (V84 à V86) |
| 1.52 à 1.64 | Livraison de la Boutique en ligne : livreurs, code de livraison, lien privé et PIN du livreur, espèces des livreurs, livraisons échouées et partielles, créneaux heures de livraison, retours à récupérer, estimation et taxe par zone (V87 à V97). **Ajoutez la règle nginx pour les aperçus de liens** (1.53) et réglez `app.frontend-url` |
| 1.55 | Le portail client (aucun changement de base) |
| 1.54 | Alertes de retour en stock (V88) |
| 1.65 à 1.69 | Stock et prix de la Boutique en ligne : emplacements de vente, stock retenu, marge par produit, péremption et numéros de série, cartons, réapprovisionnement, prix des Ventes, poids et longueurs (V98 à V101) |
| 1.70 à 1.76 | Comptabilité de la Boutique en ligne : TVA et remboursements sur les retours, paiements en ligne retenus et soldés par les versements, Espèces chez les livreurs, remises, produits de livraison et dette de fidélité, retours au coût vendu, agence pour la boutique, un compte pour chaque fournisseur de paiement (V102 à V106). Les nouveaux comptes sont ajoutés d'eux-mêmes au plan comptable quelques secondes après le démarrage ; vérifiez **Comptabilité > Plan comptable**, puis **Boutique en ligne > Paiements en ligne > Comptes par fournisseur** |

## Si un démarrage échoue

- *Migration checksum mismatch* : un fichier de migration a été modifié après son application. Restaurez le fichier d'origine.
- *Schema-validation: missing column/table* : la base est en retard sur le code. Faites le démarrage ponctuel `dbsync` décrit ci-dessus (après une sauvegarde).
- Un message qui nomme *a migration it does not know* : vous exécutez une compilation plus ancienne contre une base créée par une plus récente. Déployez la compilation plus récente.
