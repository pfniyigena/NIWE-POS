# Ce que vous devez faire à chaque mise à jour

La plupart des versions n'exigent rien de vous. Voici les versions qui demandent une **action ponctuelle**. Le technicien fait les actions techniques ; l'entreprise fait celles marquées *entreprise*.

| Version | Action | Qui |
|---|---|---|
| Toutes | Faire une **sauvegarde** et la copier hors du serveur avant la mise à jour. Garder le jar et le frontend précédents jusqu'à ce que la nouvelle version ait fonctionné un jour. | NIWE |
| 1.22.3 et suivantes | Le mot de passe de la base, le secret de connexion et le mot de passe e-mail ne sont **jamais dans les fichiers livrés** : ils sont dans les paramètres privés ou l'environnement du serveur. | NIWE |
| 1.38 | Paramètres facultatifs de cadence pour les lettres d'information (`app.online-store.newsletter.batch-size`, `daily-limit`). | NIWE |
| 1.39 | Les rappels de panier abandonné demandent un e-mail fonctionnel et `app.frontend-url` réglé sur l'adresse publique. Désactivés tant qu'on ne les active pas dans les Paramètres de la boutique. | NIWE et entreprise |
| 1.41, 1.42 | Airtel Money et plusieurs fournisseurs : les clés des fournisseurs vont dans l'environnement du serveur, et chaque fournisseur doit y être activé avant de pouvoir être coché dans les Paramètres de la boutique. | NIWE |
| 1.42 | Facultatif : mettre les fichiers de logo officiels de MTN et d'Airtel dans `frontend/src/assets/payment/` avant de compiler le frontend ; sinon les boutons affichent des noms. | NIWE |
| 1.49 | Le site ne s'installe comme application qu'en **https**. | NIWE |
| 1.51 | Lire et adapter les quatre **pages d'information** (Conditions, Confidentialité, Retours, Livraison) dans Boutique en ligne > Pages de la boutique. Ce sont des textes de départ, pas un conseil juridique. | Entreprise |
| 1.53 | Ajouter la **règle du serveur web** pour les aperçus de liens, le plan du site et robots.txt (`docs/online-store-seo.md`) et régler `app.frontend-url` sur l'adresse publique. Sans elle la boutique fonctionne mais les liens n'ont pas d'aperçu. | NIWE |
| 1.54 | Les alertes de retour en stock utilisent l'e-mail (et le SMS quand il est connecté). Aucune action. | |
| 1.57, 1.59.1 | Donner au **produit des frais de livraison** une taxe comprise ou aucune, et fixer la **taxe** de chaque zone de livraison, pour que la facture et les espèces du livreur concordent avec le total du client. | Entreprise |
| 1.59 | Régler `app.frontend-url` ; servir en https ; donner à chaque livreur un **lien et un PIN** dans Paramètres de la boutique > Livreurs. | NIWE et entreprise |
| 1.61 | Les heures de livraison sont désactivés tant que des créneaux ne sont pas ajoutés dans Paramètres de la boutique > Heures de livraison. | Entreprise |
| 1.65 | Avec plusieurs entrepôts, choisir **Stock d'où vend la boutique** (ou laisser Automatique). Vérifier la ligne sous quelques produits. | Entreprise |
| 1.66 | Choisir **Libérer les commandes sans réponse après (heures)** et la **part gardée pour la caisse**. | Entreprise |
| 1.67 | Choisir **Ne pas vendre les marchandises dont il reste moins de jours que** si la boutique vend des produits à péremption. | Entreprise |
| 1.69 | Choisir la **liste de prix** utilisée par la boutique ; marquer les produits vendus au poids ou à la longueur. | Entreprise |
| 1.70 à 1.76 | Changements comptables : ouvrir **Comptabilité > Plan comptable** quelques secondes après le premier démarrage et vérifier que les nouveaux comptes existent (Rwanda : 1011, 1012, 1013, 1020, 1021, 1022, 1030, 1050, 2810, 2820, 4030, 4040, 5240 ; Tchad : 5212 à 5219, 4197, 4198, 631, 7071, 7091). | NIWE et comptable |
| 1.71, 1.75, 1.76 | Choisir les **comptes d'attente et de versement** de chaque fournisseur dans Boutique en ligne > Paiements en ligne > Comptes par fournisseur. Enregistrer chaque **versement** de fournisseur dans Versements. Passer les **soldes d'ouverture** des comptes des fournisseurs si vous commencez en cours de route. | Comptable |
| 1.72 | Vérifier chaque jour que **Espèces chez les livreurs** concorde avec le total « À remettre » de Espèces des livreurs. | Entreprise |
| 1.73 | Les points de fidélité détenus par les clients avant cette version **ne sont pas dans la dette** : passer une écriture d'ouverture manuelle (Débit Charges de fidélisation, Crédit Dette de points de fidélité). | Comptable |
| 1.74 | Avec plus d'une agence, choisir **Agence pour laquelle la boutique vend**. | Entreprise |

Si vous avez plusieurs versions de retard, faites **toutes** les actions de chaque version que vous passez.

## Limites connues à garder en mémoire (version 1.76)

- Un paiement *à vérifier* (mauvais montant, ou second paiement d'une commande déjà payée) n'est pas dans les comptes tant que le personnel ne l'a pas traité.
- Les commandes payées en ligne avant la 1.71 n'ont pas d'acompte : leur paiement est comptabilisé sur le compte du fournisseur à la livraison. Les commandes livrées avant la 1.72 règlent les espèces des livreurs par la différence seulement. Les retours avant la 1.70 gardent leur ancien chiffre de remboursement. Les commandes payées avant la 1.75 gardent les anciens comptes.
- Un fournisseur qui verse net de ses frais : saisissez le brut que couvre le versement et les frais.
- Les vrais paiements MTN, Airtel et par carte dépendent de vos propres clés et de votre agrément ; les premiers paiements réels doivent être testés avec de petits montants.
- L'envoi de SMS est un substitut tant qu'une vraie société de SMS n'est pas connectée : les codes par SMS restent dans la liste des SMS ; l'e-mail part quand même.
