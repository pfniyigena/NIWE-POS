# Fiche de mise à jour (une page par mise à jour)

Copiez cette page pour chaque mise à jour d'un client et conservez-la avec le registre des clients.

| | |
|---|---|
| Client | |
| De la version, à la version | |
| Date et fenêtre convenues avec le client | |
| Réalisée par | |

## Avant

- [ ] Les notes de version de chaque version passée ont été lues ; les actions du chapitre 3 sont listées ci-dessous.
- [ ] Client informé ; journée clôturée si possible.
- [ ] Sauvegarde faite et copiée hors du serveur (nom du fichier, taille, lieu) : ________________
- [ ] Ancien jar et ancien frontend conservés (où) : ________________
- [ ] Pour un grand écart : essayé sur une copie des données (résultat) : ________________

## Pendant

- [ ] Service arrêté ; nouveau jar et nouveau frontend en place.
- [ ] Actions ponctuelles appliquées (liste) : ________________
- [ ] Service démarré ; le journal montre chaque nouvelle migration (dernière : V____) et *Started PosApplication* ; aucune ligne ERROR.

## Après

- [ ] Connecté en tant qu'admin ; **Paramètres > Modules** montre la licence et les modules.
- [ ] **Comptabilité > Plan comptable** contient les nouveaux comptes (quand la version le disait).
- [ ] Une vente (ou commande) de test faite et ses écritures lues dans le Journal.
- [ ] L'administrateur du client a contrôlé les écrans utilisés tous les jours.
- [ ] Registre mis à jour avec la nouvelle version et la date.
- [ ] Problèmes trouvés et leur responsable : ________________

Signé (NIWE) : ______________   Signé (client) : ______________
