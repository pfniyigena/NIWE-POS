# Les nouveautés, version par version

Les versions sont regroupées par ce qu'elles apportent. Chaque ligne dit ce que vous pouvez faire désormais. Les versions antérieures à la 1.23 sont résumées dans la dernière section.

## 1.76 : choisir les comptes de chaque fournisseur de paiement

Dans **Boutique en ligne > Paiements en ligne > Comptes par fournisseur**, vous choisissez, pour chaque fournisseur de paiement (MTN, Airtel, carte, et les suivants), le compte de **ce que le fournisseur vous doit encore** et le **portefeuille ou compte bancaire où arrivent ses versements**. Chacun peut être un compte existant ou un compte créé sur-le-champ. Les versements s'enregistrent un fournisseur à la fois.

## 1.75 : un compte pour chaque fournisseur de paiement

MTN Mobile Money, Airtel Money et la carte ont chacun leurs propres comptes, de sorte que chaque solde peut être rapproché du relevé du fournisseur. Les commandes payées avant cette version gardent leurs anciens comptes, donc aucun solde ne bouge.

## 1.73 et 1.74 : les comptes de la boutique montrent les remises, les frais de livraison et les points de fidélité ; retours au coût

Les Ventes montrent désormais le **prix complet** des marchandises ; les remises par coupon et par points sont dans **Remises accordées sur ventes** et les frais de livraison dans **Produits de livraison**. Les points de fidélité dus par la boutique sont une **dette**. Un retour remet les marchandises en stock au **coût auquel elles ont été vendues**. Une **agence** peut être choisie pour la boutique en ligne.

## 1.72 : les espèces détenues par les livreurs

Les espèces qu'un livreur prend à la porte sont comptabilisées dans **Espèces chez les livreurs** jusqu'à ce qu'il les remette. La remise les déplace vers Caisse et banque et enregistre toute différence.

## 1.71 : les paiements en ligne sont retenus puis soldés par les versements

L'argent payé en ligne est enregistré quand le fournisseur le confirme, retenu jusqu'à la livraison de la commande, et soldé quand le fournisseur verse. Un nouveau panneau **Versements** enregistre chaque versement et ses frais.

## 1.70 : les retours comptabilisent la TVA et le remboursement

Un retour contrepasse désormais la TVA en plus de la vente et comptabilise l'argent rendu au client.

## 1.65 à 1.69 : le stock et les prix utilisés par la boutique

- La boutique ne vend que depuis les **emplacements de vente** (hors de l'entrepôt principal), un seul choisi ou tous.
- Une commande de la boutique **retient son stock dès qu'elle est passée**, donc on ne peut pas vendre la dernière unité à deux clients ; les commandes sans réponse sont annulées après un nombre d'heures que vous fixez.
- Une **marge pour chaque produit** et une **part gardée pour la caisse**.
- Les **marchandises périmées** ne sont jamais vendues ; les lots proches de la péremption peuvent être écartés ; les **numéros de série** sont affichés et retournés correctement.
- Les **cartons** comptent dans le stock ; **Réapprovisionnement** tient compte des commandes de la boutique et des clients en attente.
- Les **prix et promotions des Ventes** sont utilisés en ligne ; les produits peuvent être **vendus au poids ou à la longueur**.
- Corrections : terminer une commande avec plusieurs entrepôts n'échoue plus, et les refus indiquent leur vraie raison.

## 1.52 à 1.64 : la livraison

- **Livreurs**, **bons de livraison** et **feuilles de tournée** ; le client voit le nom et le téléphone de son livreur.
- Un **code de livraison à 4 chiffres** : le client le donne au livreur pour terminer la commande. Le personnel ne le voit jamais. Il est envoyé par e-mail et par SMS (le SMS est un substitut tant qu'une société de SMS n'est pas connectée).
- Une **page privée pour chaque livreur** (lien et PIN, sans identifiant du personnel) avec ses commandes, ses espèces et ses retours à récupérer.
- **Espèces des livreurs** : suivez les espèces que les livreurs prennent jusqu'à leur remise, avec les différences enregistrées.
- **Livraisons échouées** et **livraisons partielles**, le client choisissant un **nouvel horaire de livraison**.
- **Créneaux heures de livraison** (limites par créneau, jours fermés, préavis).
- **Retours à récupérer** : un livreur récupère les marchandises retournées avec un code de retour.
- **Estimation de livraison et taxe pour chaque zone** ; les frais sont le montant que le client paie et la taxe est comprise.
- Chaque écriture comptable d'une commande en ligne se termine par le numéro de la commande.

## 1.41 à 1.51 et 1.53 à 1.55 : une boutique plus riche

- **Airtel Money** comme deuxième fournisseur de paiement, et plusieurs fournisseurs à la fois avec un choix à la commande (1.41, 1.42).
- **Publicité** : vendez de l'espace dans la boutique à d'autres entreprises, avec un rapport de vues et de clics (1.43).
- Une **page produit** pour chaque produit ; recherche, filtres et tri ; fiches produit, aperçu rapide, produits récemment consultés ; **notes** (les étoiles comptent tout de suite) et **avis** (des mots, approuvés par le personnel) (1.44 à 1.46).
- **Téléchargement de facture**, un **carnet d'adresses**, une **liste de souhaits** et des liens **WhatsApp** (1.47) ; des rangées de produits qui défilent (1.48).
- **Variantes de produit** (taille, couleur, modèle) comme un seul produit avec options (1.50) ; un **formulaire de contact** avec réponses dans le programme, et quatre **pages d'information** (1.51).
- **Aperçus de liens** dans WhatsApp, Facebook et d'autres, un **plan du site** et des données produit pour Google (1.53) ; **alertes de retour en stock** (1.54) ; le **portail** client (1.55) ; et l'**application installable** pour tout le site (1.49).

## 1.27 à 1.40 : naissance de la Boutique en ligne

Une boutique publique avec livraison, retrait et commandes en espèces (1.27) ; des e-mails à chaque étape (1.28) ; le **paiement en ligne** avec un fournisseur de test puis **MTN Mobile Money** (1.29, 1.34) ; des **comptes** clients par code envoyé par e-mail (1.30) ; des **coupons** (1.31) ; des **SMS** (1.32) ; des **retours et remboursements** (1.33) ; la boutique comme première page ; une page d'accueil complète avec images de bannière, rangées, avis, lettre d'information et pied de page (1.34 à 1.36) ; six **rapports de ventes** (1.37) ; des **lettres d'information** envoyées depuis le programme (1.38) ; des **rappels de panier abandonné** (1.39) ; des **points de fidélité** (1.40).

## 1.23 à 1.26 : le français

Le français partout : écrans, messages, listes, titres de rapports, documents imprimés, e-mails et messages écrits par le serveur. Chaque utilisateur peut changer de langue, et l'entreprise a une langue par défaut (le Tchad démarre en français, le Rwanda en anglais).

## Avant la 1.23

1.1 licences de modules ; 1.2 à 1.4 Gestion locative, Immobilier et Cabinet d'avocats ; 1.5 pagination, recherche et exports partout, recouvrement, imports avec vérification préalable, contrôles comptables, listes de prix, promotions, cartes cadeaux et fidélité en caisse ; 1.6 à 1.10 RH et Paie, Hôtel, Restaurant, POS, Fabrication et quantités décimales ; 1.11 tickets avec le numéro fiscal, pagination du tableau de bord ; 1.12 impression thermique, tiroir-caisse et afficheur client ; 1.13 une caisse liée à un seul appareil ; 1.14 journaux du serveur, journal des connexions et journal d'audit élargi ; 1.15 à 1.22 Ordres de travail, Suivi du temps, Rendez-vous, Paiements échelonnés, Abonnements, Support client, Dépenses et Immobilisations.
