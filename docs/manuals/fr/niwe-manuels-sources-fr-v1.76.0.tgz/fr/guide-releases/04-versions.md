# Versions et changements de la base de données

La structure de la base change par des **migrations** numérotées (V70, V71, ...). La migration la plus récente appliquée à une base indique la version sur laquelle elle a été démarrée en dernier. Une base créée par une version **plus récente** ne peut pas être utilisée avec un programme **plus ancien** : le programme s'arrête au démarrage et nomme la migration qu'il ne connaît pas. Restaurez une sauvegarde dans la version qui l'a faite, ou utilisez le programme plus récent.

| Version | Thème | Migrations |
|---|---|---|
| 1.32 | SMS | V70 |
| 1.33 | Retours et remboursements | V71 |
| 1.35, 1.36 | Page d'accueil, images de bannière | V72, V73 |
| 1.38 | Envoi de lettres d'information | V74 |
| 1.39 | Rappels de panier abandonné | V75 |
| 1.40 | Points de fidélité | V76 |
| 1.42 | Plusieurs fournisseurs de paiement | V77 |
| 1.43 | Publicité | V78 |
| 1.44 | Page produit | V79 |
| 1.45 | Apparence de la boutique et jours de livraison | V80 |
| 1.46 | Notes et avis | V81 |
| 1.47 | Extras du compte (facture, adresses, liste de souhaits, WhatsApp) | V82 |
| 1.48 | Rangées de produits qui défilent | V83 |
| 1.50 | Variantes de produit | V84 |
| 1.51, 1.51.1 | Pages d'information, formulaire de contact et réponses | V85, V86 |
| 1.52 | Livreurs | V87 |
| 1.54 | Alertes de retour en stock | V88 |
| 1.56 | Réception des commandes (codes) | V89 |
| 1.57 | Espèces des livreurs | V90 |
| 1.58 | Livraisons échouées et partielles | V91 |
| 1.59 | Lien privé et PIN du livreur | V92 |
| 1.59.1 | Taxe pour chaque zone de livraison | V93 |
| 1.59.2 | Codes par SMS et e-mail | V94 |
| 1.61 | Créneaux heures de livraison | V95 |
| 1.62 | Retours à récupérer | V96 |
| 1.63 | Estimation de livraison par zone | V97 |
| 1.65 | Emplacement de stock de la boutique | V98 |
| 1.66 | Stock retenu et marges | V99 |
| 1.67 | Péremption et numéros de série | V100 |
| 1.69 | Prix des Ventes, poids et longueurs | V101 |
| 1.71 | Paiements en ligne dans les comptes, versements | V102 |
| 1.72 | Espèces chez les livreurs | V103 |
| 1.74 | Coût vendu et agence de la boutique | V104 |
| 1.75 | Un compte pour chaque fournisseur de paiement | V105 |
| 1.76 | Choisir les comptes de chaque fournisseur | V106 |

Les versions absentes du tableau (par exemple 1.41, 1.49, 1.53, 1.55, 1.58.1, 1.58.2, 1.60, 1.64, 1.64.1, 1.68, 1.70, 1.73) n'ont **aucune migration**.

## Vérifier la version d'une base

Un administrateur ayant accès à la base peut exécuter `select version, description, success from flyway_schema_history order by installed_rank desc limit 5;`. La première ligne est la migration la plus récente appliquée. Sans accès à la base, le journal du dernier démarrage liste les migrations exécutées et la version du programme.
