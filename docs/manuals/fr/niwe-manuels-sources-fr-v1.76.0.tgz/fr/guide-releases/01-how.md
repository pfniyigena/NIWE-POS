# Comment fonctionnent les mises à jour

## Pourquoi il y a de nouvelles versions

NIWE ERP s'améliore par petites étapes. Chaque étape est une **version** avec un numéro comme **1.76.0** et ses propres notes de version. Une nouvelle version apporte de nouveaux écrans, des corrections, et parfois un changement de la base de données. Ce document est le point de vue du client : ce que chaque version apporte, et ce que vous devez faire, le cas échéant, en passant à celle-ci. Il s'adresse au propriétaire de l'entreprise, à l'administrateur et à la personne chez NIWE qui s'occupe de l'installation.

## Ce qu'est une mise à jour, et ce qu'elle n'est pas

- Une mise à jour remplace le **programme** (le backend et les pages web). Vos **données restent** : ventes, factures, clients, stock et comptes sont dans votre base de données et sont conservés.
- Si la nouvelle version demande un changement de la **structure de la base**, elle le fait elle-même au premier démarrage (c'est ce qu'on appelle une *migration*). Les migrations sont numérotées, s'exécutent une seule fois, dans l'ordre, et ne sont jamais modifiées par la suite.
- Votre **licence**, vos **modules** et vos **paramètres** restent tels quels. Le personnel est déconnecté une fois et se reconnecte.
- Une mise à jour n'est **pas** automatique. NIWE (ou votre propre technicien) la fait un jour convenu avec vous, en général en dehors des heures d'ouverture. Rien ne change sous vos pieds.
- Vous pouvez passer **d'une ancienne version directement à la plus récente** ; les migrations intermédiaires s'exécutent dans l'ordre. Quand l'écart est grand, NIWE essaie d'abord la mise à jour sur une copie de vos données.

## Combien de temps cela prend

Une mise à jour normale arrête le système pendant **cinq à quinze minutes** : arrêt, remplacement, démarrage, vérification. Le premier démarrage après une version avec des migrations peut durer une ou deux minutes de plus. Choisissez un moment calme, et prévenez le personnel de l'heure. Les caisses continuent de vendre pendant une courte interruption et mettent les ventes en file d'attente (voir le chapitre POS du Manuel utilisateur) ; n'effacez pas le navigateur tant que des ventes attendent.

## Votre rôle

1. **Convenez du jour et de la version** avec NIWE. Lisez l'entrée de la version au chapitre 2 et toute **action** pour vous au chapitre 3.
2. **Clôturez la journée** si vous le pouvez : caisses fermées, rien de laissé à moitié.
3. **Soyez joignable** pendant la fenêtre, pour que quelqu'un puisse vérifier le système ensuite.
4. **Après la mise à jour**, connectez-vous, regardez les écrans que vous utilisez tous les jours, faites une vente de test ou une commande de test, et prévenez NIWE tout de suite si quelque chose semble anormal.

## Le rôle de NIWE, en bref

Avant de mettre à jour, NIWE fait une **sauvegarde**, la copie hors du serveur et garde la version précédente pour pouvoir revenir en arrière ; applique les actions ponctuelles de la version ; vérifie dans le journal les migrations et les erreurs ; et contrôle quelques écrans avec vous. Si quelque chose se passe mal, la version précédente et la sauvegarde sont remises en place (voir le Guide d'installation, chapitre 7).

## Les corrections entre deux versions

Les petites corrections portent un troisième numéro : **1.58.1**, **1.64.1**. Ce sont en général un seul changement et elles ne demandent aucune action.

## Lire un numéro de version

Le premier numéro ne change que pour une très grande étape. Le deuxième numéro change à chaque publication de nouvelles fonctions (1.76). Le troisième numéro est une correction (1.76.1). Les **notes de version** de chaque version sont la liste exacte et technique ; ce document en est la version courte pour l'entreprise.
