# Corriger les erreurs en sécurité

NIWE ERP garde une trace honnête : la plupart des choses sont **annulées, créditées, retournées ou contrepassées**, pas supprimées, et chaque correction figure dans le journal d'audit avec le nom de la personne. Utilisez cela.

## Quel outil pour quelle erreur

| Erreur | Outil | Remarques |
|---|---|---|
| Un document brouillon est faux | Le modifier ou le supprimer | Seul un brouillon peut être modifié librement. |
| Une facture émise est fausse | **Annulez-la** (ou **annulez et créditez-la** s'il y a des paiements) et créez-la de nouveau | Le stock et les comptes suivent. |
| Des marchandises sont revenues | **Retour de commande client** (ou **Traiter un retour** en caisse) | Reprend aussi la TVA et le coût. |
| Une quantité de stock fausse | **Correction de stock** ou **inventaire** | Toujours avec un motif. |
| Une écriture manuelle fausse | Une **écriture de contrepassation** | Les écritures comptabilisées ne se modifient pas. |
| Un mauvais montant remis par un livreur | Une **écriture** sur Espèces chez les livreurs, Caisse et banque et Écarts de caisse | Un règlement ne peut pas être annulé sur son écran. |
| Un versement enregistré deux fois ou pour le mauvais fournisseur | Une **écriture de contrepassation** par le comptable | Gardez la référence du fournisseur dans le libellé. |
| Un remboursement fait à la main et non enregistré | Enregistrez-le sur la commande (**Je l'ai remboursé moi-même** avec la référence) | |
| Un paiement *À vérifier* | Traitez-le, notez ce que vous avez fait, **Marquer comme traité** | Il n'est pas dans les comptes avant cela. |
| Un mauvais montant dans un mois clos | Un **administrateur** rouvre les comptes jusqu'à une date (la raison est journalisée), la correction est faite, les comptes sont clôturés de nouveau | Ou passez la correction dans la période ouverte avec un libellé clair. |
| Des données de client à supprimer | Le client supprime son compte dans le portail ; le personnel **retire** une adresse de lettre d'information ou un panier abandonné | |

## Ce qu'il ne faut jamais faire

- **Ne supprimez jamais de lignes par SQL** sur une base en production pour « faire le ménage » : les comptes y font référence.
- **Ne modifiez jamais une ligne d'écriture comptabilisée** dans la base.
- **Ne changez jamais à la main une licence ou un identifiant d'installation.**
- **Ne restaurez jamais une sauvegarde par-dessus un système en production** sans faire d'abord une sauvegarde fraîche de l'état actuel et sans prévenir tout le monde. Une restauration remplace toute la base : les ventes faites depuis la sauvegarde sont perdues.
- **N'activez jamais le profil `dev`** pour contourner une licence ou une permission.

## Si une restauration est vraiment nécessaire

1. Faites une **sauvegarde fraîche** de l'état actuel (pour pouvoir revenir).
2. Dites au client ce qui sera perdu (tout ce qui a été saisi depuis la sauvegarde choisie) et obtenez son accord.
3. Restaurez (Paramètres > Sauvegarde et données > Restaurer, ou les outils de la base : Guide d'installation, chapitre 7). Le système est en mode maintenance pendant l'opération.
4. **Redémarrez** l'application et vérifiez les données.
5. Aidez l'entreprise à ressaisir ce qui a été perdu, à partir du papier et des files d'attente des caisses.

## Quand le SQL est inévitable

Parfois un défaut laisse des données dans un état qu'aucun écran ne peut corriger. Alors : le développeur écrit et relit la requête ; vous faites une **sauvegarde immédiatement avant** ; vous l'exécutez dans une transaction sur une **copie d'abord** ; vous l'exécutez sur la base de production avec l'accord du client ; vous vérifiez le résultat dans les écrans ; et vous notez la requête et son résultat dans les notes du client. Une correction nécessaire deux fois devient une migration ou un écran.
