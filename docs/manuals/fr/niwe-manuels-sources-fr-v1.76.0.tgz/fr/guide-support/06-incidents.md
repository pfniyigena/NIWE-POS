# Incidents, communication et routines

## Traiter un incident de gravité 1

1. **Accusez réception** au client en quelques minutes : « Nous nous en occupons ; prochaine information à <heure>. »
2. **Stabilisez d'abord** : si le service est en panne, remettez-le en marche ; si de l'argent est en jeu, arrêtez la cause (désactivez le fournisseur dans les Paramètres de la boutique, suspendez les commandes avec **Suspendre les commandes pour l'instant**) avant de chercher la raison.
3. **Réunissez les faits** (chapitre 2), pas des suppositions. Faites une sauvegarde avant tout changement.
4. **Décidez** : corriger en avançant, ou revenir en arrière (remettre la version précédente et la dernière bonne sauvegarde).
5. **Informez le client** toutes les heures, avec des mots simples : ce qu'on sait, ce qu'on fait, ce qu'il doit faire (par exemple « continuez à vendre ; les ventes sont mises en file »).
6. **Une fois corrigé** : confirmez avec le client que cela fonctionne, et vérifiez les comptes (Suspens à zéro, soldes justes).
7. **Rédigez la note d'après-incident** sous deux jours : ce qui s'est passé, la cause, comment elle a été trouvée, comment elle a été corrigée, combien de temps cela a duré, ce qui a été perdu, et ce qui évitera que cela se reproduise (un contrôle, une alerte, un changement dans le manuel, un défaut pour le développeur).

## Les messages qui aident

- **Dites ce que vous savez et ce que vous ne savez pas.** « Les paiements MTN sont acceptés mais les commandes n'apparaissent pas ; nous vérifions » vaut mieux que le silence.
- **Donnez au client quelque chose à faire** : une solution de contournement (espèces seulement, retrait seulement), qui appeler.
- **Ne promettez jamais une heure** que vous ne pouvez pas tenir. Promettez la prochaine information.
- Utilisez la langue du client : le français pour le Tchad et beaucoup d'utilisateurs rwandais, l'anglais sinon.

## Faire remonter au développeur

Envoyez le rapport complet du chapitre 2, dites quel client et quelle gravité, dites ce que vous avez déjà essayé, et gardez une seule personne comme contact pour que le développeur ne reçoive pas la même question de trois personnes. Demandez une **version corrective** (avec une migration si nécessaire) ou une **solution de contournement**. Quand la correction est prête, elle est essayée sur une **copie des données du client** avant la mise en production, et le registre du client est mis à jour avec la nouvelle version.

## Routines d'assistance pour chaque client

**Chaque semaine** (quelques minutes par client) : le service est-il en marche et la version notée ; la sauvegarde de la nuit est-elle arrivée hors du serveur ; l'espace disque ; le journal d'erreurs ; les dates d'échéance du certificat et de la licence (prévenez le client 60 jours avant la fin de la licence).

**Chaque mois** : un court message au propriétaire avec la version, la disponibilité, le nombre de problèmes et comment ils ont été résolus ; rappelez au comptable la routine de fin de mois (rapprochement, Suspens à zéro, clôture des comptes, sauvegarde nommée) ; demandez si des changements de personnel demandent des changements de comptes.

**Chaque trimestre** : un **exercice de restauration** ; revue des comptes du personnel ; application des mises à jour de sécurité du serveur ; un coup d'œil aux notes de version pour une mise à jour utile et une proposition de fenêtre.

**Chaque année** : la liste de contrôle de sécurité (Manuel de l'administrateur, chapitre 13) et la rotation des secrets (Guide d'installation, chapitre 8) ; le renouvellement de la licence ; une revue pour voir si les modules et le nombre d'utilisateurs correspondent encore à l'entreprise.

## Garder les manuels honnêtes

Quand un client pose une question à laquelle les manuels répondent mal, ou un problème que les manuels ne listent pas, ajoutez-le aux tableaux de *Dépannage* et, si le programme aurait dû l'empêcher, envoyez-le au développeur comme souhait. Le meilleur document d'assistance est celui que l'administrateur d'un client peut utiliser seul.
