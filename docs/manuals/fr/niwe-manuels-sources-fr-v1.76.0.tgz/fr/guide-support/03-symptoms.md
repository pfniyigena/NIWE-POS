# Symptômes et que faire

Chaque tableau donne le symptôme, la cause probable et la première action. Les problèmes au niveau du client sont aussi dans le Manuel de l'administrateur (chapitre 14).

## Le système ne démarre pas, ou est lent

| Symptôme | Cause probable | Première action |
|---|---|---|
| L'adresse ne répond pas du tout | Serveur en panne, nginx arrêté, certificat expiré, DNS | Vérifiez le serveur, `systemctl status nginx`, la date du certificat, l'enregistrement DNS. |
| nginx répond *502 Bad Gateway* | Le backend ne tourne pas ou est sur un autre port | `systemctl status niwe-<client>` ; lisez la fin du journal ; vérifiez le port dans les paramètres et dans le fichier nginx. |
| Le service s'arrête tout seul juste après le démarrage | Une erreur de démarrage | Lisez la première ligne ERROR du journal : mot de passe de la base, *Migration checksum*, *Schema-validation*, *address in use*, *cannot write backups folder* (Guide d'installation, chapitre 6). |
| Très lent partout | Disque plein, mémoire, base occupée, un énorme rapport | `df -h`, `free -m`, `top` ; cherchez dans le journal les requêtes longues ; vérifiez que les sauvegardes ne tournent pas en pleine journée. |
| Après une mise à jour : *a migration it does not know* | Un ancien jar sur une base plus récente | Déployez le jar plus récent. N'utilisez jamais l'ancien jar sur cette base. |
| Après une restauration, les écrans sont faux | Une sauvegarde d'une autre version | Restaurez dans la version qui l'a faite ou une plus récente. Redémarrez l'application après une restauration. |

## Connexion, utilisateurs et licence

| Symptôme | Cause probable | Première action |
|---|---|---|
| Tout le monde est déconnecté d'un coup | Le service a redémarré, ou le secret de connexion a changé | Normal après une mise à jour ou après un changement de `app.jwt.secret`. Reconnectez-vous. |
| Une personne ne peut pas se connecter | Mauvais mot de passe, compte inactif, bloqué après de nombreux essais | L'administrateur réinitialise le mot de passe sur la fiche de l'employé ; vérifiez *Actif* ; regardez le journal des connexions. |
| *Mot de passe oublié* n'envoie rien | E-mail non configuré, ou la personne n'a pas d'e-mail enregistré | **Envoyer un e-mail de test** ; l'administrateur fixe un mot de passe à la main. |
| *PIN non reconnu* | Mauvais PIN, personne inactive, ou deux personnes le partagent (interdit) | Réinitialisez le PIN dans la liste des employés. |
| Un module est absent ou *ne fait pas partie de votre licence* | Pas dans la licence, non activé, licence expirée, ou le rôle n'a pas accès | Paramètres > Modules : l'état de chaque module ; la date d'échéance ; le rôle de la personne. |
| *L'interrupteur développeur est activé* | Le serveur a été démarré avec le profil `dev` | Redémarrez tout de suite sans le profil `dev`. |
| Une sauvegarde restaurée dit que la licence est invalide | Un nouvel identifiant d'installation (une nouvelle base vide) plutôt qu'une restauration | Une restauration garde l'identifiant. Pour une nouvelle base, demandez à NIWE une licence pour le nouvel identifiant. |

## Caisses, appareils et impression

| Symptôme | Cause probable | Première action |
|---|---|---|
| *Hors ligne* en caisse | La connexion au serveur est tombée | Continuez à vendre : les ventes sont mises en file et se synchronisent au retour. N'effacez pas le navigateur ; vérifiez ensuite la file hors ligne pour les éléments *Échoués*. |
| La caisse refuse : mauvais appareil | La caisse est liée à un autre PC | L'administrateur la délie, ou la lie à ce PC. |
| L'imprimante thermique n'imprime rien | Navigateur, https, connexion | Chrome ou Edge en https ou localhost ; *Connecter l'appareil* ; *Imprimer une page de test* ; lisez la ligne rouge qu'elle imprime. |
| Caractères étranges sur les tickets | Page de codes | *ASCII simple* dans les paramètres de l'appareil. |
| Une vente est refusée pour cause de stock | Le stock négatif est désactivé | Recevez ou corrigez d'abord le stock. |

## Comptabilité et rapports

| Symptôme | Cause probable | Première action |
|---|---|---|
| La balance n'est pas équilibrée | Elle ne peut normalement pas l'être : chaque écriture est équilibrée. Un solde de *Suspens* signifie qu'une comptabilisation était déséquilibrée et que la différence a été mise de côté | Ouvrez Suspens dans le grand livre ; trouvez l'écriture ; corrigez par une écriture de contrepassation ; signalez le type de source au développeur. |
| *Suspens* n'est pas à zéro | Comme ci-dessus | Pareil. Il doit être à zéro à chaque fin de mois. |
| *Impossible de comptabiliser : les comptes sont clos* | Une date de verrouillage est fixée | Un administrateur peut rouvrir jusqu'à une date (la raison est journalisée) ou l'écriture est datée après le verrouillage. |
| Un nouveau compte (Espèces chez les livreurs, un compte de fournisseur) manque | Le rattrapage après le démarrage n'a pas tourné, ou le plan est personnalisé | Attendez une minute après le démarrage et rechargez le plan ; s'il manque toujours, indiquez la version au développeur. |
| Un rapport semble faux | Filtres, dates, verrouillage | Vérifiez les dates et les filtres ; ouvrez la ligne de la Balance pour voir les écritures derrière un chiffre. |
| Les rapports en ligne ne concordent pas avec les factures | Une vente compte le jour où la commande a été **terminée**, pas commandée | Comparez par date de fin. Une facture annulée affiche 0. |

## E-mail et SMS

| Symptôme | Cause probable | Première action |
|---|---|---|
| Aucun e-mail n'arrive (réinitialisation, lettre d'information, suivi des commandes) | SMTP non configuré ou faux ; le fournisseur de messagerie refuse ; dossier spam | **Envoyer un e-mail de test** ; lisez l'erreur ; vérifiez la limite d'envoi du fournisseur. Un e-mail échoué ne bloque jamais le travail lui-même. |
| Les liens des e-mails ouvrent le mauvais site | `app.frontend-url` est faux | Réglez-le sur l'adresse https publique et redémarrez. |
| Pas de SMS | Aucun fournisseur choisi, limite quotidienne, mauvais numéro | Boutique en ligne > Messages texte montre chaque SMS et son résultat. Avec l'envoi intégré, les codes restent *En attente d'une société SMS*. |
| Une lettre d'information reste en *Envoi* | Lots et limite quotidienne | Voir le Manuel de l'administrateur (chapitres 7 et 14). |
