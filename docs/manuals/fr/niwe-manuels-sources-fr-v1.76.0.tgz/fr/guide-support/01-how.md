# Comment fonctionne l'assistance

## À qui s'adresse ce guide

Ce guide s'adresse aux personnes qui aident un client quand quelque chose ne va pas : le contact d'assistance de première ligne, le technicien qui s'occupe du serveur et le développeur que l'on appelle quand c'est un défaut. Il aide aussi l'administrateur d'un client à décider s'il corrige seul ou s'il appelle. Le chapitre *Dépannage* du Manuel de l'administrateur contient les problèmes au niveau du client ; ce guide ajoute la méthode, les endroits où regarder, les façons sûres de corriger les comptes, et les problèmes de boutique et de paiement qui surviennent dans la vraie vie.

## Trois niveaux

| Niveau | Qui | Ce qu'ils font |
|---|---|---|
| **1. L'administrateur du client** | La personne qui détient le compte Admin | Réinitialise les mots de passe, vérifie les rôles et les paramètres, lit les manuels, redémarre le navigateur d'une caisse, regarde les écrans listés dans ce guide. Résout la plupart des problèmes. |
| **2. Assistance NIWE / technicien** | La personne qui s'occupe du serveur | Lit les journaux, vérifie les services, les sauvegardes et le serveur web, applique les mises à jour, corrige la configuration, aide pour les questions comptables, réunit les faits pour le niveau 3. |
| **3. Développeur** | La personne qui modifie le programme | Corrige les défauts et écrit les migrations. Reçoit un rapport complet du niveau 2, jamais « ça ne marche pas ». |

## Quelle urgence

| Gravité | Signification | Objectif |
|---|---|---|
| **1 Arrêt** | Le système est en panne, personne ne peut vendre, ou de l'argent est perdu ou pris à tort (par exemple des paiements acceptés et non enregistrés). | Commencer tout de suite ; informer le client toutes les heures. |
| **2 Gênant** | Une fonction principale échoue pour certaines personnes (une caisse ne peut pas imprimer, un module ne s'ouvre pas, l'e-mail échoue), avec une solution de contournement. | Le jour même. |
| **3 Agaçant** | Un libellé faux, un rapport lent, une question. | Sous quelques jours. |
| **4 Souhait** | Une demande de changement. | Recueilli pour une version ultérieure. |

## Les règles qui protègent les clients

1. **Ne modifiez jamais les données d'un client par SQL** sur une base en production, sauf si le développeur a écrit la requête et que vous avez une sauvegarde faite **juste avant**. Utilisez les écrans du programme : annulation, avoir, retour, écriture de contrepassation.
2. **Ne modifiez ni ne supprimez jamais une migration**, et ne lancez jamais un ancien jar contre une base créée par une version plus récente.
3. **Ne demandez jamais un mot de passe** au téléphone ou dans un message. Demandez à l'administrateur de le saisir lui-même, ou de le réinitialiser.
4. **Ne copiez jamais les données d'un client** (une sauvegarde, une capture d'écran avec des noms de clients) dans un endroit qui n'est pas privé, et supprimez les copies de test quand vous avez fini.
5. **Écrivez-le.** Chaque appel a une ligne dans les notes du client : ce qui a été signalé, ce qui a été trouvé, ce qui a été fait, la version et le résultat.
