# La boutique en ligne, les paiements et les livraisons

Il s'agit ici d'argent et de clients : soyez prudent et notez ce que vous voyez avant de changer quoi que ce soit.

## « Le client a payé mais la commande n'est pas arrivée »

1. Ouvrez **Boutique en ligne > Paiements en ligne** et cherchez le téléphone du client ou le montant. Regardez le **statut** et l'indicateur.
2. **En attente** : le client n'a pas approuvé la demande, ou la réponse du fournisseur n'est pas encore venue. La boutique interroge le fournisseur sur chaque paiement en attente environ une fois par minute ; attendez quelques minutes. S'il reste en attente bien après le moment où il aurait dû se clore, il apparaît sous *Bloqués en attente*. Demandez au client de chercher la demande sur son téléphone ; un paiement non approuvé dans la limite de la boutique expire et le client peut payer de nouveau depuis la page de la commande.
3. **Payé** mais pas de commande dans **Nouvelles** : la commande arrive à la boutique quand le paiement est confirmé ; rechargez Commandes en ligne et regardez aussi dans **En attente de paiement**.
4. **À vérifier** : le montant ou la devise différait de la commande, ou la commande a été payée deux fois. L'argent est chez le fournisseur, **pas dans les comptes** tant qu'une personne ne l'a pas traité. Voir la section suivante.
5. **Échoué** ou **Expiré** : rien n'a été prélevé ; le client peut réessayer.
6. Le portail du fournisseur lui-même dit la vérité sur l'argent : vérifiez le paiement là-bas avec la référence. Si le fournisseur dit **payé** et que la boutique dit **en attente** depuis plus de dix minutes, vérifiez que l'**adresse du webhook** est donnée au fournisseur, que les clés du fournisseur sont valides (le journal du serveur indique quand un appel au fournisseur échoue), et que `app.frontend-url` et https sont corrects. Réunissez le code de la commande et la référence du fournisseur et envoyez au développeur un rapport complet.

> **Attention :** Ne terminez pas une commande à la main pour « que ça marche » tant que son paiement n'est pas clair. Réglez d'abord ce qui est arrivé à l'argent.

## Un paiement à vérifier

Ouvrez-le, lisez pourquoi. Cas typiques :

- **Payé deux fois** pour une commande : remboursez le second paiement via le fournisseur (Airtel : depuis le compte Airtel Money, à la main), ou enregistrez le remboursement que vous avez fait vous-même avec sa référence ; notez ce que vous avez fait ; appuyez sur **Marquer comme traité**.
- **Un montant différent** : décidez avec le client s'il faut rembourser la totalité et le laisser recommander, ou rembourser la différence. Ne modifiez jamais le prix de la commande pour l'ajuster au paiement.
- Après avoir appuyé sur **Marquer comme traité**, rien n'est comptabilisé automatiquement : les comptes ne reçoivent un paiement que par les étapes normales de la commande, et un remboursement que vous avez fait est comptabilisé quand vous l'enregistrez sur la commande. Si de l'argent reste non comptabilisé, prévenez le comptable et le développeur.

## Un remboursement

- Commande annulée ou refusée, payée en ligne : la commande apparaît dans **Remboursements à faire**. **Rembourser via le fournisseur** (MTN) ou à la main (Airtel ; tout fournisseur qui ne le peut pas) puis **Je l'ai remboursé moi-même** avec la référence.
- *Le fournisseur n'a pas confirmé le remboursement* : vérifiez d'abord le portail du fournisseur. S'il est passé, enregistrez-le à la main avec la référence ; **ne répétez jamais un remboursement**.
- Une commande terminée : utilisez **Retours**, pas Commandes en ligne.
- Vérifiez ensuite que le **compte d'attente** du fournisseur a baissé du montant du remboursement.

## « Le solde du fournisseur ne correspond pas à son relevé »

Le compte d'attente de chaque fournisseur (ce qu'il doit encore à la boutique) doit être égal à ce qu'il a encaissé depuis son dernier versement, moins les remboursements qu'il a faits, moins ses frais s'il les retient. Quand ce n'est pas le cas :

1. Listez ce que le relevé du fournisseur montre pour la période : paiements encaissés, remboursements, frais, versements. Listez ce que montrent le panneau **Versements** et le grand livre du compte d'attente.
2. **Un paiement dans le relevé et pas dans le grand livre** : il est *À vérifier*, *En attente*, ou c'est une commande payée avant l'existence des comptes. Retrouvez-le par la référence.
3. **Un versement manquant** : enregistrez-le (brut, frais, date, référence). **Un versement enregistré deux fois ou pour le mauvais fournisseur** : le comptable le corrige par une écriture de contrepassation.
4. **Des frais non enregistrés** : ils font partie de l'enregistrement du versement (brut moins frais arrive à la banque).
5. **Un solde sur l'ancien compte commun Mobile Money** : paiements d'avant l'existence des comptes par fournisseur. Soldez-le par un versement de la voie *Mobile money (paiements antérieurs)*.
6. **Un remboursement à la main non enregistré** : enregistrez-le sur la commande.

Un solde qui grossit sans cesse signifie que les versements ne sont pas enregistrés ; un solde qui devient négatif signifie qu'un versement a été enregistré deux fois ou pour le mauvais fournisseur.

## Les espèces des livreurs ne concordent pas

*Espèces chez les livreurs* dans le grand livre doit être égal au total *À remettre* des **Espèces des livreurs**. Une différence signifie : une commande a été livrée avant la version 1.72 (ses espèces sont allées à Caisse et banque) ; un règlement a été comptabilisé deux fois ou à la main ; ou une commande en livraison payée en espèces a été terminée sans que les espèces soient enregistrées (le client du livreur a touché *J'ai reçu ma commande* : cela ne prouve pas que l'argent a été encaissé). Un règlement ne peut pas être annulé sur son écran : le comptable le corrige par une écriture. Si le total d'un livreur ne concorde jamais, vérifiez la taxe du produit des frais de livraison (une taxe ajoutée par-dessus rend les espèces enregistrées plus élevées que ce que le client a payé).

## Livraisons et codes

| Symptôme | Cause probable | Première action |
|---|---|---|
| Le client n'a pas de code de livraison | Le message n'est pas arrivé, ou la société de SMS n'est pas connectée | Le code est sur sa page de commande et dans Mes commandes ; l'historique de la commande dit comment chaque message s'est passé ; le personnel appuie sur **Envoyer un nouveau code au client**. |
| Le livreur obtient « code faux » | Mal saisi, ou ancien code après l'envoi d'un nouveau | Demandez au client de relire le code sur sa page de commande. Cinq essais faux le bloquent 30 minutes : un nouveau code le débloque. |
| La page du livreur dit « appelez la boutique » | La fin de commande a été refusée (stock, lot, autre raison) | L'historique de la commande donne la vraie raison ; corrigez-la (par exemple le stock) et réessayez. |
| Le livreur ne peut pas ouvrir son lien | Lien désactivé ou remplacé, livreur inactif, cinq PIN faux, mauvais `app.frontend-url`, pas de https | **Afficher le lien** ou **Donner un lien** de nouveau ; faites un **Nouveau code PIN** ; vérifiez l'adresse. |
| Une commande reste *En cours de livraison* | Personne ne l'a terminée | Terminez-la avec le code, ou enregistrez **Livraison échouée**. |
| Un client ne peut pas choisir d'horaire de livraison | Créneaux désactivés, complets, trop proches, jour fermé, au-delà des jours à l'avance, ou commande en retrait | Paramètres de la boutique > Heures de livraison ; **Changer l'heure** sur la commande permet au personnel de choisir n'importe quel créneau. |
| Après une visite manquée, le client ne peut pas reprendre rendez-vous | Créneaux désactivés, ou la commande n'est pas *Emballée après une visite manquée* | Le personnel utilise **Changer l'heure** et téléphone au client. |
| Une récupération de retour ne peut pas être terminée | Aucun livreur affecté, mauvais code de retour, cinq essais faux, commande retirée en boutique | Affectez le livreur ; **Nouveau code de retour (renvoyer)**. Pour une commande retirée en boutique, le client rapporte les marchandises. |

## Stock et prix sur la boutique

| Symptôme | Cause probable | Première action |
|---|---|---|
| Un produit affiche *Épuisé* alors qu'il y a du stock | Marge, part gardée pour la caisse, unités retenues par des commandes sans réponse, lots périmés, stock hors d'un emplacement de vente | Lisez la ligne sous le produit dans Paramètres de la boutique > Produits de la boutique : elle liste chaque chiffre (Manuel de l'administrateur, chapitre 7). |
| On a vendu à un client quelque chose qui n'est pas là | Sur-promesse : une commande a été acceptée avec **Accepter quand même** | Téléphonez au client ; recevez du stock ou annulez la commande. |
| Un prix en ligne est faux | Un prix en ligne a été saisi sur le produit, ou une promotion s'applique, ou la liste de prix | La ligne du produit affiche *Offre des Ventes : prix (nom)*. **Appliquer maintenant** recalcule ; les prix se rafraîchissent toutes les 2 minutes. |
| Un produit n'apparaît pas | Non ajouté, **Affiché** décoché, inactif, ou une variante désactivée | Produits de la boutique. |
| Un lien collé dans WhatsApp n'a pas de carte | La règle nginx ou `app.frontend-url` | `curl -A "facebookexternalhit/1.1" "https://<adresse>/shop?product=12"` doit renvoyer une page avec `og:title`. WhatsApp garde un moment les anciens aperçus : ajoutez `&v=2` au lien. |
