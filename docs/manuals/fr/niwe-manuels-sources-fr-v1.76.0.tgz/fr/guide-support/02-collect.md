# Réunir d'abord les faits

Un problème qui arrive avec les bons faits est à moitié résolu. Demandez ces éléments avant de commencer, et notez-les dans le ticket.

## Les informations standard

1. **Qui et où** : le client, la personne, son rôle, l'appareil et le navigateur.
2. **La version** du programme et l'**identifiant d'installation** (Paramètres > Modules montre l'identifiant d'installation).
3. **Ce qu'ils ont fait** : les étapes exactes et l'écran, à partir du menu.
4. **Ce qu'ils attendaient** et **ce qui s'est passé** : les mots du message, mot pour mot (une capture d'écran est le mieux).
5. **Quand** : la date et l'heure, à la minute près, et si c'est arrivé une fois ou à chaque fois.
6. **Depuis quand** : après une mise à jour, un changement de paramètres, une coupure de courant, un nouvel utilisateur ?
7. **Qui d'autre** est touché (tout le monde, une caisse, une personne) ?
8. Pour une commande ou un paiement : le **code de la commande** (par exemple `9FMMY2MC`) ou le numéro de facture, et la **référence du fournisseur**.
9. Pour une erreur : l'**identifiant de requête** et les lignes correspondantes de `niwe-erp-error.log` (Paramètres > Journaux du serveur, ou le fichier sur le serveur).

## Les faits rapides que vous pouvez lire vous-même

- **Le service tourne-t-il ?** `systemctl status niwe-<client>` ; `curl -I https://<adresse>/api/public/store/...` ou ouvrez simplement l'adresse.
- **Le journal** : `tail -n 200 /opt/niwe/<client>/logs/niwe-erp-error.log`. Cherchez l'identifiant de requête, le code de la commande, le nom d'utilisateur de la personne.
- **Le journal d'audit** (Paramètres > Journal d'audit) : qui a fait quoi, quand : annulations, retours, changements de prix, corrections de stock, règlements, changements de paramètres, avec le nom de la personne.
- **Le journal des connexions** (Paramètres) : connexions réussies et échouées et d'où.
- **Le journal comptable** (Comptabilité > Écritures comptables) : pour une commande, cherchez son code ; chaque écriture d'une commande en ligne se termine par le numéro de la commande.
- **L'historique de la commande** (Boutique en ligne > Commandes en ligne > la commande) : chaque étape avec qui et quand, le résultat des messages de code (e-mail et SMS), et la raison d'une fin de commande refusée.
- **Messages texte** (Boutique en ligne > Messages texte) : chaque SMS avec son résultat.
- **Paiements en ligne** (Boutique en ligne > Paiements en ligne) : chaque paiement en ligne avec son statut et son indicateur.

## Ce qu'il faut envoyer au développeur

Un rapport complet contient : les informations standard ci-dessus, les **étapes exactes pour le reproduire**, les **lignes de journal** autour de l'heure (avec l'identifiant de requête), une **capture d'écran**, ce que vous avez déjà essayé, s'il est **reproductible sur une copie des données** (restaurez une sauvegarde dans une base de secours pour essayer, jamais sur la production), et la gravité. Si cela concerne de l'argent, ajoutez le code de la commande, le numéro de facture, les écritures comptables et les montants que vous attendiez.
