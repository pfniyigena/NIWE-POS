# Personnel de la boutique en ligne

*Répondre aux commandes, garder la boutique à jour, surveiller l'argent.*

## Chaque jour

- {{Online Store > Online orders}}, onglet {{New}} : {{Accept}} (réserve le stock) ou {{Reject}} (donnez un motif). Une commande en livraison reçoit un {{Driver}} ; puis {{Mark packed}}, {{Out for delivery}} ou {{Ready for pick-up}}. Le client reçoit un {{delivery code}} de 4 chiffres.
- {{Complete}} en saisissant le code que le client vous lit. Le personnel ne voit jamais le code ; {{Send a new code to the customer}} s'il l'a perdu. Imprimez le {{Delivery slip}} (une commande) ou la {{Run sheet}} (la journée d'un livreur).
- {{Delivery failed}} (choisissez un motif) quand personne n'était là ; le client choisit une nouvelle heure. **Le client ne garde qu'une partie** quand il ne prend qu'une partie des marchandises.
- {{Refunds due}} : {{Refund through the provider}}, ou remboursez à la main (toujours pour Airtel) et saisissez la référence avec {{I refunded it myself}}.
- {{Online Store > Online payments}} : regardez *À vérifier* (argent qui demande une personne ; il n'est pas dans les comptes tant que vous ne l'avez pas traité), *Remboursements à faire* et *Bloqués en attente*.
- {{Online Store > Messages}} (formulaire de contact) et {{Online Store > Waiting customers}} (personnes à prévenir quand un produit revient) : répondez-leur.

## L'argent, chaque semaine

- {{Online Store > Driver cash}} : saisissez ce que chaque livreur a réellement remis, écrivez un motif pour tout écart, {{Settle the selected}}. Cela doit correspondre au compte *Espèces chez les livreurs*.
- {{Online Store > Online payments > Payouts}} : enregistrez chaque versement d'un fournisseur (brut, frais du fournisseur, date, référence du relevé du fournisseur).
- {{Online Store > Sales reports}} : une vente compte le jour où la commande a été **terminée**.

## À la demande

- {{Online Store > Returns}} : {{Approve}} (un livreur récupère les marchandises avec un code de retour) ou {{Refuse}} ; quand les marchandises sont revenues, appuyez sur {{Goods received: put back and refund}} (cochez les numéros de série revenus).
- {{Online Store > Reviews}} : {{Approve}} ou {{Hide}} les nouveaux avis écrits ; {{Remove rating}} pour une note injuste.

## Garder la boutique à jour

- {{Shop settings > Products on the shop}} : titres, prix en ligne, page produit, et les cases {{Featured}}, {{Best seller}}, {{Offer}}, {{New}}.
- {{Front page}} : annonce, images de bannière, couleur, liens de pied de page. {{Online Store > Shop pages}} : lisez et adaptez les pages Conditions, Confidentialité, Retours et Livraison.
- {{Delivery areas}} (frais, taxe, jours), {{Delivery times}}, {{Drivers}} ({{Give a link}} donne une page privée et un PIN).
- {{Online Store > Abandoned carts}}, {{Online Store > Loyalty points}}, {{Online Store > Coupons}}, {{Online Store > Newsletter}}, {{Online Store > Send a newsletter}} (un test pour vous d'abord), {{Online Store > Advertising}}.

## « Il est écrit Épuisé »

- Sous le produit : *stock vendable − réservé − retenu par les commandes non traitées − tampon − part gardée pour la caisse = vendable maintenant*. Baissez le tampon, déplacez le stock vers un emplacement de vente, traitez les commandes de {{New}}, ou regardez les lots périmés.

> **Besoin de plus ?** Voir {{Online Store}} (chapitres 23 à 25) dans le Manuel utilisateur, ou demandez à votre administrateur.
