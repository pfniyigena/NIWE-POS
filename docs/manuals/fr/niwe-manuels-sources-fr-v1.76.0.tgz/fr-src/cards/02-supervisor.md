# Superviseur de poste et responsable

*Ouvrir et fermer les caisses, approuver les exceptions, surveiller les pertes.*

## Ouvrir et fermer

- {{POS > Registers & Terminal > Open session}} : affectez le caissier, saisissez le fond de caisse.
- {{POS > Shifts}} : voyez chaque poste avec son écart ; {{Force close}} ou {{Close all sessions}} si quelqu'un est parti sans clôturer.

## Approbations à la caisse

- Saisissez votre {{PIN}} sur l'écran du caissier pour approuver une grosse remise, une annulation, un ancien retour, un prix modifié ou une grosse sortie de caisse. Votre nom est enregistré comme approbateur.

## Contrôle quotidien

- {{POS > Voids & returns}} : chaque annulation, retour, remise, changement de prix et réimpression, avec l'approbateur.
- {{POS > Cash movements}} et l'écart de chaque poste.
- Rapports : {{POS Exceptions}}, {{POS Shift Comparison}}, {{POS Sales by Cashier}}.

## Responsables de restaurant

- {{End of day}} : régler les commandes ouvertes, compter le tiroir, clôturer la journée (rapport Z).
- Journal {{Voids & comps}} ; confirmations de {{Wastage}}.

## À retenir

- Vous voyez la liste {{Needs your attention}} du tableau de bord : traitez les retards, les stocks bas et les approbations en attente.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
