# Réception d'hôtel

*Réserver, enregistrer l'arrivée, facturer, enregistrer le départ.*

## Début de journée

- {{Hotel > Front desk}} : arrivées, clients présents, départs, chambres à nettoyer, chambres hors service.

## Réservation

- {{New booking}} ou {{Walk-in}} : choisissez ou ajoutez le client, l'arrivée et le départ, le type de chambre et la chambre, le plan tarifaire, la source, l'acompte.

## Arrivée

- Ouvrez la réservation > {{Check in}} > confirmez la chambre (elle doit être propre). Imprimez la {{Registration card}}.

## Pendant le séjour

- {{+ Charge}} pour les extras. {{Move room}}, {{Change departure}}.
- {{+ Split bill / bill a company}} quand quelqu'un d'autre paie une partie.

## Départ

- Ouvrez la réservation > {{Check out}}, encaissez, {{Print invoice}}.

## À retenir

- Les marques VIP et liste noire s'affichent sur la fiche du client. Les frais d'annulation, d'absence et de départ tardif suivent la politique de l'hôtel ; la réception peut les annuler.
