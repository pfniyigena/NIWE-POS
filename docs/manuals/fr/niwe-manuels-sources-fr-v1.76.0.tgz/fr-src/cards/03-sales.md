# Commercial

*Devis, commande, facture, encaissement.*

## Le parcours

- {{Quotation}} (offre), puis {{Sale order}} (accord), puis livraison, puis {{Invoice}}, puis {{Record payment}}. Vous pouvez commencer à n'importe quelle étape.

## Devis ou commande

- {{Sales > Quotations}} ou {{Sales > Sale orders}} > {{New}}. Choisissez le client (ou {{+ New customer}}), ajoutez les produits par nom, référence ou code, vérifiez les totaux, {{Save draft}}.
- Sur un devis : {{Send to customer}}, {{Mark accepted}}, {{Convert to sale order}}.
- Sur une commande : {{Confirm}}, {{Fulfil order}}, {{Generate invoice}}.

## Facture

- {{Issue invoice}} la rend officielle. {{Record payment}} (les paiements partiels sont acceptés).
- Facture erronée ? Brouillon : modifiez ou supprimez. Émise : {{Void invoice}}, ou {{Cancel & credit invoice}} s'il y a des paiements.

## Clients

- {{Customers > Collections}} montre qui doit et depuis combien de temps ; cochez les clients et {{Send reminder}}.
- {{Customer statement}} pour tout client et toute période.

## Prix

- Les clients d'un {{customer group}} reçoivent automatiquement la {{price list}} du groupe. Un prix saisi à la main n'est jamais remplacé.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
