# Livreur

*Livrer, prendre le code, remettre l'argent.*

## Votre page privée

- La boutique vous donne un **lien** et un **PIN** (envoyés séparément). Ouvrez le lien sur votre téléphone et saisissez le PIN. Vous ne voyez que **vos** commandes. Ne partagez ni le lien ni le PIN ; si le téléphone est perdu, prévenez la boutique pour un nouveau PIN.
- Après cinq PIN faux, le lien est bloqué 30 minutes ; la boutique peut le débloquer avec un nouveau PIN.

## Une livraison

- Chaque commande montre le client, le téléphone (touchez pour appeler), l'adresse et le plan, l'heure de livraison, **ce qu'il faut encaisser** et les marchandises.
- Remettez les marchandises. Demandez au client son **code de livraison à 4 chiffres** et saisissez-le sous **Remettre**. La commande est alors terminée. Ne demandez jamais le code avant d'avoir remis les marchandises, et ne l'écrivez jamais.
- Si le client est absent, refuse, ou si l'adresse est fausse : **ne terminez pas**. Appelez la boutique ; le personnel enregistre la livraison échouée.
- Si le client ne garde qu'une partie des marchandises : appelez la boutique ; le personnel l'enregistre.
- Code faux : demandez au client de le relire sur sa page de commande. Après cinq essais faux, le code est bloqué 30 minutes : la boutique en envoie un nouveau.

## Espèces

- Commande payée en espèces : encaissez exactement ce que la page indique (**ce qu'il faut encaisser**). Une commande payée en ligne n'a rien à encaisser.
- **Espèces que je détiens**, en haut, montre ce que vous avez pris et pas encore remis. Remettez-le à la boutique ; le personnel enregistre ce que vous avez remis. Un écart demande un motif.

## Retours à récupérer

- Une liste **Retours à récupérer** montre les retours de clients qui vous sont affectés. Récupérez les marchandises, demandez le **code de retour** du client, touchez **Récupérer les articles** et saisissez-le. La boutique vérifie les marchandises et rembourse le client.

> **Besoin de plus ?** Appelez la boutique (son téléphone est sur votre page).
