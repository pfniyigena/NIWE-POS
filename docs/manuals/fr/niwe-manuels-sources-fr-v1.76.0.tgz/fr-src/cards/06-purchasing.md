# Responsable des achats

*Commander, suivre et payer les fournisseurs.*

## Commander

- {{Purchase requisitions}} pour demander, {{Purchase orders > New}} pour acheter : fournisseur, date prévue, entrepôt de réception, lignes avec coût unitaire.
- {{Send to supplier}} par e-mail ou {{Print}}.

## Recevoir et facturer

- Les livraisons partielles sont acceptées. Quand tout est reçu, une {{Bill}} est générée. {{Issue bill}}, puis {{Record payment}}.
- Mauvaise marchandise ? {{Process a return}} sur la commande.

## Payer

- {{Suppliers > Record payment}} : montant, puis {{Suggest oldest-first}} pour répartir. Imprimez le reçu.

## Prix

- {{Supplier prices}} conserve les coûts convenus avec leurs dates de validité.

## Rapports

- Dettes en cours, Balance âgée des dettes, Achats par fournisseur ou par produit.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
