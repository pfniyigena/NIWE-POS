# Serveur de restaurant

*Prendre les commandes, les envoyer en cuisine, présenter l'addition.*

## Ouvrir une table

- Plan de salle > touchez une table libre > saisissez {{Guests}} > {{Open order}}. Notez les {{allergies}}.

## Commander

- Touchez les plats du menu ; choisissez les options ; ajoutez une {{note for the kitchen}} ; réglez {{Seat}} et {{Course}}.
- {{Send to kitchen}}. Les services suivants restent *en attente* jusqu'à {{Fire course}}.

## Modifications

- Une fois un article envoyé, le retirer demande un {{manager}} et un motif ({{Void it}}). {{Give free}} demande un motif.
- {{Move table}}, {{Merge into}}, {{Split / move items}} pour les convives qui paient séparément.

## Addition et paiement

- {{Bill}} imprime la pré-addition. {{Checkout}} : ajoutez les paiements (partage égal, par article ou par parts), choisissez le {{tip}}, ou {{Charge to room}} pour les clients de l'hôtel. Rendez la monnaie affichée.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
