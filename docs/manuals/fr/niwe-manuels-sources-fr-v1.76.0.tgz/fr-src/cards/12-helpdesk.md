# Agent du support client

*Répondre vite, tenir les délais.*

## Démarrer

- {{Help Desk > Overview}} : sans réponse, en retard, bientôt dus, les miens. Ouvrez d'abord {{Needs attention}}.

## Traiter un ticket

- {{Reply to the customer}} (envoyé par e-mail) ou ajoutez une {{Internal note}} ; {{Insert a saved reply}} pour les réponses courantes.
- En attente du client ? {{Wait for customer}} arrête le chronomètre du délai.
- {{Resolve}} avec des notes ; {{Close}} ; {{Reopen}} si nécessaire.

## Rangement

- {{Merge into another ticket}} pour les doublons. Liez une {{Invoice}} ou une {{Job}}. Ajoutez des {{Tags}}. Ne cochez {{Customer can see}} que sur les fichiers à partager.
