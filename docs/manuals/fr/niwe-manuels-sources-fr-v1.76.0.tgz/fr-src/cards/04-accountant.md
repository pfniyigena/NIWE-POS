# Comptable

*Tenir les comptes, clôturer la période.*

## Chaque jour et chaque semaine

- {{Customers > Collections}} et {{Purchases > Payables Aging}} : relancez et payez à temps.
- Approuvez les {{Expenses}} ({{Expenses > Expenses}} > cochez, {{Approve selected}}) ; regardez {{Overview}} pour les factures en retard ou proches de l'échéance.
- Enregistrez les paiements fournisseurs en proposant d'abord les plus anciennes ({{Suggest oldest-first}}).

## Fin de mois

- Examinez la {{Trial Balance}}, le {{Income Statement}}, le {{Balance Sheet}}, le {{Cash Flow}} ; lancez le {{Tax Report}}.
- {{Accounting > Controls > Bank reconciliation}} : saisissez la date et le solde du relevé, cochez les lignes qui correspondent jusqu'à ce que l'écart soit nul.
- Passez les amortissements ({{Assets > Run depreciation}}) et les {{journal entries}} manuelles (débits = crédits).
- {{Close the books}} jusqu'à la fin du mois (administrateur).

## Boutique en ligne (si l'entreprise en a une)

- Chaque fournisseur de paiement (MTN, Airtel, carte) a un **compte d'attente** (ce qu'il nous doit encore) et un **compte de versement**. {{Online Store > Online payments > Payouts}} : enregistrez chaque versement avec ses frais ; un solde qui grossit sans cesse ou devient négatif signifie qu'un paiement ou un versement manque.
- Comparez chaque mois chaque compte d'attente et de portefeuille avec le relevé du fournisseur. Vérifiez que **Espèces chez les livreurs** correspond au total « À remettre » de Espèces des livreurs, et que le compte **Suspens** est à zéro.
- **Crédit client à payer**, **Cartes cadeaux à honorer** et **Dette de points de fidélité** doivent correspondre à leurs listes de clients.

## Règles à retenir

- Ne modifiez pas les écritures passées ; contrepassez-les ou annulez le document d'origine.
- Le fret d'un achat va dans les {{Landed cost}} de la réception, pas dans une dépense à part.
- L'argent d'une carte cadeau est dû (dette) tant que la carte n'est pas dépensée.

## Paie

- Lancez la paie chaque mois, {{Approve and post}}, payez par le fichier bancaire, enregistrez les paiements d'impôts et de sécurité sociale. Les taux sont un point de départ : confirmez avec votre comptable.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
