# Tout employé (Mes RH et Mon temps)

*Libre-service.*

## Mes RH

- {{Clock in}} et {{Clock out}}. {{Request leave}} (type, dates, demi-journées). Consultez vos bulletins de paie une fois la paie approuvée, votre solde de congés et vos documents. Mettez à jour votre téléphone, e-mail, adresse et contact d'urgence.

## Mon temps

- Démarrez le {{timer}} ou ajoutez du temps à la main (saisissez 1:30, 1.5, 90m ou 2h). En fin de semaine, appuyez sur {{Submit for approval}}. Corrigez ce qui est {{Sent back}}.

## Mon profil

- Changez votre mot de passe et votre {{PIN}} (4 à 6 chiffres). Gardez-les secrets.
