# Magasinier

*Savoir ce que l'on a et où c'est.*

## Réception

- {{Purchases > Purchase orders}}, ouvrez la commande, {{Record a receipt}} : quantités reçues, numéros de lot ou de série, {{Landed cost}}. Imprimez le bon de réception.
- Les marchandises arrivent dans l'emplacement {{Receiving}} de l'entrepôt. Déplacez-les vers un emplacement de {{Sales}} avec un transfert de stock.

## Corrections

- {{Stock adjustments > New}} : produit, variation de quantité (+/-), motif. Elle reste *enregistrée* jusqu'à ce qu'un approbateur appuie sur {{Confirm}}.
- {{Stock counts}} : {{Start a stock count}}, imprimez la fiche, saisissez les quantités comptées, {{Submit for approval}}.

## Réapprovisionnement

- {{Inventory > Reorder}} liste ce qui est au niveau de réapprovisionnement ou en dessous. {{Create requisition}} le transforme en demande d'achat.

## Si l'entreprise a une boutique en ligne

- La boutique ne vend que depuis les **emplacements de vente** hors de l'entrepôt principal. Le stock qui arrive reste dans *Réception* jusqu'à ce que vous le déplaciez vers un emplacement de vente. Les lots périmés ne sont jamais vendus.
- {{Reorder}} montre deux colonnes de plus : {{Online orders}} (unités retenues par des commandes non encore traitées) et {{Waiting customers}} (clients qui attendent le retour d'un produit).

## Déplacer du stock

- {{Stock transfers > New}} : produit, emplacements de départ et d'arrivée, quantité. Entre agences, le destinataire appuie sur {{Receive}} et note tout manquant.

## Retrouver une information

- Fiche produit > {{Stock movement history}}. Rapports : Stock disponible et valorisation, Stock bientôt périmé, Stock dormant.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
