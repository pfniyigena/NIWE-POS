# Rendez-vous et accueil

*Rendez-vous et clients sans réservation.*

## Prendre un rendez-vous

- Réservation > {{New appointment}} : service, date, personne souhaitée, un créneau libre, pour qui. Si un acompte est demandé, une facture bloque le créneau ; cochez {{Confirm now}} pour l'ignorer.

## La journée

- {{Calendar}} par personne ou par salle ; {{Print day sheet}}.
- Lors de la visite : {{Mark done}} ou {{No-show}}. {{Move to another time}} ou {{Cancel appointment}} (la facture impayée est annulée).

## Rappels

- {{Send reminder now}} ou {{Download calendar file}}. Des rappels automatiques partent avant la visite.
