# Administrateur

*Configurer, sécuriser, sauvegarder.*

## Premier jour

- Changez le **mot de passe admin** et le secret JWT ; renseignez {{Business details}}, {{System settings}}, {{Taxes}}, {{Payment methods}}.
- {{Settings > Modules}} : copiez l'identifiant d'installation, installez la licence, n'activez que les modules nécessaires.

## Les personnes

- {{Staff > Roles}} pour les zones d'accès (Aucun / Consulter / Gérer). Sur chaque personne : rôle, permissions d'approbation supplémentaires, accès aux agences, **PIN**.

## Chaque semaine

- Vérifiez que la **sauvegarde** existe et téléchargez-en une hors du serveur. Examinez le {{Sign-in log}} et le {{Audit Log}}. Regardez les {{Server logs}} si quelque chose a échoué.

## Pour une boutique en ligne

- Réglez `app.frontend-url` sur l'adresse publique en https. Activez chaque fournisseur de paiement avec ses propres clés dans l'environnement du serveur, jamais dans un fichier qu'on copie. Donnez à chaque fournisseur ses **comptes** ({{Online Store > Online payments > Accounts by provider}}).
- Donnez à chaque livreur un {{link and PIN}} ({{Shop settings > Drivers}}). Ajoutez la règle du serveur web pour les aperçus de liens. Lisez et adaptez les pages Conditions et Confidentialité de la boutique.

## Avant une mise à jour

- {{Backup now}}, téléchargez la sauvegarde, puis suivez les notes de version.

## À retenir

- L'activation d'un module est définitive. Restaurer une sauvegarde remplace tout et demande un redémarrage.

> **Besoin de plus ?** Voir le chapitre correspondant du Manuel utilisateur, ou demandez à votre administrateur.
