import glob, os, re, json, subprocess, html
def md2html(path):
    return subprocess.check_output(['pandoc','--from','markdown+pipe_tables+task_lists-smart','-t','html5','--no-highlight',path]).decode()
def slugify(s): return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
manuals=[('admin',"Manuel de l'administrateur","Pour la personne qui installe, configure et entretient le système.",'fr/admin'),
         ('user','Manuel utilisateur','Utilisation quotidienne de chaque module, tâche par tâche.','fr/user'),
         ('cards','Fiches de démarrage rapide par rôle','Une page par rôle, pour démarrer rapidement.','fr/cards'),
         ('install',"Guide d'installation et de déploiement","Installer et faire fonctionner NIWE ERP pour un client : serveur, base de données, paramètres, mises à jour.",'fr/guide-install'),
         ('onboard',"Guide d'intégration d'un client","De la première conversation à la première clôture mensuelle, y compris le lancement de la boutique en ligne.",'fr/guide-onboarding'),
         ('releases','Notes de version et de mise à jour pour les clients',"Ce qu'apporte chaque version et ce qu'il faut faire lors d'une mise à jour.",'fr/guide-releases'),
         ('support',"Guide d'assistance et de dépannage","Trouver la cause, résoudre le problème, corriger les comptes en toute sécurité.",'fr/guide-support')]
pages=[]; nav=[]
for key,title,desc,folder in manuals:
    items=[]
    for i,f in enumerate(sorted(glob.glob(f'{folder}/*.md'))):
        h=md2html(f)
        m=re.search(r'<h1[^>]*>(.*?)</h1>',h,re.S)
        t=re.sub('<.*?>','',m.group(1)).strip()
        h=h[:m.start()]+h[m.end():]
        # callouts
        def callout(mm):
            inner=mm.group(1)
            kind='note'
            mk=re.match(r'\s*<p><strong>(Attention|Remarque|Conseil)[:\s]',inner)
            if mk: kind={'attention':'warning','remarque':'note','conseil':'tip'}[mk.group(1).lower()]
            return f'<div class="callout {kind}">{inner}</div>'
        h=re.sub(r'<blockquote>(.*?)</blockquote>',callout,h,flags=re.S)
        h=re.sub(r'<table>(.*?)</table>',r'<div class="tablewrap"><table>\1</table></div>',h,flags=re.S)
        h=h.replace('<h2 ','<h2 ').replace('<ul class="task-list"','<ul class="task-list"')
        slug=f'{key}-{i+1}-{slugify(t)[:40]}'
        text=re.sub('<.*?>',' ',h); text=html.unescape(re.sub(r'\s+',' ',text))
        pages.append({'id':slug,'manual':key,'n':i+1,'title':t,'html':h,'text':text})
        items.append(slug)
    nav.append({'key':key,'title':title,'desc':desc,'items':items})
data={'pages':pages,'nav':nav}
js=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
tpl=open('wiki_template_fr.html').read()
out=tpl.replace('/*DATA*/null',js)
open('out-fr/NIWE-ERP-Manuels-wiki.html','w').write(out)
print(len(out)//1024,'KB',len(pages),'pages')
