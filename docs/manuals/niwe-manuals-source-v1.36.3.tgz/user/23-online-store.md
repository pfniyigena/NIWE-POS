# Online Store

The **Online Store** module gives your business a public shop on the internet at `/shop` (for example `https://erp.yourbusiness.com/shop`). When the module is on, `/shop` is also the first page a visitor sees at the main address, with a **Staff Login** link for your own people. Customers choose products, order for **delivery** or **pick-up**, and pay **in cash** or **online** (mobile money or card, when your administrator has set up a payment provider). You answer each order, and an accepted order becomes a normal sale order, invoice and payment, so stock, accounting and reports stay in one place.

The module must be in your licence and activated by an administrator (Settings > Modules). The **Online Store** group then appears in the menu with **Online orders**, **Online payments**, **Returns**, **Reviews**, **Newsletter**, **Coupons**, **Text messages**, **Shop settings** and **Open the shop**. Staff need the **Operations** area to use them.

## What a visitor sees on the first page

From top to bottom, the first page of the shop shows:

1. an **announcement bar** (a short message, optionally a link);
2. the **header** with the shop name or logo, a **search** box, the cart, **Sign in** and **Staff Login**;
3. the **banner**: your pictures sliding one after the other, with a title, a text and a button;
4. four rows of products you choose: **Featured products**, **Best-selling products**, **Special offers and discounts** and **New arrivals**. Each row slides left and right by itself and by the arrows;
5. **Customer reviews** and the shop's average rating (real reviews only, see below);
6. a **newsletter** sign-up;
7. the **footer** with quick links, contact details, opening hours, an "about" text and links to your social pages;
8. below the rows, **All products** with the category buttons.

A part with nothing to show (no featured product, no review yet, no announcement) is simply left out. When a visitor searches or picks a category, the page goes straight to the matching products.

## Setting up the shop (manager)

Open **Online Store > Shop settings**.

### Products on the shop

Search a product and press **Add**. Only products you add here are shown or sold online. For each product you can set:

- **Title on the shop** and **Online price** (leave the price empty to use the normal price; an online price below the normal price shows the normal price crossed out as an offer);
- **Order**: the lower number comes first;
- **Shown**: untick to hide the product for a while;
- the four row ticks **Featured**, **Best seller**, **Offer** and **New**: the shop never picks products by itself, you decide which products appear in each row (up to 8 per row; the first three rows follow the **Order** number, **New arrivals** shows the most recently added first). Press **Save** at the end of the product's card.

The picture is the product's own picture: add one on the product screen. Under every product the screen shows where its stock figure comes from (see *Why does the shop say "Sold out"?* below).

### Front page wording

In **Front page** write what the first page says. Everything is optional.

- **Announcement bar** and its **link**; **Banner title**, **Banner text**, **Banner button text** and **Banner button link** (empty = down to the products).
- **Banner pictures**: choose up to **8 pictures** (JPEG, PNG, WebP or GIF, 8 MB each; you can choose several at once). Use the arrows to put them in order and **Remove** to take one away. They slide every few seconds on the shop, and a visitor can use the arrows, the dots, or swipe. A wide picture, about 1600 × 600 pixels, looks best. With no picture the banner is a plain colour.
- **About the shop**, **Contact e-mail** and **Opening hours** for the footer.
- **Footer links** and **Social links**: one per line, written **Label|address**, for example `Delivery|/shop` or `Facebook|https://facebook.com/yourshop`. At most 8 and 6. An address must start with `/` (a page of this site), `https://`, `http://`, `mailto:` or `tel:`; anything else is refused.

Press **Save the front page**, then **Open the shop** to look at it.

### Delivery, pick-up and the rest

1. **Delivery areas**: add each area you deliver to, with its **Fee** and an optional **Minimum order**. With no area the shop delivers anywhere for free. With areas, the customer chooses one.
2. **The shop**: choose the **Service product for the delivery fee** (a service product, ideally without tax added on top), set **Delivery**, **Pick-up** and **Pay cash on delivery or at pick-up**, the **Pick-up address**, the **Minimum order**, **Free delivery from** an amount, and **Units kept back for the till** (the shop sells that many fewer than you hold, so the last unit is not sold twice).
3. **Customer accounts**, **Text messages**, **Returns** (how many days after completion a customer may return goods; 0 = no returns through the shop) and **Online payments** are switched on here too. Your administrator sets up the providers (Administrator Manual, chapter 7).
4. Tick **Shop is open to the public** and **Save settings**. Use **Pause orders for now** to stop taking orders without taking the page down; the message you write is shown to visitors.
5. Press **Open the shop** and place a test order before telling customers.

*Tip:* Prices on the shop include tax. Customers see stock only as *Few left* (5 or fewer) or *Sold out*, never as a number.

## Why does the shop say "Sold out"?

You do **not** need a separate stock for the shop. The shop uses the same stock as the till and the warehouses:

> stock in the **sellable locations** of your warehouses − quantities **reserved** on confirmed sales orders − the shop's **buffer** ("Units kept back for the till", 1 unless you changed it) = what the shop may still sell

The line under each product in **Products on the shop** shows these four numbers. When the last one is 0 or less the shop says *Sold out*. If the line says *Stock is not tracked for this product*, the shop always shows it as available. When a product says sold out and you believe you have stock, look for:

| What you see | Usual reason | What to do |
| --- | --- | --- |
| The last number is exactly 0 and the first is 1 | The buffer of 1 | Lower **Units kept back for the till** to 0 in the shop settings |
| The first number is 0 but the product has stock | The stock sits in a location that is not sellable (*Receiving*, *Damaged*, an inactive location) or was never entered per warehouse | Open **Inventory** and the product's stock; move the goods to a sales location with a stock transfer (see the chapter on Inventory) |
| The first number is high and the second is high too | The goods are already promised on confirmed sales orders, including accepted online orders | Complete or cancel those orders, or add stock |

Stock that arrives on a purchase receipt sits in the *Receiving* location until it is moved to a *Sales* location.

## What the customer does

The customer opens `/shop`, searches or picks a category, adds products to the cart, and presses **Proceed to checkout**. They choose **Delivery** or **Pick-up**, give a name and a phone number (an e-mail address is optional), and for delivery an area and an address. Then they choose how to pay:

- **Cash on delivery** or **Cash at pick-up**. After **Place order** the order reaches you at once.
- **Mobile money** (they type the number to pay from and approve on their phone) or **Card**. After **Place order and pay** the order reaches you only once the payment is **confirmed**.
- A **coupon code** can be typed and checked with **Apply** before ordering (when you have an active coupon).
- When text messages are on, a box offers updates about the order by text (or WhatsApp).

They then see an order **code**. The page `/shop/order/<code>` shows where the order is, lets them cancel it while it is new, **order again**, ask for a **return** or write **reviews** once it is completed. If they gave an e-mail address, they receive a message when the order is received, accepted, on its way or ready, completed or refused.

A customer may also **sign in** (top of the shop): they type their e-mail address (or a saved phone number), receive a one-time code valid for 10 minutes, and then see their orders, keep their details and use **Order again**. No password is needed, and buying as a guest always works.

## Answering orders (staff)

Open **Online Store > Online orders**. The tabs are **New**, **Awaiting payment**, **Open**, **Refunds due**, **Completed**, **Rejected**, **Cancelled** and **Everything**. The **New** tab lists orders waiting for an answer, with their number in brackets and a *late* mark when one has waited too long. The list refreshes by itself, so it can stay open on a counter screen.

- **Accept** creates a confirmed sale order that holds the stock. If the stock does not cover the order, the screen says so and offers **Accept anyway**; the sale order is then over-promised until stock arrives. Phone the customer if you are unsure. An order paid online is already paid: there is no cash to collect.
- **Reject** needs a reason; the customer sees it. An order paid online and rejected shows under **Refunds due**.
- **Mark packed** (optional), then **Out for delivery** for a delivery or **Ready for pick-up** for a pick-up. The customer is told.
- **Complete** when the goods are handed over. This takes the stock out through the sale order, issues the invoice, and records the payment. For a cash order tick **Cash collected** unless the customer has not paid yet; choose **Take stock from** a location if your business uses several warehouses.
- **Cancel order** (accepted but not completed, for example nobody answered the door) cancels the sale order and releases the stock.
- **Awaiting payment** lists orders whose customer has not paid yet. They come to **New** when the payment is confirmed, and are cancelled by themselves after a day. A payment the customer does not approve within **Minutes the customer has to pay** (30 unless changed in the shop settings) expires, and the customer can try again from the order page.

A discount from a coupon is shown on the order (*Coupon ... : ... off the items*, or *delivery fee waived*). **History** lists every step with who did it and when.

## Refunds of online payments

When a customer who paid online cancels, or you reject the order, the order moves to **Refunds due**. Open it and press **Refund through the provider** to give the money back through the payment provider. If the provider cannot do it, refund by hand outside the program, type the **reference** of your refund and press **I refunded it myself**. Once an order is completed, goods coming back go through **Returns** (below).

## Online payments (report)

**Online Store > Online payments** lists every online payment for a period, with cards for **Paid**, **In the books**, **Held for open orders**, **Refunds due**, **Refunded**, **To review** and **Failed or expired**. A payment is recorded in the books as a payment on the invoice when the order is completed; until then it is held for the order. Use the filters to see what needs a person:

- **Under review**: money arrived that needs a person, for example a different amount than the order, or a second payment for the same order. Look at it, deal with it (for instance refund the extra), write what you did and press **Mark as dealt with**.
- **Refunds due** (press *Go to the orders to refund it*) and **Stuck pending** (a payment still pending long after it should have closed).

## Coupons

**Online Store > Coupons** holds the codes a customer types at checkout. When at least one coupon is active, the shop shows a coupon box.

- A coupon gives **Percent off the items** (with an optional *Never more than* amount), **Amount off the items**, or **Free delivery**.
- Optional limits: **Minimum order**, **Valid from**, **Valid until**, **Orders it can be used on**, and **Once per customer** (the same phone number or account).
- A rejected or cancelled order gives its use back. The discount is part of the sale order and the invoice, so the invoice always equals what the customer paid.
- One coupon per order, and it applies to the whole order, not to one product.

## Returns

A customer can ask to return goods from a **completed** order, within the number of days set in the shop settings (14 unless changed), from their order page. They choose the items and quantities, give a reason and the phone number of the order (not needed when signed in).

1. Open **Online Store > Returns**. The **Waiting** tab lists new requests. Press **Approve** or **Refuse** (a note for the customer is needed to refuse).
2. When the customer has brought the goods back, press **Goods received: put back and refund** (the **To refund** tab), choose where the goods go back in, and give the money back: **Refund through the provider** for an online payment, or the same by hand with its reference; for a cash order the screen says how much cash to hand back.
3. The goods go back into stock through a normal sale order return, so stock, revenue and reports follow. A coupon discount follows the goods (the customer gets back what they paid for them); the **delivery fee is not refunded**.

The customer is e-mailed at each step. Exchanges, store credit and restocking fees are not part of this screen.

## Reviews

A customer whose order is **completed** can review each product of that order from the order page (a rating of 1 to 5 stars and optional words), using the phone number of the order or their account. One review per product per order. Only **real** reviews exist: you cannot add one yourself.

Open **Online Store > Reviews**. A new review is **Waiting**: press **Approve** to show it on the shop, **Hide** to keep it but not show it, or **Delete** to remove it for good. Only approved reviews are shown and counted in the stars of a product and of the shop. The newest approved reviews with words appear on the first page.

## Newsletter

Visitors can ask for your newsletter at the bottom of the first page. The shop sends them an e-mail with a link; they are counted only after they open it. Open **Online Store > Newsletter** to see the list (**Subscribed**, **Not confirmed**, **Unsubscribed**), to **Remove** an address, and to **Download confirmed addresses (CSV)**, with each person's own unsubscribe link, for a mailing tool.

> **Note:** The program does not send newsletters itself. The downloaded file has four columns: `email`, `language`, `confirmed_at` and `unsubscribe_link`. Import it into your own mailing tool and put each person's **unsubscribe_link** in every message (most tools call this a merge field). The link opens a page that unsubscribes that person at once, and they no longer appear in the next download, so download the list again before each mailing. A person can also unsubscribe from the page they see right after confirming, and you can **Remove** an address here when someone asks. The newsletter needs the e-mail settings of the business to be working (Administrator Manual, chapter 9). Links in the file use `app.frontend-url` (Administrator Manual, chapter 7).

## Text messages

When your administrator has chosen a text provider, the shop can text customers about their order (only those who ticked the box at checkout), text sign-in codes, and text you about new orders. **Online Store > Text messages** lists every text, also the ones that failed or were not sent, and has a **Send test message** form. There is a daily limit to keep the cost in check.

## Good to know

- Online orders from a phone number that already exists in **Customers** attach to that customer; otherwise a customer is created.
- A customer may have only a few orders waiting for an answer at once, and a script that sends many orders from one connection is slowed down. These limits are in **Shop settings**.
- Not built yet: loyalty points on online orders, abandoned-cart reminders, and a sales report just for online orders (online orders appear in the normal sales reports).
