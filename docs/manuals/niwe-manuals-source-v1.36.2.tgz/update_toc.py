import sys, subprocess, time, os, uno
from com.sun.star.beans import PropertyValue
def pv(n,v):
    p=PropertyValue(); p.Name=n; p.Value=v; return p
def run(docx, pdf):
    proc = subprocess.Popen(['soffice','--headless','--invisible','--norestore','--accept=socket,host=localhost,port=2002;urp;'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    ctx=None
    for _ in range(40):
        try:
            local=uno.getComponentContext()
            res=local.ServiceManager.createInstanceWithContext('com.sun.star.bridge.UnoUrlResolver',local)
            ctx=res.resolve('uno:socket,host=localhost,port=2002;urp;StarOffice.ComponentContext'); break
        except Exception: time.sleep(1)
    smgr=ctx.ServiceManager
    desktop=smgr.createInstanceWithContext('com.sun.star.frame.Desktop',ctx)
    doc=desktop.loadComponentFromURL('file://'+os.path.abspath(docx),'_blank',0,(pv('Hidden',True),))
    idx=doc.getDocumentIndexes()
    for i in range(idx.getCount()): idx.getByIndex(i).update()
    doc.getTextFields().refresh()
    doc.storeToURL('file://'+os.path.abspath(docx),(pv('FilterName','MS Word 2007 XML'),))
    doc.storeToURL('file://'+os.path.abspath(pdf),(pv('FilterName','writer_pdf_Export'),))
    doc.close(True)
    try: desktop.terminate()
    except Exception: pass
    proc.wait(timeout=30)
if __name__=='__main__': run(sys.argv[1], sys.argv[2])
