import sys, subprocess, os, glob, re
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

NAVY = RGBColor(0x1F,0x3A,0x5F)
def build(folder, title, subtitle, out, version="Version 1.22.0"):
    here = os.path.dirname(os.path.abspath(__file__))
    ref = os.path.join(here, 'reference.docx')
    if not os.path.exists(ref):
        subprocess.check_call(['pandoc','-o',ref,'--print-default-data-file','reference.docx'])
        d = Document(ref)
        class _S:
            def __init__(self,styles): self.m={x.name:x for x in styles}
            def __getitem__(self,k): return self.m[k]
        st = _S(d.styles)
        def font(name, size, bold=None, color=None, face='Calibri'):
            s = st[name]; s.font.name = face; s.font.size = Pt(size)
            rpr = s.element.get_or_add_rPr(); rf = rpr.find(qn('w:rFonts'))
            if rf is None: rf = OxmlElement('w:rFonts'); rpr.append(rf)
            for a in ('w:ascii','w:hAnsi','w:cs','w:eastAsia'): rf.set(qn(a), face)
            for a in ('w:asciiTheme','w:hAnsiTheme','w:cstheme','w:eastAsiaTheme'):
                if rf.get(qn(a)) is not None: del rf.attrib[qn(a)]
            if bold is not None: s.font.bold = bold
            if color is not None: s.font.color.rgb = color
        for n in ('Normal','Body Text','First Paragraph','Compact'): font(n, 10.5)
        font('Heading 1', 22, True, NAVY); font('Heading 2', 15, True, NAVY); font('Heading 3', 12, True, RGBColor(0x2E,0x5C,0x8A))
        font('Title', 30, True, NAVY); font('Subtitle', 16, False, RGBColor(0x55,0x55,0x55))
        for n in ('Body Text','First Paragraph'):
            st[n].paragraph_format.space_after = Pt(6); st[n].paragraph_format.line_spacing = 1.15
        st['Heading 1'].paragraph_format.space_before = Pt(0); st['Heading 1'].paragraph_format.space_after = Pt(12)
        st['Heading 2'].paragraph_format.space_before = Pt(16); st['Heading 2'].paragraph_format.space_after = Pt(6)
        st['Block Text'].font.size = Pt(10)
        sec = d.sections[0]; sec.left_margin = sec.right_margin = Cm(2.2); sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
        d.save(ref)
    files = sorted(glob.glob(os.path.join(folder,'*.md')))
    tmp = out + '.tmp.docx'
    cmd = ['pandoc','--from','markdown+pipe_tables+task_lists-smart',*(['--number-sections','--toc','--toc-depth=2'] if not os.environ.get('NOTOC') else []),
           '--reference-doc',ref,'-o',tmp] + files
    subprocess.check_call(cmd)
    d = Document(tmp)
    # tables: borders + header shading + font size
    for t in d.tables:
        tblPr = t._tbl.tblPr
        b = OxmlElement('w:tblBorders')
        for e in ('top','left','bottom','right','insideH','insideV'):
            x = OxmlElement('w:'+e); x.set(qn('w:val'),'single'); x.set(qn('w:sz'),'4'); x.set(qn('w:color'),'B8C4D2'); b.append(x)
        tblPr.append(b)
        for ri,row in enumerate(t.rows):
            for c in row.cells:
                if ri==0:
                    tcPr = c._tc.get_or_add_tcPr(); sh = OxmlElement('w:shd')
                    sh.set(qn('w:val'),'clear'); sh.set(qn('w:fill'),'1F3A5F'); tcPr.append(sh)
                for p in c.paragraphs:
                    p.paragraph_format.space_after = Pt(2)
                    for r in p.runs:
                        r.font.size = Pt(9.5)
                        if ri==0: r.font.bold = True; r.font.color.rgb = RGBColor(255,255,255)
    # blockquote callouts: shade
    for p in d.paragraphs:
        if p.style.name == 'Block Text':
            pPr = p._p.get_or_add_pPr(); sh = OxmlElement('w:shd')
            sh.set(qn('w:val'),'clear'); sh.set(qn('w:fill'),'EAF1F8'); pPr.append(sh)
            bd = OxmlElement('w:pBdr'); l = OxmlElement('w:left'); l.set(qn('w:val'),'single'); l.set(qn('w:sz'),'24'); l.set(qn('w:color'),'2E5C8A'); l.set(qn('w:space'),'6'); bd.append(l); pPr.append(bd)
        if p.style.name == 'Heading 1':
            p.paragraph_format.page_break_before = True
    # cover page
    body = d.element.body
    first = body[0]
    def para(text, style=None, size=None, color=None, bold=False, align=None, before=0):
        p = d.add_paragraph(); r = p.add_run(text)
        if size: r.font.size = Pt(size)
        if color: r.font.color.rgb = color
        r.font.bold = bold
        if align is not None: p.alignment = align
        p.paragraph_format.space_before = Pt(before)
        return p
    cover = [para('', before=150), para('NIWE ERP', size=14, color=RGBColor(0x2E,0x5C,0x8A), bold=True),
             para(title, size=34, color=NAVY, bold=True), para(subtitle, size=15, color=RGBColor(0x55,0x55,0x55)),
             para(version, size=12, color=RGBColor(0x55,0x55,0x55), before=24)]
    br = OxmlElement('w:p'); r = OxmlElement('w:r'); bk = OxmlElement('w:br'); bk.set(qn('w:type'),'page'); r.append(bk); br.append(r)
    for p in cover: first.addprevious(p._p)
    first.addprevious(br)
    # TOC heading style + footer page numbers
    sec = d.sections[0]
    fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = fp.add_run(title + '  |  page '); run.font.size = Pt(8.5); run.font.color.rgb = RGBColor(0x77,0x77,0x77)
    r2 = fp.add_run(); r2.font.size = Pt(8.5)
    for t,txt in (('begin',None),('instr',' PAGE '),('end',None)):
        if t=='instr':
            e = OxmlElement('w:instrText'); e.set(qn('xml:space'),'preserve'); e.text = txt
        else:
            e = OxmlElement('w:fldChar'); e.set(qn('w:fldCharType'),t)
        r2._r.append(e)
    d.core_properties.title = title; d.core_properties.author = 'NIWE'
    d.save(out); os.remove(tmp)
if __name__ == '__main__':
    build(*sys.argv[1:6])
