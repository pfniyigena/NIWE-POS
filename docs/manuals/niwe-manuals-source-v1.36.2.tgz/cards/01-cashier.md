# Cashier

*Sell, take payment, count the till.*

## Start of shift

- Your supervisor opens the session on your register with the opening float (POS > Registers & Terminal > Open session).
- Press **Go to terminal** and type your **PIN**.

## Selling

- Scan the barcode or tap a product tile. Search by name or SKU if needed.
- Choose or add the **customer** if needed (credit, loyalty points).
- Press **Payment**, pick the method (split across several if needed), complete the sale.
- A discount over your limit, a void or a hand-changed price needs a **manager's PIN**.

## Returns and mistakes

- **Receipts** shows this shift's sales with **View / Reprint** (reprints are marked COPY).
- A return: **Process a return**, type the invoice number, choose items, refund method and reason.

## Cash

- Press **Cash** for paid-in, paid-out and safe drops. Drop cash into the safe when the drawer is heavy.
- **X report** any time; it changes nothing.

## End of shift

- Record paid-in, paid-out and drops first. Open the close screen, **count the drawer** by notes and coins, explain any difference, **Close session**, print the **Z report**.

## If the connection drops

- Keep selling: sales are queued and sync by themselves. Do not clear the browser or close it while the offline queue has sales.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
