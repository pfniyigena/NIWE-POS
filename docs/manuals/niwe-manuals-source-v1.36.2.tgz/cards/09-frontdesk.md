# Hotel front desk

*Book, check in, bill, check out.*

## Start of day

- **Hotel > Front desk**: arrivals, in-house, departures, rooms to clean, out of order.

## Booking

- **New booking** or **Walk-in**: choose or add the guest, arrival and departure, room type and room, rate plan, source, deposit.

## Check in

- Open the booking > **Check in** > confirm the room (the room should be clean). Print the **Registration card**.

## During the stay

- **+ Charge** for extras. **Move room**, **Change departure**.
- **+ Split bill / bill a company** when someone else pays part.

## Check out

- Open the booking > **Check out**, take payment, **Print invoice**.

## Remember

- VIP and blacklist flags show on the guest. Cancellation, no-show and late check-out fees follow the hotel policy; the desk may waive.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
