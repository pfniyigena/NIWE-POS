# Administrator

*Set up, secure, back up.*

## First day

- Change the **admin password** and the JWT secret; set **Business details**, **System settings**, **Taxes**, **Payment methods**.
- **Settings > Modules**: copy the installation id, install the licence, activate only needed modules.

## People

- **Staff > Roles** for access areas (None / View / Manage). On each person: role, extra approval permissions, branch access, **PIN**.

## Every week

- Check the **backup** exists and download one off the server. Review the **Sign-in log** and **Audit Log**. Look at **Server logs** if anything failed.

## Before an upgrade

- **Backup now**, download it, then follow the release notes.

## Remember

- Module activation is permanent. Restoring a backup replaces everything and needs a restart.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
