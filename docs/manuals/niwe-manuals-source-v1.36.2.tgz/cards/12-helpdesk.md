# Help desk agent

*Answer fast, keep deadlines.*

## Start

- **Help Desk > Overview**: unanswered, overdue, due soon, mine. Open **Needs attention** first.

## Work a ticket

- **Reply to the customer** (e-mailed) or add an **Internal note**; **Insert a saved reply** for common answers.
- Waiting on the customer? **Wait for customer** pauses the deadline clock.
- **Resolve** with notes; **Close**; **Reopen** if needed.

## Housekeeping

- **Merge into another ticket** for duplicates. Link an **Invoice** or **Job**. Add **Tags**. Only tick **Customer can see** on files you want shared.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
