# Shift supervisor and manager

*Open and close tills, approve exceptions, watch for loss.*

## Open and close

- **POS > Registers & Terminal > Open session**: assign the cashier, enter the float.
- **POS > Shifts**: see every shift with variance; **Force close** or **Close all sessions** if someone left without closing.

## Approvals at the till

- Type your **PIN** on the cashier's screen to approve a large discount, a void, an old return, a changed price or a big paid-out. Your name is recorded as the approver.

## Daily review

- **POS > Voids & returns**: every void, return, discount, price change and reprint, with who approved.
- **POS > Cash movements** and each shift's variance.
- Reports: **POS Exceptions**, **POS Shift Comparison**, **POS Sales by Cashier**.

## Restaurant managers

- **End of day**: settle open orders, count the drawer, close the day (Z report).
- **Voids & comps** log; **Wastage** confirmations.

## Remember

- You see the dashboard's **Needs your attention** list: act on overdue items, low stock and pending approvals.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
