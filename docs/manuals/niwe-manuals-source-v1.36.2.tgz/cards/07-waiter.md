# Restaurant waiter

*Take orders, send to kitchen, bill the table.*

## Open a table

- Floor plan > tap a free table > enter **Guests** > **Open order**. Note **allergies**.

## Order

- Tap menu items; choose options; add a **note for the kitchen**; set **Seat** and **Course**.
- **Send to kitchen**. Later courses wait *on hold* until you **Fire course**.

## Changes

- After an item is sent, removing it needs a **manager** and a reason (**Void it**). **Give free** needs a reason.
- **Move table**, **Merge into**, **Split / move items** for guests who pay separately.

## Bill and pay

- **Bill** prints the pre-bill. **Checkout**: add payments (split equally, by item or by shares), choose the **tip**, or **Charge to room** for hotel guests. Give back the change shown.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
