# Purchasing officer

*Order, track and pay suppliers.*

## Order

- **Purchase requisitions** to ask, **Purchase orders > New** to buy: supplier, expected date, receive-into warehouse, lines with unit cost.
- **Send to supplier** by e-mail or **Print**.

## Receive and bill

- Partial deliveries are fine. When fully received a **Bill** is generated. **Issue bill**, then **Record payment**.
- Wrong goods? **Process a return** on the order.

## Pay

- **Suppliers > Record payment**: amount, then **Suggest oldest-first** to allocate. Print the receipt.

## Prices

- **Supplier prices** keep agreed costs with validity dates.

## Reports

- Outstanding Payables, Payables Aging, Purchases by Supplier or Product.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
