# Booking and reception

*Appointments and walk-ins.*

## Make a booking

- Booking > **New appointment**: service, date, preferred person, a free time, who it is for. If a deposit is needed an invoice holds the time; tick **Confirm now** to skip.

## The day

- **Calendar** by person or room; **Print day sheet**.
- On the visit: **Mark done** or **No-show**. **Move to another time** or **Cancel appointment** (unpaid invoice is voided).

## Reminders

- **Send reminder now** or **Download calendar file**. Automatic reminders go out before the visit.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
