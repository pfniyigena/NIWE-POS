# Kitchen and bar

*Prepare, mark ready, remake.*

## Kitchen display

- Tickets move **waiting, cooking, ready**. **Start preparing**, **Mark ready**, **Mark served**, **Bump all** for an order.
- Tickets turn amber then red as time runs out. **ALLERGY** warnings show in red.
- **Remake** records a remade dish (counted in wastage reports).

## Sold out

- Press **Sold out (86)**, search the item, add a reason. It disappears from the waiters' menu until switched back.

## Expo

- The pass: check an order is complete, **Mark everything ready** or **Serve**.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
