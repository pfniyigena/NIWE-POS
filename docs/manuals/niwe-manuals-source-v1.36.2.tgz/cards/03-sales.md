# Sales clerk

*Quote, order, invoice and get paid.*

## The path

- **Quotation** (offer) then **Sale order** (agreed) then **Fulfil** (deliver) then **Invoice** then **Record payment**. You can start at any step.

## Quotation or order

- Sales > Quotations or Sale orders > **New**. Choose the customer (or **+ New customer**), add products by name, SKU or code, check the totals, **Save draft**.
- On a quotation: **Send to customer**, **Mark accepted**, **Convert to sale order**.
- On an order: **Confirm**, **Fulfil order**, **Generate invoice**.

## Invoice

- **Issue invoice** makes it official. **Record payment** (part payments are fine).
- Wrong invoice? Draft: edit or delete. Issued: **Void invoice**, or **Cancel & credit invoice** if payments exist.

## Customers

- **Customers > Collections** shows who owes and for how long; tick customers and **Send reminder**.
- **Customer statement** for any customer and period.

## Prices

- Customers in a **customer group** get the group's **price list** automatically. A price you type by hand is never replaced.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
