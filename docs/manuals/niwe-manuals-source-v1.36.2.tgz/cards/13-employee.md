# Every employee (My HR and My time)

*Self-service.*

## My HR

- **Clock in** and **Clock out**. **Request leave** (type, dates, half days). See payslips once payroll is approved, your leave balance and documents. Update your phone, e-mail, address and emergency contact.

## My time

- Start the **timer** or add time by hand (type 1:30, 1.5, 90m or 2h). At the end of the week press **Submit for approval**. Fix anything **Sent back**.

## My profile

- Change your password and your **PIN** (4 to 6 digits). Keep both private.

> **Need more?** See the matching chapter of the User Manual, or ask your administrator.
