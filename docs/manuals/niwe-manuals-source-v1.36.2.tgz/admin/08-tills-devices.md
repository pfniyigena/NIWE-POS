# Tills, printers and devices

## Registers

A **register** is a till. Create and edit registers under **POS > Registers & Terminal** (Admin only). Each register has a name, can be pinned to one specific *Sales* location of a warehouse (and, when multi-warehouse is on, must be assigned a warehouse other than Main), and can be tied to one device (below).

Cashiers do not need to be given register access one by one: a shift is opened on a register, and the terminal always asks for a **PIN** before it opens. The PIN identifies the cashier and starts or resumes their own working session on that shift.

## Binding a register to one device (version 1.13)

You can tie a register to **one known device** so that it can be used only from that PC.

1. Sit at the till PC and sign in as an Admin.
2. Go to **POS > Registers & Terminal** and press **Bind to this device** on the register.
3. Give the PC a name, and choose whether its network address must also match (the *IP check* option).
4. From then on, any other device is refused by the server for that register: the terminal, sales, opening a shift, offline sync and cash movements, each with a clear message.

Press **Unbind** (an Admin, from any device) to free it. Reports, receipts, history and closing a shift stay available from the back office. A device can be the till of one register only. Registers that are not bound behave as before. Binding and unbinding are written to the audit log (*REGISTER_DEVICE_BOUND* and *REGISTER_DEVICE_UNBOUND*).

If the server sits behind a reverse proxy and you use the IP check, set `app.device-binding.trusted-proxies` to the proxy's address so that the real address of the till is seen.

## Thermal printing and the cash drawer (version 1.12)

Thermal printing is configured **per PC, in the browser**, at **POS > Devices**, because each till has its own hardware. Nothing is stored on the server. The complete guide is in the file `THERMAL-PRINTING.md` supplied with the system; this is a summary.

### Connection types

| Connection | Use it when | Needs |
|---|---|---|
| **Windows driver** | You want the normal print dialog, laid out for the roll (exactly 80 mm or 58 mm, no margins). | Any browser, the printer's Windows driver. |
| **Serial / COM** | You want raw ESC/POS: native text, logo, QR code, cut, cash drawer. | Chrome or Edge on **https** or **localhost**; a printer with a serial port or a virtual COM port. |
| **USB** | Same raw printing over WebUSB. | Chrome or Edge; the printer on the WinUSB driver (for example with Zadig). |

Chrome or Edge ask once to allow each device (**Connect device...**); the permission is remembered for the site. If a direct printer does not answer, the document is printed through the Windows driver and a red line explains why.

### Setting up a till, step by step

1. Open **POS > Devices**.
2. **Receipt printer**: choose the connection, press **Connect device...**, pick the printer. For COM, choose the printer's baud rate (the printer's self-test page shows it).
3. **Paper and options**: paper width (80 or 58 mm), characters per line, code page (use *Plain ASCII* if strange characters print), cut after each document, open the drawer on cash sales.
4. Press **Print test page** and **Open cash drawer**.
5. Press **Save**.

### Restaurant printers

The **Kitchen printer** and **Bar printer** are optional. In *Stations on this printer*, type the station names exactly as on the menu items (for example `Grill, Cold` for the kitchen and `Bar` for the bar). Tick *Print kitchen / bar tickets when items are sent to the kitchen*. On the order screen, **Bill** prints the guest's bill (never opens the drawer) and **Tickets** reprints tickets still in the kitchen, marked REPRINT.

### What prints where

| Document | Printer |
|---|---|
| Sale receipt and its COPY reprints, return receipt, restaurant bill and paid receipt, X and Z reports | Receipt |
| Kitchen and bar tickets | Kitchen / Bar |
| Cash drawer pulse (cash sale, restaurant cash bill, *Open drawer* on the till) | Receipt printer |

A4 reports and documents print through the browser.

### Customer display on a COM port

Under *Customer display (COM)* tick *Use a customer display on this PC*, press *Connect COM port...*, choose the command set (**ESC/POS**, **CD5220** or **Plain text**), baud rate, data bits, parity and stop bits as set on the display (usual: 9600, 8, none, 1), characters per line (20 for a 2 x 20 display), and welcome lines. Press *Send test message*. On the till the display shows the item just added, then the running total, then PAID with THANK YOU or CHANGE, and the welcome text again.

There is also a second-screen **Customer display** on the till (a browser window) that shows the current cart and total to the customer.

## Settings made on each PC

Because device settings live in the browser, they must be repeated on each till PC and are lost if the browser's site data is cleared. Keep a note of each PC's printer settings.
