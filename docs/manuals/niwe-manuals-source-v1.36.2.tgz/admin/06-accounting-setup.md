# Accounting set-up

Accounting is a core module. Every sale, purchase, expense, payroll run, asset and stock movement posts to it, so it is worth setting up carefully before real transactions begin.

## Choosing the chart of accounts

The first time Accounting is used, a short wizard (the chart-of-accounts country screen) asks which standard chart to start from. The chart sets the account names and numbers and, for Rwanda (RWF) and Chad (XAF), the currency. Choose the chart that matches your country and accountant. After the wizard, **Accounting > Chart of accounts** lets you add, rename and deactivate accounts.

> **Tip:** Agree the chart with your accountant before the first posting. Accounts that already have postings cannot simply be deleted.

## Cost centers

**Accounting > Cost centers** are optional tags (a department, a project, a branch) that expenses, bills and journal lines can carry, so that you can report cost per center. Create them before you start entering expenses if you want per-center budgets.

## Journal entries

**Accounting > Journal entries** is for manual postings: accruals, corrections, opening entries. Most entries are posted automatically by the modules; manual journals should be rare and carry a clear description.

## Controls

**Accounting > Controls** holds the period controls an accountant uses:

- **Close books**: lock a period so that nothing can be posted into it any more. Use it after month-end or year-end review.
- **Bank reconciliation**: match the bank statement against the ledger. The screen shows at most the latest 2,000 ledger lines.
- **Ledger opening balances**: enter the opening balance of each account when you start using the system part-way through a financial year.

## Opening balances (starting on a running business)

1. Decide a cut-over date and close the old system for that date.
2. Import **opening stock** (Inventory) and **customer and supplier balances** with the importers in **Settings > Backup & Data** (chapter 10). Customer and supplier opening balances become real `OB-` invoices and bills, so they age and can be collected and paid like any other.
3. Enter **ledger opening balances** under Accounting > Controls for the accounts that are not covered by the importers (bank, equity, fixed assets and similar).
4. Check the trial balance against your old system before the first live day.

## Incomes

**Accounting > Incomes** records money received that is not a sale (interest, grants). **Expenses** have their own module with approval rules, VAT handling and budgets, described in the User Manual.

## Year-end

At year-end: review the reports, post any accruals and depreciation (assets depreciate monthly), use **Close books** for the closed period, and take a **Year-end archive** export (chapter 10).
