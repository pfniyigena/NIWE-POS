# Security checklist

Work through this list before the system holds real data, and again once a year.

## Before going live

- [ ] **Change the admin password** and remove or deactivate the demo `cashier` account (or change its password and PIN).
- [ ] Change **all terminal PINs** from the demo values (1234 and 5678).
- [ ] Set a long random **`JWT_SECRET`** (the `app.jwt.secret` setting). Anyone who knows it can forge a sign-in.
- [ ] Set **`app.seed-demo-data=false`**.
- [ ] Use your own database user and password (`DB_USER`, `DB_PASSWORD`), never share them in files that are copied around, and do not expose the database port to the network.
- [ ] Serve the system over **https** (a reverse proxy or web server certificate). This is also required for direct thermal printing on till PCs that are not on localhost.
- [ ] Set `app.cors.allowed-origins` to your real address only.
- [ ] Make sure the **`dev` profile** is never used and `app.license.dev-all-modules` is off.
- [ ] Set up **E-mail settings** so that staff can use *Forgot password?*, and give each person an e-mail address.
- [ ] Confirm that a nightly backup exists and that a copy leaves the server.

## Ongoing

- Give each person their own account; use custom roles and the approval permissions rather than extra Admins.
- Review **Staff** quarterly and untick *Active* for leavers immediately.
- Review the **Sign-in log** weekly for repeated failures.
- Review the **Audit Log** for voids, returns, price overrides and stock adjustments.
- Keep the server's operating system, Java, PostgreSQL and the browser up to date.
- Restrict who can reach the server physically and by remote access.
- Bind each register to its till PC (chapter 8) where tills sit in public areas.
- Download a backup before every upgrade and keep one off-site.

## If you open the Online Store to the internet

The public shop is the one part of NIWE ERP meant for strangers, so treat the server as exposed.

- Serve it over **HTTPS only** (a certificate on the web server or load balancer) and keep the admin screens behind the same address or a separate one you can restrict.
- Only `/shop`, `/shop/order/...` and the `/api/public/...` addresses are meant to be public. The staff screens still need a sign-in, and the shop's server calls never return costs, suppliers or other customers.
- Set `server.forward-headers-strategy=native` when a proxy sits in front, so the per-connection limit works (chapter 7).
- Keep **Orders waiting per phone** and **Orders per connection per hour** low, watch the **New** orders tab, and phone a customer before packing an unusual order.
- Only `/shop`, `/shop/order/...`, `/shop/newsletter/...` and the `/api/public/...` addresses are public. Customer sign-in uses one-time codes that expire and are limited; reviews, newsletter sign-ups and returns are limited per connection and per phone number, and a hidden field catches simple robots.
- Online payments: keep the payment provider's keys in the server's environment, never in a file that is copied or committed, and use the **live** keys only on the live server. A payment call-back is never believed on its own: the shop checks the payment again with the provider.
- Banner pictures are checked by their content, not their name, and shrunk; the footer and banner links written by staff are limited to `/`, `https://`, `http://`, `mailto:` and `tel:` addresses.
- Customers' names, phone numbers, addresses and newsletter e-mail addresses are personal data: back up daily, keep the backups private, and check what the data-protection rules of your country require before you launch.
- Have the server tested by someone outside the team before the shop is announced.

## What the system does for you

- Passwords and PINs are stored securely, not in clear text.
- Sign-in uses signed tokens that expire; every server request is checked against the person's role, areas and branch access, not just hidden in the menu.
- Locked modules are refused by the server, not only hidden.
- Deleting is limited: most records are voided, reversed or deactivated, leaving a trail in the audit log.
