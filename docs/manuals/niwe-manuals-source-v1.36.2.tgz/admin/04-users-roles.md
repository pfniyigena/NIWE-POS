# Users, roles and permissions

## The three layers of access

NIWE ERP controls what each person can do in three layers. Understanding them makes user set-up easy.

1. **The base role** of the account: **Admin** or **Cashier**. An Admin can do everything. A Cashier does day-to-day work (the till, and anything the next two layers add).
2. **A custom role** (optional, one per person), built under **Staff > Roles**. It adds *access areas* to a Cashier account, each set to *No access*, *View only* or *Manage*. Examples: Manager, Accountant, Store keeper.
3. **Extra permissions** (optional, per person): individual approval rights, such as *Approve expenses* or *Override the store-wide discount cap*, that you grant one by one without making the person an Admin.

On top of this, a Cashier can be limited to specific **branches**.

> **Note:** The server enforces all of this. Hiding a menu item is only a convenience; a person without access is also refused by the server if they try to reach the data another way.

## Creating a staff account

Go to **Staff** and press the button to add a new staff member. The form has these fields:

| Field | What to enter |
|---|---|
| **Username** | The sign-in name. |
| **Password** | The initial password. Ask the person to change it after the first sign-in. |
| **Full name** | As it should appear in reports and on approvals. |
| **Email** | Optional. Needed only so the person can use **Forgot password?** on the sign-in screen. |
| **Role** | **Cashier** or **Admin**. |
| **Custom role** | *None, plain cashier*, or a role you built under Staff > Roles. Gives the access of that role on top of normal cashier work. Admins always have full access. |
| **Active** | Untick to stop the person signing in without deleting the account. |
| **Extra permissions** | Individual approval rights (below). |
| **Branch access** | Visible when you have more than one branch and the role is Cashier. |

Press **Save**. To stop someone from working, untick **Active** rather than deleting the account: their name stays on past sales, approvals and audit entries.

> **Tip:** Give every person their own account. Shared accounts make the audit log and the cashier reports useless.

### Terminal PINs

Cashiers open the sales terminal and switch cashier by typing a **PIN**. Each person's PIN identifies them, so two cashiers can ring sales on one shift without logging out. On the **Staff** list, each row shows whether a PIN is **Set** or **Not set**, with a **Set PIN** / **Change PIN** button. A PIN must be 4 to 6 digits and unique among active staff. The demo accounts have PINs 1234 (admin) and 5678 (cashier); change them.

### Branch access

If the business has several branches, tick the branches a Cashier may work in. The person will then see and work only those branches' tills, sales and approvals. **Leave all unticked for access to every branch.** Admins are never limited.

## Custom roles

Open **Staff > Roles** and press **New role**.

- **Role name**: for example *Manager*, *Accountant*, *Store keeper*.
- **Description**: optional.
- **Active**: an inactive role gives its staff no extra access until it is switched back on.
- **What this role can do**: one line per access area, each set to **No access**, **View only** or **Manage**. *View* opens the screens and lists read-only. *Manage* also lets the person create and change things.

Two ready-made roles, **Manager** and **Accountant**, exist for you to use or copy.

### The access areas

| Area | Typical screens it opens |
|---|---|
| **Sales and customers** | Customers, quotations, sale orders, price lists, promotions, gift cards, loyalty, sale-order returns, shifts, cash movements, POS voids and returns, registers; customer payments and collections |
| **Billing and payments** | Invoices, recurring invoices, credit notes, refunds, bills, supplier payments, installments; customer payments and collections; turning approved time into an invoice; recurring expenses |
| **Inventory and purchasing** | Products, categories, brands, warehouses, suppliers, purchase requisitions and orders, purchase returns, stock adjustments, counts, transfers, reorder, packaging |
| **Operations** | Manufacturing, Restaurant, Subscriptions, Help Desk, Time tracking, Work orders, Booking, Law firm, Real estate, Property management; devices |
| **Accounting** | Chart of accounts, cost centers, journal entries, controls, incomes, expenses, **Assets** |
| **Hotel** | The whole Hotel module |
| **Human resources** | Employees, documents, onboarding, attendance, leave, org chart |
| **Payroll and contracts** | Contracts and payroll (these carry salary data, so they have an area of their own) |
| **Reports and dashboard** | The dashboard and the reports of each module (view only). Some salary reports stay locked even here. |

A report screen opens to a person who has *View* on **Reports and dashboard** *or* on the module's own area, so you can let a store keeper see inventory reports without opening the whole reports area.

Only one custom role can be given to a person. If someone needs the powers of two roles, make one combined role.

### Screens that cannot be delegated

The following are always **Admin only**, whatever roles you build: **Staff and Roles, Settings** (Modules, Payment methods, Taxes, Business details, System settings, Email settings, Scheduled reports, Apps, Audit Log, Sign-in log, Server logs), **Backup & Data** including import and export, and every module's own **Settings** page. Roles never open them.

## Per-person approval permissions

Some actions need a second pair of eyes: a manager approving a write-off, for example. Instead of making that manager an Admin, tick the specific rights under **Extra permissions** on their staff record. An Admin already has all of them.

| Permission | What it allows |
|---|---|
| Confirm/reject Restaurant wastage | Review a logged wastage entry: apply its stock and accounting effect, or discard it |
| Approve general Inventory stock adjustments | Review a logged stock adjustment |
| Approve Purchase requisitions | Approve or reject a requisition awaiting approval |
| Override the store-wide discount cap | Apply a discount at checkout and exceed the configured maximum discount |
| Approve/reject Expenses | Approve or reject an expense awaiting approval, and void an approved one |
| Approve large Expenses | Approve an expense above the approval limit set in Expenses > Settings |
| Approve large asset disposals | Dispose of an asset whose book value is above the limit set in Assets > Settings, and undo a disposal |
| Approve/reject Stock transfers | Review a logged transfer between warehouses |
| Approve voids and returns at the till | Approve a void or a large return by typing a PIN, without any other manager right |
| Approve price changes at the till | Approve a hand-changed price by typing a PIN |
| Approve big paid-outs and cash corrections | Approve a large paid-out, and cancel a mistaken cash movement |

> **Tip:** The three "at the till" permissions let you give a shift supervisor just enough power to approve exceptions by typing their PIN, without opening any back-office screen to them.

## Good practice

- Keep the number of Admins small (two is typical: the owner and one deputy).
- Review the staff list every quarter; untick **Active** for leavers on the day they go.
- Use the **Audit Log** (chapter 11) to see who approved what.
- Prefer a role plus a few extra permissions to making people Admin.
