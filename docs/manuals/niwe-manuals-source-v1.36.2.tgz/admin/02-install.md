# Installing and first start

## What the system is made of

NIWE ERP has two parts that run together:

- The **backend**, a Java 21 / Spring Boot application, which holds all the business rules and talks to the database. It listens on port **8080**.
- The **frontend**, an Angular 18 web application that staff open in a browser. In development it is served on port **4200**; in production it is normally built into static files and served by a web server.
- A **PostgreSQL** database that stores everything. The database structure is created and upgraded automatically by **Flyway**.

Staff only need a modern browser (Chrome or Edge is recommended; thermal printing needs one of these).

## Requirements

- Java 21 and Maven (to build or run the backend) or the packaged backend you were given.
- Node.js and npm (to build the frontend).
- PostgreSQL, with an empty database.
- For thermal printing from a till PC: Chrome or Edge, opened on **https** or on **localhost** (see chapter 8).

## First installation

1. **Create the database.** For example: `createdb pos_app`.
2. **Set the database connection.** Give the backend the address, user and password of your database through environment variables: `DB_URL` (for example `jdbc:postgresql://localhost:5432/pos_app`), `DB_USER` and `DB_PASSWORD`, and set `JWT_SECRET` to a long random value. Alternatively put the same settings (`spring.datasource.url`, `.username`, `.password`, `app.jwt.secret`) in a private file `config/application.properties` next to where the backend is started. No password is kept in the shipped files; from version 1.22.3 the shipped files hold only harmless defaults.
3. **Start the backend.** On the very first start Flyway creates all tables (migration V1, the baseline) and the licence tables (V2) and then applies every later migration. This can take a minute. Wait for the message *Started PosApplication*.
4. **Start the frontend.** In development: `npm install` then `npm start`, and open `http://localhost:4200`. If the backend is somewhere other than `localhost:8080`, change `API_BASE` in `frontend/src/app/core/constants.ts` before building, and add the frontend's address to `app.cors.allowed-origins` in the backend properties.
5. **Sign in** as `admin` with the password `admin123` (when demo data is on, the default). On a real installation without demo data, see *A real installation without demo data* below.

> **Warning:** The demo accounts (`admin` / `admin123`, `cashier` / `cashier123`, with terminal PINs 1234 and 5678) are only meant for the first start. **Change the admin password immediately**, and set `JWT_SECRET` (the `app.jwt.secret` setting) to a long random value of your own. Chapter 13 has the full checklist.

## Demo data

On the first start the system adds demo data: an admin and a cashier, four categories, eight barcoded products, a walk-in customer, the payment methods, a standard tax rate and one register. This is helpful for learning or for a first look. It is added only once.

### A real installation without demo data

For a real business, start the very first time with `app.seed-demo-data=false`. With no demo data and an empty database, the system creates one administrator, `admin`, so that you can sign in:

- If you set `app.initial-admin-password=` to a password of your own, that is the password.
- If you leave it empty, the system makes a random password and writes it **once** to the log, in a line that starts with *FIRST START* (chapter 11). Copy it, sign in, and change it at once under your profile.

This happens only when there are no users at all, so a restart never changes your password or creates another account. Without the demo data there are also no payment methods, taxes or register yet: create them in **Settings** (steps 5 and 11 below). Do not use the demo accounts on a server that real people can reach.

## Order of set-up for a new business

A sensible order that avoids rework:

1. Change the admin password (**Staff**, then your own account) and the JWT secret.
2. Fill in **Settings > Business details**.
3. Install the licence and activate modules (**Settings > Modules**, chapter 3).
4. Set **System settings** (currency, time zone, date format, discount mode).
5. Create **Taxes** and **Payment methods**.
6. Create **Branches** and **Warehouses** (if you have more than the head office).
7. Choose the **chart of accounts** and set the accounting controls (chapter 6).
8. Create **Roles** and **Staff** accounts (chapter 4).
9. Set up **E-mail settings** (chapter 9), then the settings of each module you use (chapter 7).
10. Import products, customers, suppliers and opening balances (chapter 10), checking each file first.
11. Set up registers, printers and devices (chapter 8).
12. Make a first manual backup (**Settings > Backup & Data**).

## Where the system keeps its files

Besides the database, the backend writes its log files (chapter 11) and keeps uploaded documents and photos in its storage folder. When the backend runs as a jar, for example as a service, the log files are written to a folder named **logs** next to the jar (`niwe-erp.log`, `niwe-erp-error.log`, `niwe-access.log`) and the database backups to a folder named **backups** next to the jar; both are created when missing, so the account that runs the service must be allowed to write in the jar's folder. Include both the database backup and the storage folder in your own server backup routine.
