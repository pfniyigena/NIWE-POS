# Backup, restore, import and export

All of this is on **Settings > Backup & Data** (Admin only).

## Backups

- A **full database backup runs automatically every night**. You can also press **Backup now** at any time.
- The list shows each backup file with its **size** and **creation time**, with **Download**, **Restore** and **Delete** buttons.
- **Where the files are:** when the server runs from its jar (for example as a Windows service), backups are written to a folder named **backups** next to the jar, beside the **logs** folder; the folder is created if it is missing. To use another folder, set `app.backup.directory` in `application.properties`, as an environment variable (`APP_BACKUP_DIRECTORY`) or on the command line.
- Backups include the Flyway migration history, so a restore brings the data and its structure version back together.

> **Warning:** The backup lives on the server. If the server is lost, so are the backups. Regularly **Download** a backup and copy it to another computer or cloud storage, together with the server's document storage folder.

### Restoring

1. Take a fresh backup of the current state first (**Backup now**), in case you restore the wrong file.
2. Press **Restore** next to the backup you want, or use *Restore from an uploaded backup file* for a file you downloaded earlier or brought from another machine.
3. Confirm. **Restoring replaces the entire current database.**
4. While it runs the whole system goes into **maintenance mode**: everyone else (cashiers, other admins) sees a "please wait" screen.
5. When it finishes, **restart the application** for a clean start.

> **Warning:** Restoring a backup made by a *newer* version into an *older* version makes the migration check fail ("a migration it does not know"). Deploy the newer version instead, then restore.

### Good practice

- Test a restore on a spare computer at least once, before you need it.
- Keep at least one backup per week for a month and one per month for a year, outside the server.
- Back up before every upgrade (chapter 12), every import, and before closing the books.

## Bulk import

**Bulk import** loads data from a CSV or Excel file. The importers include products, customers, suppliers, categories, brands, **customer balances**, **supplier balances** and **ledger balances**, plus module imports (employees, law clients and matters, real estate, and others) inside their own modules.

The process is always the same and is designed to be safe:

1. Press **Download template** for the importer you want and fill it in. Keep the header row.
2. Choose the file and press **Check file** first. It processes the file exactly as the real import would, but **saves nothing**.
3. Read the result: how many rows were read, how many **can be imported** and how many **will be skipped**, a list of **Rows that will be skipped** with the reason for each, and a preview of **what will be created**.
4. Correct the file and check again until the result is what you want. A row that cannot be used is skipped and listed with the reason; the rest of the file still imports.
5. Press **Import**. The result shows how many were imported and skipped.

Notes:

- **Opening balances** (customer and supplier) become real `OB-` invoices and bills, so they age, appear in statements and collections, and are paid like any other.
- For **ledger balances**, you can choose *Put any difference in Owner's Equity* so that the opening journal balances.
- Module imports read the first sheet only, up to 2,000 rows (.xlsx or CSV).
- Imports have not been tested on very large files; split big files.

## Export and year-end archive

- **Export products** and **Export customers** download the current lists.
- **Year-end archive** downloads a snapshot of one year's business activity (sales, purchases, payments, stock adjustments) for closing out a financial year.

> **Note:** The year-end archive is a curated snapshot, **not** a full database backup. Always keep a real backup as well.

Each list in the system also has its own **Excel, PDF and CSV** export, with the same filters as the screen.
