# Logs and monitoring

The system keeps three records of what happens. They answer different questions.

| Record | Question it answers | Where |
|---|---|---|
| **Audit Log** | Who changed what in the business? | Settings > Audit Log |
| **Sign-in log** | Who signed in, and who failed to? | Settings > Sign-in log |
| **Server logs** | What is the application itself doing, and why did something fail? | Settings > Server logs |

All three are Admin only.

## Audit Log

Every important action is recorded with the time, the user, an action code and a description. Examples: voids and returns, stock adjustments and their approvals, price and discount overrides, imports and exports, shift opening and closing, binding a register, role and staff changes, time-tracking budget warnings, and many module actions.

Use the filters at the top: a **search box** (user or description), an **action** drop-down (*All actions*), **From** and **To** dates and a page size (25, 50, 100, 200). The table shows **When, Who, Action, What happened**.

Typical uses: find out who approved a discount, who voided a sale, who changed a price, who exported the customer list.

## Sign-in log

Every sign-in attempt is recorded, successful or not. The top of the page shows how many people **signed in in the last 24 hours**, how many **failed attempts** there were, and how many **addresses had failures**. Below, filter by *User name*, by result (*All attempts*, *Signed in*, *Failed*) and by dates. Columns: **When, User name, Result, Why, Address, Device**.

Watch for many failures from one address or for one user name (a sign someone is guessing passwords). Press **Refresh** to update.

## Server logs

The server writes rotating log files. When the backend runs as a jar, for example as a service, they are in a folder named **logs** next to the jar (before version 1.26.2 they were in the jar's folder itself). When it is started from a development tool without a jar, they are in a `logs` folder where it was started. The setting `app.logging.dir` (or the environment variable `APP_LOGGING_DIR`) can point them to another folder, and then it wins.

The files are:

- `niwe-erp.log`: the normal application log.
- `niwe-erp-error.log`: warnings and errors only.
- `niwe-access.log`: one line per request.

Every line carries a **request id** and the **user**. The same request id is returned to the browser in the `X-Request-Id` header, so a support person can match what a user saw with the server's record.

On **Settings > Server logs**:

- Choose a file, a level (*All levels*, *Info and above*, *Warnings and errors*, *Errors only*), type a text to search, and pick how many lines to show (last 100, 300, 1000, 2000).
- **Auto-refresh** keeps watching. **Download file** gets the whole file (the screen shows only the last part of a large file).
- Before the server has written anything the page says *No log files yet*.
- Only files whose names start with `niwe-` and end with `.log` appear here. Other files in the same folder are never shown or downloadable from the screen.

When you ask NIWE for support, send the request id and the relevant part of `niwe-erp-error.log`.

The log behaviour is controlled by the `app.logging.*` properties in the backend settings (folder, size and number of files to keep). The account that runs the service must be allowed to write in the log folder; if it is not, no log files appear.

> **Tip:** After installing the backend as a service, start it once, then open **Settings > Server logs** to confirm the files appear. If the page says *No log files yet*, check that the service account can write in the jar's folder (it has to create the `logs` folder).

## Other places to look

- The **dashboard** has a *Needs your attention* section (overdue invoices, low stock, pending approvals and similar).
- **Settings > Modules** shows the licence status and expiry.
- Each module's **Overview** and **Reports** pages show its day-to-day health.
