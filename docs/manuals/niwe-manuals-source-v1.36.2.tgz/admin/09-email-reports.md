# E-mail, alerts and scheduled reports

## E-mail settings

Many features send e-mail: invoices, statements, reminders, daily digests, scheduled reports, forgotten-password links, public-page confirmations. They all depend on **Settings > Email settings**. Fill in:

- **SMTP host** and **port**: 587 (STARTTLS) or 465 (SSL).
- **Username** and **Password** of the mail account.
- **From email** and **From name**: what recipients see as the sender.
- **Skip certificate check**: only for a mail server with a self-signed certificate; avoid it when you can.
- **Business alerts email** (the "notifications email"): the address that receives system alerts, daily digests, low-stock e-mails and so on.

Press **Send test email** and check that it arrives. Many features show a message such as "Needs e-mail set up in Settings" until this works.

> **Tip:** For Gmail or Microsoft 365 accounts you normally need an *app password* rather than the person's normal password. Use a dedicated mailbox for the system, not a personal one.

A failed e-mail never blocks the underlying work: an invoice is still issued, a job still completed. Look at the server log (chapter 11) if mail does not arrive.

## Scheduled reports

**Settings > Scheduled reports** e-mails a report as an **Excel or PDF** attachment on a schedule.

1. Press to add a schedule and give it a **Name** (for example *Monday stock valuation*).
2. Choose the **Report** and the **Format** (Excel .xlsx or PDF).
3. Choose **Repeat**: Daily, Weekly (pick the weekday) or Monthly (pick the day of month), and the **time**.
4. Add optional filters (Category, Warehouse, Branch, Days) where the report supports them.
5. **Send to**: comma-separated addresses, or blank to use the notifications e-mail.
6. Tick **Active** and save.

How periods are chosen: reports that cover a date range send the period that **just ended**: yesterday for daily, the previous 7 days for weekly, the previous calendar month for monthly. Snapshot reports (stock valuation, ageing and similar) are taken at the moment of sending.

The list shows each schedule's last run. **Send now** sends it immediately; a paused schedule is marked *(paused)*. More than fifteen reports are available, including the asset reports added in version 1.22.

> **Note:** Scheduled reports are not stopped when the report's module is locked by an expired licence.

## Other automatic e-mails and daily jobs

| Job | Where it is switched on |
|---|---|
| Low-stock digest, automatic draft purchase requisitions | Inventory settings |
| Customer collection reminders (ageing) | Customers > Collections |
| Subscription billing, reminders and digest | Subscriptions job settings |
| Rent invoicing, tenant reminders, owner statements | Property management settings |
| Lead follow-ups, viewing reminders | Real Estate settings |
| Limitation-date warnings, fee reminders, daily deadlines | Law firm settings |
| Installment reminders | Installments settings |
| Booking and appointment reminders | Booking settings |
| Help Desk deadline warnings and automatic closing | Help Desk settings |
| Weekly timesheet reminder | Time tracking settings |

The jobs run once a day at the time shown in each module's settings, in the time zone of **System settings**. If the server was off at that time, a job runs when the server is next up the same day.
