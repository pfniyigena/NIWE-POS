# Law firm

The **Law firm** group has: **Overview, Matters, Clients, Deadlines & tasks, Billing, Fee collections, Client money, Templates, Reports, Settings**. Lawyers also have **My work** (their own deadlines and tasks) and log hours in **My time**.

## Clients and matters

A **matter** is one case or engagement. A client appears under **Clients** as soon as a matter is opened for a customer; clients are ordinary customers, shared with Sales.

### Opening a matter

**Matters > New matter**:

- **Title** (for example *Mukamana v. Habimana, land dispute*), **Client**, **Lead lawyer** (default: you).
- **Practice area**, **Jurisdiction**, **Court or forum**, **Court case number**, **Opened** date.
- **How it is billed**: *Hourly, Fixed fee, Retainer, Contingency, Pro bono / legal aid*, and a **Fee agreement** in words.
- **Description**.
- **Restricted: only the team and admins can open this matter**. Restricted matters are hidden from everyone else, including in lists, reports and fee collections.

**Run the conflict check on the next screen before you start work.** The **conflict check** searches clients, contacts and the opposing parties, lawyers and witnesses recorded on matters, and logs the search. Record each **party** on the matter (name, role, phone, e-mail, ID, note) so the check can see them.

### On the matter

The matter page has tabs and sections for the **team**, **deadlines**, **tasks**, **parties**, **documents**, **billing**, **client money** and **papers**. Matter status buttons: **Put on hold, Resume, Close matter** (enter the **Outcome**, how it ended), **Reopen**, **Delete**. A matter that still holds client money cannot be closed.

- **Deadlines and tasks**: add court dates, filing dates and limitation dates so nothing is missed: **What, Type, Date, Time, Assigned to**, notes. **Done**, **Reopen**, **Edit**, **Delete**. Tasks have **Due, Assigned to, Priority** (*Low, Normal, High, Urgent*) and **Start**.
- **Papers**: a file cover sheet, an engagement and fee letter, and a closing letter. Print them, keep them in the matter's documents, or e-mail the two letters to the client.
- **Documents**: upload and keep files on the matter; a client portal can share chosen documents.

## Deadlines, tasks and the calendar

**Deadlines & tasks** lists everything due, with filters for mine or everyone. The **Calendar** shows month and week views of deadlines (mine or everyone's), with tasks and finished items on request, and a **calendar file (.ics)** you can download into Outlook, Google Calendar or a phone. Lawyers see a **daily e-mail** of deadlines and tasks due soon or overdue if your administrator switched it on.

> **Warning:** **Limitation dates** are special. Missing one can lose the case. The lead lawyer and the person assigned receive e-mail warnings at the interval set in Law firm settings (first warning, a second 3 days before, and one if the date has passed and the deadline is still open). **Mark the deadline as done to stop them.**

## Time and billing

- Lawyers log hours in **My time** and pick the matter. Hours on hourly and retainer matters are billed; on other kinds they are tracked but not billed.
- On a matter's **Billing** tab: **Hours logged, Approved time to bill, Costs to bill, Fixed-fee stages to bill, Billed (before tax), Retainer left**. **Fee terms** shows and lets you change the rate, fixed fee, retainer or contingency %. **Rates per person** override the matter rate. Approve waiting time (**Approve selected** or **Send back** with a reason).
- **Costs paid for the client** (court and filing fees, travel, courier): record the date, what, paid to, cost, **Charge client**, and optionally **Also record in Expenses**. Charged costs go on the next invoice.
- **Fixed-fee stages** are billed as each stage completes.
- Create the invoice from the matter; **Open the invoice** to review and issue it. The **Billing** menu shows an overview across matters, and **Law billing and work in progress** is a report.

## Fee collections

**Fee collections** lists unpaid issued invoices with days late and a "how late" table. You can **send reminder e-mails** (one per client, with the fee statement attached), produce a **PDF statement of fees** per client (and e-mail it), and export the list. Automatic reminders can be switched on in settings.

## Client money (trust account)

Client money belongs to the client, not the firm, and is kept separately. If it is switched off, an administrator must turn it on in Law firm settings.

On a matter's **Client money** tab:

- **Receive money**: **Amount, Date received, How paid, Reference, Paid in by, What it is for**. A **receipt** can be printed. *Never put the firm's own money or its fees in the trust account.*
- **Pay out**: **Amount** (never more than the client has), **Date**, **How paid**, **Reference**, **Paid to**, **What it is for**. The money leaves **only after another person approves** (the matter's lead lawyer or an admin): you press **Ask for approval**. A **payment voucher** can be printed.
- **Pay an invoice from trust**: choose the invoice and amount; it is marked paid and the client's balance goes down when another person approves. A **fee transfer voucher** is printed.
- **Client statement**: choose dates, **Print statement** or **E-mail to the client**.

**Client money > Overview** shows what is held per client and matter and what is waiting to be paid out. **Reconcile** compares the trust account with the bank statement; a printable sheet exists for any past reconciliation.

## Templates

**Templates** keep standard letters and documents with fields filled from the matter.

## Importing clients and matters

An administrator or manager can **Import clients** and **Import matters** from Excel or CSV: download the template, choose the file, **Check** (nothing is saved), then **Import**. Time, deadlines, documents, invoices, fee amounts and stages are not imported; set the fees on the matter afterwards.

## Reports

**Law firm > Reports** (13): Law matters, Law deadlines, Law billing and work in progress, Law fees billed, Client money held, Client money ledger, Law workload, Law lawyer productivity, Law matter profitability, Law unpaid invoices by age, Law documents and client portal, Law conflict check log, Law caseload by practice area and court. Matters, clients, contacts, deadlines, tasks, billing, balances and ledger can also be exported from their own lists (restricted matters stay hidden from people not on the team).

## Settings (administrator)

Practice areas and jurisdictions, default billing basis, restricted-by-default, limitation warnings, unpaid fee reminders and the client money switch (Administrator Manual, chapter 7).
