# Manufacturing

The **Manufacturing** group has: **Bill of materials, Production plans, Manufacturing orders, Workstations, Routings, Indirect costs, Reports**.

## How production works

A **bill of materials (BOM)** is the recipe for one finished product. A **manufacturing order** says "make this many". When you **record production**, the components are taken out of stock, the finished goods are added to stock, and the cost of making them is worked out from materials, labour, machine time and indirect costs.

## Set-up (once)

### Workstations

**Workstations > New**: a **Code** (cannot change later), **Name**, **Description**, and an **Hourly rate**: the operating cost of that machine or work area per hour.

### Routings

A routing lists the steps (operations) to make a product. **Routings > New**: **Name**, **Description**, then **+ Add operation** for each step: **Seq** (order), **Operation name** (for example Cut, Assemble, Paint, Pack), **Workstation**, **Est. minutes/unit** and **Labour rate / hour**. At least one operation is needed.

### Indirect costs

Overheads such as rent share and power. **Indirect costs > New**: **Code**, **Name**, **Allocation method** and **Rate**:

- *Flat*: a fixed total spread over the order's runs in proportion to quantity.
- *Per unit produced*: the rate for every unit produced.
- *Percent of material cost*: a percentage of each run's material cost.

### Bill of materials

**Bill of materials > New**:

1. **Finished-good product**: the product this BOM makes (cannot be changed after creation).
2. Optionally a **Name** (for example *Standard*, *Alt, no walnut*; a product can have several BOMs) and a **Routing**.
3. **Components**: search a product and set **Quantity per unit**: how many of that component it takes to make exactly **one** unit of the finished good.
4. The screen shows the **Cost of one unit (today's prices)**: *Components, Labour, Machines, Cost per unit, After by-products, Selling price, Margin*. Indirect costs are added per order and are not included here. Save to refresh after editing.
5. **By-products** (optional): bran, offcuts, whey. Each good unit also puts the stated quantity of the by-product into stock, and a **Share of the cost (%)** is taken off the finished good's unit cost.
6. Tick **Active** and **Save**.

## Production plans

**Production plans** suggest what to make. A plan looks at **sales** and **low stock** and lists, for each product, the **Bill of materials**, the quantities **From sales** and **From low stock**, the **Suggested qty** and any **Component shortfalls**. Press **Generate order** on a line to open **Generate manufacturing order**: confirm **Quantity**, optional **Scheduled date** and indirect costs, and press **Create manufacturing order**.

## Manufacturing orders

### Create

**Manufacturing orders > New**: choose the **Bill of materials**, the **Planned quantity**, an optional **Scheduled date**, **Produce at** (the location where components are consumed and finished goods added), a **Note**, and any **Indirect costs to apply**. Orders are numbered *MO-0001*, *MO-0002*...

### Confirm

An order starts as a draft. **Confirm** fixes the recipe, indirect costs and location; afterwards only the planned quantity, date and note can change. **Copy as new draft** repeats an order. **Cancel order** abandons it. **Print job card** gives the shop floor a sheet with the steps.

### See what you need

The order shows **Components for the ... still to make**: *Per unit, Needed, On hand, Short by*. It tells you if stock is short ("Negative stock is allowed, so production will still go through" if your business allows it).

### Record production

Press **Record production**:

- **Quantity to produce now** (the remaining quantity is shown). **Use what stock allows** fills in the most you can make today.
- **Scrapped / rejected units** and a **Reason** (burnt, wrong size, failed check).
- Optionally the **Actual quantity used** of components (otherwise the recipe's quantity is used) and **Actual minutes taken**.

You can record production in several runs. Each run moves stock and posts the cost. The order shows **Produced, Scrapped, Yield %, Total material / overhead / labour / machine cost, Total cost, By-product credit** and **Unit cost**, compared with the **Planned cost**.

## Reports

**Manufacturing > Reports**: **Production runs, Cost per product, Component use against recipe, Workstation time and cost, Scrap and rejects, Orders: plan against actual.** Export to Excel, PDF and CSV. *Component use against recipe* and *Orders: plan against actual* show where waste and overruns happen.
