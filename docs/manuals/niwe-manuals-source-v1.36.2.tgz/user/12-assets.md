# Assets

The **Assets** group (fixed-asset register) has: **Asset register, Overview, New asset, From purchases, Categories, Verification, Reports, Settings**. It tracks things the business owns for years (vehicles, computers, furniture, equipment), depreciates them, and posts the entries to Accounting.

## Categories (set up first)

**Assets > Categories** defines the defaults for each kind of asset: **Name**, **Method**, **Useful life** (in months), **Salvage value (% of cost)** and **Prorate the first month by days**. A new asset of that kind starts with these. Changing a category later does not change assets already registered. A category may have its own accounts (asset, accumulated depreciation, depreciation expense); left empty, the standard accounts are used. Examples: *Computers* (36 months), *Vehicles* (60), *Furniture* (84).

## Registering an asset

**Assets > New asset**:

| Field | Meaning |
|---|---|
| **Asset name** and **Tag** | For example *Delivery van*. If the tag is left empty one is generated (FA-0001...). |
| **Branch**, **Category** | Where it belongs and what kind it is. |
| **Purchase date**, **Cost** | When and for how much. |
| **Depreciation Method** | *Straight line* (same amount each month) or *Declining balance* (bigger early). **Useful life (months)**, **Salvage value**, **Start depreciating in**, **Prorate the first month by days**. |
| **Depreciation already charged before this system** | For an asset you already own: set *Start depreciating in* to the first month still to be charged. This opening amount is not posted to Accounting. Record it with a journal entry if needed. |
| **Purchase posting** | *Don't post* (the purchase is already in the books), *Post: paid in cash*, or *Post: owed to the supplier*. |
| **Location, Held by, Serial number, Supplier** | Where it is and who has it. |
| **Warranty ends, Insurance ends, Insurance policy** | The register and overview warn you before these dates. |
| **Notes**; photos and files | Attach several photos and files, such as the invoice and warranty card. |

**From a purchase** turns an item on a received purchase order into an asset in one step.

## The asset register

The register lists assets with **Tag, Asset, Category, Purchased, Cost, Accumulated, Book value, Branch, Place, Held by, Status** and totals at the top. Use the search (tag, name, serial, holder, place), filters (category, branch, place, held by) and **quick views**: *All assets, Active, Fully depreciated, Disposed, Warranty ending, Warranty ended, Insurance ending, Insurance ended*.

**Run depreciation** charges every full month up to the date you choose that has not been charged yet and posts it to Accounting. It also runs by itself every day for months that have ended.

Tick several assets for bulk actions: **Move...** (to another branch or place, with date and reason), **Hand out...** (to a user or a typed name), **Take back**, **Print tags**.

## Working with one asset

Open an asset to see its details and **history of everything done to it**. Buttons:

- **Print tag**: a printable QR tag to stick on the asset.
- **Maintenance history**.
- **Edit**: details only. If depreciation or the purchase posting already exists, cost, dates and depreciation terms cannot be edited here; use the actions below.
- **Transfer...**: move it to another branch (depreciation up to the month before stays with the old branch; later months go to the new one) and/or a new location.
- **Add an improvement**: money spent that makes the asset worth more or last longer is added to its cost; depreciation is spread again over the remaining life from the month after.
- **Write the value down (impairment)**: for damage or when worth less than the book value. It is charged as an expense and added to the accumulated depreciation.
- **Change the depreciation terms**: new remaining life, salvage value or method, from the month after the date you choose. Months already charged are not changed.
- **Take back the last month of depreciation**: removes the latest charge with a reversing entry. Not possible if an improvement, write-down or change of terms is dated after that month.
- **Hand this asset to someone**: gives custody to a user or named person and prints a **handover sheet**.
- **Dispose...**: enter the **Disposal date**, **Sale proceeds** (0 = written off) and a note. Depreciation is charged to the month before disposal, then Accounting records the cash received, removes the asset and its accumulated depreciation, and books the gain or loss. **A book value above the approval limit needs an administrator or a user with the *Approve large asset disposals* right.**
- **Undo disposal...**: a person with approval rights can reverse a disposal made by mistake. Accounting gets a reversing entry and the asset becomes active again.
- **Delete**: only for an asset that has no postings.

## Verification (physical counting)

**Assets > Verification** checks that assets are really where the books say.

1. **Start a round**: give it a **Name** (for example *Year-end count*) and limit it by **Branch, Category** or **Place**. **Start Round** lists the assets that should be there.
2. Walk around and mark each asset **Found**, **Missing** or **Damaged** (with **found at** and a note). **Mark everything still unchecked as Found** speeds up a quiet round. **Move assets to the place where they were found** corrects locations.
3. **Close the round** once everything is checked.
4. A **Missing** asset can be **Written off...** from the round.

## Overview

**Assets > Overview**: **Assets in use, Total cost, Accumulated depreciation, Book value, Next month's depreciation, Fully depreciated, Disposed, Nobody holding, Open verification rounds**, a warning if depreciation is **months behind**, breakdowns **by category** and **by branch**, and a watch list: warranty or insurance ending soon, and assets that will be fully depreciated soon.

## Reports

**Assets > Reports**: Asset Register, Assets by Category, Assets by Location, Assets by Holder, Warranty and Insurance Expiry, Depreciation Forecast, Fixed Asset Movement, Asset Verification, Depreciation Schedule, Asset Disposals, Asset Transfers.

## Settings (administrator)

The warning days for warranty and insurance, the *fully depreciated soon* window, and the **disposal approval limit**.
