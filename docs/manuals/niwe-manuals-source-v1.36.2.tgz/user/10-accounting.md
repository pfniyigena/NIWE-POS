# Accounting

**Accounting** is the ledger that every other module posts to. The group has: **Chart of accounts, Cost centers, Journal entries, Controls, Incomes, Reports**, and, when the Expenses module is used, the Expenses pages (next chapter).

> **Note:** Most entries are posted **automatically**: a sale posts revenue, tax and stock cost; a purchase posts stock and payables; payroll, depreciation, hotel night audit and so on post by themselves. Manual journal entries are for the exceptions. Setting up the chart of accounts and the controls is described in the Administrator Manual (chapter 6).

## Chart of accounts

**Accounting > Chart of accounts** lists accounts (Code, Name, Description, Status). Accounts marked *system* are posted to automatically and cannot be deactivated.

**New account**: **Code** (cannot be changed later; for example 5300), **Name** (Rent Expense), **Type** (*Asset, Liability, Equity, Revenue, Expense*), **Description**, **Active**. Press **Ledger** on an account to see every transaction on it between two dates, with a running **Balance**.

## Cost centers

**Cost centers** are tags (department, branch, project) that journal lines, expenses and incomes can carry, so that you can report cost by center. **New cost center**: Code, Name. Use *Inactive* to retire one.

## Journal entries

**Journal entries > New manual journal entry**:

1. **Date** and **Memo** (for example *Owner contribution* or *March rent*).
2. For each line choose the **Account**, a **Description**, an optional **Cost center**, and a **Debit** or a **Credit**. **+ Add line** adds more.
3. **Debits and credits must add up to the same total** before you can save; the screen shows the totals.
4. **Save**.

The list shows entries from every module as well as manual ones; open one to see its lines and its source.

> **Warning:** Posted entries are not edited. To correct a mistake, enter a reversing entry or void the source document. If the books are closed up to a date, you cannot record anything on or before that date.

## Incomes (money received that is not a sale)

**Incomes > New income**: **Date**, **Category** (a revenue-type account; add *Other Income* in the chart first if needed), **Received from** (*Customer, Vendor (supplier), Staff, Other / one-off*), the person or **Payer name**, **Amount**, **Received immediately (into Cash)** (if unticked it is posted as money still owed to the store), optional cost center, branch and memo.

## Controls (accountant and administrator)

**Accounting > Controls** has three tabs:

- **Close the books**: close the books up to a date once a period is final (for example after the March accounts are approved). Nothing dated on or before that day can then be recorded: invoices, bills, expenses, journals, imports. Voiding or correcting still works because it is recorded today. Enter the date and **Why**. **Only an admin can close or reopen the books**, and every change is logged with the reason and who did it.
- **Bank reconciliation**: **Start a reconciliation** by choosing the account, the **Statement date** and the **Ending balance on the statement**. Tick the ledger lines that appear on your bank or mobile-money statement; the screen shows **Statement balance, Matched so far, Difference**. When the difference is zero, save and complete it. **Undo** reverses a reconciliation. The system records all cash, bank and mobile money in one account called *Cash and Bank*; to reconcile a bank separately, add it as an asset account and move money to it with a journal entry.
- **Opening balances**: enter the balances of accounts when you start part-way through a year.

## Reports

**Accounting > Reports** is a menu of reports. All can be exported to Excel and PDF.

| Group | Reports |
|---|---|
| **Accounting Reports** | Tax Report, Tax Declaration, Income Statement, Balance Sheet, Profit & Loss, Financial Transactions, Cash Flow Report, Assets |
| **Journals Reports** | General Ledger (with opening and closing balance per account), Trial Balance & Nets, Trial Balance, Trial Nets, Ledger, Cost Centers, Journals Report, Chart of Accounts Directory |
| **Expenses Reports** | Expenses by Category, by Vendor, by Staff, by Client, Daily, Weekly, Monthly and Yearly Expenses |

Choose the **From** and **To** dates. For the **Trial Balance**, click a line to see the entries behind it. The **Balance Sheet** and **Income Statement** use the whole ledger to the end date.

> **Tip:** Each month: review the trial balance, reconcile cash and bank, run the tax report, then **Close the books** up to the month end.
