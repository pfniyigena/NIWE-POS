# Help Desk

The **Help Desk** group has: **Overview, Tickets, Saved replies, Categories, Settings, Reports**. It handles requests from customers and from colleagues (internal requests), with deadlines, replies by e-mail and a full history.

## Where tickets come from

- Staff create them: **Tickets > New** (a phone call, a walk-in).
- Customers send a request themselves on the public page `/helpdesk` (if switched on) and can follow the ticket, reply, add files and rate the help.

## Creating a ticket

**Tickets > New ticket**: **Type** (*Customer request* or *Internal request*; the type cannot be changed afterwards), **Customer** (optional, an existing customer or not), **Requester name, email, phone**, **Subject**, **Description**, **Category**, **Priority** (*Low, Medium, High, Urgent*) and **Assign to**.

## Working a ticket

A ticket's page shows its status, priority, category, requester, dates and, if deadlines are on, **First reply due** and **Resolve by**, with a colour when late.

- **Conversation**: choose **Internal note** (staff only) or **Reply to the customer**. A reply is e-mailed to the customer when the ticket has an e-mail address. **Insert a saved reply...** inserts a ready answer; placeholders are filled from the ticket. Tick **Then wait for the customer's answer** to set the status to waiting.
- **Wait for customer**: pauses the deadline clock until the customer answers.
- **Resolve** (with optional *Resolution notes*), **Close**, **Reopen**. Resolved tickets are closed automatically after the number of days set in settings.
- **Assigned to** and **Tags** (for example *billing, vip*).
- **Links**: attach an **Invoice number** or a **Job (work order) number** to the ticket, and follow the link back and forth.
- **Merge into another ticket...**: use it when the same problem was reported twice. The conversation and files move to the ticket you choose, and this one is closed as merged.
- **Files**: add pictures, PDFs or text (up to 10 MB each); tick **Customer can see** to share it on the public ticket page.
- **History**: every change, with who and when.

## The ticket list

Filter by status, priority, category, assignee and quick views (*overdue, unassigned, mine*). Tick several tickets for bulk actions such as assigning.

## Overview

**Help Desk > Overview** shows: **Unanswered**, **Overdue** (past a deadline), **Due soon**, **Unassigned**, **Open / in progress**, **Mine**, last 7 days in and out, **On time (30 days)**, **Avg first reply**, **Avg time to resolve**, **Customer rating**, tickets by priority and age, **Workload** per agent (*Active, Overdue, Resolved (30 days)*) and a **Needs attention** list with the reason.

## Saved replies

**Saved replies > New**: a **Title**, the **Reply text** and an optional **Category**. Placeholders for the ticket's details are filled in when you insert the reply.

## Categories

**Categories** group tickets (for example *Billing, Technical, Delivery*) for routing and reports.

## Reports

**Help Desk > Reports**: Help Desk Tickets, Help Desk Deadlines (SLA), Help Desk by Agent, Help Desk by Category, Help Desk Satisfaction, Overdue Help Desk Tickets.

## Settings (administrator)

Public page on/off, notification e-mails, replies by e-mail, deadlines (SLA) by priority, warnings and automatic closing (Administrator Manual, chapter 7).
