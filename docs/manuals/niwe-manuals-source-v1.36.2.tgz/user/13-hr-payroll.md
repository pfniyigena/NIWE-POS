# Human resources and payroll

The HR menus are: **Employees** (*Employees, New employee, Documents, Onboarding, HR reports*), **Org** (*Departments & positions, Organization chart*), **Attendance** (*Attendance, Leave, Team calendar, Settings*), **Contracts**, and **Payroll** (*Payroll runs, Adjustments, Advances & loans, Tax & social security, Rules & tax bands*).

Access to HR needs the *Human resources* area, and to contracts and payroll the separate *Payroll and contracts* area, because they carry salary data.

## Employees

### Adding an employee

**Employees > New employee**:

- **Personal details**: first and last name, date of birth, national ID, phone, e-mail, address, emergency contact and phone.
- **Job**: **Employee number** (automatic: EMP-0001...), **Hire date**, **Employment type** (*Full time, Part time, Casual, Intern*), **Job title**, **Department**, **Position**, **Reports to**, **Branch**.
- **Staff login (lets them clock in and out themselves)**: link the employee to a user account, or create one with **Give login**. The password is shown once; give it to the employee. They then use **My HR**.
- **Track attendance for pay**: when ticked, payroll deducts absent days and pays overtime from attendance records. Leave it off for salaried staff who do not clock in.
- **Bank and statutory numbers**: bank, account number, tax number, social security number.

Several employees can be loaded at once with the **employee import** (Excel/CSV with a template; use *Check file* first).

### The employee page

Shows details, **Leave balances**, **Leave requests**, **Contracts** (with **+ New contract**), documents, checklists and the **Annual earnings and tax certificate** (month by month gross pay, income tax and contributions of approved and paid payrolls for a year).

Actions: **Edit**, **Mark inactive**, **Delete** (only if no history), **Give login**, and **Employee left** (enter the **Last day** and **Reason**; this also ends the active contract on that date and can prepare **Final pay**).

### Documents

**Employees > Documents** stores contracts, IDs, certificates and other files per employee, with an **expiry date**; expiring documents are summarised so that you can renew them. An employee can see the documents HR shares with them in **My HR**.

### Onboarding and offboarding

**Onboarding** holds checklists of tasks. A **template** is a ready list (name, *For* new starters or leavers, tasks with who is responsible and a due date counted in days from the hire date or the last working day). Start a checklist from an employee's page. **Open tasks** lists what is waiting, with **Overdue only** and **Mark done**.

## Organisation

- **Departments & positions**: create departments and positions that you pick on employees.
- **Organization chart**: shows departments and **reporting lines** from the *Reports to* field.

## Attendance

**Attendance** has two tabs. **Daily records** lists each day's *In, Out, Hours, Overtime, Status* (*Present, Late, Absent*) with filters. Employees with a login see **My day** and press **Clock in** and **Clock out**. HR uses **Add or correct a day** to enter or fix a record (saving a day that already has a record replaces it). Hours and overtime are worked out from the in and out times and the working hours in **Settings**. **Summary** shows each employee's expected days, present, late, absent, on leave, hours and overtime for a period.

## Leave

**Leave** has **Requests** and **Balances**.

- **New leave request**: employee, leave type, **From**, **To**, reason, and tick *first day / last day is a half day*. Weekends and public holidays are not counted; the working days are shown. An employee can ask for leave themselves in **My HR**.
- HR or a manager presses **Approve** or **Reject**, or **Cancel**.
- **Balances** show for the year: **Entitled, Earned so far, Carried over, Used, Pending, Remaining**. Types earned monthly add one twelfth of the days per month worked. Carried-over days come from unused days of earlier years, up to the type's limit.
- **Team calendar** shows who is away when.

## Contracts

**Contracts > New**: **Employee**, **Type** (*Permanent, Fixed term, Probation, Casual, Internship*), **Job title**, **Start date**, **End date**, **Monthly basic salary**, and **Allowances and fixed deductions (monthly)**: each has a name, a kind (*Allowance (added)* or *Deduction (taken)*), an amount and whether it is **Taxable**. A deduction, for example a loan repayment, is taken from net pay after tax. A new contract is a **draft**; **activate it from the contract list when it is signed**. A report lists contracts expiring in the next 60 days.

## Payroll

### Monthly routine

1. Before the month closes: make sure contracts, leave, attendance, **Adjustments** and **Advances & loans** are up to date.
2. **Payroll > Payroll runs > Run payroll for a month**: choose the month. The system works out the pay of everyone with a contract in that month.
3. Review the run: **Gross pay, Income tax (PAYE), Contributions, Net pay, Employer cost** for each employee. If you change contracts, leave or attendance, press **Recalculate**.
4. **Approve and post**: the payroll is posted to Accounting and locked.
5. **Pay the salaries**: download the **Bank transfer file** (CSV or Excel; columns *No, SURNAME, NAME, NET SALARY, ACCOUNT NO, BANK NAME*), upload it to your bank, then press **Mark salaries as paid**. Employees without a bank account are listed.
6. **Payslips** can be e-mailed to each employee as a PDF (needs e-mail set up).
7. **Papers**: the **Payroll register** (Excel, PDF, CSV) and **Returns for the authorities**: income tax and social security (Excel and PDF).
8. **Record payments** of tax and social security when you pay the authorities (below).

If something was wrong: **Reopen** an approved payroll (entries are reversed and loan repayments given back), or **Cancel payment** if the bank transfer failed. Neither is possible while tax or social-security payments are recorded for that month.

### Adjustments

**Payroll > Adjustments**: a one-off item for an employee in a month: a **bonus, arrears or allowance** (adds) or a **fine or uniform charge** (takes), with a name, amount, month, whether it is taxable and a note. It is included the next time that month's payroll is generated. After approval it cannot be changed.

### Advances and loans

**Advances & loans > Give an advance or a loan**: choose the **employee**, the **Kind** (*Salary advance (taken in one go)* or *Loan (repaid over months)*), the **Amount given**, **Taken each month** and the date. The cash given is recorded in Accounting. Every payroll then takes the installment until nothing is left (the last one is only what remains). An advance starts in the month it is given, a loan in the next. Open a loan to see **Repayments**, **Record** a cash repayment, **Write off** the rest (it becomes a salary cost) or **Cancel this loan** (only if nothing has been repaid).

### Tax and social security

**Payroll > Tax & social security** lists, for each approved payroll month, what is **Owed**, **Paid** and **Still owed**, with the **Due** date (income tax and contributions are due by a day of the next month), marked *Settled* or *Overdue*. Use **Record payment**: **Amount, Paid on, Paid to, Receipt / reference, Note**. **Payments made** lists them and lets you cancel one entered by mistake.

### Rules and tax bands (administrator or payroll manager)

**Rules & tax bands** holds the **Income tax bands** (each taxes the part of taxable pay inside it: From, To, Rate %) and the **Contribution rules** (name, paid by employee or employer, rate %, based on gross, basic or net pay, monthly cap, owed to *Social security* or other, and whether it reduces taxable pay). **The ready-made figures are a starting point, not legal advice. Confirm every rate, ceiling and band with your accountant before running a real payroll.** If no tax bands are set, income tax is 0 for everyone.

### Final pay

When an employee leaves, **Final pay** adds the remaining days' pay, **unused leave days paid out**, **notice days the company pays** or **notice days not served**, and can take the loans back from this pay (pay is never cut below zero; what is left stays owed). It is added to the payroll of the month and taxed like the rest.

## Reports

**HR > Reports**: Employee Directory, Headcount by Department, Leave Balances, Leave Requests, Attendance Summary, Contracts Expiring (60 days), **Payroll Register** and **Payroll Summary**. Salary reports are restricted to people with payroll access. A **yearly summary** (one row per employee) is on the Payroll runs page.
