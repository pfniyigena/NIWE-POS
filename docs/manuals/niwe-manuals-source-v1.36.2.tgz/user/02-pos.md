# POS: registers, the sales terminal and shifts

The **POS** (point of sale) group is where cashiers sell, count the till and handle returns. Its menu has: **Registers & Terminal, Shifts, Voids & returns, Cash movements, POS settings, Devices, Reports**.

## How a day at the till works

1. A manager or admin **opens a session (shift)** on a register and assigns it to a cashier, with an **opening cash float**.
2. The cashier opens the **terminal** with their **PIN** and rings up sales. Payments are taken at **Checkout**.
3. During the shift: cash **paid in or out**, **drops into the safe**, returns, and X reports as needed.
4. At the end the shift is **closed**: the drawer is counted and the difference is recorded. A **Z report** is printed.

A **register** is the physical till. A **session** (or **shift**) is one working period on a register. One shift can have several **cashiers**, each with their own PIN and their own carts.

## Opening a session

Go to **POS > Registers & Terminal**. The list shows each register's **Name, Location, Warehouse, Float, Cashiers, Device** and **Status** (*Switched off*, *Open session*, *Closed*).

1. Press **Open session** on the register.
2. In **Assign to**, choose the staff member who will work the till.
3. Enter the **Opening cash float**. (The most the till may open with is shown.)
4. Press **Open till**.

If a register is tied to one PC, a note shows *Works on ... only* and *Go to terminal* is available only on that PC.

## Opening the terminal

Press **Go to terminal** on the open session. The terminal asks for your **PIN** first: type it and press Enter. A wrong PIN leaves the PIN screen up. If you do not have a PIN, ask an admin to set one, or set your own in **My profile**.

> **Note:** Your PIN opens *your own* working session on the shift. Another cashier can use the same terminal by pressing **Switch cashier** and typing their PIN; carts are kept separate.

## Selling at the terminal

### Adding items

- **Scan a barcode** into the barcode box (type it and press Enter), or tap a **product tile**, or **search by name or SKU**. The category tiles filter the product tiles. "Showing the first 200 matches" means: type more to narrow the search.
- Each line shows **Item, Qty, Discount, Price**. Use the pencil to change quantity, the bin to remove a line. For serial-numbered goods the terminal asks for the **Serial no(s)**. Quantities may be decimal where the product allows it (for example 2.5).
- The cart shows **Subtotal**, **Tax**, any **Discount on the sale** and the **Total**.

### Customer

Use the customer box to **search by name or phone**, or press **Add** to create one on the spot (name, phone, e-mail, **Tax ID**), which selects them for this sale. The box shows if the customer **Owes** money, their **available credit**, and their **loyalty points** and what the points are worth.

### Discounts

- **% Discount** gives a discount on the sale: choose **Percent** or **Amount**, enter it and a **Reason**.
- A cashier can give a discount only up to the limit in POS settings. A bigger one needs a manager's PIN (the **Manager PIN** box). A reason is required when POS settings say so.
- **Promotions** (such as buy-X-get-Y) apply automatically and the cart shows *Saved with promotions*. Type a **Coupon code** and press **Apply** for coupons.
- If your price differs from the product's price, the line shows *Price changed*. A manager may need to approve, and prices below cost may be refused.

### Several carts: hold and discard

- **+** starts another cart tab. **Hold** parks the cart with a note and opens a new one. **Discard** cancels an open cart outright (stock is untouched).

### Payment (checkout)

Press **Payment**. On **Checkout** choose how the customer pays. Tap a payment method to enter an amount; you can **split the payment across several methods**.

- **Gift card**: type the **Gift card code**, press **Check balance**, then **Use on this sale**.
- **Loyalty points**: shows the points available and what they are worth; enter the **Points** and press **Use points**. Points can be used only when the amount reaches the minimum.
- **Store credit** (credit sale): select a customer first. The customer must be enabled for credit (set on the customer record) and within their limit. You may set a **Due date**; otherwise the customer's own payment term is used.
- **Charge to room** (hotels): choose the guest who is checked in and the **Room**.

Press the final button to complete the sale. The receipt prints. Change due is shown for cash.

### Receipts and reprints

**Receipts** shows this shift's completed sales (Time, Invoice, Customer, Total, Payment) with **View / Reprint**. The first print is the original; each later print is marked **COPY 1, COPY 2...** and is listed in **Voids & returns**.

### Gift cards at the till

**Gift card** lets you **Check / add money** (type the code and press **Check**, see the balance and expiry, then **Add money**) or **Sell a new card** (amount, how it was paid, who it is for), and gives you the code to hand over.

### Customer display

**Customer display** opens a second window for the customer showing the cart and total, then *Thank you*. Drag it to the customer-facing screen.

### Offline mode

If the connection drops, the terminal shows **Offline** and keeps working from the catalogue of the last sync. Sales you ring up are **queued** on the PC (**Offline queue**) and sync automatically when the connection returns. Credit limits and some checks are applied only when the sale syncs; a sale that cannot be accepted appears as *Failed* in the queue for review, where you can **Discard** it or ask a manager.

> **Warning:** Do not clear the browser's data or close the browser while sales are waiting in the offline queue.

### Other terminal buttons

**Cash** (cash control), **X report**, **Open drawer**, **Devices** (printer set-up), **Switch cashier**, **End my session** (ends *your* session on the shift and discards carts you never checked out) and **Exit**.

## Cash during the shift

Press **Cash** to open the cash drawer screen. It shows **Opening float, Cash sales, Cash refunds, Paid in, Paid out, Dropped into the safe** and **Cash that should be in the drawer**.

- **Record** a movement: choose the kind (*paid in*, *paid out*, *drop into the safe*), the **Amount**, and **What was it for?** A paid-out above the limit needs a **Manager's PIN**. If the drawer holds more than the reminder level, you are told to drop some cash into the safe.
- **Count the drawer without closing the shift** gives a spot check: nothing moves, and the difference is kept on record.
- A mistaken movement can be **voided** (a manager may be needed). Voided movements stay visible.

The page also has buttons for the **X report** and **Z report**, and **Close the shift**.

## X and Z reports

- **X report**: a mid-shift snapshot of sales, payments, returns and cash. Run it as often as you like; it changes nothing.
- **Z report**: the closing report, numbered. It is printed when the shift is closed.

Both print to the receipt printer if one is set up.

## Closing a session

1. Record any cash paid in, paid out or dropped, **before counting**.
2. Open the close screen. It shows **Opening float, Cash sales, Cash refunds, Paid in, Paid out, Dropped into the safe** and **Expected cash in drawer**, plus **Non-cash sales (card/mobile/bank)** and **Total sales this session**.
3. **Count the drawer** by notes and coins (enter the number of each denomination, or use **+ Another value**). The system totals it.
4. If the count differs from the expected cash by more than the allowed amount, a note is required: **Why is the count off?**
5. Press **Close session**, then print the **Z report**.

Admins can **Force close** a shift or **Close all sessions** from **POS > Shifts** if a cashier has left without closing.

## Voids and returns

### Returning goods

Use **Process a return**: type the **Invoice number** (for example the number on the receipt) and press **Find**. Choose the lines and **Return qty** (or **Return all items**), the **Refund method** and the **Reason**. Returns of old sales (older than the limit in POS settings), or refunds above a limit, need a **Manager's PIN**. Press **Process return**; a return receipt prints.

### Voiding a sale

A sale can be voided only while its shift is open (after that it is a return). Voiding needs a manager's sign-in or PIN, and usually a reason.

### The log

**POS > Voids & returns** lists every void, return, discount, price change and receipt reprint: When, What, Reference, Customer, Register, By, Amount, Reason and **Approved by**. Use the search box and the register filter. This is where managers look when a till is short.

## Shifts list (supervisors)

**POS > Shifts** lists shifts with **Register, Z, Cashier, Opened, Closed, Status, Sales, Variance**, with filters for register and date, and buttons for **Cash**, **X report** and **Z report**. Expand a shift to see its **Cashiers** and add or end cashier sessions.

## Cash movements list

**POS > Cash movements** lists every paid-in, paid-out and safe drop (When, Register, What, Reason, Amount, By, Approved by), including voided ones.

## Devices

**POS > Devices** sets up the receipt printer, kitchen and bar printers, the cash drawer and the customer display **for this PC**. Settings are kept in the browser of that PC. Your administrator normally does this once (see the Administrator Manual, chapter 8). Use **Print test page** and **Open cash drawer** to check.

## Reports

**POS > Reports** has these reports, each with filters and export to Excel, PDF and CSV:

- **Sales and transactions**: Total POS Categories Sales, Total POS Brands Sales, Total POS Products Sales, POS Shifts Sales, Detailed POS Shifts Transactions.
- **Profit**: POS Shifts Profit, Total POS Categories Profit, Total POS Brands Profit, Total POS Products Profit.
- **Operations**: POS Sales by Cashier, POS Sales by Hour, POS Sales by Payment Method, **POS Exceptions** (voids, returns, discounts, price changes, reprints) and POS Shift Comparison.
- **Credit**: Credit Sale Report, Daily Credit Collection Report, Outstanding Credit Report, Overdue Credit Report.

> **Tip:** Managers should read **POS Exceptions** and **POS Shift Comparison** weekly. They show unusual voids, discounts and cash differences by cashier.
