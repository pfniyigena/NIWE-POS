# Property management (rentals)

The **Property management** group has: **Overview, Properties, Units, Owners, Tenants, Leases, Rent, Arrears, Deposits, Charges, Maintenance, Owner statements, Fee invoices, Reports, Settings**. It is for agencies that manage rented property for owners: collecting rent, paying owners, charging a management fee and handling repairs.

## The rental path

**Owner** and **property/units** → **Tenant** → **Lease** → monthly **Rent** invoice → **payment** → monthly **Owner statement** → pay the owner.

## Setting up

- **Owners**: the people you manage for (contact, bank details, fee percentage if different).
- **Properties** and **Units**: a property has units (flats, shops). Set the **management fee %** on a property, or leave it so the owner's or the module's default is used.
- **Co-owners**: on a property page, the **Owners** panel shows who owns it. **Change owners** sets owners and their percentages (they must add up to 100%) from a date. Rent, management fee and repairs are shared by the split in force. Each owner gets their own statement and fee invoice. A split covered by an agreed statement is locked.
- **Tenants** and **Leases**: **Leases > New**: tenant, unit, start and end dates, rent amount and due day, deposit. Attach documents (lease, ID, title deeds) with optional expiry dates; an overview card shows lapsing documents.

## Rent

**Rent** lists rent due and received. Rent invoices are made **automatically each morning** (the number of days before the due date is set by an administrator) or by pressing **Invoice the rent that is ready**. Each invoice goes to the tenant as a customer and is paid in Invoices as usual. A **rent receipt** (PDF, e-mail) is available for every payment.

- **Tenant account statement**: a running account per tenant (PDF, e-mail).
- **Reminders and late fees**: a morning job e-mails the tenant before the due date and when rent is late. An optional **late fee** (a percentage with a cap, or a fixed amount) is invoiced once per rent, on the rent part only.
- **Arrears**: tenants who are behind, with age and amounts.

## Charges (utilities and service charges)

**Charges** defines **charge types** (fixed monthly or metered, for example water, service charge). Add charges to a lease, enter **meter readings** and one-off charges; they become lines on the tenant's **rent invoice**. The money belongs to the agency: the owner statement counts only the rent part, and late fees are worked out on the rent only. Charges are not taxed.

## Deposits and inspections

**Deposits** keeps each lease's security deposit as a ledger of movements: *received, kept for rent, kept for damage or other reasons, refunded, moved to a renewal*, and voids. Keeping a deposit for unpaid rent settles the rent invoice for real. **Inspections** (move-in and move-out): a room list with conditions, repair costs and sign-off.

## Maintenance

**Maintenance** logs repair requests with priority, contractor, cost and who pays (owner or agency). Photos and documents can be attached. Repairs the owner pays for appear on the owner's statement, shared by the owners' percentages.

## Owner statements and fee invoices

- **Owner statements**: each month the system prepares a **draft statement** for every owner who had rent or repairs last month, showing rent received, the management fee (and VAT on it), repairs and the **amount to pay the owner**. Review any warnings, then **agree** the statement: it is booked to the accounts and can be e-mailed to the owner (PDF). To change an agreed statement, **reopen** it.
- **Fee invoices**: when a statement is agreed, a numbered **tax invoice for the management fee** is made for the owner (a document only; the statement already books the fee and VAT). It is voided when the statement is reopened and attached to the e-mailed statement.
- Statements can be created automatically from a chosen day each month, and even agreed and e-mailed when they have no warning and the owner is to be paid something (a setting).

## Overview and reports

**Overview** shows rent collected, arrears, vacancy and leases ending soon. **Reports** (16): rent roll, vacancy, lease expiry, owners, arrears, rent collection, maintenance requests, maintenance cost, owner statements, security deposits, fee invoices, utilities and service charges, rent increases due, monthly trend, repairs by contractor, documents. The owner, tenant and lease lists export to Excel, PDF and CSV.

## Settings (administrator)

Areas, "lease ending soon" days, rent due day, usual management fee % and VAT on it, rent invoicing, owner statements every month, and tenant reminder and late-fee rules.
