# Restaurant

The **Restaurant** group has: **Voids & comps, Sales analysis, End of day, Reports, Tables, Menu, Settings**, and the working screens reached from the **floor plan**: *All orders, Takeaway/Delivery, Deliveries board, Kitchen display, Reservations, Receipts, Wastage, Reports*.

## A service day at a glance

1. Waiters open the **floor plan**, tap a table and **open an order**.
2. They add menu items, note allergies, and **Send to kitchen**. The kitchen prepares on the **Kitchen display**.
3. When guests ask for the bill, the waiter prints the **Bill**, takes payment at **Checkout** (cash, card, split, or charged to a hotel room).
4. At closing time a manager runs **End of day** (the cash-up).

## Setting up the menu and tables (manager)

**Tables > New table**: **Name** (Table 1), **Section** (Main Hall), **Capacity**, **Active**. A table can be marked *Out of service* and *Available* again.

**Menu**: create **Categories**, then add products to each category. For each item set:

- **Station** (for example *Grill* or *Bar*; used to route kitchen tickets), **Course** (starter, main, dessert), **Prep (min)**.
- **Allergens** and **Choices** (sizes, cooking, extras: each option can add to the price; a group can be *Must choose* or *Up to n*).
- **Menu price**. A **recipe** (from Manufacturing > Bill of materials) makes the system deduct ingredients from stock when the dish is sold.

## Taking an order

On the **floor plan**, tap a free table, enter the number of **Guests** and press **Open order**. The order screen shows the menu on the left and the order on the right.

- Tap a menu item to add it. Items with choices open a window to pick options. Add a **Note for the kitchen** (quick-note buttons such as *No onions* are set in Restaurant settings).
- Assign **Seat** and **Course** to each line so the bill can be split by seat and courses can be fired in turn. Items for a later course wait **on hold** until you press **Fire course**.
- **Allergies**: record the guests' allergies; the kitchen ticket shows ALLERGY warnings and items that contain them.
- **Send to kitchen** prints or shows tickets for each station. The line changes to *sent*.
- Before sending, a line can be removed. After it has gone to the kitchen, taking it off needs a **manager's approval** and a **reason** (**Void it**). **Give free** (comp) needs a reason. **Send back** records a remake.

### Takeaway, delivery and room service

**New order** (floor plan): choose **Takeaway**, **Delivery** or **Room service**. Enter the customer name and phone; delivery needs an **address**; room service needs the **guest's room** (a guest must be checked in). Then **Open order**. The **Deliveries board** lists deliveries with **Driver**, **Out for delivery** and **Mark delivered**.

### Online orders and QR codes

If the public ordering page is on, guests order at your `/order` page (takeaway/delivery) or scan the **table QR code** and send an order that staff **accept** under **Online orders**. Set **Delivery areas** (fee, minimum order, extra minutes) and print the **table QR codes** under *Delivery areas & QR codes*. A new code replaces and cancels the old one.

## Moving, merging and splitting

- **Move table**: move a whole bill to a free table.
- **Merge into**: merge this order into another open table's order.
- **Split / move items**: move selected lines to a new check at the same table (by seat, or one by one) so that guests pay separately.

## The bill and payment

The order shows **Subtotal, Discounts given, Service charge, Tax, Rounding, Total, Tip, Reservation deposit already paid** and **Balance due**.

1. **Bill** prints the guest's bill (marked "not a receipt").
2. **Discount**: a percent or amount on the whole bill with a **Reason**. A discount above the waiter limit, or waiving the service charge, needs a manager.
3. **Checkout**: add payments with **+ Add payment**: choose the method and amount, or use **Custom amount**, **Split equally**, **Split by item** or **Split into guests' shares**. Choose a **Tip** (quick percent buttons or **No tip**). **Charge to which room?** puts it on a hotel guest's account.
4. The screen shows **Change to give back**. A deposit already paid is taken off.
5. Complete the payment. The receipt prints; the table is freed.

**Cancel order** frees the table without a sale; if part has gone to the kitchen, a reason and a manager's approval are required.

## Kitchen display and expo

- **Kitchen display**: tickets by status *waiting, cooking, ready*. Buttons: **Start preparing**, **Mark ready**, **Mark served**, **Bump all for this order**, **Remake**. Tickets turn amber then red as time runs out. **Sold out (86)** lets the kitchen mark an item as unavailable, with a reason.
- **Expo**: the pass. Shows each order with what is complete; **Mark everything ready**, **Serve**, **Remake**.

## Reservations and the waiting list

- **Reservations > New reservation**: guest name, phone, e-mail (for reminders), **Party size**, **Date & time**, **Minutes at table**, optional **Table**, and a **Deposit** that can be taken now with a payment method. The screen lists **Free times that day**.
- Actions on a reservation: **Seat**, **Change**, **Take deposit**, **Remind**, **No-show**, **Cancel**. **Mark overdue bookings as no-shows** does them in one click. **Seat by reservation number** works when the guest shows their code.
- **Waiting list**: **Add a party** (name, phone, party size, quoted wait, note). When a table is free the list says *Table ready*; **Seat** them or mark *Left*.
- If the public page `/reserve` is on, guests reserve online and the list shows *booked online*.

## Wastage

**Wastage > Record wastage**: choose the **Product**, **Quantity wasted** (a positive number), **Reason** (*Spoilage, Burnt / overcooked, Dropped / spilled, Expired, Prep trim, Customer complaint, Other*) and a note. The entry is logged; someone with the *Confirm restaurant wastage* right confirms or rejects it. Only then stock and accounts change.

## Voids and comps

**Voids & comps** is the log of every void, comp and cancelled order: When, Kind, Table / customer, Item, Qty, Value, Reason, By, Approved by. Managers review it for unusual patterns.

## End of day

**End of day** is the closing cash-up of the business day.

1. Settle or cancel any orders still open: the screen lists them and will not close until they are cleared.
2. Review **Sales** (checks, covers, gross, discounts, net, service charge, tax, rounding, total billed, tips), **How it was paid**, **By order type**, **Tips by server**, booking **deposits** and **Voids, comps and cancelled orders**.
3. In **Cash in the drawer** the screen works out *opening float + cash sales + deposits in - deposits refunded + paid in - paid out - tips paid out = should be in drawer*. Enter the **Counted** amount; the **Difference** shows, then **Left in drawer** and **Banked**. Add a note.
4. **Close the day**. It becomes a numbered **Z** report that you can **Print**, or export to Excel, PDF or CSV.

If something is paid after the day is closed, **Reopen the day** (give a reason) and close it again.

## Sales analysis

**Sales analysis** shows, for a period: net sales, checks, covers, average check, per cover, margin, tips and time at the table; sales **by hour, weekday, order type, how guests paid, by day, by category**, and the **Menu mix**: *Star* (sells well and earns well, protect it), *Plowhorse* (sells well, earns little: raise the price or use a cheaper recipe), *Puzzle* (earns well, sells little: promote it) and *Dog* (sells little and earns little: rework or drop).

## Receipts

**Receipts** lists paid bills with **View / Print**. A reprint is marked COPY and never opens the cash drawer.

## Settings

An administrator sets **service charge** by order type, waiter discount limit, tips, quick kitchen notes, kitchen timing, rounding and table bookings (Administrator Manual, chapter 7).

## Reports

**Restaurant > Reports**: Sales by Order Type, Orders (all types), Menu Item Sales, Menu Category Sales, Menu Item Profit, Menu Category Profit, Sales by Server, Cancelled Orders and Wastage, with Excel, PDF and CSV export.
