# About this manual and getting started

## Who this manual is for

This is the **User Manual** for NIWE ERP. It is for everyone who uses the system day to day: cashiers, sales staff, store keepers, accountants, HR officers, front-desk and booking staff, managers and owners. It explains **what you do** in each part of the system, step by step, using the words you see on screen.

You do not need to read it from start to finish. Read *Getting started* (this chapter), then the chapter or chapters for your own work. The last page of each chapter lists the **reports** for that module.

Setting up the system (users, licences, printers, backups) is covered in the separate **Administrator Manual**. If you are a cashier, accountant or store keeper, the one-page **Quick-start card** for your role is the fastest way to start.

> **Note:** You only see the parts of the system your business has switched on and that your job needs. If a menu in this manual is missing on your screen, your business may not use that module, or your role may not include it. Ask your administrator.

## Signing in

1. Open the system address in your browser (Chrome or Edge is recommended). The home page shows a **Staff Login** button, and, if your business has switched them on, tiles for public pages such as booking or help requests.
2. Press **Staff Login** and enter your **Username** and **Password**.
3. After signing in you land on the screen that suits your role: cashiers on the registers list, managers on the dashboard, and so on.

If you forget your password, press **Forgot password?** on the sign-in screen. A link is e-mailed to the address on your profile. If you have no e-mail address on your profile, ask an administrator to set a new password for you.

> **Warning:** Never share your password or PIN. Everything you do is recorded under your name in the audit log.

## Your profile

Open **My profile** from the menu to:

- Change your **Full name** and **Email**. Your e-mail is needed to use *Forgot password?*.
- **Change password**: enter your **Current password**, a **New password** and **Confirm new password**.
- **Change PIN**: your PIN (4 to 6 digits) identifies you at the sales terminal and when you approve something at the till. It must be different from every other active staff member's PIN.

## Appearance

**Appearance** (under your settings) lets you choose **Light**, **Dark** or your own colours (a page background and an accent colour). The choice is saved for your account and follows you to any device. Printed receipts, purchase orders and reports always stay white so that they print cleanly.

## Language

Use the language selector on the top bar (or on the sign-in page) to switch between **English** and **Français**. Your choice is kept on this browser and wins over the business default. If you have not chosen, you see the language your business set (Chad businesses start in French). Every module's screens, messages and report headings are translated; printed documents (PDFs), e-mails and most messages from the server are written in your **business** language (Settings > System settings), not in the language you picked on your own screen, so that a customer gets a document in the language of the business. A few messages that carry a status word can still show that word in English.

## Finding your way around

- The **menu on the left** is grouped by module (POS, Sales, Customers, Inventory, Accounting, and so on). Click a group to open it. On a phone, open the menu with the menu button at the top.
- Most lists have a **search box**, **filters** and **quick views** at the top, paging at the bottom, and **Excel, PDF and CSV** export buttons that export exactly what is filtered on screen.
- Most records follow a path: *Draft* (you can still change it), then confirmed or issued, then paid or completed. Mistakes after that are corrected by a **void**, a **credit note** or a **return**, not by deleting, so that the books stay honest.
- Where a button is greyed out or missing, you either do not have the permission or the record is in a state that does not allow it.

## Approvals (manager PIN)

Some actions need a second person: a large discount, a void, a return after many days, a hand-changed price, a big cash paid-out, an expense above a limit. When this happens the screen asks for a **Manager PIN**, or says that an approver is needed. A manager types their own PIN on your screen; their name is recorded as the approver. You never need to know their PIN.

## My HR (for every employee)

If your login is linked to an employee record, **My HR** shows your **payslips**, **leave balance**, **attendance** and documents, and lets you **Clock in** and **Clock out**, **Request leave** (choose the type, the dates, whether the first or last day is a half day, and a reason), and update your own **contact details** (phone, e-mail, address, emergency contact). Your bank account, tax number and job details can only be changed by HR. If you see "Your login isn't linked to an employee record", ask HR to link it.

## Dashboard

Managers and accountants with access see the **Dashboard**, which summarises sales, stock and money owed and has a **Needs your attention** section: overdue invoices, low stock, pending approvals and similar items that need action.

## Tips that apply everywhere

- **Type to search** in any picker (customer, product, supplier) instead of scrolling.
- **Export** buttons give you the same list you are looking at, filtered the same way.
- **Print and PDF** buttons are on documents such as invoices, quotations, purchase orders and statements.
- **Attachments**: many records let you attach files or photos; use them for proof (a signed delivery note, a supplier's invoice).
- If something looks wrong, do not delete and re-enter. Ask a manager how to correct it, and keep the reference number.
