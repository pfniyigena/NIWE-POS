# Subscriptions

The **Subscriptions** group has: **Subscription plans, Subscriptions, Overview, Reports, Job settings**. Use it for anything billed on a regular cycle: memberships, support contracts, software, rent-like services.

## Plans

**Subscription plans > New**: **Name** (for example *Gold membership*), **Description**, **Price**, **Billing interval** (*Weekly, Monthly, Quarterly, Yearly*), **Tax rate**, **Discount %** (default for new subscriptions; editable per customer), and **Active**. Inactive plans stay on existing subscriptions but cannot be chosen for new ones.

## Starting a subscription

**Subscriptions > New subscription**:

1. **Customer** (or **+ New customer**) and **Plan** (or **+ New plan**).
2. The price, interval, tax and discount are pre-filled from the plan; change them to give this customer a different deal.
3. **Quantity (seats / units)**: each invoice bills quantity × price.
4. **Setup fee (one time)** is added to the first invoice only. **Free trial (days)**: billing starts when the trial ends.
5. **Start date** and **Billing timing**: *Prepaid* (bill on the start date, before that cycle's service) or *Paid after service* (bill one cycle after the start).
6. **Term (billing cycles)**: blank = until cancelled; for a fixed term choose what happens **at the end of the term**: *Renew for another term* or *End the subscription*.
7. **Create subscription**.

## Managing a subscription

The page shows status, price, interval, next and last billing, term and notices (*Free trial until...*, *Paused*, *Cancellation scheduled*). Buttons:

- **Bill now**: issue the next invoice right away.
- **Edit terms**: change price, quantity, interval, discount, tax, setup fee or term. *Changes apply from the next bill. Nothing is charged or credited now.*
- **Change plan**: move to another plan, with the option to **settle the unused part of the current period now** (for prepaid subscriptions already billed). The screen shows days left and the monthly value before and after.
- **Pause...** with an optional reason and **Resume automatically on** date; **Resume** when ready.
- **Skip next billing**: skip one cycle.
- **Cancel subscription**: **Cancel now**, or **At the end of the paid period**. A scheduled cancellation can be withdrawn. Cancelling now cannot be undone.

**Billing history** lists the invoices and their status; **Activity** records every change.

Invoices are generated automatically each day for subscriptions whose billing date has arrived (if your administrator left that on). The job can also send reminders before billing, pause or cancel subscriptions whose invoice stays unpaid, and e-mail the customer when an invoice is overdue.

## Overview

**Subscriptions > Overview**: **Monthly recurring revenue**, yearly value, **Paying subscriptions**, average, **On trial / paused**, **Left in the last 30 days**, **Churn %** and new ones, **Billing in 7 / 30 days**, **Unpaid invoices**, **Ending**, and lists of *On trial, Cancelling, Term ending, Resuming, Billing next*, plus the unpaid subscription invoices with *Days late* and *Reminders*.

## Reports

**Subscriptions > Reports**: Subscriptions by Plan, Cancelled and Ended Subscriptions, Unpaid Subscription Invoices.

## Job settings (administrator)

The daily run time, automatic billing, reminders, what to do with unpaid invoices, the daily digest and catching up missed cycles.
