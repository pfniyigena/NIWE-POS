# Inventory

The **Inventory** group has: **Products, Categories, Brands, Stock adjustments, Stock counts, Reorder, Branches, Warehouses, Stock transfers, Packaging rules, Breakdown stock, Reports, Inventory settings**.

## Products

**Inventory > Products > New product**. The important fields:

| Field | Meaning |
|---|---|
| **Name, SKU, Barcode, Code** | How the product is identified. The *Code* is an optional second identifier and must be unique if used. Use **Print label** to print barcode labels. |
| **Icon, Description** | A picture for the till and the default text for invoice lines. |
| **Category, Brand, Tax rate** | Category and brand for reports; *Tax rate* of *None (tax-exempt)* or one of your rates. |
| **Unit price** | The selling price. |
| **Cost price** | What the product costs you. Never shown to customers; used for profit reports. Follows purchases automatically depending on the costing method. |
| **EFRIS commodity code** | Only if you submit to EFRIS. |
| **This is a service, not a physical good** | For services and made-to-order items. |
| **Track stock for this product** | Untick for a service; it can always be sold and selling it never changes stock. |
| **Stock quantity** | Current stock. After the start, change stock with adjustments, counts, receipts or transfers, not by editing here. |
| **Reorder level, Maximum stock level** | When sellable stock plus open purchase orders falls to the reorder level the product appears in **Reorder**; the suggested order quantity brings stock up to the maximum (default: twice the reorder level). |
| **Batch / serial tracking** | *None*, *Batches with expiry date* (sold earliest-expiry first), or *Serial numbers* (one per unit). Batch and serial numbers are entered when you receive a purchase order or add stock by adjustment. |

The product page has **Stock movement history**, which lists every movement of the product and where it came from.

> **Tip:** Import many products at once with **Settings > Backup & Data > Bulk import** (ask your administrator). Always press **Check file** first.

### Variants

For products that come in sizes or colours, open **Variants**: add **Options** (for example *Size*) with **Values** (S, M, L), press **Generate**, and one product is created for each combination (copying price, cost, category, brand and tax). The original becomes an inactive template and must hold no stock. Edit each variant's SKU, barcode and price afterwards.

### Labels

**Print label** from a product, or from the product list for many products, prints barcode labels on your printer.

## Categories and brands

**Categories** and **Brands** group products for the till tiles, reports and promotions. Create a brand before choosing it on a product.

## Stock adjustments

Use an adjustment to correct stock outside a normal purchase or sale (damage, theft, expiry, a recount).

1. **Stock adjustments > New**. Search the **Product**; the current stock is shown.
2. Choose the **Location** (default: main warehouse sales stock) and enter the **Quantity change**: positive to add, negative to remove. The new stock level is shown.
3. For batch products enter the batch and expiry; removing takes the earliest expiry first. For serial products list the serial numbers.
4. Choose the **Reason**: *Damage, Theft, Expiry, Recount, Other*, and add a **Note**.
5. **Save adjustment**.

> **Note:** The adjustment is only *logged for review*. Stock and accounting do not change until someone with the *Approve stock adjustments* right confirms it from the Stock adjustments list. Rejected adjustments change nothing.

## Stock counts

A stock count compares the shelf with the system.

1. **Stock counts > Start a stock count**: choose the **Warehouse**, optionally a **Category**, and add notes. **Start count** freezes the current system quantities onto a **count sheet**.
2. **Print sheet** and count. Sales and receipts can carry on while you count.
3. Enter **Counted** for each line (the sheet shows **System qty, Counted, Variance, Value**). Use **Add a product to the sheet** for something found that was not listed. **Save counts**.
4. **Submit for approval**. An approver presses **Approve & post differences**: only the *difference* between what you counted and the frozen figure is posted, so anything moved meanwhile is preserved. Use **Reopen for counting** to send it back or **Cancel count** to abandon.

## Reorder

**Inventory > Reorder** lists products whose sellable stock plus open purchase orders is at or below the reorder level (SKU, Product, Category, On hand, On order, Reorder level, Max, Order qty). Press **Create requisition** to turn the list (or ticked lines) into a purchase requisition. Your administrator can also have a draft requisition created automatically every day.

## Warehouses, locations and transfers

- **Branches** and **Warehouses** are set up by an administrator (Administrator Manual, chapter 5). A warehouse may have *Receiving, Sales, Storage* and *Damaged* locations. Damaged stock is tracked but never counted as sellable.
- **Stock transfers > New**: choose the **Product**, **From location**, **To location** (the same warehouse or another) and **Quantity**. The transfer is logged; stock moves only when someone with the *Approve stock transfers* right presses **Confirm** (or **Reject**). **Inter-branch** transfers are then received at the other end: the receiving branch presses **Receive** and enters what actually arrived (any shortfall is shown as *short*), or **Return to sender** with a note (for example *damaged*). A **transfer note** (the *Paper* column) can be printed to travel with the goods.
- After a purchase receipt, goods sit in the *Receiving* location until a transfer moves them to a *Sales* location. If a register sells from a particular location, that is where the stock must be.

## Packaging and breakdown

For selling parts of a product (a bottle in shots, a case in bottles). An administrator must switch on *Product packaging & breakdown* in Inventory settings.

- **Packaging rules > New**: choose the **Parent product** (what gets broken down) and the **Child product** (what it becomes; **+ New product** creates it on the spot), and **Units per parent** (25 shots per bottle).
- **Breakdown stock**: choose the **Packaging rule**, the **Quantity** to break down and the **Location**, optionally a note, and run it. The parent stock goes down, the child stock goes up, and the child's cost per unit is worked out. The table lists every previous breakdown.

## Negative stock and multi-warehouse

Whether the till and adjustments may take stock below zero, and whether the business uses several warehouses, are set by an administrator in Inventory settings. If a sale is refused for stock, receive or adjust stock first.

## Reports

**Inventory > Reports**: **Stock On Hand & Valuation**, **Stock Aging**, **Dead Stock** (no sales in 90 days), **Batch Stock** (lots and expiry), **Expiring Stock** (60 days), **Serial Number Register**, **Stock Movement History** (for one product).
