# Time tracking

The **Time tracking** group has: **Projects, Approvals, Bill time, Reports, Settings**. Every person who logs time uses **My time**.

## The path of a piece of time

**Log** (timer or manual) → **Submit for approval** at the end of the week → **Manager approves** → **Bill time** creates a draft invoice → issue the invoice.

## Logging your time (everyone)

Open **My time**. The top shows **Today, This week, This month** hours and what you still need to submit.

**With the timer**: choose the **Project** (and **Task**), write *What are you working on?* and press **Start**. When finished press **Stop and save**, or **Discard**. A timer left running is stopped automatically after a number of hours set by your administrator, and kept as a draft for you to check. If you forgot a timer, stop it and correct the time.

**By hand**: choose the **Date**, **Project**, **Task**, enter **Time** (type 1:30, 1.5, 90m or 2h), *What did you do?*, and tick **Billable** if it is billable. Rates come from the project; you do not enter any.

**Your week**: use **Previous week / Next week** to move around. **Copy last week** repeats last week's entries. Edit or delete a line while it is still a draft. When the week is complete press **Submit ... for approval**. An entry that is **Sent back** shows the manager's reason: correct it and submit again.

> **Note:** Your administrator can lock time up to a date (approved and invoiced weeks cannot be changed), cap hours per day and e-mail a weekly reminder to people who have not handed in last week's time.

## Projects (manager)

**Projects > New**:

- **Name**, **Code**, **Customer (who is billed)**, **Status** (*Active: time can be logged; Completed: no new time; Archived: hidden*), **Description**.
- **Hourly rate** (or use the default), **Budget (hours)**, **Start** and **End**.
- **Time on this project is billable to the customer**, and **Refuse time that would go over the budget** (needs a budget; managers can still correct entries).
- **Project team**: only the people listed can log time on the project (administrators always can).
- **Tasks**: optional breakdown with an **Estimate (h)** and the hours logged so far.
- **Rates per person**: anyone not listed is billed at the project rate. A rate is fixed on an entry when it is submitted, so a later change does not alter time already handed in.

The project page summarises **hours logged, billable, ready to invoice** and **budget used %**, and links to billing.

## Approvals and team time (manager)

**Approvals** shows:

- **Not submitted**: for the chosen week, the people who normally log time but have not handed in everything, with **Remind** per person or **Send reminder to everyone listed**.
- **Waiting for approval**: filter by status (*Not yet submitted, Approved, Sent back, Invoiced*), person and project. Tick entries and **Approve**, or **Send back** with a reason. **Correct** lets a manager fix the time or description before approving.

## Bill time

**Bill time** lists **Project, Customer, Billable hours, Ready to invoice**. Press **Prepare invoice** for a project: choose the period and due date. The screen shows one line per person and rate (Hours, Rate, Amount). **Create draft invoice** creates a draft in Sales that you can still edit before issuing. Tax follows the service product set in Time tracking settings. **Undo a time invoice** releases time so it can be billed again after a draft invoice was deleted or an issued one was voided.

## Reports

**Time tracking > Reports**: Timesheet Summary, Project Hours vs Budget, Unbilled Time, Utilisation, Time Entries.

## Settings (administrator)

Approval switch, rounding of timers, default rate, daily hour limit, forgotten-timer stop, time lock, weekly reminder, budget warning % and the service product (Administrator Manual, chapter 7).
