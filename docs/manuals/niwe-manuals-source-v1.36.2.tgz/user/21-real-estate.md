# Real estate (sales and brokerage)

The **Real estate** group has: **Overview, Properties, Leads, My follow-ups, Viewings, Deals, Projects, Unit sales, Collections, Commissions, Reports, Settings**. It is for agents and developers who list properties, work with buyers and tenants, and sell units in building projects.

## The sales path

**Property** (a listing) and **Lead** (a person interested) → **Viewing** → **Deal** (offer, reservation, agreement, commission) → money collected. For a developer: **Project** → **Units** → **Unit sale** → **Collections**.

## Properties

**Properties > New property**: type, address and area, price (sale or rent), size and features, description, **photos** (several; one is the main image), owner details and the **status** (for example available, reserved, sold). Add **documents** such as title deeds with optional expiry dates. A property can have **valuations** recorded over time. Print a **flyer with photos** for a property.

## Leads

**Leads > New lead**: contact details, what they want (buy, rent, budget, area), the **source** and the **agent**. Each lead has a **diary** where calls, visits and notes are logged.

### My follow-ups

**My follow-ups** is the agent's daily list: **late, due today, coming up, gone quiet** (a lead is "quiet" after the number of days in settings). Log a call or move the lead on; set the **next follow-up date**. If switched on, each agent gets a **morning e-mail** (about 06:30) listing late and due calls and quiet leads.

## Viewings

**Viewings** is the diary: schedule a viewing of a property for a lead, with date, time and agent. A **reminder e-mail** goes to the client and one list to the agent before the viewing (hours ahead set in settings); use **Remind** to send one by hand. A **week calendar** (Monday to Sunday) shows the diary.

## Deals

**Deals > New deal**: choose the **property** and the **lead or client**, the type (sale or rental), the agreed price, **commission shares** between agents (staff or outsiders), and the payment schedule. Stages run from offer through reservation and agreement to completion.

Printable documents for a deal: **offer, reservation, sale agreement (with the payment schedule), payment list and payment receipt**. The wording can be replaced in settings.

## Projects and unit sales (developers)

- **Projects**: a building or development with its **units** (type, size, price). **Print a price list** for a project.
- **Unit sales**: sell a unit to a buyer with a payment schedule (**Unit sales > New**). Print the **sale agreement, payment list and receipts**.
- **Collections**: lists buyers who still owe (**late, due soon, no schedule**). Log **calls, promises to pay and notes** on each sold unit, send a **reminder e-mail** to the buyer, and print or e-mail a **buyer statement**.

## Commissions

**Commissions** groups every commission share by person (staff or outsider) with its stage: **not earned yet, earned, awaiting approval, approved to pay, paid, rejected**. **Post all earned** sends earned commission to **Expenses**, where it is approved and paid. A **PDF statement** per person can be e-mailed to staff. Unit sales have no commission shares; this screen covers deals.

## Importing

**Import** on the **Leads** and **Properties** screens loads Excel or CSV files: download a template, choose a file, read the check (nothing is saved), then import. Every skipped row is listed with its spreadsheet row number and reason; duplicates are caught.

## Reports

**Real estate > Reports** (10): listings, leads, viewings, deals, commission, projects, price list, unit sales, valuations and documents. Lists also have Excel, PDF and CSV export.

## Settings (administrator)

Areas, viewing length, quiet-lead days, morning e-mail to agents, viewing reminders, and the standard wording of printed documents.
