# Glossary and common questions

## Glossary

| Term | Meaning |
|---|---|
| **Online order** | An order a customer placed on the public shop at `/shop`. It waits for staff, then becomes a sale order. |
| **Sellable now** | What the online shop may still sell of a product: stock in sellable warehouse locations, minus quantities reserved on confirmed sales orders, minus the shop's buffer. |
| **Buffer (Units kept back for the till)** | The number of units per product the shop never sells, so the last unit is not sold twice. 1 unless changed. |
| **Coupon** | A code a customer types at checkout on the online shop for a percentage or amount off the items, or free delivery. |
| **Webhook** | The address a payment provider calls to say a payment was made. The shop also checks pending payments itself. |
| **Register** | A physical till. |
| **Session / Shift** | One working period on a register, opened with a float and closed with a count. |
| **Float** | The cash put in the drawer at the start of a shift. |
| **X report / Z report** | A mid-shift snapshot (X) and the closing, numbered report (Z). |
| **Void** | Cancelling a document before or instead of correcting it; leaves a trail. |
| **Credit note** | A document that reduces what a customer owes, issued when an invoice is voided or cancelled. |
| **Quotation / Sale order / Invoice** | An offer / a confirmed order / a request for payment. |
| **Bill** | A supplier's invoice to you. |
| **GRN** | Goods received note, printed when stock is received. |
| **BOM** | Bill of materials: the recipe for a manufactured product. |
| **SKU** | Stock keeping unit: a product's own code. |
| **Landed cost** | Freight, duty and clearing added to the cost of goods received. |
| **Reorder level** | The stock level at which a product should be re-bought. |
| **Warehouse / Location** | A place stock is kept, and a shelf or area inside it (Receiving, Sales, Storage, Damaged). |
| **Branch** | A business location for reporting: sales, purchases and expenses are tagged with it. |
| **Cost center** | A tag (department, project) for cost reporting. |
| **Chart of accounts** | The list of accounts the ledger posts to. |
| **Journal entry** | A set of debit and credit lines that balance. |
| **Approver / Manager PIN** | A person with the right to approve; their PIN confirms it at your screen. |
| **Accrual / Depreciation** | Recognising a cost when incurred / spreading an asset's cost over its life. |
| **ADR / RevPAR** | Average daily rate / revenue per available room (hotels). |
| **SLA** | A promised reply or resolution time (Help Desk deadlines). |
| **MRR / Churn** | Monthly recurring revenue / share of subscriptions lost (Subscriptions). |
| **Trust account** | The account holding a client's money, separate from the firm's (Law firm). |

## Common questions

**I cannot see a menu item mentioned in this manual.** Your business may not use that module, or your role does not include it. Ask your administrator.

**I made a mistake on an invoice.** If it is still a draft, edit or delete it. If it is issued, void it (or cancel and credit it if payments exist) and create it again.

**A sale was refused because of stock.** Stock may be low and negative stock is not allowed. Receive or adjust stock first, or ask a manager.

**A discount asks for a manager.** The discount is above your allowed limit. A manager types their PIN on your screen.

**The till shows Offline.** Keep selling; sales queue and sync automatically when the connection returns. Do not clear browser data meanwhile.

**I forgot my password or PIN.** Use *Forgot password?* if your e-mail is on your profile; otherwise ask an administrator. Change your own PIN in **My profile**.

**How do I get the numbers out to Excel?** Every list and report has **Excel, PDF and CSV** buttons; they export exactly what is on screen, with the same filters.

**Who changed this?** Ask an administrator to check the **Audit Log**; most important actions are recorded with the person and time.
