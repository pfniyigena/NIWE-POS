# Installments

The **Installments** group has: **Agreements, Collections, New plan, Reports, Settings**. It lets a customer pay an existing invoice in parts over time, with optional interest and late fees.

## Creating a plan

1. Issue the invoice first (Sales > Invoices). On the invoice press **Pay in instalments**, or use **Installments > New plan** and choose an **Invoice** (an issued invoice with a customer and an unpaid balance).
2. The screen shows the **Invoice total, paid** and **still owed**.
3. Optionally take a **Deposit now** (and how it is **paid by**). The deposit is recorded as a payment on the invoice.
4. Set the **Number of instalments**, **Every** (week, 2 weeks, month, 3 months) and the **First due date**.
5. **Interest**: *None*, *Flat (on the whole amount)* or *Reducing balance*, with a **Yearly rate %**. Add **Grace days**, a **Late fee (fixed)** and/or a **Late fee (% of unpaid)**. Tick **Whole amounts (no cents)** for currencies without cents; the last instalment takes any rounding.
6. Tick **Email the customer reminders for this plan** if wanted.
7. Press **Preview schedule** to see each instalment's due date, principal, interest and total, then save. The starting values come from Installments settings.

## Collecting

On a plan, **Record a payment**: amount, method and note. A payment goes to the **oldest unpaid instalment first**; interest and late fees are settled before principal. The plan shows **Total payable, Paid, Outstanding, Overdue**.

Documents: **Schedule (PDF)**, **Statement (PDF)**, **Agreement (PDF)** (printed with the terms), **E-mail statement** (optionally with the agreement), **Send reminder**.

## Managing a plan

- **Edit schedule**: change dates and amounts, add or remove unpaid instalments. What is already paid stays as it is; the principal must still add up and interest cannot go below what was paid. **Split principal evenly** helps.
- **Pay off early**: settles every unpaid instalment today. Part of the interest on instalments not yet due can be waived (a percentage, changeable per payoff). It shows *Principal left, Interest left, Late fees left, Interest waived* and **To pay now**; press **Receive ... and close the plan**.
- **Mark defaulted**: the customer has stopped paying. No more late fees or reminders are added; payments are still accepted; use **Back to active** to reverse. Your settings may default plans automatically after a number of days overdue.
- **Write off**: books the unpaid principal as a bad debt and the invoice shows nothing outstanding. A reason is required. This cannot be undone from here.
- **Cancel plan**: whatever is unpaid stays on the invoice as an ordinary debt; unpaid interest and late fees are dropped.

## Collections

**Installments > Collections** is the collector's work list: **Overdue in this list**, **Broken promises**, **Promised for today**, **Never contacted**. For each plan it shows the customer, overdue amount and age, next due date, last contact and promise to pay. **Log contact**: *Phone call, Visit* or *Promise to pay* (with a date and amount) and a note. Every send is added to the collections log.

## Reports

**Installments > Reports**: Instalment Agreements, Instalments Due (next 30 days), Overdue Instalments, Defaulted and Written-off Instalments, Instalment Collections.

## Settings (administrator)

Reminder timing, starting values for new plans, early-payoff interest waiver, automatic default, and the agreement wording.
