# Booking (appointments)

The **Booking** group has: **Calendar, Appointments, Services, Rooms & equipment, Working hours, Reports, Settings**. It is for businesses that sell time slots: salons, clinics, studios, courts. Staff who perform services see their own list under **My appointments**. Guests can also book by themselves on the public page, if your business switched it on.

## Set-up (manager)

### Services

**Services > New**: **Name**, **Description** (shown on the public page), **Length (minutes)**, **Buffer after (minutes)** (cleaning or rest time), **Price**, **Payment needed to confirm** (*None: pay at the visit; A deposit; The full price*, with **Deposit (% of price)**), whether it **Needs a room or piece of equipment** of a kind (for example Room, Chair, Court), a **Colour on the calendar**, **Who can do this** (leave empty for anyone), **Can be booked** and **Show on the public booking page**.

### Rooms and equipment

**Rooms & equipment**: add a room or piece of equipment (Name, Kind, Capacity, Notes) only if your services need one. **Blocked time** stops bookings for everything (a public holiday), one person (leave) or one room (repairs): choose *Applies to*, the dates and a reason.

### Working hours and leave

By default everyone who performs a service can be booked during the business opening hours. **Working hours** lets you give a person their own days and hours (inside the opening hours) and add **Leave** for days they are away.

## Making an appointment

**Calendar > New appointment**:

1. Choose the **Service**. Its length and price are shown.
2. Choose the **Date**, optionally **Prefer a person** (*Anyone free*), and pick a **Time** from the free slots. If nothing is free, try another day or person.
3. **Person** and **Room / equipment**: *Assign automatically* or pick.
4. **Who is it for?** An existing customer, or a walk-in (name, phone, e-mail for the confirmation) and notes.
5. If the service needs payment to confirm, an **invoice is raised** and the time is **held** for the guest to pay. Tick **Confirm now without waiting for payment** to skip this.

## The calendar

**Booking calendar** shows the day by hour, **By person** or **By room / equipment**, with counts for *Today, Next 7 days, Waiting for payment* and *No-shows this month*. Unpaid and no-show appointments are marked. **Print day sheet** gives a sheet for the day.

## Working with an appointment

Open an appointment to see the time, the person, a **Code**, how long it is held, and the guest's other visits (a warning shows if the guest has missed earlier appointments). Actions:

- **Confirm without payment**, **Mark done**, **No-show**.
- **Move to another time**: pick a free slot.
- **Cancel appointment** (optional reason). An unpaid invoice for this booking is voided; money already received stays on the invoice for you to refund or keep.
- **Payment**: shows price and deposit, the **Invoice**, what is paid; **Record payment** or **Create invoice**.
- **Reminder and calendar**: **Send reminder now** (e-mail with a calendar file) or **Download calendar file**. A reminder is sent automatically before the visit when the setting is on. Guests can also move their own booking online.
- **Notes**.

## Reports

**Booking > Reports**: Appointments, Booking utilisation, Bookings by service.

## Settings (administrator)

Opening hours, booking rules (earliest, furthest ahead, hold for payment, online cancel), reminders, the public page at `/book` and how to pay.
