# Customers

The **Customers** group has: **Customer statement, Customer payments, Collections**. The customer list itself is under **Customers** (the list of people and companies you sell to).

## Adding and editing a customer

**Customers > New** (or the **Add** button at the till for a quick one). Fields:

- **Name**, **Phone**, **Email**, **Tax ID** (needed for tax invoices to businesses).
- **Customer group (price list)**: *None (normal prices)* or a group (see the Sales chapter).
- **Allow this customer to buy on credit**: store credit. **Only an administrator can change this.** When on, set the **Credit limit** and the **Default payment term (days)**; leave the term blank for no default due date.

The customer page shows **Credit enabled / Credit off** and buttons **Edit, Invoices, Payments, Statement, Record payment**.

> **Note:** Customers are never deleted if they have history. Untick or deactivate instead. Merge duplicates by asking an administrator.

## Credit sales and limits

A customer with credit enabled may buy on account at the till or on an invoice, up to the **Credit limit**. The terminal shows **Owes ...** and **available credit** next to the customer. A sale that would go over the limit is refused (offline sales are checked when they sync).

## Recording a customer payment

From the customer page press **Record payment**, or from an invoice use **Record payment**.

1. Enter the **Payment amount** and **Payment method**.
2. Optionally add a **Note**.
3. The payment is applied to the customer's oldest unpaid items first, unless you are paying a specific invoice.

**Customers > Customer payments** lists all payments (Type, Receipt #, Customer, Date, Amount, Method, Recorded by, Note, Applied to), with **View details**. Switch on **Show every customer's payments** to see everyone's.

## Customer statement

**Customers > Customer statement**: choose the **Customer** and the **From** and **To** dates. The statement lists every invoice (Invoice, Date, Register, Cashier, Items, Subtotal, Tax, Grand total, Payment, Credit, Due date, **Outstanding**) with totals. **Export Excel** or **Export PDF**, or e-mail it from Collections.

## Collections (who owes you money)

**Customers > Collections** is the credit controller's daily screen.

- At the top: **Customers owe ...** in total and how much of it is **overdue**, split by **How late**: *Not yet due, 1 to 30 days, 31 to 60 days, 61 to 90 days, Over 90 days*. Click an amount to list the items behind it.
- Three tabs: **By customer**, **Unpaid items**, **Reminders sent**.
- Filters: search by customer, phone or number; **Overdue only**; **All branches**.
- **Send reminder**: tick the customers to remind and press **Send reminder to ... chosen**. Each customer gets one e-mail listing everything overdue, with their statement attached. Or use the **PDF** and **E-mail** buttons on a single row.
- **Automatic reminders** can be switched on by the administrator.
- **Export** buttons give Excel, PDF and CSV.

Counted here: issued invoices and till sales made on credit that are not paid in full. An item with no due date falls due after the customer's default payment term (or immediately if there is none).

> **Warning:** E-mail must be set up (Administrator Manual, chapter 9) for reminders and statements to be sent. The page tells you if it is not.

## Reports

Customer-related reports are in **Sales > Reports**: Sales by Customer, Customer Payments, Receivables Aging; and in **POS > Reports** (Credit): Credit Sale Report, Daily Credit Collection Report, Outstanding Credit Report, Overdue Credit Report.
