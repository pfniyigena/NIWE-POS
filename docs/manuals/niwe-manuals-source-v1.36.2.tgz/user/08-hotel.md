# Hotel

The **Hotel** group has: **Front desk, Bookings, Reservation chart, Housekeeping, Maintenance, Guests, Guest register, Rooms, Room types, Rates, Company accounts, Groups, Online booking, Reports, Settings**.

> **Note:** A hotel is set up once by an administrator in this order: **room types** (name and nightly rate), then **rooms**, then **Settings** (how room revenue reaches accounting, tax, check-in and check-out times, fee policy). Once the Hotel module is on, a **Charge to room** payment method is available in the POS and the Restaurant.

## The front desk

**Hotel > Front desk** is the receptionist's home screen. It shows **Occupied, Occupancy %, Free tonight, Arrivals due, Departures due, To clean** and **Out of order**, then three lists: **Arrivals, In-house, Departures** (Booking, Guest, Room, Stay, Balance). A star marks VIP guests and a flag marks blacklisted guests. Buttons: **New booking** and **Walk-in** (a guest arriving without a booking).

## Making a booking

**Bookings > New booking** (or **Walk-in** on the front desk):

1. **Guest**: choose an **Existing guest** (search by name, phone or ID number) or enter a **New guest** (full name, phone, e-mail, ID number).
2. **Stay**: **Arrival**, **Departure**, **Room type**, **Adults**, **Children**. Choose a **Room**, or *Assign later*. If none is free the screen says so.
3. **Rate plan**: *Standard rate* or a plan such as Corporate. The screen shows the price for each night, the total before tax, the tax, and the total with tax.
4. **Source**: where the booking came from (phone, website, agent), used in reports.
5. Optionally **Agree a different price with the guest** (a nightly rate before tax), add **Notes** and a **Deposit** (amount and how it was paid).
6. Save.

## Working with a booking

Open a booking to see the guest, room, stay, rate per night, deposit and **Bills**. Buttons change with the booking's status (*Booked, Checked in, Checked out, No-show, Cancelled*):

- **Check in**: choose the **Room**. You may check in even if the room is not marked clean (tick the option).
- **Edit**, **Move room**, **Change departure**.
- **+ Charge** adds an extra (minibar, laundry, service) to the guest's bill. **Pay fee owed** takes payment of a cancellation or no-show fee.
- **Check out**: closes the bill, takes payment, and posts the invoice.
- **No-show** and **Cancel booking** apply the fee policy set in Hotel settings; the front desk can waive any fee.
- Documents: **Print invoice**, **Bill (PDF)**, **Registration card**, **Confirmation**, **E-mail confirmation**.

### Split bills and billing a company

A stay has one bill by default. **+ Split bill / bill a company** adds another bill (for example *Extras*, *Company*, *Spouse*). Choose who each bill is **Billed to**: the guest, a company with credit enabled, or the group. A company must first be set up for credit under **Customers**. **Room nights here** moves the room charges to a particular bill.

## Reservation chart

**Reservation chart** shows rooms down the side and days across (two weeks, with « and » buttons to move). Green bars are in-house guests, amber are bookings; each bar runs from the arrival day up to, but not including, the departure day. Rooms out of order are marked. Use it to see gaps and move bookings.

## Housekeeping

**Housekeeping** lists rooms with their status: **Dirty, Cleaning, Clean, Inspected**, plus *Occupied*, *DND* (do not disturb), *Vacant* and *Out of order*. Housekeepers press **Start cleaning**, **Clean**; a supervisor marks **Inspected**. Check-in expects a clean room. Housekeeping also has boards for supplies and for **lost and found** items.

## Maintenance

**Maintenance** logs room problems. Enter the **Room**, the **Problem** (for example *Air conditioner not cooling*), the **Priority** (*Low, Normal, High, Urgent*) and details. Tick **Take the room out of service until fixed** and set **Out of service from** / **Back in service on**. With dates, only those nights are blocked; with no dates the room is blocked right away until the request is **Done**. If existing bookings fall inside the blocked dates the screen warns you; move those guests or change dates. Buttons: **Start**, **Done**, **Reopen**, **Delete**.

## Guests and the guest register

- **Guests** lists guests. Open a guest to see **Stays, Lifetime spend, Average per stay, Last stay, Usually books via**, and **ID documents** (passport, national ID, driving licence, visa; upload scans). Mark a guest **VIP** or **Blacklisted**.
- **Merge a duplicate into** combines two records of the same person: all bookings, groups, lost-and-found items and ID documents move over and the other record is removed. **This cannot be undone.**
- **Guest register** is the official arrivals-and-departures register, with export, for authorities that require it.

## Rooms, room types and rates (set-up)

- **Room types**: name and nightly rate (the standard price).
- **Rooms**: room number, type, floor and status.
- **Rates**: **Seasonal rules** change a room type's price for a date range and optionally certain weekdays (a fixed price, a percentage change, or an amount added/taken off; **Min nights**; **Priority**: the rule with the highest priority wins). **Rate plans** give a discount on top (percent or amount). The **Price calendar** shows the resulting one-night price per day. Existing bookings keep their price.

## Company accounts

**Company accounts** lists stays billed to a company at check-out: **Company, Billed, Received, Owing, Overdue, Open bills**. Open a company, **Show bills**, and when it pays use **Receive money**: **Amount, Method, Reference** (cheque or transfer number), **Date**. Overdue bills are highlighted.

## Groups

For weddings, conferences and tours. **Groups > New**: **Group name**, **Arrival**, **Departure**, **Contact person**, phone, e-mail, **Who pays** (*Each guest pays their own bill; The group pays the rooms, guests pay extras; The group pays everything*) and an invoice-to customer.

- **Room blocks**: hold rooms off general sale (**Room type, Rooms, Group rate / night, From, To**, and a **Release unbooked rooms on** date; unbooked rooms go back on sale then, or **Release now**).
- **Add rooms** for the group, then **Rooming list**: paste guest names, one per line, with **Put names on rooms**. Export the rooming list to Excel, PDF or CSV.
- **Statement** shows what the group owes. **Confirm**, **Complete** or **Cancel group** (cancels every room that has not arrived; you can waive cancellation fees).

## Online booking

If the hotel's public booking page is on, guests choose room types and dates and book online. Bookings arrive in **Bookings** with source *Website*. An administrator sets the page's text and rules under **Online booking**.

## Night audit

At the **night audit time** set in Hotel settings, the system posts each night's room charge to accounting. The **Night audit** report checks the hotel's cash, revenue, tax, deposits, city ledger and group ledger against Accounting, and is the manager's end-of-day check.

## Reports

**Hotel > Reports**: the **Daily** report; **Occupancy** with **Room nights sold, Room nights available, Room revenue, ADR** (average daily rate) and **RevPAR** (revenue per available room); **Revenue by booking source**; **Forecast and pick-up**; and the **Night audit**. Choose *Last 7 days, Last 30 days* or *This month*, or enter dates. All export to Excel, PDF and CSV.
