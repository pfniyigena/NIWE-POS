# Work orders

The **Work orders** group has: **Work orders, Board, Calendar, Planned maintenance, Service packages, Reports**. A work order (job card) records a piece of work for a customer, or internal maintenance, with its people, parts, time, costs and billing. Staff with a login see their own jobs under **My jobs**.

## Creating a job

**Work orders > New work order**:

- **Type**: *Customer job (billed)* or *Internal maintenance or repair*.
- **Priority**: *Low, Normal, High, Urgent*.
- **Start from a service package** (optional): copies the package's checklist, parts and price.
- **Title**, **Description**, **Customer**, **Asset (optional)** (an item from the asset register, for maintenance cost reports), **What is being worked on** (for example *Laptop serial 123* or *Vehicle RAB 123A*).
- **Assigned to**, **Scheduled**, **Due**, **Hourly rate** and an optional **Fixed price** (leave empty to bill hours and parts).

## Estimates and customer approval

If your administrator switched on *New customer jobs need the customer's approval*, work cannot start until an **estimate** has been sent to the customer and **approved** (the job shows *Approved* or *Declined*). You can switch this off for a single job. The customer receives a PDF estimate and the **job card** and a completion note are PDFs you can print or e-mail.

## Working on a job

On the job page you have:

- **Checklist**: steps to tick off (**Edit steps**: one step per line). A job cannot be completed with open steps unless you tick *Complete even though ... checklist step(s) are not done*.
- **Parts and materials**: search a product and add it with a quantity and price (or mark *In fixed price*). **Stock moves and the cost is posted when the job is completed**, so record every part first.
- **Outside costs**: a supplier's work or a purchased item (date, what, supplier, cost, **Charge customer**), optionally **Record as expense in** an account, or *Don't record*.
- **Hours**: time logged on the job by people through *Log time* (internal hours are recorded for information; salaries are paid through payroll; with a fixed price the hours are not billed).
- **Cost and price**: parts cost, outside costs, total cost and the price.
- **Manufacturing Order**: to make something for the job, create a linked manufacturing order from a bill of materials; the job cannot be completed until the order is produced.
- Photos and files can be attached.

Buttons: **Put on hold**, **Log time**, **Edit details**, **Complete...**, **Reopen**, **Cancel job**, **Delete**.

### Completing and invoicing

**Complete...** takes the parts out of stock and posts their cost, with an optional note. Then **Invoice**: preview what will be billed (lines and total before tax), set a due date and **Create draft invoice**. The job shows **On invoice**. **Release (bill again)** frees it if the draft was deleted.

## Board and calendar

- **Board**: columns by status. **Drag a card into In progress to start it, or into On hold**. Filter by **Everyone / Unassigned**, **Customer and internal**, **Customer jobs**, **Internal maintenance**, or search. Cards show *Due ... (late)*, urgency and checklist progress.
- **Calendar**: jobs by scheduled date, to plan the week.

## Planned maintenance

**Planned maintenance** creates jobs for you on a repeating schedule (for example servicing a generator every 3 months). **+ New schedule**: **Title**, **Type**, **Priority**, **Customer**, **Asset**, **Service package**, **Assigned to**, prices, **Repeat every n days/weeks/months**, **Next one is due**, **Create the job this many days early**, **Job is due after n days**, and *Do not create a new job while the last one is still open*. A check runs every morning; **Run now** creates due jobs immediately.

## Service packages

**Service packages** are templates: **Name, Code, Description, Fixed price** (0 = bill hours and parts), **Estimated hours**, a **Checklist** and **Usual parts** (with quantity and whether in the price).

## Reports

**Work orders > Reports**: Work Orders, Work Order Profitability, Maintenance Cost by Asset, Overdue Work Orders.
