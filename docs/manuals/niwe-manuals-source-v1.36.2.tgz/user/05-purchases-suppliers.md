# Purchases and suppliers

The **Purchases** group covers buying: **Purchase requisitions, Purchase orders, Bills, Purchase returns, Reports**. **Suppliers** has the supplier list, **Supplier prices**, **Supplier payments** and the **Supplier statement**.

## The buying path

**Requisition** (a request to buy, optional) → **Purchase order** (sent to the supplier) → **Receipt** (goods arrive, stock goes up) → **Bill** (what you owe) → **Supplier payment**.

## Suppliers

**Suppliers > New supplier**: **Name, Contact person, Phone, Email, Tax ID** (VAT or tax registration number), **Address**, **Notes**, and **Active** (selectable on a new purchase order). Untick *Active* for a supplier you no longer use; do not delete a supplier with history.

You can also add a supplier on the spot from a purchase order with **+ New supplier**.

### Supplier prices

**Supplier prices** records agreed costs: **Supplier, Product, Unit cost, Valid from, Valid to, Note**. When you add that product to a purchase order for that supplier the agreed cost is suggested.

## Purchase requisitions

A requisition asks for something to be bought, and goes to someone who may approve it.

1. **Purchase requisitions > New**: add **Notes**, then search products and set **Quantity requested** (with an optional note per line).
2. **Save draft**, then submit it for approval.
3. A person with the *Approve purchase requisitions* right approves or rejects it. An approved requisition can be turned into a purchase order.

> **Tip:** The **Reorder** screen (Inventory) can create a requisition from every product that is low on stock, in one click.

## Purchase orders

1. **Purchase orders > New**. Choose the **Supplier**, **Expected date** and, if you have several warehouses, **Receive into warehouse**. (Received stock lands in that warehouse's *Receiving* location; move it to a *Sales* location with a stock transfer.)
2. Add lines: search a product, set **Quantity**, **Unit cost** (and **Discount %** or a whole-order **Discount**). The form can be **pre-filled with low-stock items** when you come from Reorder.
3. **Save draft**. On the order, press **Send to supplier** (e-mails the order) or **Print**. Use **Edit** while it is still a draft, and **Cancel order** if it will not go ahead.

### Recording a receipt (goods arrive)

On the order, **Record a receipt**:

- For each line enter **Receiving now** (the remaining quantity is shown). Partial deliveries are fine.
- For batch or serial products enter the **Batch / lot no.** and expiry, or the **Serial numbers** (one per line or comma-separated).
- **Landed cost for this delivery (optional)**: freight, duty, clearing. It is spread over the delivered products by value and added to their cost and to Inventory in the books. Record freight here, **not** as a separate expense, or it would be counted twice. Tick *Already paid* if you paid it at once; otherwise it is recorded as owed.
- Press **Record receipt**. Stock goes up. When all lines are fully received, the order is complete and a bill is generated.
- You can print a **goods received note (GRN)** for the delivery.

### Returning goods to a supplier

On the order press **Process a return**: choose the product, **Returning now** and a **Reason**. The order shows **Returned** and **Refund due from supplier**. All returns are listed in **Purchase returns**.

## Bills

A **bill** is the supplier's invoice to you. It is generated once an order is fully received, or manually from the order.

- **Bills** lists them: Bill #, Purchase order, Supplier, Date, Status, Total, **Outstanding**.
- A draft bill can be edited; press **Issue bill** to make it official (it then posts to accounting). Use **Delete draft** to remove an unissued one.
- **Record payment** from the bill or from the supplier page. **Void bill** (with a reason) if it was wrong.

## Supplier payments

**Suppliers > Record payment** (or from a bill):

1. Enter the **Payment amount** and optional **Note**.
2. The screen lists the supplier's unpaid orders and bills (Order / Bill #, Date, Total cost, Outstanding). Press **Suggest oldest-first**, or type an amount in **Allocate** for each. The allocated total must equal the payment amount.
3. Save. **Print receipt** gives a Supplier Payment Receipt showing what it was applied to and the **Remaining balance**.

**Supplier payments** lists all payments, with **Payment history**.

## Supplier statement

**Suppliers > Supplier statement**: choose a supplier and dates to see what you bought, what you paid and the balance. Export to Excel or PDF.

## Reports

**Purchases > Reports**: Purchase Orders, Outstanding Payables Report, Purchases by Supplier, Purchases by Product, Purchases by Category, Bills, Purchase Returns, Supplier Payments, **Payables Aging**. All filter by date and export to Excel, PDF and CSV.
