# Sales

The **Sales** group (back-office selling, as opposed to the till) has: **Quotations, Sale orders, Price lists, Customer groups, Sale order returns, Invoices, Recurring invoices, Credit notes, Reports, Settings**. Promotions, gift cards and loyalty (switched on in **Sales > Settings**) have their own pages.

## The selling path

For business-to-business or on-account selling the usual path is:

**Quotation** (an offer) → **Sale order** (the customer has agreed) → **Fulfil** (deliver the goods) → **Invoice** (ask for payment) → **Record payment**.

You can start at any step: an invoice can be raised without a quotation or order.

## Quotations

A quotation is an offer with a validity date. It does not move stock or accounting.

1. **Sales > Quotations > New**.
2. Choose the **Customer** (or press **+ New customer** to add one: name, phone, e-mail, Tax ID).
3. Optionally set **Valid until**, **Branch** (if you have several), and **Notes**.
4. Optionally set a **Discount (whole quotation)** as a **Percentage** or **Fixed amount** (this field appears only when your administrator set discounts to *Global*; in *Per line* mode each line has its own **Discount %**).
5. Under **Line items**, search a product by name, SKU or code. The list shows stock and price. Set **Quantity** and **Unit price**. **+ New product** adds a quick product (name, unit price, description) that you complete later.
6. Check the totals (**Subtotal, Tax, Discount, Grand total**) and press **Save draft**.

On the quotation, buttons follow its status: **Edit**, **Send to customer** (e-mails the PDF, status *Sent*), **Mark accepted**, **Mark expired**, **Reject**, and **Convert to sale order**. Statuses: *Draft, Sent, Accepted, Rejected, Expired*.

> **Tip:** If the customer belongs to a *customer group*, the group's price list is used for the prices automatically.

## Sale orders

A sale order records what the customer has agreed to buy. It reserves nothing until you fulfil it.

1. **Sales > Sale orders > New** (or **Convert to sale order** on a quotation). The form is the same as a quotation, with **Expected date**.
2. **Save draft**. Press **Confirm** when it is agreed. A confirmed order cannot be freely edited; use **Cancel order** if it will not go ahead.
3. **Fulfil order**: choose **Fulfil from** (the warehouse or location), enter **Fulfilling now** for each line (the remaining quantity is shown), enter **Serial numbers delivered** if the product is serial-tracked (otherwise the oldest in stock is used), and press **Record fulfillment**. Stock goes down. Partly delivered orders are *Partially fulfilled*; when everything is delivered it is *Fulfilled*. You can print a **delivery note**.
4. **Generate invoice** creates the invoice for the order; **View invoice** opens it.

The order page shows **Paid**, **Outstanding**, **Returned** and **Refund due to customer**.

### Returns on a sale order

**Process a return** lets you choose what the customer is returning (**Returning now**), where to put the stock back (**Return stock to**) and a **Reason**. The return appears under **Return history** and in **Sales > Sale order returns**. A **Refund due** amount is created if the order was already paid.

## Invoices

**Sales > Invoices** lists all invoices (search by invoice number, customer or sale order; filter by status, date and branch).

- **New invoice**: same form as an order, plus **Due date**. Press **Save draft**.
- A **Draft** can still be edited or deleted (**Delete draft**). Press **Issue invoice** to make it official: it gets its number, posts to accounting, reduces stock if not already fulfilled, and may be e-mailed to the customer and to the invoice-receiver list set in Sales settings.
- **Record payment**: enter the **Payment amount** (up to the outstanding), the **Payment method** and an optional **Note**. Part-payments are normal. **Payment history for this invoice** shows each receipt. **Record another payment** for further instalments.
- **Pay in instalments** (if the Installments module is on) turns an unpaid invoice into a payment plan.
- Mistakes after issuing: **Void invoice** (give a reason; nothing has been paid) or **Cancel & credit invoice** (when payments exist: you choose to **Refund** by a method or move the money to **Customer credit**). Both create a **credit note**.

Statuses: *Draft, Issued, Partially paid, Paid, Void, Cancelled*.

## Credit notes

**Sales > Credit notes** lists credit notes (Credit note #, Invoice #, Customer, Voided, Reason, Amount) with **View invoice** and **Print**. A credit note is issued automatically when an invoice is voided or cancelled; you do not create one by hand.

## Recurring invoices

For regular billing (a monthly retainer, rent, service fees).

1. **Sales > Recurring invoices > New**.
2. Give it a **Name**, the **Customer**, the **Frequency** (*Weekly, Monthly, Quarterly, Yearly*), the **Next run date**, and **Due in days**.
3. Add the lines; the **Grand total (each cycle)** is shown.
4. Tick **Active** and save.

A daily job generates the next invoice on or after the next run date, then moves the date forward one cycle. Untick **Active** to pause.

## Price lists and customer groups

- **Price lists** hold special prices. A list can set a price for individual products (even a lower price for bigger quantities) and move every other product up or down by a percentage (**Adjust all other products by (%)**: -10 means 10% below normal). It can be limited by **Valid from / Valid to** and switched on or off.
- **Customer groups** put customers in a group and give the group a price list. At the till, and on invoices, quotations and sale orders, those customers then get the list's prices. Use **Add customers** on the group to assign members.
- A price you type by hand is never replaced by a price list.

## Promotions and coupons

**Sales > Promotions** (when switched on). Press **New promotion**:

- **What it does**: *Percent off*, *Amount off*, or *Buy some, get some free* (for example buy 2 get 1 free, repeating).
- **It applies to**: *One product*, *A category* or *The whole cart*.
- Optional: **Needs at least this spend**, **Valid from/to**, **Coupon code** (with a code the promotion works only when the cashier types it), **Customer group**, and limits on total uses and uses per customer.
- The list shows each promotion's **Used** count; **Sales** lists the sales that used it.

The till works out promotions by itself: each line gets the one best promotion for its product or category, then the one best whole-cart promotion comes off what is left, after any discount the cashier typed. Promotions apply at the till, not on invoices, quotations or sale orders.

## Gift cards

**Sales > Gift cards** (when switched on). **Sell a gift card**: the **Amount**, **Paid by** (or *Given free*), **Bought by**, **For**, **Expires on** and a **Card code** (made for you if empty).

> **Note:** Money paid for a gift card is **not sales yet**. The shop owes it back as goods, shown as **Owed on gift cards**. It becomes sales when the card is spent at the till.

On the list you can see a card's **History**, **Add money**, change its **Expiry**, **Block** or **Unblock** it. Filters: *Can be spent now, Money left, Empty, Blocked, Expired*. **Release expired balances** moves expired, unspent balances from "owed" into income.

## Loyalty points

**Sales > Loyalty** (when switched on). A named customer earns points on every sale (the walk-in customer does not). Points can pay part of a later sale at the till.

Rules (set by a manager): spend per point, points earned, what **one point is worth**, the **fewest points that can be spent at once**, and the maximum percentage of a sale that points can pay. Open a customer from the list to see their **History** or to **Add or take away points** (use a minus to take away) with a **Reason**.

## Sales settings

Admin only: switch **Promotions, Gift cards, Loyalty points** on or off and set the **Invoice receiver emails**.

## Reports

**Sales > Reports**: Sales Orders, Sales by Customer, Sales by Product, Sales by Category, Invoices, Credit Notes, Sale Order Returns, Customer Payments, **Receivables Aging**. Each has date and other filters and exports to Excel, PDF and CSV.
