import glob, os, re, json, subprocess, html
def md2html(path):
    return subprocess.check_output(['pandoc','--from','markdown+pipe_tables+task_lists-smart','-t','html5','--no-highlight',path]).decode()
def slugify(s): return re.sub(r'[^a-z0-9]+','-',s.lower()).strip('-')
manuals=[('admin','Administrator Manual','For the person who installs, configures and looks after the system.','admin'),
         ('user','User Manual','Day-to-day use of every module, task by task.','user'),
         ('cards','Role quick-start cards','One page per role, to get started quickly.','cards')]
pages=[]; nav=[]
for key,title,desc,folder in manuals:
    items=[]
    for i,f in enumerate(sorted(glob.glob(f'{folder}/*.md'))):
        h=md2html(f)
        m=re.search(r'<h1[^>]*>(.*?)</h1>',h,re.S)
        t=re.sub('<.*?>','',m.group(1)).strip()
        h=h[:m.start()]+h[m.end():]
        # callouts
        def callout(mm):
            inner=mm.group(1)
            kind='note'
            mk=re.match(r'\s*<p><strong>(Warning|Note|Tip)[:\s]',inner)
            if mk: kind=mk.group(1).lower()
            return f'<div class="callout {kind}">{inner}</div>'
        h=re.sub(r'<blockquote>(.*?)</blockquote>',callout,h,flags=re.S)
        h=re.sub(r'<table>(.*?)</table>',r'<div class="tablewrap"><table>\1</table></div>',h,flags=re.S)
        h=h.replace('<h2 ','<h2 ').replace('<ul class="task-list"','<ul class="task-list"')
        slug=f'{key}-{i+1}-{slugify(t)[:40]}'
        text=re.sub('<.*?>',' ',h); text=html.unescape(re.sub(r'\s+',' ',text))
        pages.append({'id':slug,'manual':key,'n':i+1,'title':t,'html':h,'text':text})
        items.append(slug)
    nav.append({'key':key,'title':title,'desc':desc,'items':items})
data={'pages':pages,'nav':nav}
js=json.dumps(data,ensure_ascii=False).replace('</','<\\/')
tpl=open('wiki_template.html').read()
out=tpl.replace('/*DATA*/null',js)
open('wiki/index.html','w').write(out)
print(len(out)//1024,'KB',len(pages),'pages')
