# Logs and monitoring

The system keeps three records of what happens. They answer different questions.

| Record | Question it answers | Where |
|---|---|---|
| **Audit Log** | Who changed what in the business? | Settings > Audit Log |
| **Sign-in log** | Who signed in, and who failed to? | Settings > Sign-in log |
| **Server logs** | What is the application itself doing, and why did something fail? | Settings > Server logs |

All three are Admin only.

## Audit Log

Every important action is recorded with the time, the user, an action code and a description. Examples: voids and returns, stock adjustments and their approvals, price and discount overrides, imports and exports, shift opening and closing, binding a register, role and staff changes, time-tracking budget warnings, and many module actions.

Use the filters at the top: a **search box** (user or description), an **action** drop-down (*All actions*), **From** and **To** dates and a page size (25, 50, 100, 200). The table shows **When, Who, Action, What happened**.

Typical uses: find out who approved a discount, who voided a sale, who changed a price, who exported the customer list.

## Sign-in log

Every sign-in attempt is recorded, successful or not. The top of the page shows how many people **signed in in the last 24 hours**, how many **failed attempts** there were, and how many **addresses had failures**. Below, filter by *User name*, by result (*All attempts*, *Signed in*, *Failed*) and by dates. Columns: **When, User name, Result, Why, Address, Device**.

Watch for many failures from one address or for one user name (a sign someone is guessing passwords). Press **Refresh** to update.

## Server logs

The server writes rotating log files under its `logs` folder:

- `niwe-erp.log`: the normal application log.
- `niwe-erp-error.log`: warnings and errors only.
- `niwe-access.log`: one line per request.

Every line carries a **request id** and the **user**. The same request id is returned to the browser in the `X-Request-Id` header, so a support person can match what a user saw with the server's record.

On **Settings > Server logs**:

- Choose a file, a level (*All levels*, *Info and above*, *Warnings and errors*, *Errors only*), type a text to search, and pick how many lines to show (last 100, 300, 1000, 2000).
- **Auto-refresh** keeps watching. **Download file** gets the whole file (the screen shows only the last part of a large file).
- Before the server has written anything the page says *No log files yet*.

When you ask NIWE for support, send the request id and the relevant part of `niwe-erp-error.log`.

The log behaviour is controlled by the `app.logging.*` properties in the backend settings (folder, size and number of files to keep).

## Other places to look

- The **dashboard** has a *Needs your attention* section (overdue invoices, low stock, pending approvals and similar).
- **Settings > Modules** shows the licence status and expiry.
- Each module's **Overview** and **Reports** pages show its day-to-day health.
