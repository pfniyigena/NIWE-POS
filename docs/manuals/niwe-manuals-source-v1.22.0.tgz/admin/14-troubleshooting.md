# Troubleshooting

| Problem | Likely cause and what to do |
|---|---|
| **A module is missing from the menu** | It is not in the licence, not yet activated, or the person's role has no access to it. Check **Settings > Modules**. Activation is by an Admin and is permanent. |
| **"X is not part of your license" (403)** | The module is locked. Install a licence that contains it (chapter 3). |
| **All non-core modules locked suddenly** | The licence has expired. Nothing is lost. Install the renewal. |
| **A person cannot see a screen they should** | Their custom role has *No access* for its area, the role is *inactive*, or the screen is admin-only (Settings, Staff, Backup). See the area table in chapter 4. |
| **A cashier cannot approve a void/discount** | They lack the matching approval permission. Add it under **Extra permissions** on their staff record, or ask an Admin to type their PIN. |
| **"PIN not recognized" at the terminal** | The PIN is wrong, or belongs to an inactive person. PINs are 4 to 6 digits and unique among active staff. Reset it on the Staff list. |
| **A till says it is refused / wrong device** | The register is bound to another device. Unbind it (Admin) or bind it to this PC (chapter 8). |
| **Cannot sell: warehouse message** | Multi-warehouse is on and the register still uses the Main warehouse. Assign a different warehouse to the register. |
| **Sale refused because of stock** | *Allow negative stock* is off and the sale would oversell. Receive stock or adjust it. |
| **A thermal printer does nothing** | Check the connection type, that the browser is Chrome or Edge on https/localhost, press *Connect device...*, then *Print test page*. A red line on the printout says why it fell back to the driver. |
| **Strange characters on receipts** | Change the code page to *Plain ASCII* in the PC's device settings. |
| **No e-mail arrives** | Check **Email settings** and use **Send test email**. Check the recipient's address and the server log. A failed e-mail never blocks the work itself. |
| **Daily job did not run** | Check the module settings for the job's on/off switch and time, and that the time zone in System settings is right. A job runs when the server is next up that day. |
| **Backup restore stuck on "please wait"** | Restore is running. Wait, then restart the application when it finishes. |
| **Server will not start: checksum or schema message** | See chapter 12, *If a start-up fails*. |
| **Import skips many rows** | Read the reasons in *Rows that will be skipped* after **Check file**; correct and check again. |
| **A report looks wrong** | Check the filters and dates, and whether the books were closed for that period (Accounting > Controls). |
| **A user forgot their password** | If they have an e-mail address on file, use *Forgot password?* on the sign-in screen. Otherwise an Admin sets a new password on the Staff record. |

## When you contact support

Send NIWE: the **version number**, the **installation id** (Settings > Modules), what you did, what you expected and what happened, a screenshot, and the **request id** and the matching lines from `niwe-erp-error.log` (Settings > Server logs).
