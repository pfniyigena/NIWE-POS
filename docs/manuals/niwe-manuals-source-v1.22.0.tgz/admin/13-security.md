# Security checklist

Work through this list before the system holds real data, and again once a year.

## Before going live

- [ ] **Change the admin password** and remove or deactivate the demo `cashier` account (or change its password and PIN).
- [ ] Change **all terminal PINs** from the demo values (1234 and 5678).
- [ ] Set a long random **`app.jwt.secret`** in the backend properties. Anyone who knows it can forge a sign-in.
- [ ] Set **`app.seed-demo-data=false`**.
- [ ] Change the database user and password from `postgres`/`postgres`, and do not expose the database port to the network.
- [ ] Serve the system over **https** (a reverse proxy or web server certificate). This is also required for direct thermal printing on till PCs that are not on localhost.
- [ ] Set `app.cors.allowed-origins` to your real address only.
- [ ] Make sure the **`dev` profile** is never used and `app.license.dev-all-modules` is off.
- [ ] Set up **E-mail settings** so that staff can use *Forgot password?*, and give each person an e-mail address.
- [ ] Confirm that a nightly backup exists and that a copy leaves the server.

## Ongoing

- Give each person their own account; use custom roles and the approval permissions rather than extra Admins.
- Review **Staff** quarterly and untick *Active* for leavers immediately.
- Review the **Sign-in log** weekly for repeated failures.
- Review the **Audit Log** for voids, returns, price overrides and stock adjustments.
- Keep the server's operating system, Java, PostgreSQL and the browser up to date.
- Restrict who can reach the server physically and by remote access.
- Bind each register to its till PC (chapter 8) where tills sit in public areas.
- Download a backup before every upgrade and keep one off-site.

## What the system does for you

- Passwords and PINs are stored securely, not in clear text.
- Sign-in uses signed tokens that expire; every server request is checked against the person's role, areas and branch access, not just hidden in the menu.
- Locked modules are refused by the server, not only hidden.
- Deleting is limited: most records are voided, reversed or deactivated, leaving a trail in the audit log.
