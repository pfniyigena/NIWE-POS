# Business set-up

This chapter covers the shared settings that every module uses. All are under **Settings** unless stated.

## Business details

**Settings > Business details** holds the name, address, phone, e-mail and **Tax ID** of the business, and its **logo**. These print on receipts, invoices, quotations, statements and e-mails, and the business name is included in module requests to NIWE. Fill it in before you issue the first document.

## System settings

**Settings > System settings** (press **Save** at the bottom; *System settings saved* confirms):

| Setting | Notes |
|---|---|
| **Currency** | Pick the currency. The **Currency symbol** is filled in from it; override it if you would rather show a code (for example "UGX"). |
| **Time zone** | Used for shift times, scheduled reports and daily jobs. |
| **Date format** | How dates show on screen and documents. |
| **Max discount (%)** | The highest discount percentage allowed on any single sale line, store-wide. Someone with the *Override the store-wide discount cap* permission can exceed it. |
| **Discount** | **Off**: no discount field on quotations, sale orders, invoices, purchase orders and bills. **Per line**: each line has its own discount. **Global**: one discount for the whole document. Only one mode applies at a time, store-wide. The POS terminal's own discount is separate and always available (subject to the till rules in chapter 8). |

> **Note:** If you choose the Rwanda or Chad chart of accounts while the currency is still the untouched default, the currency is set to RWF or XAF for you.

## Taxes

**Settings > Taxes** lists your tax rates (Code, Name, Rate, Pricing, Status). Press **New tax rate** to add one.

- **Pricing** is either *Tax-inclusive* (the price already contains the tax) or *Tax added on top*.
- Each product picks its own tax rate, or none for tax-exempt goods, in **Inventory > Products**. Any number of rates can be active at once.
- Set a rate to **Inactive** instead of deleting it when it is no longer used; old documents keep it.

## Payment methods

**Settings > Payment methods** lists the ways customers pay (Order, Code, Name, Cash-equivalent, Store credit, Status). Press **New payment method** to add one.

- Flag **Cash-equivalent** only for methods that should count as *cash in the drawer* when a till is reconciled. Everything else is treated as non-cash at shift close.
- **Order** decides the sequence of the methods on the checkout screen (lower comes first). Set it on the edit screen.
- **Store credit** marks a method that draws on a customer's credit balance.
- **Room charge** ("Charge to room") appears once the Hotel module is active.
- Common choices: Cash, Card, Mobile money, Bank transfer, Cheque, Gift card, Loyalty.

## Branches

**Inventory > Branches** (or the Branches list in your menu) lists your branches. A branch owns one or more warehouses; sales, purchases and expenses are tagged with their branch so that you can report per branch. Everything recorded before branches existed belongs to the **Head office** (marked with a star), which cannot be deactivated.

Press **New branch** and fill in:

- **Code** (for example KLA), **Name**, optional **Address**, **Phone**, **Email**.
- **Receipt header** (optional). Stored per branch.
- **Tax & numbering** (optional): **Tax ID / TIN**, **EFRIS branch code**, **Document prefix** (for example `KLA-`). These are stored for each branch.
- **Active**.

## Warehouses and locations

**Inventory > Warehouses**. A warehouse is a place where stock is kept. Fields: **Name**, optional **Address**, the **Branch** it belongs to (shown when you have more than one branch), and **Low-stock threshold**.

- **Low-stock threshold**: a product is flagged low (on the dashboard and the stock-on-hand report), and an alert e-mail is sent, when this warehouse's stock of it drops below the number. Leave it blank to use the store-wide default (set under Inventory settings).
- Your primary warehouse cannot be deactivated.
- A warehouse can have **Locations**: shelves, bins, a receiving area. Each location has a type that drives behaviour:

| Type | Purpose |
|---|---|
| **Receiving** | Every purchase or receipt lands on the warehouse's one Receiving location. |
| **Sales** | A sale or return targets a Sales location. Every warehouse always has at least one active. |
| **Storage** | A plain holding area. |
| **Damaged** | Stock is tracked but never counted as sellable. |

A location's type cannot be changed after it is created. A register can be pinned to one specific Sales location (chapter 8), and stock transfers can move stock directly between any two locations.

## Apps (EFRIS)

**Settings > Apps** lists integrations such as the EFRIS (tax authority) connection for Uganda, Rwanda and Chad. Open an app and fill in its settings. Sales sent to EFRIS keep their own fiscal QR code on the receipt.
