# Licence and modules

## How licensing works

Which modules a business may use is decided by a **licence file** that NIWE signs for that one installation. A module can be used only when it is **in the licence** *and* an administrator has **activated** it.

- **Core modules** are always active: **Sales, Purchases and Accounting**.
- Products and stock, customers, suppliers, staff and settings are shared by every module and are always available.
- All other modules (for example Hotel, Restaurant, Payroll, Assets) need to be in the licence and then activated.

The licence file has the extension `.niwelic`. It is signed with a digital signature (Ed25519) and checked inside the application, so it cannot be edited by hand. It is checked offline: no internet connection is needed.

## The installation id

Every installation gets a random **installation id** the first time it starts. It is stored in the database, so it travels with backups. A licence is issued for exactly this id and will not work on another installation.

You find it on **Settings > Modules**, in the *License* section, next to a **Copy** button.

## Getting and installing a licence

1. Open **Settings > Modules** and press **Copy** next to the installation id.
2. Send the id to NIWE together with the list of modules the business bought.
3. NIWE sends back a `.niwelic` file.
4. On **Settings > Modules**, upload the file. The message *License installed* appears and the licence is listed under *Installed licenses* (number, issued date, expiry date, modules, who installed it).
5. Activate the modules the business needs (next section).

The screen shows who the licence is issued to, its number, issue date and expiry date (or *no expiry date*).

## Activating modules

Each module card on **Settings > Modules** shows a state:

| State on screen | Meaning |
|---|---|
| **Core / Always on** | Sales, Purchases, Accounting. Nothing to do. |
| **In your license** | Licensed but not yet switched on. Press **Activate**. |
| **Active** | In use. It cannot be turned off again. |
| **Locked (Request)** | Not in your licence. You may press **Request**. |
| **Requested** | A request was sent; it is waiting for NIWE. You may **Withdraw request**. |
| **License expired** | The module was in a licence that has expired. |

> **Warning:** Activation is permanent. Once a module is activated it cannot be deactivated. Activate only what the business really needs; a module that is not activated is hidden from every menu.

Some modules work together. When you activate one, the system may activate another that it depends on and tells you so ("Also activated, because it works together with..."). The module cards show *Works together with* and *Needed by* lines.

After you activate **Hotel**, the screen reminds you to set it up in this order: first room types (name and nightly rate), then rooms, then the hotel settings (accounting mode, tax, times). The *Charge to room* payment method then becomes available in the POS and the Restaurant.

## Requesting a module you do not have

On a locked module press **Request**, optionally add a note (why you need it, how many users, when) and press **Send request**.

- If e-mail is set up (**Settings > Email settings**) and the setting `app.license.vendor-email` has an address, the request is e-mailed to NIWE with the installation id and the business name.
- Otherwise the screen shows the text so you can send it by hand.

> **Note:** A request unlocks nothing. The module becomes available only when you install a new licence file that contains it.

## Expiry

A licence may have an expiry date. During the **last 30 days** an administrator sees a warning on **Settings > Modules** ("The license expires on ... (n days). Ask NIWE for a renewal in good time."). After the date:

- Non-core modules **lock**; Sales, Purchases and Accounting keep working.
- **Nothing is deleted.** Your data is untouched.
- Installing a renewed licence restores access immediately.

## What a locked module does

It is greyed out on **Settings > Modules** and hidden from menus. The server refuses calls to its own screens' data (HTTP 403, "X is not part of your license"), its public pages answer "not available", and its morning jobs are skipped.

Reports, the dashboard, products, customers, invoices and stock are shared and stay open. Scheduled e-mail reports are not stopped when a module is locked.

## For developers only

The setting `app.license.dev-all-modules=true`, together with the `dev` profile, makes every module count as licensed. It is ignored unless the `dev` profile is active.

> **Warning:** Never start a customer installation with the `dev` profile. If the screen shows "The developer switch is on: every module counts as licensed", the installation is running in development mode and must be restarted normally.
