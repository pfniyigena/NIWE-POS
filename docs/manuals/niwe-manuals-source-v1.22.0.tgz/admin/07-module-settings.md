# Module settings

Every module that needs choices keeps them on its own **Settings** page, at the bottom of that module's menu. All of these pages are **Admin only**. This chapter lists them, in the order of the menu, and explains the choices that matter. Press **Save** on each page; most show *Saved* when done.

> **Tip:** Set a module up *before* staff start using it. Some settings (for example Help Desk deadlines) only apply to records created after you switch them on.

## Sales settings (Sales > Settings)

- **Features**: switch on only what you use: **Promotions** (discounts, buy-X-get-Y, coupons), **Gift cards**, **Loyalty points** (the earning and spending rules are set on the Loyalty page). When a feature is off, its menu entries and till parts are hidden and the server refuses to use it. What was already saved is kept and works again when you switch it back on.
- **Invoice receiver emails**: one address per line. Whenever an invoice is issued, a PDF copy is e-mailed to the customer's own address and to everyone on this list. It is sent only if e-mail is set up (chapter 9); a failed send never blocks or undoes the invoice.

## POS settings (POS > POS settings)

The rules the till enforces. They are the main control against loss at the counter.

| Group | Setting |
|---|---|
| **Cash at the till** | A closing difference up to a set amount is accepted without comment; a bigger one needs a note saying why. Closing a shift needs the notes and coins counted (option). A paid-out from the drawer above an amount needs a manager's PIN (0 = no limit). Remind the cashier to drop cash into the safe when the drawer holds more than an amount (0 = no reminder). |
| **Voids and returns** | Voiding a sale needs a manager (their sign-in or PIN). A sale can be voided only while its shift is open (afterwards it is a return). A return needs a reason. Returns of sales older than a number of days need a manager (0 = no limit). A refund above an amount needs a manager (0 = no limit). The reasons offered for a return (separated by commas). |
| **Discounts and prices at the till** | A cashier may give a discount up to a percent alone; above it a manager approves (0 = every discount needs a manager). A discount needs a reason. A manager may change a price at the till. Refuse a price below the item's cost. The reasons offered for a discount. |
| **Receipts** | Paper: 80 mm or 58 mm thermal roll. Extra lines under the business details (opening hours, phone, VAT note). Text at the bottom of every receipt. Print the business logo. Print a QR code of the invoice number (sales sent to EFRIS keep their own QR code). |

The first printing of a receipt is the original; every later printing is marked **COPY 1, COPY 2...** and listed in **Voids & returns**. "A manager" means an Admin, or a person with the *Approve voids and returns / price changes / big paid-outs* permissions from chapter 4.

## Inventory settings (Inventory > Inventory settings)

- **Allow negative stock** (default on): a sale or manual adjustment may take stock below zero. Untick it to make checkout refuse a sale that would oversell and Stock adjustments refuse a correction that would go negative.
- **Product packaging & breakdown**: lets you break one product into smaller sellable units (a bottle into shots, a case into bottles). Off by default; packaging rules can be configured but a breakdown is refused until this is on.
- **Multi-warehouse**: off by default, the store stays on one warehouse ("Main"). When on, you can create further warehouses, but no sale may complete against Main any more: every register must be assigned a different warehouse (**POS > Registers & Terminal**) before it can ring a sale. Purchases always land on Main's default location.
- **Costing method**: *Weighted average* (recommended), *Last purchase cost*, or *Manual* (never change cost automatically). Landed cost on receiving needs weighted average or last purchase.
- **Daily stock jobs**: *Email a daily low-stock digest* (one e-mail a day to the notifications address, nothing on a day when nothing is low); *Draft purchase requisitions automatically* (each day one DRAFT requisition for products at or below their reorder level; it never submits or approves, and skips products already on an open requisition); *Run from* (store time); and a *Run now* button that uses the saved settings.
- **Restaurant kitchen location**: where restaurant orders and wastage take their stock from (shown when the store has more than one location).

## Expenses settings (Expenses > Settings)

- **Approval limit**: expenses above this amount can only be approved by an Admin or someone with *Approve large expenses*. 0 = no limit.
- **Nobody approves, rejects or voids an expense they entered themselves** (option).
- **Block approval when it would go over the monthly budget**: an Admin can still approve with an override, which is written to the expense history.
- **Days until a bill is due** (used when an unpaid bill is entered without a due date) and **Warn this many days before the due date**.

## Assets settings (Assets > Settings)

- **Warn before a warranty or insurance ends (days)**.
- **"Fully depreciated soon" means within (months)**.
- **Disposal approval limit (book value)**: disposing of an asset whose book value is above this needs an Admin or a user with *Approve large asset disposals*. 0 = no limit.

## Installments settings (Installments > Settings)

- **Email reminders**: send reminders to customers (needs e-mail), how many days before a due date, and how often to chase overdue instalments.
- **Starting values for a new plan**: whole amounts (no cents) for currencies such as RWF and XAF, yearly interest %, grace days, late fee (fixed) and late fee (% of unpaid).
- **Early payoff and default**: the percent of interest waived on an early payoff (changeable per payoff); mark a plan defaulted after this many days overdue (0 = never automatically).
- **Agreement wording**: one term per line, printed under "Terms" on the agreement PDF. Leave empty for the standard wording; have your own text checked by a lawyer.

## Subscriptions job settings (Subscriptions > Job settings)

- **Run from (store time)**: the daily job time, using the time zone in System settings. If the server was off then, it runs when next up the same day.
- **Bill due subscriptions automatically**: each active subscription whose next billing date has arrived gets its invoice. Turn off to bill only by hand with **Bill now**.
- **Email upcoming-billing reminders**: how many days before, to the customer and/or the notifications e-mail.
- **When an invoice stays unpaid**: do nothing, pause the subscription, or cancel it after a number of days past the invoice date. Pausing can be undone with **Resume**; cancelling cannot.
- **Email a daily results digest** to the notifications e-mail (not sent on days when nothing happened).
- **Overdue reminders and catching up**: e-mail the customer when a subscription invoice is overdue (first reminder after n days, then every n days, at most n reminders), and **Missed billing cycles to bill in one run** (1 = one per day; a higher number catches up at once, each with its own period).
- **Run now** uses the saved settings and counts as today's run.

## Help Desk settings (Help Desk > Settings)

- **Public website**: when on, anyone can send a support request and follow a ticket at `/helpdesk` on your site without signing in; options let customers reply and attach files and rate the help. Switch it off to close the page.
- **Notification emails**: one address per line; they get an e-mail for each new ticket, for customer replies to an unassigned ticket, and for missed deadlines.
- **E-mail each reply to the customer** when the ticket has an e-mail address.
- **Deadlines (SLA)**: give every new ticket a first-reply and a resolution deadline by priority (Urgent, High, Medium, Low), counted in calendar hours from creation; time *waiting for the customer* does not count. Only tickets created after you switch this on get deadlines. Options: internal tickets too; warning e-mail before the deadline and alert when missed; **Close a resolved ticket automatically after (days)**.

## Time tracking settings (Time tracking > Settings)

- A manager must approve submitted time (switch off to approve everything automatically).
- **Round stopped timers up to** exact minutes, 5, 6, 10, 15, 30 minutes or 1 hour.
- **Default hourly rate**, **most hours one person can log in a day**, **working hours in a day** (for utilisation).
- **Keeping timesheets tidy**: stop a timer running more than n hours (kept as a draft for the person to check; 0 = never); **Lock time up to and including** a date so approved and invoiced weeks stay as they are; a weekly reminder e-mail to people who have not handed in last week's time; a warning when a project has used n% of its budget (recorded in the audit log).
- **Service product billed time is invoiced under**: the product named "Professional services (time)" can be created automatically; its tax rate and accounting follow the product.

## Booking settings (Booking > Settings)

- **Opening hours**: opens, closes, time between start times, working days.
- **Booking rules**: earliest booking (minutes ahead), furthest ahead (days), hold for payment (minutes), online cancel until (hours before).
- **Reminders and moving a booking**: e-mail the guest a reminder (with a calendar file) n hours before; guests may move their own booking on the public page.
- **Public website**: guests pick a service and a time themselves at `/book`. Also confirmation e-mail, bookings per phone number per day, page title, intro text, and how to pay (shown to guests who owe a deposit).

## Work orders settings (Work orders)

- **New customer jobs need the customer's approval**: work cannot start until an estimate has been sent and approved (can be switched off for a single job).
- **E-mail the customer when a job is completed**: a completion note (PDF) is sent. If the e-mail fails, the job is still completed.

## Attendance and leave settings (HR > Attendance > Settings)

- **Working time**: work starts at, grace period (minutes), hours in a normal day, overtime pays (multiple of normal hourly pay), working days. Clocking in after the start time plus grace counts as late.
- **Leave types**: name, days a year, whether days become available all at the start of the year or are earned month by month, carry-over (max days), paid or unpaid, paid out when leaving.
- **Public holidays**: add the holidays of each year; they are not counted as leave or working days.

## Hotel settings (Hotel > Settings)

- **How room revenue reaches Accounting**: *Every night* (posted by the night audit; best for most hotels), *At check-out*, or *At booking and check-out* (booked value is held as unearned revenue until check-out). The mode can only be changed when no booking is open.
- **Tax on rooms and services (%)**, **check-in time**, **check-out time**, **night audit runs at**.
- **Cancellation and fee policy**: free cancellation until n days before arrival; late-cancellation, no-show, early-departure fees (in nights); late check-out fee. The front desk can waive any fee. See also **Online booking** settings for the hotel's public booking page.

## Restaurant settings (Restaurant > Settings)

Service charge by order type (dine-in, takeaway, delivery) and VAT on it; the most a waiter may discount without a manager; tips (quick-choice percents); quick kitchen notes; usual preparation time and amber/red thresholds for kitchen tickets; rounding of the bill; and table bookings from the public site at `/reserve`.

## Law firm settings (Law firm > Settings)

Practice areas and jurisdictions (one per line); "due soon" window; default billing basis for new matters (Hourly, Fixed fee, Retainer, Contingency, Pro bono); daily e-mail of deadlines and tasks to each lawyer; new matters restricted by default; **limitation date warnings** (first warning n days before, a second 3 days before, and one if the date has passed); and **unpaid fees**: the usual payment term and automatic client reminders listing late invoices with a statement attached.

## Real Estate settings (Real Estate > Settings)

Areas you work in; how long a viewing lasts; when a lead is "quiet"; a morning e-mail to each agent about late and due calls and quiet leads (agents need an e-mail address on their user account); and viewing reminders to the person viewing and the agent.

## Property Management settings (Property management > Settings)

Areas; when a lease is "ending soon"; the day rent usually falls due; the usual management fee % and VAT on it; rent invoicing (how many days before the due date, and automatically every morning); and **owner statements every month** (make last month's statements automatically from a chosen day, and optionally agree them and e-mail owners when they have no warnings). There is also a separate reminder and late-fee page for tenants.

## Settings that are not in a module

**Settings > System settings, Business details, Email settings, Payment methods, Taxes, Scheduled reports, Apps, Backup & Data** are covered in chapters 5, 9 and 10. The **Loyalty**, **Promotions**, **Gift cards** and **Price lists** pages are maintained by staff with the Sales area and are described in the User Manual.
