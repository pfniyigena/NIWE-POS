# About this manual

## Who it is for

This is the **Administrator Manual** for NIWE ERP (the NIWE POS/ERP system). It is written for the person who installs, configures and looks after the system: the business owner, the IT person, or the office manager who holds the **Admin** account. Day-to-day instructions for cashiers, accountants, store keepers and other staff are in the separate **User Manual** and in the **Role quick-start cards**.

You do not need to be a programmer to follow most of this manual. Chapters 2 and 12 (installation and upgrades) are technical and are meant for whoever manages the server.

## How the manual is organised

| Chapter | What it covers |
|---|---|
| 2. Installing and first start | Requirements, database, starting the system, first sign-in |
| 3. Licence and modules | Installation id, licence file, activating and requesting modules |
| 4. Users, roles and permissions | Staff accounts, custom roles, per-person approval rights, branch access |
| 5. Business set-up | Business details, currency, taxes, payment methods, branches, warehouses |
| 6. Accounting set-up | Chart of accounts, cost centers, controls, opening balances |
| 7. Module settings | Where each module keeps its own settings |
| 8. Tills, printers and devices | Thermal printing, cash drawer, customer display, binding a register to a PC |
| 9. E-mail, alerts and scheduled reports | SMTP, business alerts, scheduled reports, daily stock jobs |
| 10. Backup, restore, import and export | Nightly backup, restore, bulk import with check-first, year-end archive |
| 11. Logs and monitoring | Audit log, sign-in log, server logs |
| 12. Upgrades and migrations | Installing a new version, database migrations |
| 13. Security checklist | What to change before going live |
| 14. Troubleshooting | Common problems and what to do |

## Conventions

- Menu paths are written like **Settings > Modules**. The words are exactly as they appear on screen.
- Buttons and fields are written in **bold**.
- Boxes marked *Note*, *Tip* and *Warning* call attention to things that matter. A warning describes something that cannot easily be undone.

## What is new in this edition

This edition covers everything up to **version 1.22.0**. The main administrator-facing additions since version 1.12 are:

- **1.12** Thermal (Epson ESC/POS) printing, cash drawer and COM customer display.
- **1.13** A register can be tied to one known device.
- **1.14** Server logs and the sign-in log; more actions in the audit log; currency follows the chart of accounts (RWF for Rwanda, XAF for Chad).
- **1.15 to 1.22** Improvements to Work Orders, Time Tracking, Booking, Installments, Subscriptions, Help Desk, Expenses and Assets, including new approval permissions (*Approve large expenses*, *Approve large asset disposals*) and new reports available to scheduled reports.
