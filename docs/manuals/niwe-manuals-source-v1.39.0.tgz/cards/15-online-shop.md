# Online shop staff

*Answer orders, keep the shop fresh.*

## Every day

- **Online Store > Online orders**, tab **New**: **Accept** (holds the stock) or **Reject** (give a reason). Then **Mark packed**, **Out for delivery** or **Ready for pick-up**, and **Complete** when the goods are handed over (tick **Cash collected** for cash).
- **Refunds due**: open the order and press **Refund through the provider**, or refund by hand and enter the reference.
- **Online payments**: look at *Under review* and *Stuck pending*.
- **Online Store > Sales reports**: sales by day, orders with invoices, payment methods, orders not counted as sales, coupons and best-selling products. A sale counts on the day the order was **completed**.

## When asked

- **Returns**: **Approve** or **Refuse**; when the goods are back press **Goods received: put back and refund**.
- **Reviews**: **Approve** or **Hide** the new ones.

## Keep the shop fresh

- **Shop settings > Products on the shop**: titles, online prices, and the ticks **Featured**, **Best seller**, **Offer**, **New** for the rows of the first page.
- **Front page**: announcement, banner text and up to 8 banner pictures, footer links.
- **Abandoned carts** shows visitors who left a cart after typing their e-mail; the shop reminds them after 1 hour and 3 days (switch on in Shop settings; **Remove** forgets an address).
- **Coupons** for a promotion; **Newsletter** to see the subscribers; **Send a newsletter** to write, test and send one (a test to yourself first; **Stop sending** works while it goes out).

## "It says Sold out"

- Under the product: *sellable warehouse stock − reserved − buffer = sellable now*. Lower the buffer, move stock to a sales location, or complete the orders that hold it.

> **Need more?** See *Online Store* in the User Manual, or ask your administrator.
