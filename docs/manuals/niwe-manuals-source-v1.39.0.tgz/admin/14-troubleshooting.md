# Troubleshooting

| Problem | Likely cause and what to do |
|---|---|
| **A module is missing from the menu** | It is not in the licence, not yet activated, or the person's role has no access to it. Check **Settings > Modules**. Activation is by an Admin and is permanent. |
| **"X is not part of your license" (403)** | The module is locked. Install a licence that contains it (chapter 3). |
| **All non-core modules locked suddenly** | The licence has expired. Nothing is lost. Install the renewal. |
| **A person cannot see a screen they should** | Their custom role has *No access* for its area, the role is *inactive*, or the screen is admin-only (Settings, Staff, Backup). See the area table in chapter 4. |
| **A cashier cannot approve a void/discount** | They lack the matching approval permission. Add it under **Extra permissions** on their staff record, or ask an Admin to type their PIN. |
| **"PIN not recognized" at the terminal** | The PIN is wrong, or belongs to an inactive person. PINs are 4 to 6 digits and unique among active staff. Reset it on the Staff list. |
| **A till says it is refused / wrong device** | The register is bound to another device. Unbind it (Admin) or bind it to this PC (chapter 8). |
| **Cannot sell: warehouse message** | Multi-warehouse is on and the register still uses the Main warehouse. Assign a different warehouse to the register. |
| **Sale refused because of stock** | *Allow negative stock* is off and the sale would oversell. Receive stock or adjust it. |
| **A thermal printer does nothing** | Check the connection type, that the browser is Chrome or Edge on https/localhost, press *Connect device...*, then *Print test page*. A red line on the printout says why it fell back to the driver. |
| **Strange characters on receipts** | Change the code page to *Plain ASCII* in the PC's device settings. |
| **No e-mail arrives** | Check **Email settings** and use **Send test email**. Check the recipient's address and the server log. A failed e-mail never blocks the work itself. |
| **Daily job did not run** | Check the module settings for the job's on/off switch and time, and that the time zone in System settings is right. A job runs when the server is next up that day. |
| **Backup restore stuck on "please wait"** | Restore is running. Wait, then restart the application when it finishes. |
| **Server will not start: checksum or schema message** | See chapter 12, *If a start-up fails*. |
| **Import skips many rows** | Read the reasons in *Rows that will be skipped* after **Check file**; correct and check again. |
| **A report looks wrong** | Check the filters and dates, and whether the books were closed for that period (Accounting > Controls). |
| **A user forgot their password** | If they have an e-mail address on file, use *Forgot password?* on the sign-in screen. Otherwise an Admin sets a new password on the Staff record. |

## The online shop

| Problem | Likely cause and what to do |
|---|---|
| **The shop says "Sold out" but I have stock** | The shop sells *stock in sellable locations − reserved on confirmed sales orders − Units kept back for the till* (default 1). Open **Online Store > Shop settings > Products on the shop**: the line under the product shows each number. A single unit shows as sold out because of the buffer (set it to 0 to change that). Stock in a *Receiving*, *Damaged* or inactive location, or never entered per warehouse, is not counted: move it to a sales location with a stock transfer. Goods promised on confirmed sales orders are not counted either. |
| **A product does not appear on the shop** | It is not added in **Products on the shop**, **Shown** is unticked, or the product is inactive. A product appears in a row only when its tick (**Featured**, **Best seller**, **Offer**, **New**) is on. |
| **The first page has no banner picture, or shows a plain colour** | No banner picture is uploaded (Shop settings > Front page > Banner pictures), or the upload was refused: only JPEG, PNG, WebP and GIF pictures up to 8 MB are accepted, at most 8. |
| **A review does not appear** | New reviews wait for staff: approve it in **Online Store > Reviews**. Only reviews with words appear on the first page, and only for completed orders. |
| **A customer pressed Subscribe but nothing arrived** | The newsletter needs working e-mail settings (**Send test email**, chapter 9). Ask them to look in the spam folder; an address can ask for a new e-mail once every 10 minutes. The address stays **Not confirmed** until the link is opened. |
| **A newsletter stays on "Sending" and few e-mails leave** | It goes out in batches of `app.online-store.newsletter.batch-size` a minute and never more than `daily-limit` in 24 hours (chapter 7); the daily limit shown on **Send a newsletter** says how much of it is used. If several e-mails failed in a row it paused: read the reason shown on the newsletter, fix the mail settings (**Send test email**, chapter 9) and press **Try the failed ones again**. |
| **The confirmation or unsubscribe link opens the wrong site** | `app.frontend-url` is not set to the public address of the site (chapter 7). The unsubscribe links in the downloaded newsletter list are built from the same setting. |
| **Customers say they get no abandoned-cart reminder** | **Send reminders for abandoned carts** is off in Shop settings, e-mail is not set up (chapter 9), or the customer did not type an e-mail address before leaving. Look at **Online Store > Abandoned carts**: **Waiting** carts get their first e-mail about an hour after the last change (the job runs every 3 minutes); **Ordered** and **Stopped** carts get nothing; **Nothing to remind** means every item was gone or the reminder was too late. A small warning sign on a row shows the mail server's reason. The link in the e-mail opens the wrong site when `app.frontend-url` is wrong (chapter 7). |
| **The online payment option is missing at checkout** | **Customers can pay online** is off, no provider is chosen, or the provider is not available (for MTN: not switched on, a key missing, or the base address is not https; the server log says which). |
| **An order stays "Awaiting payment"** | The customer has not approved the payment. A pending payment is checked about once a minute and the order is cancelled after a day. Look at **Online Store > Online payments** for *Stuck pending*. |
| **A payment is under review** | The amount or currency the provider reports differs from the order, or the order was paid twice. Look at it in **Online payments**, handle it (refund the difference if needed) and press **Mark as dealt with**. |
| **A refund says the provider did not confirm it** | Check the refund in the provider's portal. If it went through, record it by hand with the provider's reference (**I refunded it myself**); never refund twice. |
| **No texts are sent** | No text provider is chosen, the daily limit is reached, or the number is not valid. **Online Store > Text messages** lists every text with its result. |
| **Everyone is "too many requests"** | The server sits behind a proxy and `server.forward-headers-strategy=native` is not set (chapter 7). |

## When you contact support

Send NIWE: the **version number**, the **installation id** (Settings > Modules), what you did, what you expected and what happened, a screenshot, and the **request id** and the matching lines from `niwe-erp-error.log` (Settings > Server logs).
