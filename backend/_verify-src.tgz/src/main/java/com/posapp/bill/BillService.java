package com.posapp.bill;

import com.posapp.audit.AuditLogService;
import com.posapp.bill.dto.BillDto;
import com.posapp.catalog.CatalogService;
import com.posapp.catalog.Product;
import com.posapp.common.ApiException;
import com.posapp.common.GlobalDiscountType;
import com.posapp.common.TaxMath;
import com.posapp.email.DocumentPdfService;
import com.posapp.inventory.PurchaseOrderService;
import com.posapp.inventory.SupplierPaymentService;
import com.posapp.inventory.dto.PurchaseOrderDto;
import com.posapp.inventory.dto.PurchaseOrderLineDto;
import com.posapp.inventory.dto.RecordBillPaymentRequest;
import com.posapp.inventory.dto.SupplierPaymentDto;
import com.posapp.settings.StoreSettingsService;
import com.posapp.user.AppUser;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * Fourier: "The Purchase order should flow same workflow as Sale order (with Bills and Refunds
 * equivalent with Invoices and Credit note)." The accounts-payable mirror of {@code
 * com.posapp.invoice.InvoiceService}, scoped to this app's actual need: every {@link Bill} is
 * generated from a {@code com.posapp.inventory.PurchaseOrder} (see {@code Bill}'s class javadoc
 * for why there's no standalone-bill path the way a standalone {@code Invoice} exists) — {@link
 * #buildFromPurchaseOrder} is the only place this reaches into the purchasing module, always
 * through {@code PurchaseOrderService}'s own public {@link PurchaseOrderService#getById}, which
 * returns a plain {@code PurchaseOrderDto}, never the {@code PurchaseOrder} entity itself — same
 * "no entity coupling across the module boundary" convention {@code InvoiceService} follows for
 * {@code SalesOrderService}.
 * <p>
 * Where a supplier's payment against a bill is actually recorded/validated is {@code
 * SupplierPaymentService} — this service only reads it (via {@link #toDto}, for the amountPaid/
 * amountOutstanding figures on every {@link BillDto}) — same "the payment service owns the payable
 * math" boundary {@code InvoiceService} draws against {@code CustomerCreditService}.
 */
@Service
public class BillService {

    private final BillRepository billRepository;
    private final PurchaseOrderService purchaseOrderService;
    private final CatalogService catalogService;
    private final AuditLogService auditLogService;
    private final DocumentPdfService documentPdfService;
    private final StoreSettingsService storeSettingsService;
    private final SupplierPaymentService supplierPaymentService;
    /** Applies the bill's branch document prefix and supplies the branch header for printed copies. */
    private final com.posapp.branch.BranchService branchService;

    public BillService(BillRepository billRepository,
                        PurchaseOrderService purchaseOrderService,
                        CatalogService catalogService,
                        AuditLogService auditLogService,
                        DocumentPdfService documentPdfService,
                        StoreSettingsService storeSettingsService,
                        SupplierPaymentService supplierPaymentService,
                        com.posapp.branch.BranchService branchService) {
        this.billRepository = billRepository;
        this.purchaseOrderService = purchaseOrderService;
        this.catalogService = catalogService;
        this.auditLogService = auditLogService;
        this.documentPdfService = documentPdfService;
        this.storeSettingsService = storeSettingsService;
        this.supplierPaymentService = supplierPaymentService;
        this.branchService = branchService;
    }

    private com.posapp.branch.dto.BranchReceiptInfo branchInfo(Bill bill) {
        return bill.getBranchId() != null ? branchService.receiptInfo(bill.getBranchId()) : null;
    }

    private BillDto toDto(Bill bill) {
        return BillDto.from(bill, supplierPaymentService.amountPaidForBill(bill), supplierPaymentService.outstandingForBill(bill),
                subtotalAmount(bill), taxAmount(bill), discountAmount(bill));
    }

    private static BigDecimal lineTax(BillLine line) {
        return TaxMath.taxOnAmount(line.getLineTotal(), line.getTaxRatePercent(), Boolean.TRUE.equals(line.getTaxInclusive()));
    }

    private static BigDecimal lineNet(BillLine line) {
        return TaxMath.netOfTax(line.getLineTotal(), lineTax(line), Boolean.TRUE.equals(line.getTaxInclusive()));
    }

    /** Fourier: "Same for discount ... it will be per line" — derived from (unitCost * quantity - lineTotal), since the pre-discount gross is never itself persisted. */
    private static BigDecimal lineDiscountAmount(BillLine line) {
        BigDecimal grossBeforeDiscount = line.getUnitCost().multiply(BigDecimal.valueOf(line.getQuantity())).setScale(2, RoundingMode.HALF_UP);
        return grossBeforeDiscount.subtract(line.getLineTotal()).setScale(2, RoundingMode.HALF_UP);
    }

    /** Sum of every line's own discount, purely informational (already folded into subtotalAmount/totalAmount, via lineTotal). Zero whenever the feature is off or no line has one. */
    public static BigDecimal discountAmount(Bill bill) {
        BigDecimal total = BigDecimal.ZERO;
        for (BillLine line : bill.getLines()) {
            total = total.add(lineDiscountAmount(line));
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    /** Sum of every line's pre-tax (net) contribution — computed live from the (frozen, post-issue) lines rather than its own persisted column, same as every other per-document total in this app. */
    public static BigDecimal subtotalAmount(Bill bill) {
        BigDecimal total = BigDecimal.ZERO;
        for (BillLine line : bill.getLines()) {
            total = total.add(lineNet(line));
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    /** Sum of every line's own tax — zero when no line has a tax rate assigned (see BillLine.taxRatePercent's javadoc). */
    public static BigDecimal taxAmount(Bill bill) {
        BigDecimal total = BigDecimal.ZERO;
        for (BillLine line : bill.getLines()) {
            total = total.add(lineTax(line));
        }
        return total.setScale(2, RoundingMode.HALF_UP);
    }

    /** Fourier: "same workflow as Sale order" — {@code supplierId} narrows this to one supplier's own bills, newest first; null (the store-wide Bills screen) returns everything. */
    @Transactional(readOnly = true)
    public List<BillDto> listAll(Long supplierId) {
        List<Bill> bills = billRepository.findAllByOrderByBillDateDesc();
        if (supplierId != null) {
            bills = bills.stream().filter(b -> supplierId.equals(b.getSupplierId())).toList();
        }
        return bills.stream().map(this::toDto).toList();
    }

    @Transactional(readOnly = true)
    public BillDto getById(Long id) {
        return toDto(getEntityOrThrow(id));
    }

    /** Null (not a 404) when no bill has ever been generated for this order — lets the Purchase Order detail screen tell "none yet" apart from "look it up and something went wrong." */
    @Transactional(readOnly = true)
    public BillDto getByPurchaseOrderIdOrNull(Long purchaseOrderId) {
        return billRepository.findByPurchaseOrderId(purchaseOrderId).map(this::toDto).orElse(null);
    }

    /**
     * Deliberate, explicit action from the Purchase Order's own "Generate bill" button — an
     * already-{@code ISSUED} snapshot, available from {@code SENT} onward (same floor as {@code
     * InvoiceService.generate}'s own DRAFT/CANCELLED guard — a bill can be raised the moment an
     * order is actually placed with the supplier, even before anything has arrived). Contrast
     * {@link #generateDraftFromPurchaseOrder} below, which builds the exact same snapshot but
     * starts it as {@code DRAFT} instead, for the automatic on-receipt path.
     */
    @Transactional
    public BillDto generate(Long purchaseOrderId) {
        Bill saved = buildFromPurchaseOrder(purchaseOrderId, BillStatus.ISSUED);
        auditLogService.record("BILL_GENERATED",
                "Generated bill " + saved.getBillNumber() + " for purchase order " + saved.getPurchaseOrderNumber()
                        + " (" + saved.getTotalAmount() + ")",
                "Bill", saved.getId());
        return toDto(saved);
    }

    /**
     * Fourier: "same workflow as Sale order" — the automatic-on-full-receipt mirror of {@code
     * InvoiceService.generateDraftFromSalesOrder}: the exact same snapshot {@link #generate}
     * builds, just left as {@code DRAFT} rather than immediately {@code ISSUED}, since nobody
     * explicitly asked for this one — it's a side effect of the order's own {@code
     * PurchaseOrderStatus} reaching {@code RECEIVED}, not a deliberate "bill this now" click, so
     * an admin gets a chance to review it and issue it themselves when ready. Called from {@code
     * PurchaseOrderController.receive} right after a receiving call brings the order to {@code
     * RECEIVED}, guarded there so it only ever runs once per order — same "wired in at the
     * controller layer to avoid a circular bean dependency" reasoning {@code
     * SalesOrderController.fulfill}'s own javadoc documents.
     */
    @Transactional
    public BillDto generateDraftFromPurchaseOrder(Long purchaseOrderId) {
        Bill saved = buildFromPurchaseOrder(purchaseOrderId, BillStatus.DRAFT);
        auditLogService.record("BILL_DRAFT_CREATED",
                "Automatically created draft bill " + saved.getBillNumber() + " for purchase order "
                        + saved.getPurchaseOrderNumber() + " now that it is fully received (" + saved.getTotalAmount() + ")",
                "Bill", saved.getId());
        return toDto(saved);
    }

    /**
     * Refused for a DRAFT or CANCELLED Purchase Order (nothing's actually been committed to the
     * supplier yet, or the commitment was undone) and refused a second time for any order that
     * already has one, since this app only ever bills one Purchase Order once (see {@code Bill}'s
     * class javadoc) — shared by {@link #generate} and {@link #generateDraftFromPurchaseOrder},
     * which differ only in the {@code status} they hand in.
     */
    private Bill buildFromPurchaseOrder(Long purchaseOrderId, BillStatus status) {
        PurchaseOrderDto po = purchaseOrderService.getById(purchaseOrderId);
        if ("DRAFT".equals(po.status()) || "CANCELLED".equals(po.status())) {
            throw ApiException.badRequest("Cannot bill purchase order " + po.orderNumber() + " — it is " + po.status()
                    + ". Send it to the supplier first.");
        }
        if (billRepository.findByPurchaseOrderId(purchaseOrderId).isPresent()) {
            throw ApiException.badRequest("Purchase order " + po.orderNumber() + " already has a bill.");
        }

        Bill bill = new Bill();
        // Own "BILL-" prefix — see Bill's class javadoc for why this never collides with
        // PurchaseOrder's "PO-".
        bill.setBranchId(po.branchId());
        bill.setBillNumber(branchService.prefixedNumber(bill.getBranchId(), "BILL-" + System.currentTimeMillis()));
        bill.setStatus(status);
        bill.setPurchaseOrderId(po.id());
        bill.setPurchaseOrderNumber(po.orderNumber());
        bill.setSupplierId(po.supplierId());
        bill.setSupplierName(po.supplierName());
        bill.setNotes(po.notes());
        // Fourier: "Except POS other module can have global discount ... Either on line or
        // global" — carried straight through from the Purchase Order this was generated from,
        // same "freeze what was actually ordered" reasoning as every other snapshot field here;
        // already validated once when the order was created/edited.
        bill.setDiscountPercent(po.discountPercent());
        // Fourier: "Global discount should be a fixed amount or percentage with percentage as
        // the default" — likewise carried straight through, so this bill shows back how the
        // Purchase Order's own discount was actually entered.
        bill.setDiscountType(GlobalDiscountType.parse(po.discountType()));
        bill.setDiscountFixedAmount(po.discountFixedAmount());

        for (PurchaseOrderLineDto lineDto : po.lines()) {
            BillLine line = new BillLine();
            line.setBill(bill);
            if (lineDto.productId() != null) {
                Product product = catalogService.getProductOrThrow(lineDto.productId());
                line.setProduct(product);
            }
            line.setProductName(lineDto.productName());
            line.setQuantity(lineDto.quantityOrdered());
            line.setUnitCost(lineDto.unitCost());
            // Fourier: "Same for discount ... it will be per line" — carried straight through
            // from the Purchase Order line this was generated from, same "freeze what was
            // actually ordered" reasoning as taxCode/taxRatePercent just below; already
            // validated once when that line was created/edited.
            line.setDiscountPercent(lineDto.discountPercent());
            BigDecimal grossBeforeDiscount = lineDto.unitCost().multiply(BigDecimal.valueOf(lineDto.quantityOrdered())).setScale(2, RoundingMode.HALF_UP);
            BigDecimal lineTotal = TaxMath.applyDiscount(grossBeforeDiscount, lineDto.discountPercent());
            line.setLineTotal(lineTotal);
            // Fourier: "for purchases, sales, invoices, bills the tax are not being captured" —
            // carried straight through from the Purchase Order line this was generated from, not
            // re-derived from the live product — same "freeze what was actually ordered"
            // reasoning as productName/unitCost just above.
            line.setTaxCode(lineDto.taxCode());
            line.setTaxRatePercent(lineDto.taxRatePercent());
            line.setTaxInclusive(lineDto.taxInclusive());
            bill.getLines().add(line);
        }
        // Fourier: "for purchases, sales, invoices, bills the tax are not being captured" — now
        // tax-inclusive; previously just the sum of every line's gross lineTotal.
        bill.setTotalAmount(subtotalAmount(bill).add(taxAmount(bill)).setScale(2, RoundingMode.HALF_UP));

        return billRepository.save(bill);
    }

    /** DRAFT -&gt; ISSUED: the moment an auto-generated draft bill becomes a real, numbered, payable document. */
    @Transactional
    public BillDto issue(Long id) {
        Bill bill = getEntityOrThrow(id);
        if (bill.getStatus() != BillStatus.DRAFT) {
            throw ApiException.badRequest("Only a draft bill can be issued — " + bill.getBillNumber() + " is " + bill.getStatus());
        }
        bill.setStatus(BillStatus.ISSUED);
        bill.setBillDate(java.time.Instant.now());
        Bill saved = billRepository.save(bill);
        auditLogService.record("BILL_ISSUED",
                "Issued bill " + saved.getBillNumber() + " for " + saved.getSupplierName() + " (" + saved.getTotalAmount() + ")",
                "Bill", saved.getId());
        return toDto(saved);
    }

    /** A DRAFT was never a real document — deleting it is fine, same as {@code InvoiceService.deleteDraft}. */
    @Transactional
    public void deleteDraft(Long id) {
        Bill bill = getEntityOrThrow(id);
        if (bill.getStatus() != BillStatus.DRAFT) {
            throw ApiException.badRequest("Only a draft bill can be deleted — " + bill.getBillNumber() + " is " + bill.getStatus());
        }
        billRepository.delete(bill);
        auditLogService.record("BILL_DRAFT_DELETED", "Deleted draft bill " + bill.getBillNumber(), "Bill", bill.getId());
    }

    /**
     * ISSUED -&gt; VOID: marks this document invalid — e.g. to correct a mistake. Refused once any
     * payment has been recorded against it (see {@code SupplierPaymentService.outstandingForBill});
     * a bill that's already been paid is cancelled via a Purchase Return instead (processed
     * against the underlying Purchase Order) — see {@code Bill}'s own class javadoc for why this
     * entity, unlike {@code Invoice}, has no separate "cancel a paid one" path of its own.
     *
     * <p>Fourier: "Refunds equivalent with Credit note" — every void now also stamps {@link
     * Bill#refundNumber}, this document's own identifier as a refund (see that field's javadoc);
     * this is what makes it show up on the new Refunds screen ({@link #listRefunds}) and printable
     * there ({@link #refundPdf}).
     */
    @Transactional
    public BillDto voidBill(Long id, String reason) {
        Bill bill = getEntityOrThrow(id);
        if (bill.getStatus() != BillStatus.ISSUED) {
            throw ApiException.badRequest("Bill " + bill.getBillNumber() + " is already " + bill.getStatus());
        }
        if (supplierPaymentService.amountPaidForBill(bill).compareTo(BigDecimal.ZERO) > 0) {
            throw ApiException.badRequest("Cannot void bill " + bill.getBillNumber() + " — it already has a payment recorded against it. "
                    + "Process a purchase return against " + bill.getPurchaseOrderNumber() + " instead.");
        }
        bill.setStatus(BillStatus.VOID);
        bill.setVoidedAt(java.time.Instant.now());
        bill.setVoidReason(reason);
        // Own "REF-" prefix — see Bill.refundNumber's javadoc.
        bill.setRefundNumber(branchService.prefixedNumber(bill.getBranchId(), "REF-" + System.currentTimeMillis()));
        Bill saved = billRepository.save(bill);
        auditLogService.record("BILL_VOIDED", "Voided bill " + saved.getBillNumber() + " — refund " + saved.getRefundNumber(), "Bill", saved.getId());
        return toDto(saved);
    }

    /** Fourier: "Refunds equivalent with Credit note" — every voided bill, store-wide, newest-voided first; backs the new Refunds list screen. */
    @Transactional(readOnly = true)
    public List<BillDto> listRefunds() {
        return billRepository.findByStatusOrderByVoidedAtDesc(BillStatus.VOID).stream()
                .map(this::toDto)
                .toList();
    }

    /** The Refund's own printable PDF — same A4 shape {@link #pdf} already builds for the bill itself, just headed "Refund." Refused for anything but a VOID bill — there is no refund before that. */
    @Transactional(readOnly = true)
    public byte[] refundPdf(Long id) {
        Bill bill = getEntityOrThrow(id);
        if (bill.getStatus() != BillStatus.VOID) {
            throw ApiException.badRequest("Bill " + bill.getBillNumber() + " has no refund — it was never voided");
        }
        return documentPdfService.refundPdf(toDto(bill), storeSettingsService.getSettingsEntity(), branchInfo(bill));
    }

    /** The same A4 PDF the Purchase Order/Invoice detail screens' own "Print" buttons open, at any status. */
    @Transactional(readOnly = true)
    public byte[] pdf(Long id) {
        Bill bill = getEntityOrThrow(id);
        return documentPdfService.billPdf(toDto(bill), storeSettingsService.getSettingsEntity(), branchInfo(bill));
    }

    /** Fourier: "Let record payment per invoice not per customer" mirrored on the purchasing side — thin pass-through to {@code SupplierPaymentService.recordBillPayment}. */
    @Transactional
    public SupplierPaymentDto recordPayment(Long id, RecordBillPaymentRequest request, AppUser caller) {
        return supplierPaymentService.recordBillPayment(id, request, caller);
    }

    /** This bill's own payment history — see {@code SupplierPaymentService.paymentHistoryForBill}'s javadoc. */
    @Transactional(readOnly = true)
    public List<SupplierPaymentDto> paymentHistory(Long id) {
        return supplierPaymentService.paymentHistoryForBill(id);
    }

    Bill getEntityOrThrow(Long id) {
        return billRepository.findById(id)
                .orElseThrow(() -> ApiException.notFound("Bill not found: " + id));
    }
}
